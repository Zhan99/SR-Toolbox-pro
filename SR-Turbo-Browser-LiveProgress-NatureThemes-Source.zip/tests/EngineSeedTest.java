package com.srcreation.browser;
import java.io.*;
import java.nio.file.*;
import java.util.Arrays;
public class EngineSeedTest {
    static void check(boolean b){if(!b)throw new AssertionError();}
    public static void main(String[] args)throws Exception{
        Path dir=Files.createTempDirectory("sr-seed-test");
        File target=dir.resolve("engine").toFile(), sample=dir.resolve("sample").toFile();
        byte[] good="new verified engine".getBytes(), old="old engine".getBytes();
        try{
            Files.write(sample.toPath(),good);String hash=EngineSeed.hash(sample);
            Files.write(target.toPath(),old);
            check(EngineSeed.install(target,()->new ByteArrayInputStream(good),hash,false));
            check(Arrays.equals(Files.readAllBytes(target.toPath()),good));
            check(!EngineSeed.install(target,()->{throw new IOException("should not read");},hash,false));
            check(EngineSeed.install(target,()->new ByteArrayInputStream(good),hash,true));
            try{EngineSeed.install(target,()->new ByteArrayInputStream(old),hash,true);throw new AssertionError();}catch(IOException expected){}
            check(Arrays.equals(Files.readAllBytes(target.toPath()),good));
            try{EngineSeed.install(target,()->{throw new IOException("read error");},hash,true);throw new AssertionError();}catch(IOException expected){}
            check(Arrays.equals(Files.readAllBytes(target.toPath()),good));
            Files.delete(target.toPath());check(EngineSeed.install(target,()->new ByteArrayInputStream(good),hash,false));
            check(dir.toFile().list().length==2);
            System.out.println("Verified engine seed: replacement, reuse, forced repair, checksum rejection, failure preservation, missing engine and cleanup passed");
        }finally{for(File f:dir.toFile().listFiles())f.delete();Files.delete(dir);}
    }
}
