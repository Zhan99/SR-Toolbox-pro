package com.srcreation.browser;
public class VideoLinksTest {
    static void eq(String expected,String actual){if(!java.util.Objects.equals(expected,actual))throw new AssertionError(expected+" != "+actual);}
    public static void main(String[] args){
        eq("video/mp4",VideoLinks.mime("https://cdn.example/file.MP4?token=abc",null,false));
        eq("video/webm",VideoLinks.mime("https://cdn.example/a.webm",null,true));
        eq("video/mp4",VideoLinks.mime("https://cdn.example/media?id=1","video/mp4; charset=utf-8",true));
        eq("application/octet-stream",VideoLinks.mime("https://cdn.example/media",null,true));
        eq(null,VideoLinks.mime("https://cdn.example/media",null,false));
        eq(null,VideoLinks.mime("blob:https://example.com/1","video/mp4",true));
        eq(null,VideoLinks.mime("https://cdn.example/live.m3u8","video/mp4",true));
        eq(null,VideoLinks.mime("https://cdn.example/manifest","application/dash+xml",true));
        eq(null,VideoLinks.mime("https://cdn.example/part.m4s",null,true));
        eq(null,VideoLinks.mime("https://user:pass@example.com/a.mp4",null,true));
        eq(null,VideoLinks.mime("https://cdn.example/page","text/html",true));
        System.out.println("Video link validation passed");
        if(args.length>0)System.out.print(VideoLinks.SCAN);
    }
}
