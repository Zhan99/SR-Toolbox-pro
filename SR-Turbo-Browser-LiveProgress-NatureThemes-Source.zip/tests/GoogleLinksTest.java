package com.srcreation.browser;
public class GoogleLinksTest {
    static void check(boolean b){if(!b)throw new AssertionError();}
    public static void main(String[] args){
        check(GoogleLinks.isAccountSite(GoogleLinks.GMAIL));check(GoogleLinks.isAccountSite(GoogleLinks.CHOOSE));check(GoogleLinks.isAccountSite(GoogleLinks.ADD));check(GoogleLinks.isAccountSite(GoogleLinks.MANAGE));
        check(GoogleLinks.isOAuth("https://accounts.google.com/o/oauth2/v2/auth?client_id=abc"));check(!GoogleLinks.isOAuth(GoogleLinks.CHOOSE));
        for(String url:new String[]{"https://accounts.google.com.evil.test/","https://evil.test/?accounts.google.com","https://accounts.google.com@evil.test/","https://evil.test@accounts.google.com/","http://accounts.google.com/","javascript:alert(1)","https://www.google.com/", "bad url"})check(!GoogleLinks.isAccountSite(url));
        check(GoogleLinks.isSignInPage(GoogleLinks.CHOOSE));check(GoogleLinks.isSignInPage(GoogleLinks.ADD));check(!GoogleLinks.isSignInPage(GoogleLinks.GMAIL));check(!GoogleLinks.isSignInPage("https://accounts.google.com.evil.test/"));
        System.out.println("Google account URL routing tests passed");
    }
}
