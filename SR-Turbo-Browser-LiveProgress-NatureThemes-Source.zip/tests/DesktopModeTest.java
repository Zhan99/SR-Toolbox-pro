package com.srcreation.browser;
public class DesktopModeTest {
    static void check(boolean condition,String detail){if(!condition)throw new AssertionError(detail);}
    public static void main(String[] args){
        String mobile="Mozilla/5.0 (Linux; Android 15; Pixel 9 Build/XYZ; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/145.0.7312.28 Mobile Safari/537.36";
        String desktop=DesktopMode.agent(mobile,true);
        check(desktop.contains("X11; Linux x86_64; wv"),"desktop platform with WebView marker");
        check(desktop.contains("Chrome/145.0.7312.28")&&!desktop.contains("Mobile")&&!desktop.contains("Android"),"real version; no mobile token");
        check(DesktopMode.agent(mobile,false).equals(mobile),"restore mobile identity");
        check(DesktopMode.agent("unknown",true).equals("unknown"),"unknown agent fallback");
        check(DesktopMode.effective(true,"https://example.com"),"ordinary URL");
        check(DesktopMode.effective(true,"about:blank"),"new tab inherits global mode");
        check(DesktopMode.effective(true,"https://www.google.com/search?q=hello"),"Google search desktop");
        check(!DesktopMode.effective(false,"https://example.com"),"global off");
        for(String url:new String[]{GoogleLinks.CHOOSE,GoogleLinks.GMAIL,GoogleLinks.MANAGE,GoogleLinks.ADD}){
            check(!DesktopMode.effective(true,url),"account identity exception");
            check(DesktopMode.label(true,false,url).contains("ACCOUNT EXCEPTION"),"exception visible");
        }
        check(DesktopMode.effective(true,"https://accounts.google.com.example.com/"),"exact account hostname only");
        check(DesktopMode.label(true,false,"https://example.com").contains("NEXT LOAD"),"pending desktop status");
        check(DesktopMode.label(false,true,"https://example.com").contains("NEXT LOAD"),"pending mobile status");
        check(DesktopMode.label(true,true,"https://example.com").equals("DESKTOP"),"active status");
        check(DesktopMode.label(false,false,"https://example.com").isEmpty(),"disabled status");
        check(DesktopMode.WIDE_VIEWPORT.contains("width=1280"),"wide viewport script");
        check(DesktopMode.useOverview(true,true),"original desktop auto fit enabled");
        check(!DesktopMode.useOverview(true,false),"desktop auto fit disabled");
        check(DesktopMode.useOverview(false,true)&&DesktopMode.useOverview(false,false),"mobile/account overview unchanged");
        DesktopMode.Profile original=DesktopMode.Profile.ORIGINAL, normal=DesktopMode.Profile.NORMAL, phone=DesktopMode.Profile.MOBILE;
        String page="https://example.com";
        check(DesktopMode.restore(null,true)==original,"migrate existing desktop");
        check(DesktopMode.restore(null,false)==phone,"migrate existing mobile");
        check(DesktopMode.restore("NORMAL",true)==normal,"persist normal desktop");
        check(DesktopMode.restore("bad",true)==original,"invalid preference fallback");
        for(DesktopMode.Profile profile:DesktopMode.Profile.values()){
            check(DesktopMode.restore(profile.name(),false)==profile,"round trip profile");
            check(DesktopMode.effective(profile,page)==profile,"ordinary page profile");
            check(DesktopMode.effective(profile,"about:blank")==profile,"new tab profile");
            check(DesktopMode.effective(profile,GoogleLinks.CHOOSE)==phone,"account exception");
        }
        check(DesktopMode.overview(original,true)&&!DesktopMode.overview(original,false),"preserve original zoom toggle");
        check(DesktopMode.overview(normal,true)&&DesktopMode.overview(normal,false),"normal desktop always fit");
        check(DesktopMode.pcViewport(360).contains("width=1280, initial-scale=0.2813"),"portrait fit");
        check(DesktopMode.pcViewport(800).contains("initial-scale=0.6250"),"landscape fit");
        check(DesktopMode.pcViewport(1500).contains("initial-scale=1.0000"),"large screen fit");
        check(DesktopMode.overview(phone,true)&&DesktopMode.overview(phone,false),"mobile overview unchanged");
        check(DesktopMode.forceWideViewport(original,false,page),"original wide viewport when zoom off");
        check(!DesktopMode.forceWideViewport(original,true,page),"original auto zoom no injection");
        check(!DesktopMode.forceWideViewport(normal,false,page)&&!DesktopMode.forceWideViewport(phone,false,page),"no normal/mobile viewport injection");
        check(!DesktopMode.forceWideViewport(original,false,GoogleLinks.GMAIL),"no account viewport injection");
        check(DesktopMode.label(normal,original,false,true,page).contains("NEXT LOAD"),"mode pending even between desktop variants");
        check(DesktopMode.label(original,original,false,true,page).contains("NEXT LOAD"),"zoom pending");
        check(DesktopMode.label(normal,normal,true,true,page).equals("NORMAL DESKTOP"),"normal active label");
        check(DesktopMode.label(phone,phone,true,true,page).equals("MOBILE"),"mobile active label");
        check(DesktopMode.label(normal,phone,true,true,GoogleLinks.CHOOSE).contains("ACCOUNT EXCEPTION"),"normal account label");
        System.out.println("DesktopModeTest: all checks passed");
    }
}
