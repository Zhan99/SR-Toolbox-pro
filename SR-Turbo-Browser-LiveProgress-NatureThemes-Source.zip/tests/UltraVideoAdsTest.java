package com.srcreation.browser;
public class UltraVideoAdsTest {
    public static void main(String[] args){byte[] data=UltraVideoAds.script(true,true,true).getBytes(java.nio.charset.StandardCharsets.UTF_8);System.out.write(data,0,data.length);}
}
