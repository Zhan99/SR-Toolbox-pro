import com.sun.source.tree.*;
import com.sun.source.util.*;
import javax.tools.*;
import java.nio.file.*;
import java.util.*;

/** SDK-independent regression check for duplicate local declarations in nested Java scopes.
 * This is not a substitute for the Android javac step. */
public class LocalScopeCheck {
    public static void main(String[] args) throws Exception {
        var compiler = ToolProvider.getSystemJavaCompiler();
        var diagnostics = new DiagnosticCollector<JavaFileObject>();
        try (var fm = compiler.getStandardFileManager(diagnostics, null, null);
             var paths = Files.walk(Path.of(args[0]))) {
            var files = paths.filter(p -> p.toString().endsWith(".java")).map(Path::toFile).sorted().toList();
            var task = (JavacTask) compiler.getTask(null, fm, diagnostics, List.of("-proc:none"), null, fm.getJavaFileObjectsFromFiles(files));
            var trees = Trees.instance(task);
            int errors = 0;
            for (CompilationUnitTree unit : task.parse()) {
                var checker = new Checker(unit, trees);
                checker.scan(unit, null);
                errors += checker.errors;
            }
            for (var d : diagnostics.getDiagnostics()) if (d.getKind() == Diagnostic.Kind.ERROR) { System.err.println(d); errors++; }
            if (errors > 0) throw new AssertionError(errors + " Java syntax/scope errors");
            System.out.println("Java syntax and nested-local scope check passed: " + files.size() + " files");
        }
    }
    static final class Checker extends TreePathScanner<Void,Void> {
        final CompilationUnitTree unit; final Trees trees;
        Deque<Set<String>> scopes = new ArrayDeque<>(); int errors;
        Checker(CompilationUnitTree unit, Trees trees) { this.unit=unit; this.trees=trees; }
        Void scoped(java.util.function.Supplier<Void> action) {
            scopes.push(new HashSet<>());
            try { return action.get(); } finally { scopes.pop(); }
        }
        @Override public Void visitClass(ClassTree t, Void p) {
            var previous=scopes; scopes=new ArrayDeque<>();
            try { return super.visitClass(t,p); } finally { scopes=previous; }
        }
        @Override public Void visitMethod(MethodTree t, Void p) { return scoped(()->super.visitMethod(t,p)); }
        @Override public Void visitBlock(BlockTree t, Void p) { return scoped(()->super.visitBlock(t,p)); }
        @Override public Void visitLambdaExpression(LambdaExpressionTree t, Void p) { return scoped(()->super.visitLambdaExpression(t,p)); }
        @Override public Void visitForLoop(ForLoopTree t, Void p) { return scoped(()->super.visitForLoop(t,p)); }
        @Override public Void visitEnhancedForLoop(EnhancedForLoopTree t, Void p) { return scoped(()->super.visitEnhancedForLoop(t,p)); }
        @Override public Void visitCatch(CatchTree t, Void p) { return scoped(()->super.visitCatch(t,p)); }
        @Override public Void visitTry(TryTree t, Void p) {
            scoped(()->{scan(t.getResources(),p);scan(t.getBlock(),p);return null;});
            scan(t.getCatches(),p);scan(t.getFinallyBlock(),p);return null;
        }
        @Override public Void visitSwitch(SwitchTree t, Void p) { return scoped(()->super.visitSwitch(t,p)); }
        @Override public Void visitSwitchExpression(SwitchExpressionTree t, Void p) { return scoped(()->super.visitSwitchExpression(t,p)); }
        @Override public Void visitVariable(VariableTree t, Void p) {
            // Fields are legal to shadow. Method/block/lambda variables are not.
            if (!scopes.isEmpty() && !(getCurrentPath().getParentPath().getLeaf() instanceof ClassTree)) {
                String name=t.getName().toString();
                if(scopes.stream().anyMatch(s->s.contains(name))) {
                    long pos=trees.getSourcePositions().getStartPosition(unit,t);
                    System.err.println(unit.getSourceFile().getName()+":"+unit.getLineMap().getLineNumber(pos)+": duplicate local variable "+name);
                    errors++;
                }
                scopes.peek().add(name);
            }
            return super.visitVariable(t,p);
        }
    }
}
