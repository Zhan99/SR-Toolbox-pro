package com.srcreation.browser;

public final class HistoryTitlesTest {
    static void eq(String expected, String actual) {
        if (!expected.equals(actual)) throw new AssertionError(expected + " != " + actual);
    }
    public static void main(String[] args) {
        String url = "https://www.youtube.com/watch?v=example";
        eq("বাংলা গজল — YouTube", HistoryTitles.display("বাংলা গজল — YouTube", url));
        eq("Google Search", HistoryTitles.display(" Google Search ", "https://google.com"));
        eq("Untitled page", HistoryTitles.display(null, url));
        eq("Untitled page", HistoryTitles.display("", url));
        eq("Untitled page", HistoryTitles.display("   ", url));
        eq("Untitled page", HistoryTitles.display(url, url));
        eq("Untitled page", HistoryTitles.display("HTTPS://example.org/a", url));
        eq("Untitled page", HistoryTitles.display("www.example.org", url));
        eq("Untitled page", HistoryTitles.display("about:blank", url));
        eq("Untitled page", HistoryTitles.display("http://example.org", url));
        System.out.println("History titles: 10 checks passed");
    }
}
