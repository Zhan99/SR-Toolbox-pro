package com.srcreation.browser;
import java.time.LocalDate;
public class VideoEnginePolicyTest {
    public static void main(String[] args){
        LocalDate today=LocalDate.of(2026,11,26);long now=200000000L;
        test(VideoEnginePolicy.version("2025.11.12\n").equals("2025.11.12"));
        test(VideoEnginePolicy.version("garbage").isEmpty());
        test(VideoEnginePolicy.version("2026.02.30").isEmpty());
        test(VideoEnginePolicy.outdated("2025.11.12",today));
        test(!VideoEnginePolicy.outdated("2026.10.26",today));
        test(VideoEnginePolicy.needsCheck("2026.10.26",today,now,0));
        test(!VideoEnginePolicy.needsCheck("2026.10.26",today,now,now-1000));
        test(VideoEnginePolicy.needsCheck("2026.10.26",today,now,now-86400000L));
        test(VideoEnginePolicy.needsCheck("2026.10.26",today,now,now+1000));
        test(VideoEnginePolicy.forbidden("ERROR: HTTP Error 403: Forbidden"));
        test(VideoEnginePolicy.error("HTTP Error 403: Forbidden").contains("rejected"));
        System.out.println("Video engine policy: 11 checks passed");
    }
    static void test(boolean b){if(!b)throw new AssertionError();}
}
