from PIL import Image, ImageDraw, ImageFilter
import math, random, pathlib
out=pathlib.Path(__file__).resolve().parents[1] / 'app/src/main/res/drawable-nodpi'
out.mkdir(parents=True,exist_ok=True)
W,H=720,1200

def sky(top,bottom):
 im=Image.new('RGB',(W,H)); d=ImageDraw.Draw(im)
 for y in range(H):
  t=y/(H-1); d.line((0,y,W,y),fill=tuple(round(a+(b-a)*t) for a,b in zip(top,bottom)))
 return im

def glow(im,x,y,r,col):
 layer=Image.new('RGBA',im.size); d=ImageDraw.Draw(layer);d.ellipse((x-r,y-r,x+r,y+r),fill=(*col,155)); layer=layer.filter(ImageFilter.GaussianBlur(r*.48)); im.paste(layer,(0,0),layer)

def poly(d,pts,c): d.polygon([(int(x),int(y)) for x,y in pts],fill=c)
def ridge(d,seed,y,amp,c,step=55):
 rng=random.Random(seed); pts=[(x,y+rng.uniform(-amp,amp)) for x in range(-step,W+step*2,step)];poly(d,pts+[(W+step,H),(-step,H)],c)
def pines(d,seed,base,lo,hi,c,count):
 rng=random.Random(seed)
 for _ in range(count):
  x=rng.randrange(-30,W+30); h=rng.randrange(lo,hi); y=base+rng.randrange(-25,30); w=h*.25
  d.rectangle((x-2,y-h*.9,x+2,y),fill=c)
  for k in range(4):
   yy=y-h+k*h*.2; ww=w*(.4+k*.2);poly(d,[(x,yy),(x-ww,yy+h*.37),(x+ww,yy+h*.37)],c)
def save(im,name): im.save(out/f'theme_{name}.webp','WEBP',quality=86,method=6)
# Alpine
im=sky((47,83,139),(224,188,150));glow(im,540,350,110,(255,218,165));d=ImageDraw.Draw(im);d.ellipse((507,317,573,383),fill=(255,227,185));
poly(d,[(0,705),(0,605),(100,455),(178,512),(305,320),(420,505),(505,420),(720,620),(720,780)],(103,130,155))
poly(d,[(155,553),(305,320),(420,505),(370,465),(347,481),(305,423),(277,471),(249,455)],(225,236,237))
poly(d,[(0,710),(110,570),(215,646),(330,532),(444,665),(560,535),(720,695),(720,780),(0,780)],(55,85,109));
d.rectangle((0,750,W,H),fill=(41,82,104)); rng=random.Random(10)
for i in range(130):
 y=rng.randrange(755,H);x=rng.randrange(W);l=rng.randrange(12,110);d.line((x,y,min(W,x+l),y),fill=rng.choice([(62,103,121),(85,122,136),(107,142,150)]),width=1)
pines(d,5,780,60,140,(25,54,64),27);pines(d,6,1220,100,260,(19,40,49),19);save(im,'alpine')
# Forest
im=sky((26,66,65),(158,191,158));glow(im,460,425,140,(214,224,167));d=ImageDraw.Draw(im)
for k,(y,c) in enumerate([(675,(96,142,122)),(800,(57,111,92)),(940,(34,82,68)),(1220,(15,49,43))]):
 ridge(d,20+k,y,45,c);pines(d,30+k,y+50,100+k*27,230+k*50,c,45)
save(im,'forest')
# Ocean
im=sky((38,102,150),(200,239,220));glow(im,550,430,110,(255,245,187));d=ImageDraw.Draw(im);d.ellipse((517,397,583,463),fill=(255,241,195));d.rectangle((0,680,W,H),fill=(34,132,150));
rng=random.Random(4)
for y in range(680,H):
 t=(y-680)/(H-680);d.line((0,y,W,y),fill=(round(29+41*t),round(111+71*t),round(145+25*t)))
for i in range(160):
 y=rng.randrange(682,H);x=rng.randrange(W);d.line((x,y,x+rng.randrange(12,94),y),fill=rng.choice([(80,184,185),(113,205,198),(170,225,208)]),width=1)
poly(d,[(0,980),(130,1030),(320,1050),(520,1130),(720,1150),(720,H),(0,H)],(225,201,150));poly(d,[(0,960),(150,1020),(320,1040),(530,1117),(720,1140),(720,1153),(520,1134),(320,1054),(130,1034),(0,984)],(225,247,227));
# silhouette palms
for x,y,h in [(65,1080,315),(695,1160,245)]:
 d.line((x,y,x+35,y-h),fill=(22,65,64),width=14)
 xx=x+35;yy=y-h
 for a in [-3,-2.5,-2,-1.2,-.5,.15,.6]:
  ex=xx+math.cos(a)*110;ey=yy+math.sin(a)*70;poly(d,[(xx,yy),(xx+(ex-xx)*.55,yy+(ey-yy)*.55-16),(ex,ey+30),(xx+(ex-xx)*.5,yy+(ey-yy)*.5+13)],(22,65,64))
save(im,'ocean')
# Sunset
im=sky((73,53,111),(251,154,99));glow(im,500,550,180,(255,184,105));d=ImageDraw.Draw(im);d.ellipse((420,470,580,630),fill=(255,213,147))
for k,(y,c) in enumerate([(700,(167,91,104)),(815,(135,70,91)),(955,(100,55,76)),(1090,(68,39,64))]):
 pts=[(x,y+math.sin(x/150+k*1.4)*65+math.sin(x/240+k)*25) for x in range(-10,W+12,8)];poly(d,pts+[(W,H),(0,H)],c)
save(im,'sunset')
# Aurora
im=sky((11,20,56),(66,91,129));rng=random.Random(15);d=ImageDraw.Draw(im)
for _ in range(210):
 x,y=rng.randrange(W),rng.randrange(0,730);r=rng.choice([1,1,1,2]);d.ellipse((x,y,x+r,y+r),fill=rng.choice([(159,182,212),(220,235,251),(129,158,191)]))
lay=Image.new('RGBA',im.size);ld=ImageDraw.Draw(lay)
for k in range(7):
 pts=[(x,340+math.sin(x/150+k*.16)*95+math.sin(x/75)*27+k*14) for x in range(-20,W+30,5)];ld.line(pts,fill=(68,230,163,110-k*10),width=30+k*6)
lay=lay.filter(ImageFilter.GaussianBlur(17));im.paste(lay,(0,0),lay);d=ImageDraw.Draw(im)
ridge(d,3,820,130,(35,48,83),80);ridge(d,9,965,100,(22,32,62),90);pines(d,19,1220,120,270,(13,22,45),33);save(im,'aurora')
# Blossom
im=sky((137,121,171),(255,212,211));glow(im,520,470,140,(255,223,201));d=ImageDraw.Draw(im);d.ellipse((463,413,577,527),fill=(255,232,214));ridge(d,19,740,70,(169,136,171),80);ridge(d,6,865,60,(124,111,147),90);ridge(d,7,1070,70,(82,86,118),90)
rng=random.Random(35)
for side in [0,1]:
 x=0 if side==0 else W; direction=1 if side==0 else -1
 for i in range(8):
  yy=170+i*85; ex=x+direction*rng.randrange(100,245);ey=yy-rng.randrange(30,100);d.line((x,yy,ex,ey),fill=(91,60,87),width=6)
  for j in range(35):
   t=rng.random();px=x+(ex-x)*t+rng.gauss(0,29);py=yy+(ey-yy)*t+rng.gauss(0,25);r=rng.randrange(4,13);d.ellipse((px-r,py-r,px+r,py+r),fill=rng.choice([(244,166,190),(255,197,210),(255,222,228),(216,132,170)]))
for i in range(45):
 x,y=rng.randrange(W),rng.randrange(450,H);d.ellipse((x,y,x+5,y+8),fill=(236,176,202))
save(im,'blossom')
# Crystal Falls: a misty ravine with a layered cascade and pools.
im=sky((64,127,140),(219,235,190));glow(im,380,300,155,(255,245,192));d=ImageDraw.Draw(im)
for k,(y,c) in enumerate([(510,(103,155,147)),(640,(68,121,109)),(780,(35,89,77))]):ridge(d,91+k,y,80,c)
poly(d,[(0,420),(130,460),(245,590),(290,840),(240,1200),(0,1200)],(37,81,66));poly(d,[(720,430),(575,495),(480,590),(440,820),(520,1200),(720,1200)],(32,72,65))
poly(d,[(305,535),(390,535),(410,750),(390,845),(460,980),(210,980),(310,845),(330,750)],(177,224,222))
poly(d,[(334,535),(370,535),(381,755),(355,855),(415,980),(268,980),(338,850),(352,750)],(231,246,234));d.ellipse((130,895,595,1190),fill=(70,151,153));d.ellipse((212,925,500,1030),fill=(148,214,205))
rng=random.Random(92)
for i in range(150):
 y=rng.randrange(960,1200);x=rng.randrange(145,575);l=rng.randrange(8,65);d.line((x,y,min(605,x+l),y),fill=rng.choice([(100,180,176),(124,192,185),(168,221,206)]),width=1)
pines(d,93,810,70,190,(25,74,59),26);pines(d,94,1230,80,270,(18,61,52),25);save(im,'waterfall')
# Wildflower Meadow
im=sky((109,179,211),(255,233,178));glow(im,505,320,165,(255,245,195));d=ImageDraw.Draw(im);d.ellipse((479,294,531,346),fill=(255,250,211));
for seed,y,amp,c in [(110,600,65,(130,166,111)),(111,720,55,(104,149,83)),(112,825,70,(73,128,67)),(113,960,65,(49,107,57))]:ridge(d,seed,y,amp,c,90)
rng=random.Random(114)
for _ in range(360):
 x=rng.randrange(W);y=rng.randrange(820,H);z=(y-790)/410;h=int(rng.randrange(7,29)*z+3);r=max(1,int(rng.randrange(3,8)*z));col=rng.choice([(255,224,112),(247,183,201),(242,240,221),(180,173,240)]);d.line((x,y,x+2,y-h),fill=(68,126,58),width=max(1,int(z*2)))
 for a in range(5):
  xx=x+2+math.cos(a*2*math.pi/5)*r;yy=y-h+math.sin(a*2*math.pi/5)*r;d.ellipse((xx-r*.6,yy-r*.6,xx+r*.6,yy+r*.6),fill=col)
 d.ellipse((x+2-r*.4,y-h-r*.4,x+2+r*.4,y-h+r*.4),fill=(234,180,62))
save(im,'meadow')
# River Serenity: winding river between blue mountain layers.
im=sky((99,153,187),(228,225,192));glow(im,200,360,160,(255,235,187));d=ImageDraw.Draw(im)
for k,(y,amp,c) in enumerate([(580,110,(112,151,167)),(680,115,(78,125,144)),(805,75,(52,101,116))]):ridge(d,124+k,y,amp,c,70)
poly(d,[(0,820),(180,747),(365,793),(530,748),(720,805),(720,H),(0,H)],(67,117,100));poly(d,[(365,750),(400,757),(430,815),(347,875),(290,930),(410,1005),(720,1090),(720,1200),(310,1200),(170,1040),(190,950),(315,866),(385,814)],(130,190,198));poly(d,[(384,758),(398,768),(412,815),(333,876),(266,938),(230,1000),(300,1100),(435,1200),(310,1200),(170,1040),(190,950),(315,866),(385,814)],(92,155,177));pines(d,129,900,45,100,(33,80,76),30);pines(d,130,1230,60,220,(22,65,67),17);save(im,'river')
# Moonlit Lake
im=sky((13,24,57),(108,127,167));glow(im,490,335,150,(202,224,255));d=ImageDraw.Draw(im);d.ellipse((447,292,533,378),fill=(225,237,255));rng=random.Random(133)
for _ in range(140):
 x=rng.randrange(W);y=rng.randrange(20,560);r=rng.choice([1,1,1,2]);d.ellipse((x-r,y-r,x+r,y+r),fill=rng.choice([(183,202,226),(224,232,252),(143,167,213)]))
for k,(y,c) in enumerate([(650,(66,84,123)),(740,(36,61,91))]):ridge(d,134+k,y,95,c)
d.rectangle((0,760,W,H),fill=(29,58,86));rng=random.Random(138)
for _ in range(180):
 y=rng.randrange(766,H);x=rng.randrange(W);l=rng.randrange(8,90);c=(99,133,169) if abs(x-490)<55+(y-760)*.15 else (49,82,112);d.line((x,y,min(W,x+l),y),fill=c,width=1)
pines(d,139,780,70,170,(18,41,65),25);pines(d,140,1230,90,250,(15,33,55),19);save(im,'moonlake')
