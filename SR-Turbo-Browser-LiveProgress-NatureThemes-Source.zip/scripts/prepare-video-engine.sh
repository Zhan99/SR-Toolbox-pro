#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
version=2026.11.23
hash=e8665ed64d6b9172773e812f891fb707a0cb1ee8d9ef4fc1acb00cabee4c5256
out=app/src/main/assets/sr-yt-dlp
mkdir -p "$(dirname "$out")"
if [[ -f "$out" ]] && printf '%s  %s\n' "$hash" "$out" | sha256sum -c -; then exit 0; fi
tmp=$(mktemp)
trap 'rm -f "$tmp"' EXIT
curl --fail --location --proto '=https' --proto-redir '=https' --connect-timeout 30 --max-time 180 --retry 3 --retry-delay 2 --output "$tmp" "https://github.com/yt-dlp/yt-dlp/releases/download/$version/yt-dlp"
printf '%s  %s\n' "$hash" "$tmp" | sha256sum -c -
actual=$(python3 "$tmp" --ignore-config --version)
[[ "$actual" == "$version" ]] || { echo "Unexpected engine version: $actual" >&2; exit 1; }
python3 - "$tmp" <<'PY'
import sys, zipfile
with zipfile.ZipFile(sys.argv[1]) as z:
    assert any(n.startswith('yt_dlp_ejs/') for n in z.namelist()), 'Bundled EJS scripts missing'
PY
mv "$tmp" "$out"
echo "Verified yt-dlp $version with bundled EJS"
