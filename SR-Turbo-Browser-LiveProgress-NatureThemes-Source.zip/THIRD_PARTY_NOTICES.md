# Third-party components

The new downloader uses the following externally resolved dependencies, not copied library binaries in this source archive:

- youtubedl-android library and FFmpeg wrapper 0.18.1 — GPL-3.0 as published at Maven Central; corresponding project source: https://github.com/yausername/youtubedl-android/tree/0.18.1
- yt-dlp — upstream source and license details: https://github.com/yt-dlp/yt-dlp
- FFmpeg — upstream source and licensing details: https://ffmpeg.org/legal.html ; exact build and configuration are provided by the wrapper upstream.

`COPYING-GPL-3.0.txt` reproduces the GPL v3 license text. Before distributing a compiled APK, review the exact bundled versions, their complete notices, and applicable GPL/source-offer obligations for the combined work and any other bundled components. These notices are not a substitute for compliance. The app is not affiliated with YouTube or Google.

- Optional runtime host list: AdAway, https://github.com/AdAway/adaway.github.io/blob/master/hosts.txt (CC Attribution 3.0 per source header). Downloaded separately by the app; the original header is retained in the cached list. No third-party host-list copy is bundled in this source archive.
