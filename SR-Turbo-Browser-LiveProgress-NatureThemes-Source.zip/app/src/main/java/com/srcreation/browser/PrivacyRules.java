package com.srcreation.browser;
import java.net.URI;
import java.util.Locale;
final class PrivacyRules {
    static final String[] LABELS={"Last hour","Last 24 hours","Last 7 days","Last 30 days","All time"};
    private static final long[] WINDOWS={3600000L,86400000L,604800000L,2592000000L};
    static boolean inRange(long at,long now,int range){if(range==4)return true;if(range<0||range>=WINDOWS.length)return false;return at>0&&at<=now&&at>=now-WINDOWS[range];}
    static String webUrl(String input){String s=input.trim();if(s.isEmpty()||s.length()>4096)return null;if(!s.matches("(?i)^https?://.*")){if(s.contains("://")||s.matches("(?i)^(javascript|data|file|content|intent|mailto|tel):.*"))return null;s="https://"+s;}try{URI u=new URI(s);if(u.getHost()==null||u.getRawUserInfo()!=null||u.getPort()>65535)return null;String scheme=u.getScheme().toLowerCase(Locale.ROOT);if(!scheme.equals("http")&&!scheme.equals("https"))return null;return scheme+s.substring(s.indexOf(':'));}catch(Exception e){return null;}}
}
