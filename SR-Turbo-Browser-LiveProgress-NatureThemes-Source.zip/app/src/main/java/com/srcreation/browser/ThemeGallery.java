package com.srcreation.browser;

import android.app.Dialog;
import android.graphics.Color;
import android.view.*;
import android.widget.*;

/** Offline previews and immediate application without recreating any WebView. */
final class ThemeGallery {
    static int art(BrowserTheme theme){switch(theme){
        case ALPINE:return R.drawable.theme_alpine;
        case FOREST:return R.drawable.theme_forest;
        case OCEAN:return R.drawable.theme_ocean;
        case SUNSET:return R.drawable.theme_sunset;
        case AURORA:return R.drawable.theme_aurora;
        case BLOSSOM:return R.drawable.theme_blossom;
        case WATERFALL:return R.drawable.theme_waterfall;
        case MEADOW:return R.drawable.theme_meadow;
        case RIVER:return R.drawable.theme_river;
        case MOONLAKE:return R.drawable.theme_moonlake;
        default:return 0;
    }}
    static void show(BrowserActivity a){
        if(a.privateMode())return;
        Dialog dialog=new Dialog(a);dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout panel=Ui.column(a);Ui.pad(panel,a,16);panel.setBackground(Ui.bg(a.paper(),24,a));
        LinearLayout header=Ui.row(a);LinearLayout title=Ui.column(a);title.addView(Ui.text(a,"Theme gallery",23,a.fg(),true));title.addView(Ui.text(a,"SR TURBO  /  PERSONALIZE",11,a.accent(),true));header.addView(title,new LinearLayout.LayoutParams(0,-2,1));header.addView(Ui.button(a,"×",a.fg(),a.card(),dialog::dismiss));panel.addView(header);
        panel.addView(Ui.text(a,"Choose a look. Scenery is stored offline and appears behind Quick Access.",13,a.muted(),false));
        LinearLayout setting=Ui.row(a);Ui.pad(setting,a,8);TextView label=Ui.text(a,"Home screen scenery",14,a.fg(),true);setting.addView(label,new LinearLayout.LayoutParams(0,-2,1));Switch toggle=new Switch(a);toggle.setChecked(a.scenery);toggle.setContentDescription("Show home screen scenery");setting.addView(toggle);panel.addView(setting);
        toggle.setOnCheckedChangeListener((v,on)->{a.scenery=on;a.pref("theme_scenery",on);a.refreshTheme();});
        ScrollView scroll=new ScrollView(a);LinearLayout grid=Ui.column(a);scroll.addView(grid);panel.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        BrowserTheme[] options=BrowserTheme.values();int columns=a.getResources().getConfiguration().screenWidthDp<350?1:2;
        for(int i=0;i<options.length;i+=columns){LinearLayout row=Ui.row(a);row.setGravity(Gravity.TOP);for(int j=i;j<Math.min(options.length,i+columns);j++){
            BrowserTheme option=options[j];boolean selected=a.theme==option;LinearLayout tile=Ui.column(a);Ui.pad(tile,a,8);Ui.ripple(tile,a,selected?a.activeFill():a.card(),16,selected?a.accent():a.line());
            FrameLayout preview=new FrameLayout(a);preview.setBackground(Ui.gradient(a,option.nav,option.toolbar,12));preview.setClipToOutline(true);int image=art(option);if(image!=0){ImageView picture=new ImageView(a);android.graphics.BitmapFactory.Options opts=new android.graphics.BitmapFactory.Options();opts.inSampleSize=4;picture.setImageBitmap(android.graphics.BitmapFactory.decodeResource(a.getResources(),image,opts));picture.setScaleType(ImageView.ScaleType.CENTER_CROP);preview.addView(picture,new FrameLayout.LayoutParams(-1,-1));}
            LinearLayout mock=Ui.column(a);Ui.pad(mock,a,7);mock.setBackgroundColor(0x550b1524);TextView mockBar=Ui.text(a,"⚡ SR TURBO",11,option.highlight,true);mockBar.setBackground(Ui.bg(option.nav,8,a));Ui.pad(mockBar,a,5);mock.addView(mockBar);LinearLayout mini=Ui.row(a);for(String name:new String[]{"G","▶","f"}){TextView logo=Ui.text(a,name,16,option.fg,true);logo.setGravity(Gravity.CENTER);logo.setBackground(Ui.bg(option.card,8,a));LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(0,Ui.dp(a,34),1);mp.setMargins(2,Ui.dp(a,10),2,0);mini.addView(logo,mp);}mock.addView(mini);preview.addView(mock,new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM));tile.addView(preview,new LinearLayout.LayoutParams(-1,Ui.dp(a,128)));
            TextView name=Ui.text(a,option.title,14,a.fg(),true);name.setPadding(0,Ui.dp(a,8),0,0);tile.addView(name);TextView description=Ui.text(a,option.description,11,a.muted(),false);description.setMinLines(2);tile.addView(description);tile.addView(Ui.text(a,selected?"✓ ACTIVE":"Tap to apply",12,selected?a.accent():a.muted(),true));tile.setFocusable(true);tile.setContentDescription(option.title+(selected?", active":", apply theme"));tile.setOnClickListener(v->{dialog.dismiss();a.applyTheme(option);});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(Ui.dp(a,4),Ui.dp(a,8),Ui.dp(a,4),Ui.dp(a,4));row.addView(tile,lp);
        }grid.addView(row);}
        panel.addView(Ui.button(a,"Done",a.accent(),a.card(),dialog::dismiss));dialog.setContentView(panel);dialog.show();Window w=dialog.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.setLayout(Math.min(a.getResources().getDisplayMetrics().widthPixels-Ui.dp(a,16),Ui.dp(a,650)),Math.min(a.getResources().getDisplayMetrics().heightPixels-Ui.dp(a,70),Ui.dp(a,820)));}
    }
}
