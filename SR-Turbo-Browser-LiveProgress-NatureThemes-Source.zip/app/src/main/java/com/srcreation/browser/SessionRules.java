package com.srcreation.browser;
import java.net.URI;
import java.util.List;
/** Pure session and shortcut ordering rules. No private session is persisted by the Activity. */
final class SessionRules {
    static final int MAX_TABS=20;
    static final String HOME="about:blank";
    static String safeUrl(String raw){
        try{URI u=URI.create(raw);String scheme=u.getScheme();if(!"http".equalsIgnoreCase(scheme)&&!"https".equalsIgnoreCase(scheme))return HOME;
            if(u.getHost()==null||u.getRawUserInfo()!=null||GoogleLinks.isSignInPage(raw))return HOME;
            return raw;
        }catch(RuntimeException e){return HOME;}
    }
    static int index(int chosen,int size){return size<=0?-1:Math.max(0,Math.min(size-1,chosen));}
    static int percent(int n){return Math.max(0,Math.min(100,n));}
    static String title(String label,String url){if(label!=null&&!label.trim().isEmpty()&&!"New tab".equals(label)&&!label.equals(url))return label;String host=ShortcutStyle.host(url);return host.isEmpty()?"Untitled page":host;}
    static <T> boolean move(List<T> items,int from,int to){if(from<0||to<0||from>=items.size()||to>=items.size()||from==to)return false;T item=items.remove(from);items.add(to,item);return true;}
}
