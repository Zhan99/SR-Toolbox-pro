package com.srcreation.browser;

import android.Manifest;import android.app.*;import android.content.*;import android.content.pm.PackageManager;import android.graphics.Color;import android.net.Uri;import android.os.*;import android.view.*;import android.view.inputmethod.*;import android.webkit.*;import android.widget.*;
import org.json.*;import java.util.*;

public class BrowserActivity extends Activity {
    static final String PREF="browser";static final String HOME="about:blank";
    final ArrayList<Tab> tabs=new ArrayList<>();final ArrayList<Entry> history=new ArrayList<>(),bookmarks=new ArrayList<>(),quickLinks=new ArrayList<>();
    LinearLayout root,top,bottom;FrameLayout content,full,stage;View homePanel;EditText address;TextView progress;TextView tabCount,security,modeIndicator,menuButton,videoButton;int current=-1;boolean restoringTabs=false,clearingTabs=false;final Map<Tab,TextView> tabStatuses=new HashMap<>();Dialog tabDialog;boolean dark=false,desktopAutoZoom=true,facebookCompatibility=true;DesktopMode.Profile displayMode=DesktopMode.Profile.MOBILE;String search="Google";int connections=DownloadEngine.MAX_CONNECTIONS;final UploadPicker uploadPicker=new UploadPicker(this);WebChromeClient.CustomViewCallback fullCallback;boolean privateMode(){return false;}
    BrowserTheme theme=BrowserTheme.CLASSIC_LIGHT;boolean scenery=true;
    AdProtection adProtection;TextView shield,downloadButton;String lastDownloadLabel=null,lastDownloadDescription=null;BrowserTheme lastDownloadTheme;
    final Runnable downloadPoll=new Runnable(){public void run(){refreshDownloadBadge();videoHandler.postDelayed(this,500);}};
    void refreshDownloadBadge(){
        if(downloadButton==null)return;
        DownloadBadge meter=new DownloadBadge();
        if(!privateMode()){
            synchronized(DownloadService.class){DownloadService.load(this);for(DownloadService.Task t:DownloadService.tasks.values())meter.add(t.state,t.bytes,t.total);}
            if(meter.count==0&&YouTubeDownloadService.busy&&!"Updating".equals(YouTubeDownloadService.state))meter.video(YouTubeDownloadService.state,YouTubeDownloadService.bytes,YouTubeDownloadService.total);
        }
        String label=meter.label(),description=meter.description();
        if(Objects.equals(label,lastDownloadLabel)&&Objects.equals(description,lastDownloadDescription)&&lastDownloadTheme==palette())return;
        lastDownloadLabel=label;lastDownloadDescription=description;lastDownloadTheme=palette();
        if(label.isEmpty()){if(downloadButton.getCompoundDrawables()[1]==null)PremiumIcons.apply(downloadButton,"↓",Color.WHITE,22);downloadButton.setContentDescription("Downloads");Ui.ripple(downloadButton,this,palette().nav,12,palette().nav);}
        else{downloadButton.setCompoundDrawables(null,null,null,null);downloadButton.setText(label);downloadButton.setTextColor(palette().highlight);downloadButton.setContentDescription("Downloads: "+meter.description());Ui.ripple(downloadButton,this,palette().toolbar,12,palette().highlight);}
    }
    final java.util.concurrent.atomic.AtomicLong blockedRequests=new java.util.concurrent.atomic.AtomicLong(),blockedPopups=new java.util.concurrent.atomic.AtomicLong(),skippedAds=new java.util.concurrent.atomic.AtomicLong();
    final Runnable adPoll=new Runnable(){public void run(){Tab t=active();if(t!=null)syncVideoAds(t);for(Tab other:tabs)if(other!=t&&other.adConfig!=videoAdConfig(other))syncVideoAds(other);refreshShield();videoHandler.postDelayed(this,800);}};
    int videoAdConfig(Tab t){if(adProtection==null||!AdRules.youtube(AdRules.host(t.url))||!adProtection.enabled(t.url))return 0;return (adProtection.banners?1:0)|(adProtection.skip?2:0)|(adProtection.mute?4:0);}
    void syncVideoAds(Tab t){
        if(adProtection==null||t.pendingRestore||t.adSyncing||!AdRules.youtube(AdRules.host(t.url)))return;
        if(t.percent<10)return;
        int config=videoAdConfig(t),generation=t.adGeneration;t.adSyncing=true;
        t.web.evaluateJavascript(UltraVideoAds.script((config&1)!=0,(config&2)!=0,(config&4)!=0),result->{
            if(!tabs.contains(t)||generation!=t.adGeneration)return;t.adSyncing=false;
            try{JSONArray info=new JSONArray(result);t.adConfig=config;long count=info.getLong(0);if(count>t.adSkipCount)skippedAds.addAndGet(count-t.adSkipCount);t.adSkipCount=count;t.adPlaying=info.getBoolean(1);t.adStall=info.getBoolean(2);}catch(Exception ignored){}if(active()==t)refreshShield();
        });
    }
    void refreshShield(){if(shield==null||adProtection==null)return;Tab t=active();boolean on=t!=null&&adProtection.any(t.url);String status=on&&t.adStall?" • CHECK":on&&t.adPlaying?" • AD":"";shield.setText(on?"⬟ "+blockedRequests.get()+status:"⬡");shield.setTextColor(on?palette().highlight:0xffa9bacd);shield.setContentDescription("Ad protection "+(on?"active":"inactive")+", "+blockedRequests.get()+" blocked requests"+status);}
    void applyPopupPolicy(Tab t){if(adProtection!=null)t.web.getSettings().setJavaScriptCanOpenWindowsAutomatically(!privateMode()&&(!adProtection.popups||adProtection.allow.contains(AdRules.host(t.filterPage))));}
    void protectionChanged(){for(Tab t:tabs){applyPopupPolicy(t);syncVideoAds(t);}refreshShield();}
    void adSettings(){
        if(adProtection==null)return;
        Dialog dialog=new Dialog(this);dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout shell=Ui.column(this);Ui.pad(shell,this,16);shell.setBackground(Ui.bg(paper(),24,this));
        shell.addView(Ui.text(this,"Ad protection",23,fg(),true));shell.addView(Ui.text(this,"ULTRA VIDEO PROTECTION  /  SR TURBO",11,accent(),true));
        ScrollView scroll=new ScrollView(this);LinearLayout body=Ui.column(this);scroll.addView(body);shell.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        section(body,"SESSION STATISTICS");body.addView(Ui.text(this,blockedRequests.get()+" requests blocked  •  "+blockedPopups.get()+" pop-ups blocked  •  "+skippedAds.get()+" skip clicks",14,fg(),true));
        section(body,"FILTER CONTROLS");String[] keys={"ads","yt","skip","banners","mute","tracking","popups","auto"};String[] names={"Website ad block","YouTube ad block","Instant auto skip","Sponsored card blocker","Video ad auto mute","Tracker protection","Pop-up blocker","Automatic filter updates"};String[] details={"Known advertising hosts + updated list","Known external ad hosts • experimental","Detect visible mobile and desktop Skip controls","Hide known mobile and desktop ad cards","Mute detected ads and restore previous sound","Block known tracker hosts","Block unsolicited new windows","Check daily when browsing"};boolean[] values={adProtection.ads,adProtection.yt,adProtection.skip,adProtection.banners,adProtection.mute,adProtection.tracking,adProtection.popups,adProtection.auto};
        for(int i=0;i<keys.length;i++){final String key=keys[i];if(privateMode()&&key.equals("auto"))continue;LinearLayout row=controlRow(body,"⬟",names[i],details[i],values[i]);Switch sw=new Switch(this);sw.setContentDescription(names[i]);sw.setChecked(values[i]);row.addView(sw);sw.setOnCheckedChangeListener((button,value)->{adProtection.set(key,value);protectionChanged();dialog.dismiss();adSettings();});row.setOnClickListener(v->sw.setChecked(!sw.isChecked()));}
        Tab tab=active();String page=tab==null?HOME:tab.url;String host=AdRules.host(page);if(!host.isEmpty()&&!AdRules.exempt(host)){section(body,"CURRENT WEBSITE");boolean enabled=adProtection.enabled(page);actionRow(body,dialog,"⬡",enabled?"Allow ads on this site":"Enable protection on this site",host,enabled?"PROTECTED":"ALLOWED",enabled,()->{adProtection.allowSite(page,enabled);protectionChanged();toast("Saved • reload the page to apply");adSettings();});}
        if(tab!=null&&AdRules.youtube(host)){section(body,"PLAYBACK RECOVERY");body.addView(Ui.text(this,tab.adStall?"Playback may be stalled after an ad.":"If playback stalls, allow ads for this site and reload.",13,muted(),false));actionRow(body,dialog,"↻","Restore normal playback","Allow ads on this site and reload current page","",false,()->{adProtection.allowSite(page,true);protectionChanged();if(active()==tab)tab.web.reload();});}
        if(!privateMode()){section(body,"FILTER UPDATES");body.addView(Ui.text(this,adProtection.status,13,muted(),false));actionRow(body,dialog,"↻","Update filters now","Official AdAway hosts list • HTTPS","",false,()->{if(adProtection.updating.get()){toast("Update already running");return;}adProtection.update(true,()->runOnUiThread(()->{if(!isFinishing()&&!isDestroyed()){toast(adProtection.status);refreshShield();}}));toast("Updating filters");});}
        body.addView(Ui.text(this,"Skip works only when available. Unskippable ads may still play; mute is best effort. Reload after changing network filters.",12,muted(),false));
        shell.addView(Ui.button(this,"Done",fg(),card(),dialog::dismiss));dialog.setContentView(shell);dialog.show();Window win=dialog.getWindow();if(win!=null){win.setBackgroundDrawableResource(android.R.color.transparent);win.setLayout((int)(getResources().getDisplayMetrics().widthPixels*.95),(int)(getResources().getDisplayMetrics().heightPixels*.85));}
    }
    LinearLayout addressBar;TextView brandLogo;final ArrayList<View> chromeButtons=new ArrayList<>(),toolbarButtons=new ArrayList<>();
    BrowserTheme palette(){return privateMode()?BrowserTheme.CLASSIC_DARK:theme;}
    int fg(){return palette().fg;}int paper(){return palette().paper;}int card(){return palette().card;}
    int muted(){return palette().muted;}int line(){return palette().line;}int accent(){return palette().accent;}int activeFill(){return palette().active;}
    boolean scenicHome(){return !privateMode()&&theme.wallpaper(scenery);}
    int homeFg(){return scenicHome()?Color.WHITE:fg();}int homeMuted(){return scenicHome()?0xffe1edf6:muted();}
    void applyTheme(BrowserTheme selected){if(privateMode())return;theme=selected;dark=selected.dark;getSharedPreferences(PREF,0).edit().putString("premium_theme",theme.name()).putBoolean("dark",dark).apply();refreshTheme();}
    void refreshTheme(){BrowserTheme p=palette();getWindow().setStatusBarColor(p.nav);getWindow().setNavigationBarColor(p.nav);if(root==null)return;root.setBackgroundColor(p.paper);top.setBackgroundColor(p.nav);bottom.setBackgroundColor(p.nav);addressBar.setBackground(Ui.bg(p.toolbar,16,this));brandLogo.setTextColor(p.highlight);security.setTextColor(p.highlight);for(View v:chromeButtons)Ui.ripple(v,this,p.nav,12,p.nav);for(View v:toolbarButtons)Ui.ripple(v,this,p.toolbar,12,p.toolbar);progress.setTextColor(p.highlight);progress.setBackground(Ui.surface(this,p.toolbar,12,p.line));if(active()!=null&&HOME.equals(active().url))showHome();refreshModes();refreshVideoButton();refreshShield();lastDownloadTheme=null;refreshDownloadBadge();}
    boolean turbo(){return connections>8;}
    boolean desktopOn(){return displayMode!=DesktopMode.Profile.MOBILE;}
    boolean bookmarked(){Tab t=active();return !privateMode()&&t!=null&&http(t.url)&&bookmarks.stream().anyMatch(e->e.url.equals(t.url));}
    void refreshModes(){
        if(modeIndicator==null||menuButton==null)return;
        Tab t=active();
        int count=(turbo()?1:0)+(desktopOn()?1:0)+(displayMode==DesktopMode.Profile.ORIGINAL&&desktopAutoZoom?1:0)+(dark?1:0)+(privateMode()?1:0);
        String mode=t==null||HOME.equals(t.url)?displayMode.badge:DesktopMode.label(displayMode,t.appliedMode,t.overview,desktopAutoZoom,t.url);
        String label=(turbo()?"⚡ TURBO":"STANDARD")+"  ·  "+mode+(displayMode==DesktopMode.Profile.ORIGINAL&&desktopAutoZoom&&(t==null||HOME.equals(t.url)||(t.appliedMode==DesktopMode.Profile.ORIGINAL&&t.overview))?"  ·  AUTO ZOOM":"")+(privateMode()?"  ·  PRIVATE":"")+(dark&&!privateMode()?"  ·  DARK":"");
        modeIndicator.setText(label);modeIndicator.setTextColor(turbo()?palette().highlight:0xffb5c6d8);menuButton.setText(count>0?"⋮  "+count:"⋮");menuButton.setContentDescription("Browser menu, "+count+" active modes");menuButton.setTextColor(count>0?palette().highlight:Color.WHITE);
    }
    void setDark(boolean value){applyTheme(value?BrowserTheme.CLASSIC_DARK:BrowserTheme.CLASSIC_LIGHT);}
    void setConnections(int value){connections=Math.max(1,Math.min(DownloadEngine.MAX_CONNECTIONS,value));pref("turbo_connections",connections);if(active()!=null&&HOME.equals(active().url))showHome();refreshModes();}
    void chooseConnections(){String[] a=new String[DownloadEngine.MAX_CONNECTIONS];for(int k=0;k<a.length;k++)a[k]=(k+1)+(k>=8?"  •  Turbo priority":"  •  Standard");new AlertDialog.Builder(this).setTitle("Maximum connections").setSingleChoiceItems(a,connections-1,(x,k)->{setConnections(k+1);x.dismiss();}).setNegativeButton("Cancel",null).show();}
    void chooseSearch(){String[] a={"Google","DuckDuckGo","Bing","Brave"};new AlertDialog.Builder(this).setTitle("Search engine").setSingleChoiceItems(a,Arrays.asList(a).indexOf(search),(x,k)->{search=a[k];pref("search",search);x.dismiss();}).setNegativeButton("Cancel",null).show();}
    static class VideoItem {final String url,mime;VideoItem(String u,String m){url=u;mime=m;}}
    final Handler videoHandler=new Handler(Looper.getMainLooper());
    final Runnable videoPoll=new Runnable(){public void run(){Tab t=active();if(t!=null&&http(t.url)&&(!FacebookMobile.isSite(t.url)||t.percent==100))scanVideos(t,null);videoHandler.postDelayed(this,t!=null&&FacebookMobile.isSite(t.url)?8000:2200);}};
    @Override protected void onResume(){super.onResume();videoHandler.removeCallbacks(downloadPoll);videoHandler.post(downloadPoll);videoHandler.removeCallbacks(videoPoll);videoHandler.post(videoPoll);videoHandler.removeCallbacks(adPoll);videoHandler.post(adPoll);if(adProtection!=null)adProtection.update(false,null);if(!privateMode())DownloadService.recoverIfNeeded(this);}
    @Override protected void onPause(){videoHandler.removeCallbacks(downloadPoll);videoHandler.removeCallbacks(videoPoll);videoHandler.removeCallbacks(adPoll);saveSession();super.onPause();}
    class Tab{final ArrayList<VideoItem> videos=new ArrayList<>();int videoGeneration=0;boolean videoScanning=false;Runnable videoDone;WebView web;Entry historyEntry;boolean adSyncing,adPlaying,adStall;int adGeneration,adConfig;long adSkipCount;volatile String filterPage=HOME;String url=HOME,title="New tab";DesktopMode.Profile appliedMode=DesktopMode.Profile.MOBILE;boolean overview=true;String actualAgent;int percent=100;boolean pendingRestore=false;boolean facebookRetry=false;String loadError="";Tab(WebView w){web=w;actualAgent=w.getSettings().getUserAgentString();}}
    static class Entry{String title,url;long time;Entry(String t,String u){this(t,u,System.currentTimeMillis());}Entry(String t,String u,long at){title=t;url=u;time=at;}}
    @Override public void onCreate(Bundle b){super.onCreate(b);adProtection=new AdProtection(this,privateMode());if(!privateMode()){android.content.SharedPreferences p=getSharedPreferences(PREF,0);theme=BrowserTheme.restore(p.getString("premium_theme",null),p.getBoolean("dark",false));dark=theme.dark;scenery=p.getBoolean("theme_scenery",true);displayMode=DesktopMode.restore(p.getString("display_mode",null),p.getBoolean("desktop_default",false));desktopAutoZoom=p.getBoolean("desktop_auto_zoom",true);facebookCompatibility=p.getBoolean("facebook_mobile_compat",true);CookieManager.getInstance().setAcceptCookie(true);search=p.getString("search","Google");connections=DownloadEngine.restoreConnections(p.getInt("turbo_connections",DownloadEngine.MAX_CONNECTIONS),p.getBoolean("max_speed_v24",false));if(!p.getBoolean("max_speed_v24",false))p.edit().putInt("turbo_connections",connections).putBoolean("max_speed_v24",true).apply();readEntries(p.getString("history","[]"),history);readEntries(p.getString("bookmarks","[]"),bookmarks);if(p.contains("quick_access"))readEntries(p.getString("quick_access","[]"),quickLinks);else defaultQuickLinks();}else{dark=true;displayMode=DesktopMode.restore(b==null?null:b.getString("private_display_mode"),b!=null&&b.getBoolean("private_desktop",false));desktopAutoZoom=b==null||b.getBoolean("private_desktop_auto_zoom",true);getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);CookieManager.getInstance().setAcceptCookie(false);WebStorage.getInstance().deleteAllData();}
        build();if(!privateMode())restoreSession(b);if(tabs.isEmpty())newTab(HOME);handleIntent(getIntent());}
    void restoreSession(Bundle state){
        ArrayList<Entry> saved=new ArrayList<>();android.content.SharedPreferences prefs=getSharedPreferences(PREF,0);
        readEntries(prefs.getString("session_tabs","[]"),saved);int selected=prefs.getInt("session_current",0);
        // Persistent state is authoritative; older releases only had the instance Bundle.
        if(!prefs.contains("session_tabs")&&state!=null){ArrayList<String> old=state.getStringArrayList("tabs");if(old!=null){for(String u:old)saved.add(new Entry("",u,0));selected=state.getInt("current",0);}}
        restoringTabs=true;
        try{for(Entry e:saved){if(tabs.size()>=SessionRules.MAX_TABS)break;String u=SessionRules.safeUrl(e.url);Tab t=createTab(u);t.url=u;t.title=HOME.equals(u)?"New tab":SessionRules.title(e.title,u);t.pendingRestore=!HOME.equals(u);}if(!tabs.isEmpty())switchTo(SessionRules.index(selected,tabs.size()));}
        finally{restoringTabs=false;}saveSession();
    }
    void saveSession(){if(privateMode()||restoringTabs||clearingTabs||tabs.isEmpty())return;JSONArray saved=new JSONArray();for(Tab t:tabs){String u=SessionRules.safeUrl(t.url);JSONObject row=new JSONObject();try{row.put("url",u).put("title",HOME.equals(u)?"New tab":SessionRules.title(t.title,u));saved.put(row);}catch(JSONException ignored){}}getSharedPreferences(PREF,0).edit().putString("session_tabs",saved.toString()).putInt("session_current",SessionRules.index(current,tabs.size())).apply();}
    void eraseSession(){if(!privateMode())getSharedPreferences(PREF,0).edit().putString("session_tabs","[]").putInt("session_current",0).apply();}
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);handleIntent(i);}
    void handleIntent(Intent i){if(i!=null&&Intent.ACTION_VIEW.equals(i.getAction())&&i.getData()!=null&&http(i.getDataString())){navigate(i.getDataString());i.setAction(null);}}
    @Override protected void onSaveInstanceState(Bundle out){super.onSaveInstanceState(out);out.putString("private_display_mode",displayMode.name());out.putBoolean("private_desktop",desktopOn());out.putBoolean("private_desktop_auto_zoom",desktopAutoZoom);if(!privateMode()){ArrayList<String> a=new ArrayList<>();for(Tab t:tabs)a.add(SessionRules.safeUrl(t.url));out.putStringArrayList("tabs",a);out.putInt("current",current);}}
    static boolean http(String s){return s!=null&&(s.startsWith("https://")||s.startsWith("http://"));}
    void readEntries(String raw,List<Entry> dest){try{JSONArray a=new JSONArray(raw);for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);dest.add(new Entry(o.optString("title"),o.optString("url"),o.optLong("time",0)));}}catch(JSONException ignored){}}
    void saveEntries(String key,List<Entry> entries){if(privateMode())return;JSONArray a=new JSONArray();for(Entry e:entries){JSONObject o=new JSONObject();try{o.put("title",e.title).put("url",e.url).put("time",e.time);a.put(o);}catch(JSONException ignored){}}getSharedPreferences(PREF,0).edit().putString(key,a.toString()).apply();}
    void pref(String key,Object value){if(privateMode())return;android.content.SharedPreferences.Editor e=getSharedPreferences(PREF,0).edit();if(value instanceof Boolean)e.putBoolean(key,(Boolean)value);else if(value instanceof Integer)e.putInt(key,(Integer)value);else e.putString(key,String.valueOf(value));e.apply();}
    void build(){root=Ui.column(this);root.setBackgroundColor(paper());top=Ui.column(this);top.setBackgroundColor(palette().nav);Ui.pad(top,this,8);LinearLayout brand=Ui.row(this);brandLogo=Ui.text(this,privateMode()?"◉  PRIVATE SESSION":"⚡  SR TURBO",16,palette().highlight,true);brand.addView(brandLogo,new LinearLayout.LayoutParams(0,-2,1));videoButton=Ui.button(this,"▶ ↓",Color.WHITE,palette().nav,this::videoPicker);videoButton.setContentDescription("Download video from this page");brand.addView(videoButton);chromeButtons.add(videoButton);downloadButton=Ui.button(this,"↓",Color.WHITE,palette().nav,this::downloads);PremiumIcons.apply(downloadButton,"↓",Color.WHITE,22);downloadButton.setContentDescription("Downloads");downloadButton.setMinWidth(Ui.dp(this,58));brand.addView(downloadButton);chromeButtons.add(downloadButton);menuButton=Ui.button(this,"⋮",Color.WHITE,palette().toolbar,this::menu);brand.addView(menuButton);toolbarButtons.add(menuButton);top.addView(brand);
        LinearLayout bar=Ui.row(this);addressBar=bar;bar.setBackground(Ui.bg(palette().toolbar,16,this));security=Ui.text(this,"○",18,palette().highlight,true);Ui.pad(security,this,8);security.setOnClickListener(v->siteInfo());bar.addView(security);address=new EditText(this);address.setSingleLine(true);address.setTextColor(Color.WHITE);address.setHintTextColor(0xffa9bacd);address.setHint("Search or enter URL");address.setTextSize(15);address.setSelectAllOnFocus(true);address.setBackgroundColor(Color.TRANSPARENT);address.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);address.setImeOptions(EditorInfo.IME_ACTION_GO);address.setOnEditorActionListener((v,a,e)->{if(a==EditorInfo.IME_ACTION_GO||(e!=null&&e.getKeyCode()==KeyEvent.KEYCODE_ENTER&&e.getAction()==KeyEvent.ACTION_DOWN)){navigate(address.getText().toString());return true;}return false;});bar.addView(address,new LinearLayout.LayoutParams(0,Ui.dp(this,48),1));TextView reloadButton=Ui.button(this,"↻",Color.WHITE,palette().toolbar,()->{Tab t=active();if(t!=null){if(t.percent<100){t.web.stopLoading();t.percent=100;updateBar(t);refreshTabStatus(t);}else if(HOME.equals(t.url))showHome();else reloadTab(t);}});PremiumIcons.apply(reloadButton,"↻",Color.WHITE,20);reloadButton.setContentDescription("Reload or stop loading");bar.addView(reloadButton);toolbarButtons.add(reloadButton);top.addView(bar);modeIndicator=Ui.text(this,"",11,palette().highlight,true);modeIndicator.setPadding(Ui.dp(this,8),Ui.dp(this,5),0,Ui.dp(this,2));modeIndicator.setOnClickListener(v->menu());modeIndicator.setFocusable(true);LinearLayout status=Ui.row(this);status.addView(modeIndicator,new LinearLayout.LayoutParams(0,-2,1));progress=Ui.text(this,"",12,palette().highlight,true);progress.setGravity(Gravity.CENTER);progress.setPadding(Ui.dp(this,10),Ui.dp(this,4),Ui.dp(this,10),Ui.dp(this,4));progress.setBackground(Ui.surface(this,0xff164744,12,0xff297c79));progress.setVisibility(View.GONE);status.addView(progress,new LinearLayout.LayoutParams(-2,-2));shield=Ui.text(this,"⬡",12,palette().highlight,true);Ui.pad(shield,this,6);shield.setOnClickListener(v->adSettings());status.addView(shield,new LinearLayout.LayoutParams(-2,-2));top.addView(status);root.addView(top);
        content=new FrameLayout(this);root.addView(content,new LinearLayout.LayoutParams(-1,0,1));bottom=Ui.row(this);bottom.setBackgroundColor(palette().nav);nav("‹",()->{Tab t=active();if(t!=null&&t.web.canGoBack())goHistory(t,-1);else home();});nav("›",()->{Tab t=active();if(t!=null&&t.web.canGoForward())goHistory(t,1);});nav("⌂",this::home);tabCount=nav("1",this::tabSwitcher);nav("+",()->newTab(HOME));root.addView(bottom);stage=new FrameLayout(this);stage.addView(root,new FrameLayout.LayoutParams(-1,-1));setContentView(stage);refreshTheme();if(active()!=null)display(active());refreshModes();}
    TextView nav(String s,Runnable r){TextView t=Ui.button(this,s,Color.WHITE,palette().nav,r);t.setTextSize(23);PremiumIcons.apply(t,s,Color.WHITE,24);bottom.addView(t,new LinearLayout.LayoutParams(0,Ui.dp(this,54),1));chromeButtons.add(t);return t;}
    Tab active(){return current>=0&&current<tabs.size()?tabs.get(current):null;}
    Tab createTab(String url){WebView w=new WebView(this);Tab t=new Tab(w);tabs.add(t);configure(t);applyDesktop(t,url);w.setVisibility(View.INVISIBLE);content.addView(w,new FrameLayout.LayoutParams(-1,-1));return t;}
    void newTab(String url){if(tabs.size()>=SessionRules.MAX_TABS){toast("Maximum 20 tabs");return;}if(privateMode()&&GoogleLinks.isAccountSite(url)){toast("Google account access is disabled in private mode");url=HOME;}Tab t=createTab(url);t.url=http(url)?url:HOME;t.filterPage=t.url;t.pendingRestore=http(url);switchTo(tabs.size()-1);}
    void configure(Tab t){WebView w=t.web;WebSettings s=w.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(!privateMode());s.setDatabaseEnabled(false);s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setAllowFileAccessFromFileURLs(false);s.setAllowUniversalAccessFromFileURLs(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);s.setSafeBrowsingEnabled(true);s.setSupportZoom(true);s.setBuiltInZoomControls(true);s.setDisplayZoomControls(false);s.setUseWideViewPort(true);s.setLoadWithOverviewMode(true);s.setMediaPlaybackRequiresUserGesture(true);s.setJavaScriptCanOpenWindowsAutomatically(false);s.setSupportMultipleWindows(true);if(privateMode())s.setCacheMode(WebSettings.LOAD_NO_CACHE);CookieManager.getInstance().setAcceptThirdPartyCookies(w,false);
        w.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest request){if(adProtection!=null&&adProtection.block(t.filterPage,request.getUrl().toString(),request.isForMainFrame())){blockedRequests.incrementAndGet();return new WebResourceResponse("text/plain","UTF-8",204,"No Content",java.util.Collections.emptyMap(),new java.io.ByteArrayInputStream(new byte[0]));}return null;}
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest request){Uri u=request.getUrl();if(http(u.toString())){if(request.isForMainFrame()){if(privateMode()&&GoogleLinks.isAccountSite(u.toString())){toast("Google account access is disabled in private mode");return true;}t.filterPage=u.toString();applyPopupPolicy(t);applyDesktop(t,u.toString());}return false;}if(request.isForMainFrame()&&request.hasGesture()&&("tel".equals(u.getScheme())||"mailto".equals(u.getScheme())||"sms".equals(u.getScheme()))){try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception e){toast("No compatible app");}}return true;}
            @Override public void onPageStarted(WebView v,String url,android.graphics.Bitmap f){if(!tabs.contains(t)||t.pendingRestore)return;t.filterPage=url;t.adGeneration++;t.adSyncing=false;t.adPlaying=false;t.adStall=false;t.adSkipCount=0;t.adConfig=0;applyPopupPolicy(t);uploadPicker.cancel(v);t.loadError="";t.historyEntry=null;resetVideos(t);if(!HOME.equals(url)){if(http(url))applyDesktop(t,url);if(!Objects.equals(t.url,url))t.title=SessionRules.title(null,url);t.url=url;t.percent=0;saveSession();refreshTabStatus(t);if(active()==t){if(t.web.getVisibility()!=View.VISIBLE||homePanel!=null)display(t);updateBar(t);}}}
            @Override public void onPageFinished(WebView v,String url){if(!tabs.contains(t)||t.pendingRestore||!Objects.equals(v.getUrl(),url))return;if(http(url)){if(t.facebookRetry){t.facebookRetry=false;v.getSettings().setCacheMode(privateMode()?WebSettings.LOAD_NO_CACHE:WebSettings.LOAD_DEFAULT);}if(t.appliedMode==DesktopMode.Profile.NORMAL&&!GoogleLinks.isAccountSite(url)){int pixels=v.getWidth()>0?v.getWidth():getResources().getDisplayMetrics().widthPixels;int dp=Math.max(1,Math.round(pixels/getResources().getDisplayMetrics().density));v.evaluateJavascript(DesktopMode.pcViewport(dp),null);}else if(DesktopMode.forceWideViewport(t.appliedMode,t.overview,url))v.evaluateJavascript(DesktopMode.WIDE_VIEWPORT,null);t.url=url;t.title=Objects.toString(v.getTitle(),url);if(!privateMode()&&!GoogleLinks.isSignInPage(url)){t.historyEntry=new Entry(t.title,url);history.add(0,t.historyEntry);if(history.size()>300)history.remove(history.size()-1);saveEntries("history",history);}}else if(HOME.equals(url)&&HOME.equals(t.url)){t.title="New tab";}else return;t.percent=100;syncVideoAds(t);saveSession();refreshTabStatus(t);if(active()==t){if(HOME.equals(t.url))showHome();updateBar(t);if(http(url))scanVideos(t,null);}}
            @Override public void doUpdateVisitedHistory(WebView v,String url,boolean reload){if(tabs.contains(t)&&!t.pendingRestore&&http(url)){if(!Objects.equals(t.url,url)){t.historyEntry=null;resetVideos(t);}t.url=url;t.filterPage=url;saveSession();if(active()==t)updateBar(t);}}
            @Override public void onReceivedError(WebView v,WebResourceRequest request,WebResourceError error){if(request.isForMainFrame()){t.loadError="Network error "+error.getErrorCode();t.percent=100;refreshTabStatus(t);if(active()==t)updateBar(t);}}
            @Override public void onReceivedHttpError(WebView v,WebResourceRequest request,WebResourceResponse response){if(request.isForMainFrame())t.loadError="HTTP "+response.getStatusCode();}
            @Override public void onReceivedSslError(WebView v,SslErrorHandler h,android.net.http.SslError e){h.cancel();t.loadError="TLS certificate error";toast("Unsafe TLS certificate • connection blocked");}
            @Override public boolean onRenderProcessGone(WebView v,RenderProcessGoneDetail detail){int idx=tabs.indexOf(t);if(idx>=0){closeTab(idx);toast("Page renderer stopped. Open the page again.");}return true;}
        });w.setWebChromeClient(new WebChromeClient(){@Override public void onProgressChanged(WebView v,int p){if(!tabs.contains(t)||t.pendingRestore)return;t.percent=SessionRules.percent(p);refreshTabStatus(t);if(p>=10)syncVideoAds(t);if(active()==t)updateBar(t);}@Override public void onReceivedTitle(WebView v,String title){if(!tabs.contains(t)||t.pendingRestore)return;t.title=title;saveSession();Entry e=t.historyEntry;if(!privateMode()&&tabs.contains(t)&&e!=null&&history.contains(e)&&Objects.equals(e.url,t.url)&&Objects.equals(e.url,v.getUrl())&&HistoryTitles.usable(title,e.url)&&!Objects.equals(e.title,title)){e.title=title;saveEntries("history",history);}}
            @Override public boolean onCreateWindow(WebView v,boolean dialog,boolean gesture,Message result){if(!gesture&&(privateMode()||adProtection.popups&&!adProtection.allow.contains(AdRules.host(t.filterPage)))){blockedPopups.incrementAndGet();return false;}if(tabs.size()>=20)return false;newTab(HOME);Tab nt=active();WebView.WebViewTransport transport=(WebView.WebViewTransport)result.obj;transport.setWebView(nt.web);result.sendToTarget();return true;}
            @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams params){return uploadPicker.open(v,cb,params);}
            @Override public void onShowCustomView(View view,CustomViewCallback cb){if(full!=null||active()!=t){cb.onCustomViewHidden();return;}fullCallback=cb;full=new FrameLayout(BrowserActivity.this);full.setBackgroundColor(Color.BLACK);full.addView(view,new FrameLayout.LayoutParams(-1,-1));stage.addView(full,new FrameLayout.LayoutParams(-1,-1));getWindow().getDecorView().setSystemUiVisibility(5894);}
            @Override public void onHideCustomView(){hideFull();}
        });w.setDownloadListener((url,ua,disposition,mime,len)->requestDownload(url,ua,disposition,mime,len));w.setOnLongClickListener(v->{WebView.HitTestResult hit=w.getHitTestResult();if(hit==null||!http(hit.getExtra()))return false;String link=hit.getExtra();new AlertDialog.Builder(this).setItems(new String[]{"Open in new tab","Copy link","Download link"},(d,i)->{if(i==0)newTab(link);else if(i==1)copy(link);else requestDownload(link,w.getSettings().getUserAgentString(),null,null,-1);}).show();return true;});}
    void hideFull(){if(full==null)return;full.removeAllViews();stage.removeView(full);full=null;getWindow().getDecorView().setSystemUiVisibility(0);if(fullCallback!=null){fullCallback.onCustomViewHidden();fullCallback=null;}}
    @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);uploadPicker.result(req,result,data);}
    void switchTo(int n){if(n<0||n>=tabs.size())return;if(full!=null)hideFull();current=n;address.clearFocus();Tab chosen=active();if(chosen.pendingRestore){chosen.pendingRestore=false;load(chosen,chosen.url);}else display(chosen);saveSession();}
    void removeHomePanel(){if(homePanel!=null){content.removeView(homePanel);homePanel=null;}}
    // Keep every live WebView attached; do not pause timers, reload or stop hidden tabs.
    void display(Tab t){if(t!=active())return;removeHomePanel();for(Tab other:tabs)other.web.setVisibility(other==t&&!HOME.equals(t.url)?View.VISIBLE:View.INVISIBLE);if(HOME.equals(t.url)){showHome();}else{t.web.bringToFront();}updateBar(t);}
    void updateBar(Tab t){if(!address.hasFocus())address.setText(HOME.equals(t.url)?"":t.url);security.setText(t.url.startsWith("https://")?"▣":t.url.startsWith("http://")?"!":"○");tabCount.setText(String.valueOf(tabs.size()));progress.setText("LOADING  "+SessionRules.percent(t.percent)+"%");progress.setVisibility(!HOME.equals(t.url)&&t.percent<100&&!t.pendingRestore?View.VISIBLE:View.GONE);refreshModes();refreshVideoButton();refreshShield();}
    void load(Tab t,String url){url=FacebookMobile.entry(url,displayMode==DesktopMode.Profile.MOBILE);if(privateMode()&&GoogleLinks.isAccountSite(url)){toast("Google account access is disabled in private mode");return;}t.historyEntry=null;resetVideos(t);applyDesktop(t,url);if(!Objects.equals(t.url,url))t.title=SessionRules.title(null,url);t.url=url;t.filterPage=url;applyPopupPolicy(t);t.percent=0;t.pendingRestore=false;display(t);saveSession();t.web.loadUrl(url);}
    void navigate(String input){String s=input.trim();if(s.isEmpty())return;String lower=s.toLowerCase(Locale.ROOT);if(lower.startsWith("http://")||lower.startsWith("https://")){s=lower.substring(0,lower.indexOf(':'))+s.substring(s.indexOf(':'));}else if(!s.contains(" ")&&(s.matches("(?i)(localhost|[a-z0-9-]+(\\.[a-z0-9-]+)+)([:/].*)?")||s.matches("(?i)localhost:\\d+.*"))){s="https://"+s;}else{s=searchBase()+Uri.encode(s);}address.clearFocus();((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(address.getWindowToken(),0);root.setFocusableInTouchMode(true);root.requestFocus();if(active()!=null)load(active(),s);}
    String searchBase(){switch(search){case "DuckDuckGo":return "https://duckduckgo.com/?q=";case "Bing":return "https://www.bing.com/search?q=";case "Brave":return "https://search.brave.com/search?q=";default:return "https://www.google.com/search?q=";}}
    void home(){Tab t=active();if(t==null)return;t.historyEntry=null;resetVideos(t);t.web.stopLoading();applyDesktop(t,HOME);t.web.loadUrl(HOME);t.url=HOME;t.title="New tab";t.percent=100;t.pendingRestore=false;showHome();updateBar(t);saveSession();}
    void showHome(){
        removeHomePanel();
        for(Tab t:tabs)t.web.setVisibility(View.INVISIBLE);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setClipToPadding(false);
        LinearLayout panel=Ui.column(this);panel.setBackgroundColor(scenicHome()?Color.TRANSPARENT:paper());Ui.pad(panel,this,16);panel.setClipChildren(false);panel.setClipToPadding(false);
        scroll.addView(panel,new ScrollView.LayoutParams(-1,-2));
        if(privateMode()){
            TextView title=Ui.text(this,"Private browsing",25,fg(),true);panel.addView(title);
            panel.addView(Ui.text(this,"Separate session • history not saved\nCookies disabled • downloads may remain",14,muted(),false));
        }else renderQuickAccess(panel);
        View spacer=new View(this);panel.addView(spacer,new LinearLayout.LayoutParams(1,Ui.dp(this,24),1));
        TextView credit=Ui.text(this,"SR CREATION FARM",10,homeMuted(),true);credit.setGravity(Gravity.CENTER);credit.setLetterSpacing(.16f);Ui.pad(credit,this,12);if(scenicHome())credit.setBackground(Ui.bg(0x990b1524,14,this));panel.addView(credit);
        FrameLayout home=new FrameLayout(this);home.setBackgroundColor(paper());
        if(scenicHome()){ImageView wallpaper=new ImageView(this);wallpaper.setScaleType(ImageView.ScaleType.CENTER_CROP);wallpaper.setImageResource(ThemeGallery.art(theme));wallpaper.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);home.addView(wallpaper,new FrameLayout.LayoutParams(-1,-1));View shade=new View(this);shade.setBackground(new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0x990b1524,0x300b1524,0x990b1524}));home.addView(shade,new FrameLayout.LayoutParams(-1,-1));}
        home.addView(scroll,new FrameLayout.LayoutParams(-1,-1));homePanel=home;content.addView(home,new FrameLayout.LayoutParams(-1,-1));
    }
    void defaultQuickLinks(){String[][] links={{"Google","https://www.google.com"},{"YouTube","https://www.youtube.com"},{"Facebook","https://www.facebook.com"},{"Wikipedia","https://www.wikipedia.org"},{"GitHub","https://github.com"},{"Gmail","https://mail.google.com"}};for(String[] pair:links)quickLinks.add(new Entry(pair[0],pair[1],0));}
    void saveQuick(){saveEntries("quick_access",quickLinks);if(active()!=null&&HOME.equals(active().url))showHome();}
    void renderQuickAccess(LinearLayout panel){
        if(privateMode())return;
        LinearLayout header=Ui.row(this);header.setPadding(0,Ui.dp(this,6),0,0);
        LinearLayout heading=Ui.column(this);heading.addView(Ui.text(this,"Quick access",24,homeFg(),true));
        heading.addView(Ui.text(this,quickLinks.size()+" saved websites",12,homeMuted(),false));
        header.addView(heading,new LinearLayout.LayoutParams(0,-2,1));
        TextView manage=Ui.button(this,"Manage",accent(),activeFill(),this::manageQuick);header.addView(manage);panel.addView(header);
        int columns=ShortcutStyle.columns(getResources().getConfiguration().screenWidthDp);
        int count=quickLinks.size()+(quickLinks.size()<48?1:0);
        for(int i=0;i<count;i+=columns){
            LinearLayout row=Ui.row(this);row.setClipChildren(false);row.setClipToPadding(false);
            for(int j=i;j<i+columns;j++){
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,Ui.dp(this,112),1);lp.setMargins(Ui.dp(this,4),Ui.dp(this,12),Ui.dp(this,4),0);
                if(j>=count){row.addView(new View(this),lp);continue;}
                Entry item=j<quickLinks.size()?quickLinks.get(j):null;
                View tile=shortcutTile(item);row.addView(tile,lp);
                if(j<12&&android.animation.ValueAnimator.areAnimatorsEnabled()){
                    tile.setAlpha(0f);tile.setTranslationY(Ui.dp(this,7));
                    tile.animate().alpha(1f).translationY(0f).setDuration(180).setStartDelay(j*25L).start();
                }
            }
            panel.addView(row);
        }
        TextView hint=Ui.text(this,"Tap to open  •  Hold and drag to reorder  •  Manage to edit",12,homeMuted(),false);hint.setGravity(Gravity.CENTER);hint.setPadding(Ui.dp(this,8),Ui.dp(this,12),Ui.dp(this,8),Ui.dp(this,12));if(scenicHome()){hint.setBackground(Ui.bg(0xc20b1524,14,this));LinearLayout.LayoutParams hintLp=new LinearLayout.LayoutParams(-1,-2);hintLp.topMargin=Ui.dp(this,16);panel.addView(hint,hintLp);}else panel.addView(hint);
    }
    View shortcutTile(Entry item){
        boolean add=item==null;
        LinearLayout tile=Ui.column(this);tile.setGravity(Gravity.CENTER);Ui.pad(tile,this,6);
        Ui.ripple(tile,this,card(),20,line());tile.setElevation(Ui.dp(this,2));tile.setFocusable(true);tile.setClickable(true);
        tile.setContentDescription(add?"Add website shortcut":"Open "+item.title+"; hold and drag to reorder");
        tile.setOnClickListener(v->{if(add)editQuick(null,false);else navigate(item.url);});
        if(!add){tile.setOnLongClickListener(v->{v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);boolean started=v.startDragAndDrop(ClipData.newPlainText("Quick access","reorder"),new View.DragShadowBuilder(v),item,0);if(!started)quickActions(item);return true;});}
        tile.setOnDragListener((v,event)->{
            Object local=event.getLocalState();if(!(local instanceof Entry)||!quickLinks.contains(local))return false;
            Entry moving=(Entry)local;
            switch(event.getAction()){
                case DragEvent.ACTION_DRAG_STARTED:return true;
                case DragEvent.ACTION_DRAG_ENTERED:Ui.ripple(v,this,activeFill(),20,accent());return true;
                case DragEvent.ACTION_DRAG_EXITED:case DragEvent.ACTION_DRAG_ENDED:Ui.ripple(v,this,card(),20,line());return true;
                case DragEvent.ACTION_DROP:int from=quickLinks.indexOf(moving),to=add?quickLinks.size()-1:quickLinks.indexOf(item);if(SessionRules.move(quickLinks,from,to)){saveEntries("quick_access",quickLinks);v.post(()->{if(active()!=null&&HOME.equals(active().url))showHome();});}return true;
                default:return true;
            }
        });
        FrameLayout badge=new FrameLayout(this);
        ShortcutStyle.Brand brand=add?ShortcutStyle.Brand.OTHER:ShortcutStyle.brand(item.url);
        int[] colors={0xff2870c9,0xff08796f,0xff7653b8,0xffb24e6c,0xffa76018,0xff42647f};
        int shade=add?accent():colors[ShortcutStyle.palette(item.url)];
        int icon=0;
        switch(brand){
            case GOOGLE:icon=R.drawable.quick_google;break;
            case YOUTUBE:icon=R.drawable.quick_youtube;break;
            case FACEBOOK:icon=R.drawable.quick_facebook;break;
            case GITHUB:icon=R.drawable.quick_github;break;
            case GMAIL:icon=R.drawable.quick_gmail;break;case INSTAGRAM:icon=R.drawable.quick_instagram;break;case TIKTOK:icon=R.drawable.quick_tiktok;break;case WHATSAPP:icon=R.drawable.quick_whatsapp;break;case CHATGPT:icon=R.drawable.quick_chatgpt;break;case GEMINI:icon=R.drawable.quick_gemini;break;
            default:break;
        }
        int fill=brand==ShortcutStyle.Brand.GITHUB?0xff1e293b:brand==ShortcutStyle.Brand.OTHER&&!add?shade:brand==ShortcutStyle.Brand.WIKIPEDIA?Color.WHITE:0xfff4f7fb;
        if(add)fill=activeFill();
        badge.setBackground(Ui.bg(fill,16,this));
        if(icon!=0){ImageView image=new ImageView(this);image.setImageResource(icon);image.setScaleType(ImageView.ScaleType.FIT_CENTER);badge.addView(image,new FrameLayout.LayoutParams(Ui.dp(this,34),Ui.dp(this,34),Gravity.CENTER));}
        else {String symbol=add?"+":brand==ShortcutStyle.Brand.WIKIPEDIA?"W":ShortcutStyle.initial(item.title,item.url);
            TextView mark=Ui.text(this,symbol,add?30:24,add?accent():brand==ShortcutStyle.Brand.WIKIPEDIA?Ui.INK:Color.WHITE,true);mark.setGravity(Gravity.CENTER);
            if(brand==ShortcutStyle.Brand.WIKIPEDIA)mark.setTypeface(android.graphics.Typeface.SERIF,android.graphics.Typeface.BOLD);
            badge.addView(mark,new FrameLayout.LayoutParams(-1,-1));}
        tile.addView(badge,new LinearLayout.LayoutParams(Ui.dp(this,52),Ui.dp(this,52)));
        TextView name=Ui.text(this,add?"Add site":item.title,12,add?accent():fg(),true);name.setGravity(Gravity.CENTER);name.setMaxLines(2);name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams label=new LinearLayout.LayoutParams(-1,-2);label.topMargin=Ui.dp(this,7);tile.addView(name,label);
        if(android.animation.ValueAnimator.areAnimatorsEnabled()){
            android.animation.StateListAnimator states=new android.animation.StateListAnimator();
            states.addState(new int[]{android.R.attr.state_pressed},shortcutScale(tile,.94f));states.addState(new int[]{},shortcutScale(tile,1f));tile.setStateListAnimator(states);
        }
        return tile;
    }
    android.animation.Animator shortcutScale(View tile,float scale){
        android.animation.AnimatorSet set=new android.animation.AnimatorSet();
        set.playTogether(android.animation.ObjectAnimator.ofFloat(tile,"scaleX",scale),android.animation.ObjectAnimator.ofFloat(tile,"scaleY",scale));set.setDuration(110);return set;
    }
    @Override public void onConfigurationChanged(android.content.res.Configuration config){super.onConfigurationChanged(config);if(active()!=null&&HOME.equals(active().url))showHome();}
    void quickActions(Entry item){new AlertDialog.Builder(this).setTitle(item.title).setItems(new String[]{"Edit shortcut","Delete shortcut","Move earlier","Move later"},(d,i)->{if(i==0)editQuick(item,false);else if(i==1)deleteQuick(item,false);else{int pos=quickLinks.indexOf(item);if(SessionRules.move(quickLinks,pos,pos+(i==2?-1:1)))saveQuick();}}).setNegativeButton("Cancel",null).show();}
    void manageQuick(){if(privateMode())return;Dialog d=new Dialog(this);LinearLayout panel=Ui.column(this);Ui.pad(panel,this,16);panel.setBackgroundColor(paper());panel.addView(Ui.text(this,"Manage quick access",22,fg(),true));panel.addView(Ui.text(this,quickLinks.size()+" / 48 shortcuts",13,muted(),false));panel.addView(Ui.button(this,"+ Add website",accent(),activeFill(),()->{d.dismiss();editQuick(null,true);}));ScrollView scroll=new ScrollView(this);LinearLayout list=Ui.column(this);scroll.addView(list);panel.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));for(Entry item:new ArrayList<>(quickLinks)){LinearLayout r=controlRow(list,"↗",item.title,item.url,false);r.setOnLongClickListener(v->{d.dismiss();quickActions(item);return true;});r.addView(Ui.button(this,"Edit",accent(),paper(),()->{d.dismiss();editQuick(item,true);}));TextView del=Ui.button(this,"×",0xffcc5151,card(),()->{d.dismiss();deleteQuick(item,true);});del.setContentDescription("Delete "+item.title);r.addView(del);}panel.addView(Ui.button(this,"Done",fg(),card(),d::dismiss));d.setContentView(panel);d.show();Window w=d.getWindow();if(w!=null){w.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-Ui.dp(this,24),Ui.dp(this,460)),Math.min(getResources().getDisplayMetrics().heightPixels-Ui.dp(this,100),Ui.dp(this,620)));}}
    void deleteQuick(Entry item,boolean manage){new AlertDialog.Builder(this).setTitle("Remove shortcut?").setMessage(item.title+"\n"+item.url).setNegativeButton("Cancel",(d,i)->{if(manage)manageQuick();}).setPositiveButton("Delete",(d,i)->{quickLinks.remove(item);saveQuick();toast("Shortcut removed");if(manage)manageQuick();}).show();}
    void editQuick(Entry item,boolean manage){if(privateMode())return;if(item==null&&quickLinks.size()>=48){toast("Maximum 48 shortcuts");if(manage)manageQuick();return;}LinearLayout panel=Ui.column(this);Ui.pad(panel,this,18);EditText name=new EditText(this),url=new EditText(this);name.setSingleLine(true);name.setHint("Website name");url.setSingleLine(true);url.setHint("https://example.com");url.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);if(item!=null){name.setText(item.title);url.setText(item.url);}else if(active()!=null&&http(active().url)){name.setText(active().title);url.setText(active().url);}panel.addView(name);panel.addView(url);AlertDialog d=new AlertDialog.Builder(this).setTitle(item==null?"Add quick access":"Edit quick access").setView(panel).setNegativeButton("Cancel",(a,b)->{if(manage)manageQuick();}).setPositiveButton("Save",null).create();d.show();d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String u=PrivacyRules.webUrl(url.getText().toString());if(u==null){url.setError("Enter a valid HTTP or HTTPS website");return;}String n=name.getText().toString().trim();if(n.isEmpty())n=Uri.parse(u).getHost();if(n.length()>80){name.setError("Use at most 80 characters");return;}for(Entry e:quickLinks)if(e!=item&&e.url.equals(u)){url.setError("This website is already saved");return;}if(item==null)quickLinks.add(new Entry(n,u));else{item.title=n;item.url=u;}saveQuick();d.dismiss();toast("Shortcut saved");if(manage)manageQuick();});}
    void closeTab(int index){if(index<0||index>=tabs.size())return;Tab t=tabs.remove(index);uploadPicker.cancel(t.web);ViewGroup p=(ViewGroup)t.web.getParent();if(p!=null)p.removeView(t.web);t.web.destroy();if(tabs.isEmpty()){current=-1;newTab(HOME);}else{if(current>index)current--;if(current>=tabs.size())current=tabs.size()-1;switchTo(current);}}
    String tabStatus(Tab t){return t.pendingRestore?"SAVED • tap to load":t==active()?t.percent<100?"ACTIVE • "+t.percent+"%":"✓ ACTIVE":t.percent<100?"LOADING • "+t.percent+"%":"OPEN";}
    void refreshTabStatus(Tab t){TextView status=tabStatuses.get(t);if(status!=null)status.setText(tabStatus(t));}
    void tabSwitcher(){
        Dialog dialog=new Dialog(this);tabDialog=dialog;LinearLayout panel=Ui.column(this);Ui.pad(panel,this,16);panel.setBackground(Ui.bg(paper(),24,this));
        LinearLayout header=Ui.row(this);LinearLayout heading=Ui.column(this);heading.addView(Ui.text(this,"Tab manager",24,fg(),true));heading.addView(Ui.text(this,tabs.size()+" / 20 tabs  •  "+(privateMode()?"Private session":"Session saved"),12,muted(),false));header.addView(heading,new LinearLayout.LayoutParams(0,-2,1));header.addView(Ui.button(this,"×",fg(),card(),dialog::dismiss));panel.addView(header);
        ScrollView scroll=new ScrollView(this);LinearLayout grid=Ui.column(this);scroll.addView(grid);panel.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));tabStatuses.clear();
        int columns=getResources().getConfiguration().screenWidthDp<320?1:2;LinearLayout row=null;
        for(int i=0;i<tabs.size();i++){Tab t=tabs.get(i);boolean selected=t==active();if(i%columns==0){row=Ui.row(this);grid.addView(row);}
            LinearLayout tile=Ui.column(this);Ui.pad(tile,this,10);Ui.ripple(tile,this,selected?activeFill():card(),18,selected?accent():line());tile.setElevation(Ui.dp(this,1));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(Ui.dp(this,4),Ui.dp(this,10),Ui.dp(this,4),0);row.addView(tile,lp);
            LinearLayout tools=Ui.row(this);TextView number=Ui.text(this,String.format(Locale.ROOT,"%02d",i+1),12,muted(),true);tools.addView(number,new LinearLayout.LayoutParams(0,-2,1));TextView close=Ui.button(this,"×",0xffc45c60,card(),()->{int index=tabs.indexOf(t);dialog.dismiss();if(index>=0)closeTab(index);tabSwitcher();});close.setContentDescription("Close tab "+(i+1));tools.addView(close);tile.addView(tools);
            FrameLayout preview=new FrameLayout(this);preview.setBackground(Ui.gradient(this,selected?0xff145e61:0xff263b55,palette().nav,14));android.graphics.Bitmap favicon=t.pendingRestore?null:t.web.getFavicon();if(favicon!=null&&!favicon.isRecycled()){ImageView image=new ImageView(this);image.setImageBitmap(favicon);image.setScaleType(ImageView.ScaleType.FIT_CENTER);preview.addView(image,new FrameLayout.LayoutParams(Ui.dp(this,38),Ui.dp(this,38),Gravity.CENTER));}else{TextView initial=Ui.text(this,HOME.equals(t.url)?"⌂":ShortcutStyle.initial(t.title,t.url),28,palette().highlight,true);initial.setGravity(Gravity.CENTER);preview.addView(initial,new FrameLayout.LayoutParams(-1,-1));}tile.addView(preview,new LinearLayout.LayoutParams(-1,Ui.dp(this,76)));
            TextView title=Ui.text(this,HOME.equals(t.url)?"New tab":SessionRules.title(t.title,t.url),14,fg(),true);title.setMaxLines(2);title.setMinLines(2);title.setEllipsize(android.text.TextUtils.TruncateAt.END);title.setPadding(0,Ui.dp(this,8),0,0);tile.addView(title);
            TextView host=Ui.text(this,HOME.equals(t.url)?"Quick access":ShortcutStyle.host(t.url),11,muted(),false);host.setSingleLine(true);host.setEllipsize(android.text.TextUtils.TruncateAt.END);tile.addView(host);
            TextView state=Ui.text(this,tabStatus(t),10,accent(),true);state.setPadding(0,Ui.dp(this,8),0,0);tile.addView(state);tabStatuses.put(t,state);tile.setFocusable(true);tile.setOnClickListener(v->{int index=tabs.indexOf(t);dialog.dismiss();if(index>=0)switchTo(index);});
        }
        if(row!=null&&tabs.size()%columns!=0)row.addView(new View(this),new LinearLayout.LayoutParams(0,1,1));panel.addView(Ui.button(this,"+  New tab",palette().nav,palette().highlight,()->{dialog.dismiss();newTab(HOME);}));dialog.setOnDismissListener(d->{if(tabDialog==dialog){tabStatuses.clear();tabDialog=null;}});dialog.setContentView(panel);dialog.show();Window win=dialog.getWindow();if(win!=null){win.setBackgroundDrawableResource(android.R.color.transparent);win.setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-Ui.dp(this,16),Ui.dp(this,640)),Math.min(getResources().getDisplayMetrics().heightPixels-Ui.dp(this,70),Ui.dp(this,740)));}
    }
    void menu(){showControlCenter(false);}
    void section(LinearLayout host,String title){TextView t=Ui.text(this,title,11,muted(),true);t.setLetterSpacing(.10f);t.setPadding(Ui.dp(this,5),Ui.dp(this,16),0,Ui.dp(this,7));host.addView(t);}
    LinearLayout controlRow(LinearLayout host,String icon,String title,String detail,boolean enabled){
        LinearLayout r=Ui.row(this);Ui.pad(r,this,12);r.setMinimumHeight(Ui.dp(this,66));Ui.ripple(r,this,enabled?activeFill():card(),15,enabled?accent():line());
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=Ui.dp(this,7);host.addView(r,rp);
        TextView ico=Ui.text(this,icon,20,enabled?accent():muted(),true);ico.setGravity(Gravity.CENTER);PremiumIcons.apply(ico,icon,enabled?accent():muted(),22);ico.setContentDescription(title);ico.setBackground(Ui.bg(enabled?card():paper(),12,this));r.addView(ico,new LinearLayout.LayoutParams(Ui.dp(this,38),Ui.dp(this,38)));
        LinearLayout texts=Ui.column(this);texts.setPadding(Ui.dp(this,11),0,Ui.dp(this,6),0);r.addView(texts,new LinearLayout.LayoutParams(0,-2,1));texts.addView(Ui.text(this,title,15,fg(),true));if(!detail.isEmpty())texts.addView(Ui.text(this,detail,12,muted(),false));return r;
    }
    void actionRow(LinearLayout host,Dialog d,String icon,String title,String detail,String badge,boolean enabled,Runnable action){LinearLayout r=controlRow(host,icon,title,detail,enabled);TextView end=Ui.text(this,badge.isEmpty()?"›":badge,12,enabled?accent():muted(),true);Ui.pad(end,this,5);if(enabled)end.setBackground(Ui.bg(card(),9,this));r.addView(end);r.setFocusable(true);r.setOnClickListener(v->{d.dismiss();action.run();});}
    void toggleRow(LinearLayout host,Dialog d,boolean settingsOnly,String icon,String title,String detail,boolean on,java.util.function.Consumer<Boolean> change){
        toggleRow(host,d,settingsOnly,icon,title,detail,on,change,true);
    }
    void toggleRow(LinearLayout host,Dialog d,boolean settingsOnly,String icon,String title,String detail,boolean on,java.util.function.Consumer<Boolean> change,boolean reopen){
        LinearLayout r=controlRow(host,icon,title,detail,on);LinearLayout end=Ui.column(this);end.setGravity(Gravity.CENTER);TextView state=Ui.text(this,on?"✓ ON":"OFF",11,on?accent():muted(),true);end.addView(state);Switch toggle=new Switch(this);toggle.setContentDescription(title);toggle.setChecked(on);toggle.setThumbTintList(android.content.res.ColorStateList.valueOf(on?accent():0xff91a1b2));toggle.setTrackTintList(android.content.res.ColorStateList.valueOf(on?0xff74bdb0:0xffb6c0cc));end.addView(toggle);r.addView(end);toggle.setOnCheckedChangeListener((v,checked)->{d.dismiss();change.accept(checked);if(reopen)showControlCenter(settingsOnly);});r.setFocusable(true);r.setOnClickListener(v->toggle.setChecked(!toggle.isChecked()));
    }
    void displayRow(LinearLayout host,Dialog d,boolean settingsOnly,DesktopMode.Profile mode,String icon,String detail){
        boolean selected=displayMode==mode;
        actionRow(host,d,icon,mode.title,detail,selected?"✓ ACTIVE":"○ OFF",selected,()->{
            if(selected){showControlCenter(settingsOnly);return;}
            setDisplayMode(mode);
        });
    }
    void showControlCenter(boolean settingsOnly){
        Dialog d=new Dialog(this);d.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout shell=Ui.column(this);shell.setBackground(Ui.bg(paper(),24,this));Ui.pad(shell,this,16);
        LinearLayout head=Ui.row(this);LinearLayout titles=Ui.column(this);titles.addView(Ui.text(this,settingsOnly?"Settings":"Control center",23,fg(),true));titles.addView(Ui.text(this,"SR TURBO  /  "+(privateMode()?"PRIVATE":"BROWSER"),11,accent(),true));head.addView(titles,new LinearLayout.LayoutParams(0,-2,1));TextView close=Ui.button(this,"×",fg(),card(),d::dismiss);close.setContentDescription("Close menu");head.addView(close);shell.addView(head);
        ScrollView scroll=new ScrollView(this);scroll.setVerticalScrollBarEnabled(false);LinearLayout body=Ui.column(this);scroll.addView(body);shell.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        section(body,"ACTIVE MODES");toggleRow(body,d,settingsOnly,"⚡","Turbo Boost",connections+" max connections · next downloads",turbo(),v->setConnections(v?DownloadEngine.MAX_CONNECTIONS:8));
        section(body,"WEBSITE DISPLAY • CHOOSE ONE");
        displayRow(body,d,settingsOnly,DesktopMode.Profile.ORIGINAL,"▣","Previous desktop behavior · optional original auto zoom");
        displayRow(body,d,settingsOnly,DesktopMode.Profile.NORMAL,"▤","PC-style 1280 px layout · fit entire page width");
        displayRow(body,d,settingsOnly,DesktopMode.Profile.MOBILE,"▯","Original mobile identity and responsive layout");
        if(displayMode==DesktopMode.Profile.ORIGINAL)toggleRow(body,d,settingsOnly,"⊕","Desktop auto zoom","Original automatic page scaling · ON fits page",desktopAutoZoom,this::setDesktopAutoZoom,false);
        else actionRow(body,d,"⊕","Desktop auto zoom","Saved for original Desktop mode only",desktopAutoZoom?"SAVED ON":"SAVED OFF",false,()->toast("Select original Desktop mode to change auto zoom"));
        if(!privateMode())toggleRow(body,d,settingsOnly,"f","Facebook mobile compatibility","Mobile layout profile · Facebook only",facebookCompatibility,value->{facebookCompatibility=value;pref("facebook_mobile_compat",value);toast("Saved • reload Facebook to apply");});
        if(active()!=null&&FacebookMobile.isSite(active().url))actionRow(body,d,"↻","Repair Facebook mobile page","Fresh reload or open clean mobile homepage","",false,this::facebookRepair);
        section(body,"APPEARANCE & PRIVACY");
        actionRow(body,d,"⬟","Advanced ad blocker","YouTube • website ads • tracker protection",active()!=null&&adProtection.any(active().url)?"✓ ON":"SETTINGS",active()!=null&&adProtection.any(active().url),this::adSettings);
        if(!privateMode())actionRow(body,d,"✦","Premium themes & scenery",BrowserTheme.values().length+" themes · offline wallpaper gallery",theme.title,true,()->ThemeGallery.show(this));
        if(privateMode())actionRow(body,d,"◐","Dark theme","Always on in private mode","✓ ON",true,()->toast("Private theme is always dark"));else toggleRow(body,d,settingsOnly,"◐","Dark theme","Switch to classic dark or light",dark,this::setDark);
        if(!settingsOnly)actionRow(body,d,"◉",privateMode()?"Exit private session":"Private session",privateMode()?"Separate session active":"Open a separate session",privateMode()?"✓ ON":"OFF",privateMode(),()->{if(privateMode())finish();else startActivity(new Intent(this,PrivateActivity.class));});
        section(body,"DOWNLOAD & SEARCH");if(!privateMode())actionRow(body,d,"▶","Video downloader","YouTube · Facebook · supported sites",active()!=null&&YouTubeLinks.canonical(active().url)!=null?"READY":"",active()!=null&&YouTubeLinks.canonical(active().url)!=null,this::siteVideoDownloader);if(bulkAvailable(active()))actionRow(body,d,"⇩","Download right-side videos","Select loaded recommendations / mix videos","BATCH",true,this::youtubeBulk);actionRow(body,d,"▶","Download video","Find direct videos or use page link",active()!=null&&!active().videos.isEmpty()?String.valueOf(active().videos.size()):"",active()!=null&&!active().videos.isEmpty(),this::videoPicker);actionRow(body,d,"↧","Downloads","View transfer progress","",false,this::downloads);actionRow(body,d,"↗","Direct download","Paste a file URL","",false,this::direct);actionRow(body,d,"⬡","Background downloads","Battery settings & automatic recovery","",false,this::backgroundDownloadSettings);actionRow(body,d,"≋","Connection limit","Applies to new downloads",String.valueOf(connections),false,this::chooseConnections);actionRow(body,d,"⌕","Search engine","Default web search",search,false,this::chooseSearch);
        if(!settingsOnly){section(body,"PAGE TOOLS");actionRow(body,d,"+","New tab",tabs.size()+" / 20 open","",false,()->newTab(HOME));actionRow(body,d,"★",bookmarked()?"Remove bookmark":"Add bookmark",privateMode()?"Unavailable in private mode":"Current page",bookmarked()?"✓ SAVED":"",bookmarked(),()->{if(bookmarked()){bookmarks.removeIf(e->e.url.equals(active().url));saveEntries("bookmarks",bookmarks);toast("Bookmark removed");}else addBookmark();});actionRow(body,d,"☆","Bookmarks","Saved websites","",false,()->entries(bookmarks,"Bookmarks"));actionRow(body,d,"◷","History","Recently visited pages","",false,()->entries(history,"History"));actionRow(body,d,"⌕","Find in page","Search text on this page","",false,this::find);actionRow(body,d,"↗","Share page","Send current link","",false,this::share);actionRow(body,d,"▤","Copy page URL","Copy current link","",false,()->{if(active()!=null&&http(active().url))copy(active().url);});}
        section(body,"PREFERENCES");if(!privateMode()){actionRow(body,d,"G","Google account & Gmail","Open Google pages in SR Turbo","",false,this::googleCenter);actionRow(body,d,"+","Add quick access","Save a website shortcut","",false,()->editQuick(null,false));actionRow(body,d,"▦","Manage quick access",quickLinks.size()+" saved shortcuts","",false,this::manageQuick);}if(!settingsOnly)actionRow(body,d,"⚙","Settings","Personalize your browser","",false,this::settings);actionRow(body,d,"⌫","Clear browsing data","Time range • history, site data & more","",false,this::clearData);actionRow(body,d,"ⓘ","About developer","SR Creation Farm","",false,this::about);
        d.setContentView(shell);d.show();Window w=d.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);w.setDimAmount(.55f);w.setGravity(Gravity.TOP|Gravity.END);android.util.DisplayMetrics dm=getResources().getDisplayMetrics();w.setLayout(Math.min(dm.widthPixels-Ui.dp(this,20),Ui.dp(this,440)),Math.min(dm.heightPixels-Ui.dp(this,90),Ui.dp(this,760)));WindowManager.LayoutParams lp=w.getAttributes();lp.y=Ui.dp(this,8);lp.x=Ui.dp(this,10);w.setAttributes(lp);}}
    void entries(List<Entry> list,String title){if(privateMode()){toast("Not saved in private session");return;}if(list.isEmpty()){toast("No "+title.toLowerCase(Locale.ROOT)+" yet");return;}boolean historyOnly=list==history;ArrayList<Entry> snapshot=new ArrayList<>(list);String[] names=new String[snapshot.size()];for(int i=0;i<snapshot.size();i++){Entry e=snapshot.get(i);names[i]=historyOnly?HistoryTitles.display(e.title,e.url):e.title+"\n"+e.url;}new AlertDialog.Builder(this).setTitle(title).setItems(names,(d,i)->navigate(snapshot.get(i).url)).setNeutralButton("Clear all",(d,i)->new AlertDialog.Builder(this).setMessage("Clear all "+title.toLowerCase(Locale.ROOT)+"?").setNegativeButton("Cancel",null).setPositiveButton("Clear",(a,b)->{list.clear();saveEntries(title.equals("History")?"history":"bookmarks",list);}).show()).setNegativeButton("Close",null).show();}
    void addBookmark(){Tab t=active();if(privateMode()||t==null||!http(t.url)){toast("Bookmark unavailable");return;}bookmarks.removeIf(e->e.url.equals(t.url));bookmarks.add(0,new Entry(t.title,t.url));saveEntries("bookmarks",bookmarks);toast("Bookmark saved");}
    void applyDesktop(Tab t,String url){
        DesktopMode.Profile next=DesktopMode.effective(displayMode,url);
        String agent=DesktopMode.agent(t.actualAgent,next!=DesktopMode.Profile.MOBILE);
        if(next==DesktopMode.Profile.MOBILE&&!privateMode()&&FacebookMobile.isSite(url))agent=FacebookMobile.agent(agent,facebookCompatibility);
        WebSettings settings=t.web.getSettings();
        if(!Objects.equals(settings.getUserAgentString(),agent))settings.setUserAgentString(agent);
        boolean overview=DesktopMode.overview(next,desktopAutoZoom);
        if(t.appliedMode!=next||t.overview!=overview){t.appliedMode=next;t.overview=overview;settings.setUseWideViewPort(true);settings.setLoadWithOverviewMode(overview);t.web.setInitialScale(0);}
    }
    void setDesktopAutoZoom(boolean value){
        desktopAutoZoom=value;pref("desktop_auto_zoom",value);refreshModes();
        Tab t=active();
        if(t!=null&&displayMode==DesktopMode.Profile.ORIGINAL&&t.appliedMode==DesktopMode.Profile.ORIGINAL&&http(t.url)&&t.percent==100){
            new AlertDialog.Builder(this).setTitle("Desktop auto zoom")
                .setMessage("Setting saved. Reload this page to apply now? Other tabs will not be reloaded.")
                .setNegativeButton("Next navigation",null)
                .setPositiveButton("Reload page",(d,i)->{if(active()==t&&tabs.contains(t)&&t.percent==100)reloadTab(t);}).show();
        }else toast(value?"Auto zoom on • next desktop page":"Auto zoom off • next desktop page");
    }
    void facebookRepair(){
        Tab t=active();if(t==null||!FacebookMobile.isSite(t.url))return;
        if(displayMode!=DesktopMode.Profile.MOBILE){toast("Select Mobile mode first");return;}
        android.content.pm.PackageInfo provider=WebView.getCurrentWebViewPackage();
        String version=provider==null?"unknown":provider.versionName;
        new AlertDialog.Builder(this).setTitle("Facebook mobile repair")
            .setMessage("Reload without cached responses, or open the clean mobile homepage. Cookies and other tabs are kept.\nWebView: "+version+"\nLast main-page error: "+(t.loadError.isEmpty()?"none reported":t.loadError))
            .setNegativeButton("Cancel",null)
            .setNeutralButton("Mobile homepage",(dialog,which)->retryFacebook(t,true))
            .setPositiveButton("Fresh reload",(dialog,which)->retryFacebook(t,false)).show();
    }
    void retryFacebook(Tab t,boolean homepage){
        if(active()!=t||!tabs.contains(t)||!FacebookMobile.isSite(t.url)||displayMode!=DesktopMode.Profile.MOBILE)return;
        t.web.stopLoading();t.facebookRetry=true;t.web.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        if(homepage)load(t,FacebookMobile.HOME);else reloadTab(t);
        videoHandler.postDelayed(()->{if(tabs.contains(t)&&t.facebookRetry){t.facebookRetry=false;t.web.getSettings().setCacheMode(privateMode()?WebSettings.LOAD_NO_CACHE:WebSettings.LOAD_DEFAULT);}},30000);
    }
    void reloadTab(Tab t){applyDesktop(t,t.url);t.web.reload();}
    void goHistory(Tab t,int delta){WebBackForwardList list=t.web.copyBackForwardList();WebHistoryItem item=list.getItemAtIndex(list.getCurrentIndex()+delta);if(item!=null)applyDesktop(t,item.getUrl());t.web.goBackOrForward(delta);}
    void setDisplayMode(DesktopMode.Profile mode){
        if(displayMode==mode)return;
        displayMode=mode;
        if(!privateMode())getSharedPreferences(PREF,0).edit().putString("display_mode",mode.name()).putBoolean("desktop_default",desktopOn()).apply();
        Tab t=active();
        if(t!=null&&HOME.equals(t.url))applyDesktop(t,HOME);
        refreshModes();
        if(t!=null&&http(t.url)&&t.percent==100){
            new AlertDialog.Builder(this).setTitle(mode.title)
                .setMessage("Default saved for all tabs and future navigation. Reload only this page now? Other tabs will keep running.")
                .setNegativeButton("Next navigation",null)
                .setPositiveButton("Reload page",(d,i)->{if(active()==t&&tabs.contains(t)&&t.percent==100)reloadTab(t);}).show();
        }else toast(mode.title+" saved • next page");
    }
    void find(){Tab t=active();if(t==null||!http(t.url))return;EditText input=new EditText(this);input.setSingleLine(true);input.setHint("Find text");AlertDialog d=new AlertDialog.Builder(this).setTitle("Find in page").setView(input).setPositiveButton("Next",null).setNeutralButton("Previous",null).setNegativeButton("Done",(x,y)->t.web.clearMatches()).create();d.setOnDismissListener(x->t.web.clearMatches());d.show();input.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){t.web.findAllAsync(s.toString());}public void afterTextChanged(android.text.Editable e){}});d.getButton(-1).setOnClickListener(v->t.web.findNext(true));d.getButton(-3).setOnClickListener(v->t.web.findNext(false));}
    void share(){Tab t=active();if(t!=null&&http(t.url))startActivity(Intent.createChooser(new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,t.url),"Share page"));}
    void copy(String s){((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("URL",s));toast("Copied");}
    void siteInfo(){Tab t=active();String u=t==null?HOME:t.url;new AlertDialog.Builder(this).setTitle("Site information").setMessage((u.startsWith("https://")?"HTTPS URL. Certificate errors are blocked.":u.startsWith("http://")?"HTTP is not encrypted. Avoid passwords or sensitive data.":"New tab")+"\n\n"+u).setPositiveButton("OK",null).show();}
    void settings(){showControlCenter(true);}
    void clearData(){
        LinearLayout panel=Ui.column(this);Ui.pad(panel,this,18);TextView intro=Ui.text(this,"Choose a time range and what to remove. Downloaded files and browser preferences are kept.",13,Ui.MUTED,false);panel.addView(intro);
        Spinner range=new Spinner(this);ArrayAdapter<String> ranges=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,PrivacyRules.LABELS);ranges.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);range.setAdapter(ranges);panel.addView(range);range.setSelection(4);
        CheckBox hist=new CheckBox(this),site=new CheckBox(this),saved=new CheckBox(this),downloadLog=new CheckBox(this);hist.setText("Browsing history");site.setText("Cookies, cache, site storage, form data & open tabs (all time)");saved.setText("Bookmarks & quick access");downloadLog.setText("Finished download records (all time)");hist.setChecked(true);site.setChecked(true);saved.setChecked(true);downloadLog.setChecked(true);panel.addView(hist);panel.addView(site);if(!privateMode()){panel.addView(saved);panel.addView(downloadLog);}else{hist.setChecked(false);hist.setEnabled(false);saved.setChecked(false);downloadLog.setChecked(false);}
        TextView detail=Ui.text(this,"",13,Ui.MUTED,false);Ui.pad(detail,this,8);panel.addView(detail);Runnable update=()->{boolean all=range.getSelectedItemPosition()==4;site.setChecked(all);downloadLog.setChecked(all&&!privateMode());site.setEnabled(all);downloadLog.setEnabled(all&&!privateMode());detail.setText(all?"Clearing site data closes all tabs and may sign you out of websites. Active or resumable downloads remain.":"Time filtering applies to saved history, bookmarks and shortcuts. WebView does not support time-filtered cookies/cache/storage or tab history. Use All time to remove them. Older entries without dates are retained.");};range.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(AdapterView<?> a,View v,int pos,long id){update.run();}public void onNothingSelected(AdapterView<?> a){}});update.run();ScrollView scroll=new ScrollView(this);scroll.addView(panel);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Clear browsing data").setView(scroll).setNegativeButton("Cancel",null).setPositiveButton("Clear selected",null).create();dialog.show();dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{int selection=range.getSelectedItemPosition();boolean h=hist.isChecked(),s=site.isChecked()&&selection==4,b=saved.isChecked()&&!privateMode(),dl=downloadLog.isChecked()&&selection==4&&!privateMode();if(!h&&!s&&!b&&!dl){toast("Choose at least one data type");return;}new AlertDialog.Builder(this).setTitle("Confirm clear").setMessage("Remove selected data for "+PrivacyRules.LABELS[selection].toLowerCase(Locale.ROOT)+"?"+(s?" All open tabs will close and website sign-ins may be removed.":"")).setNegativeButton("Cancel",null).setPositiveButton("Clear now",(a,i)->{dialog.dismiss();applyClear(selection,h,s,b,dl);}).show();});
    }
    void applyClear(int range,boolean hist,boolean site,boolean saved,boolean downloadLog){long now=System.currentTimeMillis();if(hist){history.removeIf(e->PrivacyRules.inRange(e.time,now,range));saveEntries("history",history);}if(saved){bookmarks.removeIf(e->PrivacyRules.inRange(e.time,now,range));saveEntries("bookmarks",bookmarks);quickLinks.removeIf(e->PrivacyRules.inRange(e.time,now,range));saveQuick();}if(downloadLog){DownloadService.clearFinishedRecords(this);YouTubeDownloadService.clearFinished(this);}if(!site){if(range==4&&hist)for(Tab t:tabs)t.web.clearHistory();refreshModes();toast("Selected data cleared");return;}
        clearingTabs=true;eraseSession();if(full!=null)hideFull();uploadPicker.cancelAll();ArrayList<Tab> old=new ArrayList<>(tabs);tabs.clear();current=-1;content.removeAllViews();homePanel=null;for(Tab t:old){t.web.stopLoading();t.web.clearCache(true);t.web.clearHistory();t.web.clearFormData();ViewGroup parent=(ViewGroup)t.web.getParent();if(parent!=null)parent.removeView(t.web);t.web.destroy();}WebStorage.getInstance().deleteAllData();WebViewDatabase db=WebViewDatabase.getInstance(this);db.clearFormData();db.clearHttpAuthUsernamePassword();WebView.clearClientCertPreferences(null);if(hist){history.clear();saveEntries("history",history);}AlertDialog busy=new AlertDialog.Builder(this).setMessage("Clearing website data…").setCancelable(false).create();busy.show();CookieManager.getInstance().removeAllCookies(removed->{CookieManager.getInstance().flush();if(isFinishing()||isDestroyed())return;busy.dismiss();clearingTabs=false;address.clearFocus();newTab(HOME);address.setText("");toast("Selected data cleared");});
    }
    void googleCenter(){if(privateMode()){toast("Google account access is disabled in private mode");return;}
        LinearLayout panel=Ui.column(this);Ui.pad(panel,this,18);panel.setBackgroundColor(paper());
        panel.addView(Ui.text(this,"GOOGLE ACCOUNT  •  IN-APP",17,fg(),true));
        panel.addView(Ui.text(this,"Google pages open in a new SR Turbo tab. Google does not support sign-in in Android WebView; login or account switching may be blocked. No external browser will open automatically.",14,muted(),false));
        ScrollView scroll=new ScrollView(this);scroll.addView(panel);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Google account & Gmail").setView(scroll).setNegativeButton("Close",null).create();
        String[] labels={"Open Gmail","Choose / connect Google account","Add another Google account","Manage Google account"};
        String[] urls={GoogleLinks.GMAIL,GoogleLinks.CHOOSE,GoogleLinks.ADD,GoogleLinks.MANAGE};
        for(int j=0;j<labels.length;j++){final String url=urls[j];TextView button=Ui.button(this,labels[j]+"   ›",fg(),card(),()->{dialog.dismiss();newTab(url);});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=Ui.dp(this,8);panel.addView(button,lp);}
        dialog.show();
    }
    void about(){new AlertDialog.Builder(this).setTitle("SR Turbo Browser • 3.4").setMessage("Developer: Shahriar Rahman\nBrand: SR Creation Farm\n© 2026 SR Creation Farm\n\nAndroid WebView browser with a smart multi-connection download engine.").setPositiveButton("YouTube",(d,i)->navigate("https://www.youtube.com/@SRCreation-farm")).setNeutralButton("Facebook",(d,i)->navigate("https://fb.com/srcreation.farm")).setNegativeButton("Close",null).show();}
    void downloads(){if(privateMode()){new AlertDialog.Builder(this).setTitle("Download history").setMessage("The normal download manager opens outside the private session.").setPositiveButton("Open",(d,i)->startActivity(new Intent(this,DownloadsActivity.class))).setNegativeButton("Cancel",null).show();}else startActivity(new Intent(this,DownloadsActivity.class));}
    void direct(){EditText e=new EditText(this);e.setHint("https://example.com/file.zip");e.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);new AlertDialog.Builder(this).setTitle("Direct download URL").setView(e).setNegativeButton("Cancel",null).setPositiveButton("Continue",(d,i)->requestDownload(e.getText().toString().trim(),active()==null?null:active().web.getSettings().getUserAgentString(),null,null,-1)).show();}
    void requestDownload(String url,String agent,String disposition,String mime,long length){
        if(YouTubeLinks.canonical(url)!=null){if(privateMode()){toast("Open a normal tab to use YouTube downloads");return;}quickVideoDownload(YouTubeLinks.canonical(url));return;}
        if(!http(url)){toast("Only HTTP/HTTPS file downloads are supported");return;}
        String guess=URLUtil.guessFileName(url,disposition,mime);
        String inferred=MimeTypeMap.getSingleton().getMimeTypeFromExtension(MimeTypeMap.getFileExtensionFromUrl(guess).toLowerCase(Locale.ROOT));
        String type=mime==null?(inferred==null?"application/octet-stream":inferred):mime.split(";",2)[0];
        try{String cookie=privateMode()?"":CookieManager.getInstance().getCookie(url);
            Intent intent=new Intent(this,DownloadService.class).setAction(DownloadService.ADD).putExtra("url",url).putExtra("agent",agent).putExtra("cookie",cookie).putExtra("name",guess).putExtra("mime",type).putExtra("connections",connections);
            startForegroundService(intent);toast(privateMode()?"Download queued • file remains outside private mode":"Download queued • continues in background");
            if(Build.VERSION.SDK_INT>=33&&!privateMode()&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED&&!getSharedPreferences(PREF,0).getBoolean("download_notification_asked",false)){pref("download_notification_asked",true);requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},9);}
        }catch(Exception e){toast("Cannot start download: "+e.getMessage());}
    }
    void quickVideoDownload(String link){
        if(link==null){startActivity(new Intent(this,YouTubeDownloadsActivity.class));return;}
        if(YouTubeDownloadService.busy){toast("A video download is already running");return;}
        LinearLayout panel=Ui.column(this);Ui.pad(panel,this,16);
        panel.addView(Ui.text(this,"Choose quality. Tap Download to confirm you have permission from the site and rights holder. The download starts immediately.",14,fg(),false));
        Spinner quality=new Spinner(this);String[] labels={"360p","480p","720p HD","1080p Full HD"};int[] heights={360,480,720,1080};ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,labels);quality.setAdapter(adapter);quality.setSelection(2);panel.addView(quality);
        new AlertDialog.Builder(this).setTitle("Download authorized video").setView(panel).setNegativeButton("Cancel",null).setPositiveButton("Download",(d,i)->{try{if(YouTubeDownloadService.busy){toast("A video download is already running");return;}startForegroundService(new Intent(this,YouTubeDownloadService.class).setAction(YouTubeDownloadService.START).putExtra("url",link).putExtra("quality",heights[quality.getSelectedItemPosition()]));toast("Video download started • see Downloads");}catch(Exception e){toast("Cannot start: "+e.getMessage());}}).show();
    }
    void backgroundDownloadSettings(){new AlertDialog.Builder(this).setTitle("Background downloads").setMessage("Downloads run in a foreground service with a notification. If your phone stops them, open app settings and allow background activity / unrestricted battery use if available. Android force-stop and manufacturer restrictions can still stop transfers.").setNegativeButton("Close",null).setPositiveButton("App settings",(d,i)->{try{startActivity(new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())));}catch(Exception e){toast("Open Android app settings manually");}}).show();}
    void resetVideos(Tab t){t.videoGeneration++;t.videoScanning=false;t.videoDone=null;t.videos.clear();if(active()==t)refreshVideoButton();}
    void refreshVideoButton(){if(videoButton==null)return;Tab t=active();if(!privateMode()&&t!=null&&YouTubeLinks.canonical(t.url)!=null){videoButton.setText("▶ ↓ YT");videoButton.setTextColor(palette().highlight);videoButton.setContentDescription("YouTube downloader");return;}int n=t==null?0:t.videos.size();videoButton.setText(n>0?"▶ ↓ "+n:!privateMode()&&t!=null&&SiteVideoLinks.facebook(t.url)?"▶ ↓ FB":"▶ ↓");videoButton.setTextColor(n>0?palette().highlight:Color.WHITE);videoButton.setContentDescription(n>0?"Download video, "+n+" detected":"Download video from this page");}
    void scanVideos(Tab t,Runnable done){
        if(!tabs.contains(t)||!http(t.url)||isFinishing()||isDestroyed()){if(done!=null)done.run();return;}
        if(t.videoScanning){if(done!=null)t.videoDone=done;return;}
        t.videoScanning=true;t.videoDone=done;final int gen=t.videoGeneration;final String page=t.url;
        t.web.evaluateJavascript(VideoLinks.SCAN,result->{
            if(!tabs.contains(t)||isDestroyed()||gen!=t.videoGeneration)return;
            t.videoScanning=false;Runnable callback=t.videoDone;t.videoDone=null;if(!Objects.equals(t.url,page))return;
            try{JSONArray found=new JSONArray(result);ArrayList<VideoItem> valid=new ArrayList<>();HashSet<String> seen=new HashSet<>();for(int i=0;i<found.length()&&valid.size()<VideoLinks.MAX;i++){JSONObject o=found.getJSONObject(i);String u=o.optString("url");String mime=VideoLinks.mime(u,o.optString("mime"),o.optBoolean("fromVideo"));if(mime!=null&&seen.add(u))valid.add(new VideoItem(u,mime));}t.videos.clear();t.videos.addAll(valid);}catch(Exception ignored){}
            if(active()==t){refreshVideoButton();if(callback!=null&&!isFinishing())callback.run();}
        });
    }
    void siteVideoDownloader(){if(privateMode()){toast("Open a normal tab to use the video engine");return;}Tab t=active();quickVideoDownload(t==null?null:SiteVideoLinks.canonical(t.url));}
    void youtubeDownloader(){if(privateMode()){toast("Open a normal tab to use YouTube downloads");return;}Tab t=active();quickVideoDownload(t==null?null:YouTubeLinks.canonical(t.url));}
    boolean bulkAvailable(Tab t){return !privateMode()&&t!=null&&displayMode==DesktopMode.Profile.NORMAL&&t.appliedMode==DesktopMode.Profile.NORMAL&&YouTubeBulk.watchPage(t.url);}
    void youtubeBulk(){Tab t=active();if(!bulkAvailable(t)){toast("Open a YouTube watch page in Normal Desktop mode first");return;}final String page=t.url;final int gen=t.videoGeneration;
        t.web.evaluateJavascript(YouTubeBulk.SCAN,result->{if(isFinishing()||isDestroyed()||active()!=t||!Objects.equals(page,t.url)||gen!=t.videoGeneration)return;
            ArrayList<String> links=new ArrayList<>(),titles=new ArrayList<>();HashSet<String> seen=new HashSet<>();
            try{JSONArray rows=new JSONArray(result);for(int k=0;k<rows.length()&&links.size()<YouTubeBulk.MAX;k++){JSONObject row=rows.getJSONObject(k);String link=YouTubeLinks.canonical(row.optString("url"));if(link!=null&&seen.add(link)){links.add(link);String title=row.optString("title",link);titles.add(title.substring(0,Math.min(160,title.length())));}}}catch(Exception e){toast("Could not scan right-side videos. Try again.");return;}
            if(links.isEmpty()){toast("No loaded right-side videos found. Wait for the list or scroll it, then scan again.");return;}
            startActivity(new Intent(this,YouTubeDownloadsActivity.class).putStringArrayListExtra("batch_urls",links).putStringArrayListExtra("batch_titles",titles));
        });
    }
    void videoPicker(){Tab t=active();if(bulkAvailable(t)){new AlertDialog.Builder(this).setTitle("YouTube downloads").setItems(new String[]{"Download current video","Download loaded right-side videos"},(d,k)->{if(k==0)youtubeDownloader();else youtubeBulk();}).setNegativeButton("Cancel",null).show();return;}if(!privateMode()&&t!=null&&YouTubeLinks.canonical(t.url)!=null){youtubeDownloader();return;}if(t==null||!http(t.url)){toast("Open a video webpage first");return;}scanVideos(t,()->showVideos(t));}
    void showVideos(Tab t){if(active()!=t||isFinishing()||isDestroyed())return;
        LinearLayout panel=Ui.column(this);Ui.pad(panel,this,16);panel.setBackgroundColor(paper());
        panel.addView(Ui.text(this,"VIDEO DOWNLOAD  •  "+t.videos.size()+" FOUND",17,fg(),true));
        panel.addView(Ui.text(this,"Play a video and scan again for direct files, or open a single public video/Reel page in the video engine. Download only with permission.",13,muted(),false));
        ScrollView sc=new ScrollView(this);sc.addView(panel);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Download video").setView(sc).setNegativeButton("Close",null).setNeutralButton("Scan again",(d,i)->videoPicker()).create();
        if(!privateMode())panel.addView(Ui.button(this,"↓  Download from video page / paste link",palette().nav,palette().highlight,()->{dialog.dismiss();if(active()==t)siteVideoDownloader();}));
        for(VideoItem item:new ArrayList<>(t.videos)){
            String name=URLUtil.guessFileName(item.url,null,item.mime);String host=Objects.toString(Uri.parse(item.url).getHost(),"");
            LinearLayout box=Ui.column(this);Ui.pad(box,this,12);box.setBackground(Ui.surface(this,card(),14,line()));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=Ui.dp(this,10);panel.addView(box,lp);
            TextView title=Ui.text(this,name,15,fg(),true);title.setMaxLines(2);box.addView(title);box.addView(Ui.text(this,host+"  •  "+item.mime,12,muted(),false));
            box.addView(Ui.button(this,"↓  Download video",palette().nav,palette().highlight,()->{dialog.dismiss();if(active()==t)requestDownload(item.url,t.web.getSettings().getUserAgentString(),null,item.mime,-1);}));
        }
        if(t.videos.isEmpty())panel.addView(Ui.text(this,"No direct video link found yet. Try the video page option above (normal session), or use the site’s official download button.",14,muted(),false));
        dialog.show();
    }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    @Override public void onBackPressed(){if(full!=null){hideFull();return;}Tab t=active();if(t!=null&&t.web.canGoBack()){goHistory(t,-1);return;}if(!privateMode()){saveSession();finish();return;}if(t!=null&&!HOME.equals(t.url)){home();return;}if(tabs.size()>1){closeTab(current);return;}super.onBackPressed();}
    @Override protected void onDestroy(){videoHandler.removeCallbacks(downloadPoll);videoHandler.removeCallbacks(videoPoll);videoHandler.removeCallbacks(adPoll);uploadPicker.cancelAll();if(full!=null)hideFull();for(Tab t:tabs){if(privateMode()){t.web.clearCache(true);t.web.clearHistory();}ViewGroup p=(ViewGroup)t.web.getParent();if(p!=null)p.removeView(t.web);t.web.destroy();}if(privateMode()){CookieManager.getInstance().removeAllCookies(null);WebStorage.getInstance().deleteAllData();}super.onDestroy();}
}
