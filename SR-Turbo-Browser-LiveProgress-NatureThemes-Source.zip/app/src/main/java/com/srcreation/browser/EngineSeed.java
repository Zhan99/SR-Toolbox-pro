package com.srcreation.browser;

import java.io.*;
import java.nio.file.*;
import java.security.MessageDigest;

/** Installs the build-pinned, verified upstream zipimport artifact, never a remote executable at runtime. */
final class EngineSeed {
    static final String VERSION="2026.11.23";
    static final String SHA256="e8665ed64d6b9172773e812f891fb707a0cb1ee8d9ef4fc1acb00cabee4c5256";
    interface Source { InputStream open() throws IOException; }
    static String hash(File file) throws Exception {
        MessageDigest md=MessageDigest.getInstance("SHA-256");
        try(InputStream in=new FileInputStream(file)) { byte[] b=new byte[65536]; int n; while((n=in.read(b))!=-1) md.update(b,0,n); }
        StringBuilder out=new StringBuilder(64); for(byte b:md.digest()){int v=b&255;out.append(Character.forDigit(v>>>4,16)).append(Character.forDigit(v&15,16));}return out.toString();
    }
    static boolean install(File target, Source source, String expected, boolean force) throws Exception {
        if(!force && target.isFile() && expected.equals(hash(target))) return false;
        File parent=target.getParentFile(); if(!parent.isDirectory()&&!parent.mkdirs())throw new IOException("Cannot create engine directory");
        File tmp=File.createTempFile("engine-", ".tmp", parent);
        try {
            try(InputStream in=source.open(); FileOutputStream out=new FileOutputStream(tmp)) {
                byte[] b=new byte[65536]; int n; long count=0; while((n=in.read(b))!=-1){count+=n;if(count>16*1024*1024)throw new IOException("Engine exceeds size limit");out.write(b,0,n);}out.getFD().sync();
            }
            if(!expected.equals(hash(tmp))) throw new IOException("Engine SHA-256 verification failed; rebuild with the official verified artifact.");
            Files.move(tmp.toPath(),target.toPath(),StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);
            return true;
        } finally { if(tmp.exists())tmp.delete(); }
    }
}
