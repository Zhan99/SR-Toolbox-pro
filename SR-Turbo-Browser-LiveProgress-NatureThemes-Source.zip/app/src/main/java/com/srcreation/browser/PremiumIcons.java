package com.srcreation.browser;
import android.graphics.drawable.Drawable;
import android.widget.TextView;
import android.view.Gravity;
final class PremiumIcons {
 static void apply(TextView v,String key,int color,int size){int res;switch(key){case "‹":res=R.drawable.premium_back;break;case "›":res=R.drawable.premium_forward;break;case "⌂":res=R.drawable.premium_home;break;case "+":res=R.drawable.premium_add;break;case "↓":res=R.drawable.premium_download;break;case "↻":res=R.drawable.premium_reload;break;case "⬡":res=R.drawable.premium_shield;break;case "⚡":res=R.drawable.premium_bolt;break;case "▶":res=R.drawable.premium_play;break;case "▦":res=R.drawable.premium_grid;break;case "⌕":res=R.drawable.premium_search;break;case "◷":res=R.drawable.premium_history;break;case "☆":res=R.drawable.premium_star;break;case "★":res=R.drawable.premium_star;break;case "▣":res=R.drawable.premium_screen;break;case "▯":res=R.drawable.premium_mobile;break;case "✦":res=R.drawable.premium_theme;break;case "↗":res=R.drawable.premium_share;break;case "⚙":res=R.drawable.premium_settings;break;case "⇩":res=R.drawable.premium_download;break;case "↧":res=R.drawable.premium_download;break;case "▤":res=R.drawable.premium_screen;break;default:return;}
 Drawable d=v.getContext().getDrawable(res).mutate();d.setTint(color);int px=Ui.dp(v.getContext(),size);d.setBounds(0,0,px,px);v.setText("");v.setGravity(Gravity.CENTER);v.setCompoundDrawables(null,d,null,null);v.setContentDescription(key);
 }
}
