package com.srcreation.browser;

import java.time.LocalDate;
import java.util.Locale;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/** Pure Java policy for checking the actual executable, not its cached release tag. */
final class VideoEnginePolicy {
    private static final Pattern VERSION=Pattern.compile("(?m)^\\s*(\\d{4})\\.(\\d{2})\\.(\\d{2})(?:\\.\\d+)?\\s*$");
    private static final LocalDate MINIMUM=LocalDate.of(2026,10,26);
    static String version(String output){
        if(output==null)return "";
        Matcher m=VERSION.matcher(output);if(!m.find())return "";
        String v=m.group().trim();return date(v)==null?"":v;
    }
    private static LocalDate date(String v){
        try{return LocalDate.parse(v.substring(0,10).replace('.','-'));}catch(Exception e){return null;}
    }
    static boolean outdated(String v, LocalDate today){LocalDate d=date(v);return d==null||d.isBefore(MINIMUM)||d.isBefore(today.minusDays(90));}
    static boolean needsCheck(String v,LocalDate today,long now,long previous){return outdated(v,today)||previous<=0||now<previous||now-previous>=86400000L;}
    static boolean forbidden(String text){String s=text.toLowerCase(Locale.ROOT);return s.contains("http error 403")||s.contains("403 forbidden")||s.contains("403: forbidden");}
    static String error(String text){
        if(forbidden(text))return "YouTube rejected the media request (HTTP 403). The server refused this request. If the bundled engine is current, use YouTube's official download options; repairing the same engine cannot override server permissions.";
        String s=text.toLowerCase(Locale.ROOT);
        if(s.contains("sabr"))return "YouTube did not provide a compatible downloadable format (SABR). Some videos cannot be saved; a newer verified APK may be needed.";
        if(s.contains("python")&&(s.contains("version")||s.contains("unsupported")))return "Video engine runtime may be incompatible. A newer Android engine build is required.\n"+text;
        return text;
    }
}
