package com.srcreation.browser;

import java.util.*;
import java.net.URI;

/** Snapshot of already loaded right-rail video links. No auto-scroll or playlist expansion. */
final class YouTubeBulk {
    static final int MAX=500;
    static boolean watchPage(String url) {
        try { URI u=new URI(url); return "https".equalsIgnoreCase(u.getScheme()) && "www.youtube.com".equalsIgnoreCase(u.getHost()) && "/watch".equals(u.getPath()) && YouTubeLinks.canonical(url)!=null; }
        catch(Exception e){return false;}
    }
    static ArrayList<String> normalize(Collection<String> links) {
        LinkedHashSet<String> out=new LinkedHashSet<>();
        if(links!=null)for(String s:links){String link=YouTubeLinks.canonical(s);if(link!=null)out.add(link);if(out.size()>=MAX)break;}
        return new ArrayList<>(out);
    }
    static String folder(String id) {return "Download/SR Turbo/YouTube/Batch-"+id;}
    // The page is already open. Read only rendered link elements within its right-hand rail.
    static final String SCAN="(function(){if(location.origin!=='https://www.youtube.com'||location.pathname!=='/watch')return [];var rail=document.querySelector('ytd-watch-flexy #secondary');if(!rail)return [];var out=[],seen=new Set();for(var a of rail.querySelectorAll('a[href]')){if(!a.getClientRects().length||a.closest('[hidden],ytd-ad-slot-renderer,ytd-promoted-sparkles-web-renderer,ytd-display-ad-renderer,ytd-in-feed-ad-layout-renderer'))continue;var item=a.closest('ytd-compact-video-renderer,ytd-playlist-panel-video-renderer,yt-lockup-view-model,ytd-reel-item-renderer,ytm-shorts-lockup-view-model,yt-shorts-lockup-view-model');if(!item)continue;try{var u=new URL(a.href,location.href);if(u.origin!==location.origin)continue;var id=u.pathname==='/watch'?u.searchParams.get('v'):(u.pathname.match(/^\\/shorts\\/([A-Za-z0-9_-]{11})\\/?$/)||[])[1];if(!id||!(/^[A-Za-z0-9_-]{11}$/).test(id)||seen.has(id))continue;seen.add(id);var title=item.querySelector('#video-title, #video-title-link, .yt-lockup-metadata-view-model__title, [role=heading]');var text=(title?(title.getAttribute('title')||title.textContent):'')||a.getAttribute('aria-label')||a.getAttribute('title')||id;out.push({url:'https://www.youtube.com/watch?v='+id,title:text.trim().slice(0,160)});if(out.length>=500)break;}catch(e){}}return out;})()";
    private YouTubeBulk(){}
}
