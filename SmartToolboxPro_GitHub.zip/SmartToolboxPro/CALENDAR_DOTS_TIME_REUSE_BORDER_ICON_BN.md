# SR Smart Toolbox Pro — 1.5.16-alpha42

## ১. WhatsApp Scheduler-এর ক্যালেন্ডারে ডট
- Scheduler-এর **তারিখ (📅)** বাটনে চাপলে নতুন Month Calendar খুলবে। আগের/পরের মাসে যেতে `‹` ও `›` আছে।
- যে তারিখে কোনো **সংরক্ষিত Scheduler Message বা History** আছে, তারিখের নিচে **●** ডট দেখাবে।
- Single বা Group-এর সদস্যভিত্তিক রেকর্ড, এবং পুনরাবৃত্ত শিডিউলের `lastTriggeredAtMillis` থাকলে সেটির দিনও চিহ্নিত হবে।
- ডট মানেই WhatsApp-এ ডেলিভার হয়েছে এমন নয়; এটি শুধু **অ্যাপে থাকা রেকর্ড** বোঝায়। রেকর্ড স্থায়ীভাবে Delete করলে সেই রেকর্ড থেকে আর ডট আসবে না।
- ক্যালেন্ডারে তারিখ ট্যাপ করলে শুধু তারিখ বদলাবে—**ঘণ্টা/মিনিট একই থাকবে**।

## ২. পুরোনো মেসেজ Edit/Reuse
- **Edit / Reuse** চাপলে History-এর মেসেজ ও নম্বর নতুন Schedule Form-এ আসবে; পুরোনো History ও Send Attempt Record অপরিবর্তিত থাকবে।
- আগের সময় ৬:৩০ PM হলে একই **৬:৩০ PM** রাখা হবে।
- আজ সেই সময় এখনো ভবিষ্যতে থাকলে **তারিখ আজ** হবে। যদি ইতিমধ্যে সময় পেরিয়ে যায়, পরের দিন হবে, যাতে অতীতের Alarm সেভ না হয়।
- Group Name, নম্বর, মেসেজ, Time, Date, Repeat—সব আগের মতো ম্যানুয়ালি পরিবর্তন করা যাবে।
- Pending Item-এর Edit-এও পুরোনো দিন চলে গেলে একই নিয়ম প্রযোজ্য; ভবিষ্যতের শিডিউল অপরিবর্তিত থাকে।

## ৩. Floating Icon ডিসপ্লের বর্ডারে
- আগে মতো **Floating Icon Settings → Keep floating icon at the screen border when idle** ON (ডিফল্ট ON) থাকলে এবং Overlay Permission থাকলে আইকন Idle অবস্থায় **বাম বা ডান ডিসপ্লে কিনারায়** থাকবে; Portrait ও Landscape দুটোতেই।
- Quick Controls খুললে সাময়িকভাবে বড় আইকন/মেনু দেখা যাবে। Menu বন্ধ হলে Edge Tab-এ ফেরত যাবে।
- **২ সেকেন্ড চেপে ধরে Drag** করলে ম্যানুয়াল অবস্থান Save হবে এবং পরে স্বয়ংক্রিয় Edge Mode সেই অবস্থান পরিবর্তন করবে না। Edge Tab-কে ধরে টানলেও Release-এর পর পূর্ণ Floating Icon নির্বাচিত অবস্থানে থাকবে।
- আগের স্বয়ংক্রিয় Border আচরণ ফেরাতে **Floating Icon Settings → ↩ Reset icon to screen border** চাপুন।
- Floating Overlay বন্ধ থাকলে নিজে থেকে চালু হবে না; System Navigation/Protected Screen-এ Android Overlay সীমাবদ্ধতা আছে।

## পরীক্ষা
- `SchedulerCalendarLogicTest`: ১৫টি case PASS।
- `FloatingBoundaryPolicyTest`: ১৪টি case PASS।
- আগের Test-সহ GitHub Workflow-এর ৩০টি স্থানীয় Source/Logic যাচাই PASS।
- Java AST Syntax, XML Parse, YAML এবং Bash Syntax PASS।
- Android SDK/Gradle ও বাস্তব ফোন না থাকায় সম্পূর্ণ APK Build এবং Live Overlay Touch/Alarm Test এখানে করা হয়নি।
