# SR Smart Toolbox Pro — Night Screen v1.5.10-alpha36

## নতুন ফিচার
- Night Screen **ON** করলে স্ক্রিনের ওপর Black/Warm Overlay থাকবে এবং **Modify System Settings** অনুমতি থাকলে Android-এর Physical Screen Brightness সর্বনিম্ন নথিভুক্ত মান `1/255`-এ নামানো হবে। Android API-তে সেটিংটির documented minimum `1` (০ নয়); ০ দিলে স্ক্রিন ব্যবহার অনিরাপদ/অসম্ভব হতে পারে।
- Auto Brightness আগে চালু থাকলে সাময়িকভাবে Manual Mode করা হয়; Night Screen বন্ধ করার সময় **আগের Brightness ও আগের Auto-Brightness Mode ফিরিয়ে দেওয়া হয়**। একাধিক Overlay Update আগের সংরক্ষিত Brightness মুছে দেয় না।
- ব্যবহারকারী Night Screen চালু অবস্থায় নিজে Brightness বা Auto Brightness বদলে দিলে **নতুন সেটিংটি প্রাধান্য পায়**, পুরোনো Snapshot দিয়ে সেটি ওভাররাইড করা হয় না।
- Permission না দিলে System Brightness পরিবর্তন হবে না; কেবল Black Overlay কাজ করবে। অ্যাপ কোনো Permission নিজে থেকে Grant করে না।
- Night Screen Screen-এর নিজস্ব Status Bar এবং Navigation Bar কালো হয়। **অন্য অ্যাপের Notification Shade/Status Bar একটি সাধারণ অ্যাপ জোর করে কালো করতে পারে না**; System Brightness কমালে সেই অংশের ব্যাকলাইটও কমে। Android-এর Protected/System UI সবসময় আলাদা।
- Android 12+ এ Input Pass-through কাজ করার জন্য Black Overlay Window-এর সর্বোচ্চ Opacity `0.78` রাখা হয়েছে। UI-র 0–95% Dimming Slider আগের মতো আছে; Combined Effective Dimming ও Brightness ডিভাইসভেদে পরিবর্তিত হবে।
- Foreground Notification-এ **Turn off & restore** অ্যাকশন আছে; Night Screen Screen-এর **Turn off** ও Floating Control-ও আগের মতো কাজ করে।
- Lock Screen আনলক করা, Notification Access বা ফোনের System UI নিয়ন্ত্রণ করার চেষ্টা করা হয় না।

## চালু করার নিয়ম
১. SR Smart Toolbox Pro → Night Screen খুলুন।
২. **Display over other apps** অনুমতি দিন (Black Overlay প্রয়োজন)।
৩. **Lower the phone brightness while Night Screen is ON** ON রাখুন।
৪. **Grant Modify system settings permission** বাটন থেকে Android Settings-এ গিয়ে অনুমতি দিন। এটি ঐচ্ছিক, তবে Physical Brightness কমাতে দরকার।
৫. Night Screen → **Start dimming** চাপুন। Floating Icon অথবা Night Screen Notification থেকে Off করতে পারবেন।
৬. Off করলে আগের Brightness ও Auto Brightness ফিরতে চেষ্টা করবে। Permission মাঝপথে বাতিল করলে পরে আবার অনুমতি দিতে হতে পারে।

## GitHub APK Build
`SmartToolboxPro_GitHub.zip` এবং `.github/workflows/build-apk.yml` নতুন Release থেকে Upload করুন। Commit → Actions → `Build SR Smart Toolbox Pro APK`।

## QA
- NightBrightnessPolicyTest: ২১টি PASS।
- NightBrightnessControllerTest (Android Settings-এর JDK Stubs): ২৯টি PASS।
- আগের সব ফিচারসহ ২৪টি স্থানীয় GitHub Actions Source/Unit Validation Step PASS।
- ৫৯টি App Java Source AST Syntax Check PASS, ৬টি Android XML Parse PASS।
- Source ZIP, Workflow YAML ও ZIP-only GitHub Extraction Test PASS (Release Packaging-এ)।
- **পূর্ণ Gradle APK Build ও ফোনের বাস্তব Brightness/Status Bar পরীক্ষা হয়নি।** Android SDK/Gradle অনুপস্থিত।
