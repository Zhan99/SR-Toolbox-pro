# SR Smart Toolbox Pro — 1.5.20-alpha46

## ১. Battery Full Voice — Ringtone Volume
- Battery Full Voice-এ বাংলা, English এবং দুটো ভাষার অপশন আগের মতো থাকবে।
- Offline WAV MediaPlayer এবং Device TTS—**দুই পথেই** `AudioAttributes.USAGE_NOTIFICATION_RINGTONE` ব্যবহৃত হয়েছে; ফলে ফোনের Ringtone Volume ও Sound Mode অনুযায়ী অডিও চলার চেষ্টা করবে।
- **অ্যাপ নিজে রিংটোন ভলিউম বাড়ায় না।** Silent, Vibrate, Do Not Disturb বা OEM volume mapping থাকলে অডিও নিঃশব্দ হতে পারে।
- `Full Charge Voice Alert` স্ক্রিনে ফোনের Volume Button Ringtone Stream নিয়ন্ত্রণ করবে।
- একটি আলাদা notification sound বাজিয়ে দুইবার শব্দ হওয়া এড়াতে বর্তমান silent notification channel রক্ষা করা হয়েছে।

## ২. Floating Sidebar — Portrait + Landscape Border
- গোল Icon নির্ধারিত Idle Time শেষে Vertical Edge Bar হবে—**Portrait ও Landscape দুই মোডেই**।
- Edge Bar সর্বদা বাম অথবা ডান ডিসপ্লে বর্ডারে থাকবে, মাঝখানে ভেসে থাকবে না।
- ২ সেকেন্ড Hold করে Tab Drag করলে নতুন উচ্চতা ও পছন্দের সাইড নির্বাচন করা যাবে; আঙুল ছাড়লে সেই বর্ডারে লেগে থাকবে।
- Screen rotation হলে Tab স্বয়ংক্রিয়ভাবে নতুন Display Width/Height অনুযায়ী সরে যাবে।
- পূর্ণ Bubble Icon-এর আগের Tap/Swipe, Manual Move, Idle Timer, Swipe/Hold Vibration এবং Quick Controls সংরক্ষিত।
- Android বিশেষ/সুরক্ষিত Screen-এ Overlays লুকিয়ে রাখতে পারে।

## ৩. WhatsApp Scheduler — Show / Hide Calendar
- Scheduler-এর **আজকের মেসেজ** সবসময় থাকবে।
- Calendar-এর পাশে `▴ Hide / ▾ Show` বাটন থাকবে। পছন্দ অ্যাপের SharedPreferences-এ সংরক্ষিত হবে।
- Show থাকলে আগের মতো ● ডটসহ পুরোনো/ভবিষ্যতের তারিখ ও ঐ দিনের মেসেজ দেখা যাবে।
- Hide করলে Calendar ও নির্বাচিত অতীত/ভবিষ্যৎ দিনের তালিকা লুকাবে; মেসেজ, Group History অথবা Alarm কিছুই মুছবে না।

## ৪. QR / Barcode — Gallery থেকে Scan
- QR Scanner পেজে দুটি বাটন: **Scan QR/Barcode (Camera)** এবং **Choose Image from Gallery**।
- Android Documents/Gallery Picker থেকে একটি `image/*` ফাইল নির্বাচন করে On-device ML Kit `17.3.0` দিয়ে QR/Barcode পড়া হবে।
- ছবি না পড়া গেলে, কোনো কোড না থাকলে অথবা মেসেজ না থাকলে পরিষ্কার Error Message দেখাবে।
- একটি কোডের Result Copy, Share, এবং Web Link থাকলে Open করা যাবে।
- ব্যবহারকারী নিজে যে ছবিটি বাছবে, শুধু সেটিতে access; পুরো Photo Library অনুমতি প্রয়োজন নেই।
- Gallery Decoder Bundled; Camera Scan-এর Google Code Scanner আগের মতো চলবে।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- **Android SDK ও Gradle এখানে নেই:** পূর্ণ APK Build বা বাস্তব ফোনে QR/Barcode, Battery Volume, Overlay Orientation পরীক্ষিত হয়নি। GitHub Actions-এ Build এবং ফোনে পরীক্ষা করতে হবে।
- মেসেজ ডেলিভারি কিংবা QR স্ক্যানের সফলতা নিশ্চিত বলা হচ্ছে না; এগুলো ডিভাইস, ছবির মান, Android UI ও অনুমতির ওপর নির্ভর করে।
