# SR Smart Toolbox Pro v1.5.23-alpha49 — Video Player Removal & Sidebar Input Fix

## কী বাদ দেওয়া হয়েছে
- SR Video Player, Video Library, Folder browsing, subtitles, gesture zoom, NEW badge, watch progress, playback speed, PiP, background playback, Media3 dependency এবং MediaSession Service।
- Home card, floating menu shortcut, Video Player settings এবং Video Player-এর জন্য প্রয়োজনীয় Android permissions।
- পুরোনো ফোনের ভিডিও ফাইল **ডিলিট করা হয় না**; শুধু অ্যাপের ভিডিও প্লেয়ার কোড সরানো হয়েছে।
- QR/Barcode Scanner-এর Gallery Scan আগের মতো থাকবে: সেটি ফোন থেকে ছবি বাছার মাধ্যমে কাজ করে, Video Player-এর ওপর নির্ভর করে না।

## Swipe-only Floating Sidebar
- Floating Settings-এ Swipe to Open ON করলে লম্বালম্বি Hidden Bar শুধু Swipe-এ খুলবে; Tap to Open-ও ON থাকলেও Hidden Bar Tap-এ খুলবে না। Bubble-এর Tap আগের মতো আলাদা সেটিং মানবে।
- পূর্বে Bar-এর বাইরে 44dp অদৃশ্য Touch Target ছিল; এখন Bar-এর দৃশ্যমান প্রস্থের সমান ছোট Overlay Window। ফলে পাশের ডিসপ্লে ট্যাপ আগের মতো Android/App-এ পৌঁছাবে।
- বারের ঠিক ওপর Tap করলে Android Overlay তা গ্রহণ করবে কিন্তু মেনু খুলবে না; Android-এর নিরাপত্তা-সীমার কারণে সেই স্পর্শ নিচের অ্যাপে পুনরায় পাঠানো সম্ভব নয়।
- বিদ্যমান Side, Height, 2-second Hold-and-Drag, Portrait/Landscape Alignment ও Auto-Hide সংরক্ষিত।

## Independent global Sound/Vibration
Home → ⋮ → Premium / Classic & Sounds →
- Interface Sound: ON/OFF — অ্যাপের UiSound cues।
- Interface Vibration: ON/OFF — বাটন, পেজ Back, Home Tool Cards, Sidebar Swipe, 2s Hold-Drag feedback।
- Floating-specific Swipe Vibration / Hold Vibration সুইচও আগের মতো থাকবে; Global OFF থাকলে সেগুলোও বন্ধ।
- Android System Haptic Feedback OFF থাকলে অ্যাপ কম্পন দেবে না।
- Battery Full Voice Alert ও Video ছাড়া বাকি টুলের অডিও সিস্টেম আলাদা। Interface Sound OFF করলে Battery Alert বন্ধ হবে না।

## GitHub Build
`SmartToolboxPro_GitHub.zip` এবং `.github/workflows/build-apk.yml` আপলোড করে Actions → Build SR Smart Toolbox Pro APK চালাও।
এই পরিবেশে Android SDK/Gradle না থাকলে এখানে পূর্ণ APK Build যাচাই সম্ভব নয়।
