# SR Smart Toolbox Pro — Scheduler Inbox Update

**Version:** 1.5.6-alpha32 (versionCode 32)

## নতুন Folder-Style Schedule Inbox
WhatsApp Smart Scheduler-এর নিচের দীর্ঘ Schedule List এখন পাঁচটি ভাঁজযোগ্য বিভাগে সাজানো:

1. 📅 **আজকের শিডিউল** — আজকের বাকি `pending` শিডিউল।
2. 🌅 **আগামীকালের শিডিউল** — আগামী দিনের `pending` শিডিউল।
3. 🗂 **পরবর্তী দিনের শিডিউল** — আগামীকালের পরের দিনগুলো।
4. 🕓 **সময় পেরিয়েছে / History** — শেষ হওয়া (`done`), পাঠানোর চেষ্টা (`attempted`), সময় হওয়া (`due`) এবং সময় পার হয়ে গেলেও `pending` থাকা মেসেজ। **এতে সব মেসেজ ডেলিভার হয়েছে, এমন বোঝায় না।**
5. ⏸ **বিরতিতে থাকা শিডিউল** — `paused` অবস্থা; প্রয়োজনে Edit দিয়ে সময়/অনুমতি ঠিক করুন।

প্রতিটি ফোল্ডারে মেসেজের সংখ্যা ও খুলে/বন্ধ করার চিহ্ন থাকবে। প্রথমবার আজকের ফোল্ডার খোলা, অন্যগুলো বন্ধ থাকবে। কোন ফোল্ডার খোলা/বন্ধ রেখেছেন তা অ্যাপে সংরক্ষিত হবে। ফোল্ডার খুললে আগের মতো নাম/নম্বর, Group Name, Message Preview, সময় ও Live Countdown এবং Edit, Delete, WhatsApp ও History Reuse-এর বাটন দেখা যাবে।

- ফোনের **বর্তমান স্থানীয় তারিখ** অনুযায়ী Today ও Tomorrow হিসাব হয়।
- দিনের সীমানা পেরোলে, শিডিউল Overdue হলে, অথবা Status পরিবর্তন হলে খোলা Scheduler Screen-এ ফোল্ডারের হিসাব আপডেট হয়।
- পূর্ববর্তী `items_json` স্টোরেজের Schema/Alarm ID পরিবর্তন করা হয়নি; পুরোনো সেভ করা Schedule ও Group তথ্য সংরক্ষিত থাকবে।
- এটি শুধু **ইউজার ইন্টারফেসের সংগঠন**; Message Send/Alarm/Accessibility সংক্রান্ত আগের আচরণ বদলায় না।

## যাচাই
- `SchedulerSectionLogicTest`: 28 assertions passed, including local midnight, year boundary and DST cases.
- GitHub Workflow-এর source/unit verification: 20 local steps passed.
- Source ZIP ও Workflow integrity verified.
- **Android SDK/Gradle build এবং বাস্তব ফোনে UI পরীক্ষা এখানে করা হয়নি।** GitHub Actions-এ `:app:assembleDebug` সফল হলে APK পাওয়া যাবে।
