# SR Smart Toolbox Pro — 1.5.19-alpha45

## Floating Icon (Home → Floating Icon Settings)
- **Auto-hide into vertical edge bar**: ON থাকলে ১–৬০ সেকেন্ডের পছন্দের সময় শেষে গোল ST Icon স্ক্রিনের বাম/ডান কিনারায় একটি লম্বালম্বি Edge Bar-এ সরে যাবে।
- Menu খোলা থাকলে Menu-এর নিজস্ব ৩ সেকেন্ড idle-close নিয়ম বজায় থাকবে। Menu বন্ধ হওয়ার পর Floating Icon-এর আলাদা Auto-hide Delay শুরু হবে। 
- **Tap to Open** এবং **Swipe to Open** আগের মতো স্বাধীন সেটিং। Swipe Haptics পূর্বের মতো।
- **2-second Hold vibration**: আঙুল টানা ২ সেকেন্ড না নড়িয়ে চেপে রাখলে একটি ছোট ভাইব্রেশন হবে, তারপর Drag করা যাবে। সাধারণ Tap বা দ্রুত Swipe-এ এই Long-Hold Vibration বাজবে না। ফোনে হ্যাপটিক সুবিধা/সিস্টেম সেটিংসের ওপর নির্ভর করে।
- **Vertical edge bar height**: ৬৪–১৩৬ dp। Width আগের Slider থেকে পরিবর্তন করা যায়। এটি ছোট লম্বালম্বি ট্যাব, গোল ST Bubble নয়।
- **Toolbox Box Width**: ১৭৬–৪৪০ dp। **Height**: ১৮৫–৭৬০ dp। ছোট Box-এ কন্ট্রোলগুলো ভেতরে স্ক্রল করা যাবে।
- হাতে Hold+Drag করার পর নির্বাচিত অবস্থান মনে রাখা হয়। নির্ধারিত সময় পরে Edge Bar হয়; পুনরায় খুললে সংরক্ষিত জায়গায় Icon দেখা যায়।

## WhatsApp Scheduler (ক্যালেন্ডার)
- নিচে শুধু **আজকের মেসেজ** এবং **সবসময় দৃশ্যমান Month Calendar**।
- অতীত ও ভবিষ্যতের মেসেজ আলাদা লম্বা তালিকায় দেখানো হবে না; Calendar-এ মাস বদলে তারিখ ট্যাপ করলে নিচে ওই দিনের Message বা Group Card দেখা যাবে।
- Single Message ও Group Message-এর Scheduled Date এবং `lastTriggeredAtMillis` অনুযায়ী সংশ্লিষ্ট তারিখে **● ডট** হবে। ডট **ডেলিভারি নিশ্চিত করার চিহ্ন নয়**।
- আগের শিডিউলগুলোর JSON/Alarm ID অপরিবর্তিত। পূর্বের Edit/Reuse, Group Record, Phone Contacts, Scheduler Notepad, Auto Send চেষ্টা এবং History রেকর্ড বজায় আছে।

## পরীক্ষা ও সীমা
- Pure-Java FloatingIdleLogic: ১৫টি Test PASS; SchedulerInboxLogic: ১৪টি Test PASS।
- GitHub Actions স্থানীয় Source/Unit ধাপ: ৩৩টি PASS; Java AST ৮৮টি সোর্স PASS; Android XML ছয়টি parse PASS।
- সম্পূর্ণ APK Build, Overlay gesture ও Calendar-এর বাস্তব ফোনে UI পরীক্ষা এখানে করা হয়নি।
- Android নিরাপত্তা, OEM Full-Screen Overlay এবং System Navigation Gesture-এর কারণে কিছু স্ক্রিনে Floating Bar প্রদর্শন/স্পর্শ সীমিত হতে পারে।
