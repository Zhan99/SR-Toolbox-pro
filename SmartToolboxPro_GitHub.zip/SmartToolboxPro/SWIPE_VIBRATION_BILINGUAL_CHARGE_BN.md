# SR Smart Toolbox Pro — Swipe Vibration & Bengali/English Charge Alert

**সংস্করণ:** `1.5.18-alpha44` (`versionCode 44`)

## 📳 Floating Icon: Swipe Vibration
- Home → ⋮ → Floating Icon Settings → **📳 Swipe Vibration — vibrate when swipe opens menu**।
- Swipe to Open চালু রেখে Icon/Edge Tab-এর ওপর সফল Swipe দিয়ে Quick Controls খোলার সময় **একটি ছোট ভাইব্রেশন** হয়।
- **Tap-to-Open** বা **২ সেকেন্ড Hold + Drag**-এ ভাইব্রেশন দেওয়া হয় না।
- Swipe Vibration আলাদা ON/OFF; ডিফল্ট ON। Android System Haptic Feedback বন্ধ থাকলে এই ফিচারও ভাইব্রেট করবে না।
- কম্পন ডিভাইসের Vibrator Hardware, OS Settings, DND ও Overlay Permission-এর সীমাবদ্ধতার মধ্যে কাজ করে।
- `android.permission.VIBRATE` (Normal permission) যোগ করা হয়েছে। এর জন্য আলাদা Runtime Permission Prompt লাগে না। App Permissions পেজে কারণও দেখায়।

## 🔋 Battery Full Voice Alert: Bengali / English / Both
- Home → ⋮ → Full Charge Voice Alert → **Alert voice language**।
- তিনটি ভাষা: **বাংলা**, **English**, **বাংলা + English (both)**।
- Bengali: “ব্যাটারি ফুল চার্জ হয়েছে, চার্জ থেকে খুলুন।”
- English: “The battery is fully charged. Please unplug your charger.”
- BOTH বেছে নিলে Notification bilingual হবে এবং অফলাইনে প্রথমে বাংলা, পরে English বাক্য শোনা যাবে।
- Notification-এর Full Alert Title, Text, চলমান Monitoring Title ও Stop Action ভাষা অনুযায়ী বদলায়।
- **Prefer best available phone voice (TTS)** সুইচ ডিফল্ট ON; ফোনে উন্নত মানের *ইনস্টল করা অফলাইন* ভয়েস থাকলে সেটি ব্যবহার হবে। না থাকলে অ্যাপের ভিতরে থাকা অফলাইন Bengali/English WAV চালু হয়। BOTH মোডে দুই আলাদা অফলাইন রেকর্ডিং বাজে যাতে এক ভাষার TTS অন্য ভাষাকে ভুলভাবে না পড়ে।
- **Voice Preview** থেকে বাছাই করা ভাষার সতর্কবার্তা শুনতে পারবেন। Silent/DND/Alarm Volume ও OEM Battery Restriction-এর প্রভাব থাকতে পারে।
- আগের মতো চার্জ ১০০% হলে একই চার্জিং সেশনে **একবারই** সতর্ক করবে; চার্জার খুলে আবার লাগালে নতুন সেশন গণ্য হবে।
- অফলাইন English fallback একটি synthesised voice। কোন ফোনে কতটা natural voice পাওয়া যাবে, সেটি ফোনের TTS engine ও ইনস্টল করা voice package-এর ওপর নির্ভর করে; মানবকণ্ঠের সমান মানের নিশ্চয়তা দেওয়া যায় না।

## অপরিবর্তিত
- WhatsApp Scheduler, Notepad, Group Cards, Calendar Dots, Premium/Classic Theme, ২ সেকেন্ড Hold-to-Move, Apps Backup, Night Screen, Video Player, আগের ১৬টি UI Sound এবং সব Permissions-এর অন্যান্য ব্যবস্থা সোর্সে সংরক্ষিত।

## যাচাই ও সীমাবদ্ধতা
- GitHub Actions workflow-এর **৩২টি স্থানীয় Source/Unit যাচাই** পাস।
- Java compiler AST syntax/duplicate-field verifier: **৮৪টি Java ফাইল পাস**।
- নতুন হ্যাপটিক Logic: ৭ Test; ভাষা/Notification Text Logic: ২৪ Test; **৩১টি নতুন Test পাস**।
- Android XML: ৬টি পার্স হয়েছে; ১৯টি Manifest Permission App Permissions-এর ব্যাখ্যার সঙ্গে মিলে।
- Bengali WAV: ৪.৭ সেকেন্ড; English WAV: ৪.২ সেকেন্ড। উভয়ের Mono 16-bit PCM ফরম্যাট যাচাই হয়েছে।
- **পূর্ণ `:app:assembleDebug` ও বাস্তব ডিভাইসে Test এই পরিবেশে হয়নি**—Android SDK ও Gradle ইনস্টল নেই। GitHub Actions Build ও ফোনে পরীক্ষা প্রয়োজন।
