# SR Smart Toolbox Pro — Apps Backup & Restore

**Version:** `1.5.14-alpha40` · **Developer:** Shahriar Rahman · **Brand:** SR Creation Farm

## ১. কী যুক্ত হয়েছে

Home Screen এবং ⋮ Menu-তে **📦 Apps Backup & Restore** সেকশন।

- ফোনে ইনস্টল করা অ্যাপগুলোর Original Launcher/App Icon, App Name, Package Name, Version, **APK File Size**, Last Update Date।
- **All / User Apps / System Apps** ফিল্টার; ডিফল্টে All।
- App Name বা Package Name দিয়ে Search, Refresh, একাধিক অ্যাপ Selection, **Select All (বর্তমান ফিল্টারে দেখানো অ্যাপ)** ও **Deselect All**।
- **Backup Selected:** ফোনের Internal Storage/SD card-এর নিজে বাছা ফোল্ডারে সরাসরি original `.apk` / `.apks` সংরক্ষণ।
- **Share Selected:** মূল APK ফাইল(গুলো) Android-এর Sharing Sheet-এ পাঠানো।
- **Uninstall Selected:** শুধু User App; **প্রতিটি অ্যাপের জন্য Android-এর Uninstall Confirmation**; বাতিল করলে পরের অনুরোধ বন্ধ। নিজের অ্যাপ ও System Apps বাদ থাকবে।
- **Restore Saved:** `.apk` বা `.apks` ফাইল বেছে Android-এর Install Confirmation দিয়ে ইনস্টল; নির্বাচিত ফোল্ডারের Backup List থেকেও Restore।
- Premium/Classic, Night Screen, Scheduler, Group Cards, Notepad, Video Player, Floating Controls এবং Branding কোড অপরিবর্তিত রাখা হয়েছে।

## ২. সঠিক Original APK Backup ফরম্যাট

**Single/Monolithic APK:** `com.example.app_v2_... .apk` নামের ফাইলে ফোনে ইনস্টল থাকা **মূল `base.apk` বাইট-অপরিবর্তিত** কপি হয়। APK Rebuild, Resign বা Recompile করা হয় না।

**Split APK / App Bundle:** `com.example.app_v2_... .apks` ফাইল আসলে একটি ZIP Archive। এর মধ্যে থাকবে মূল `base.apk`, প্রতিটি ইনস্টল করা `split_000.apk`, `split_001.apk` ইত্যাদি এবং `info.json`। **শুধু `base.apk` Backup করে ভুলভাবে `.apk` বলা হচ্ছে না।** এই `.apks` সরাসরি সাধারণ APK Installer-এ ট্যাপ করে ইনস্টল করা যাবে না; অ্যাপের **Restore** অপশন ব্যবহার করতে হবে। Restore Android PackageInstaller Session দিয়ে সব অংশ একসঙ্গে ইনস্টল করে; Android Signatures/Compatibility যাচাই করে। কিছু অ্যাপ/OS-এ Restore ব্যর্থ হতে পারে।

**খুব গুরুত্বপূর্ণ:** এটি **APK Install File Backup**, কোনো অ্যাপের Private Data, Login, WhatsApp Chat, Files, Database বা Android Account Backup নয়। কিছু System/Protected অ্যাপের APK পড়া যায় না; তখন Backup ব্যর্থ হিসেবে দেখানো হবে।

## ৩. ব্যবহার

1. **📦 Apps Backup & Restore** খুলুন। প্রথমবার ইনস্টল করা অ্যাপগুলো Load হবে।
2. User বা System ফিল্টার, Search, Check Box অথবা Select All ব্যবহার করুন।
3. **Choose memory / SD-card folder** চাপুন, Android File Picker-এ আপনার পছন্দের ফোল্ডার নির্বাচন করুন। এই Folder Permission সংরক্ষিত থাকবে।
4. **Backup selected APKs** চাপুন। ব্যর্থ হলে Error Summary দেখা যাবে। `.apk` / `.apks` ফাইল নির্বাচিত ফোল্ডারে থাকবে।
5. **Share original APKs** চাপলে Android Share Sheet খুলবে।
6. **Uninstall selected apps** চাপলে Android একে একে User App-এর জন্য Confirmation দেখাবে। অনুমতি ছাড়া কিছু ডিলিট হবে না।
7. **Restore a saved .apk / .apks** অথবা Saved Backups-এর Restore চাপুন। Android প্রয়োজনে **Install unknown apps** অনুমতি চাইবে। `.apks` Restore চললে Package Installer Confirmation/Notification অনুমোদন দিন।

## ৪. Android Permission/Policy/সীমাবদ্ধতা

- `QUERY_ALL_PACKAGES` অ্যাপগুলোর পূর্ণ Inventory দেখানোর জন্য; Android 11+ package visibility অনুসারে প্রয়োজন হতে পারে। **Google Play-এ প্রকাশ করতে হলে Play Console-এর broad visibility policy ও Permission Declaration আলাদাভাবে পূরণ করতে হবে; অনুমোদন নিশ্চিত নয়।**
- `REQUEST_INSTALL_PACKAGES` শুধু User-initiated Restore-এর জন্য।
- `REQUEST_DELETE_PACKAGES` শুধু Android-confirmed Uninstall-এর জন্য।
- APK ফোল্ডারের জন্য Android Storage Access Framework (`ACTION_OPEN_DOCUMENT_TREE`) ব্যবহার করা হয়েছে; `MANAGE_EXTERNAL_STORAGE`/All Files Access দরকার নেই।
- Android/OEM নির্দিষ্ট সুরক্ষিত অ্যাপের APK পড়তে বা System Apps আনইনস্টল করতে বাধা দিতে পারে।
- APK Size হলো `.apk` এবং ইনস্টল করা Split APK-গুলোর মোট File Size; **App Data/Cache-সহ Android Settings-এ দেখানো সম্পূর্ণ Storage Size নয়**।
- Split Restore-এর সময় Android PackageInstaller Session এবং User Confirmation লাগে; অন্য Android Version/CPU/Signature বা missing required Dynamic Feature হলে Restore ব্যর্থ হতে পারে।
- APK Backup/Share ফোনে চলে; সেগুলো নিজের অজান্তে কোনো সার্ভারে আপলোড করা হয় না। Sharing অপশন ব্যবহার করলে আপনি নিজে প্রাপক/অ্যাপ নির্বাচন করেন।

## ৫. পরীক্ষা (সত্যিকারের ফলাফল)

- Pure Java Backup Policy — **৩৬টি Test PASS**।
- Single APK Binary Fidelity ও Split Archive Real-Byte Test — **১০টি Test PASS**।
- Pure Java/Source/Manifest-নির্ভর GitHub Workflow-এর **২৮টি স্থানীয় Test Step PASS**।
- **৭১টি Java ফাইলের AST Syntax ও Duplicate-Field Check PASS**।
- APK Output ZIP Integrity, Extracted-Project Source Test এবং Manifest/XML/Bash Syntax পরীক্ষা Release Packaging-এ করা হয়েছে।
- **পূর্ণ Android Gradle `:app:assembleDebug` Build এখানে চালানো যায়নি**, Android SDK/Gradle এখানে নেই। Android ডিভাইসে Installed App Query, SAF Folder, Split Restore, Installer Approval ও Uninstall Test এখান থেকে সম্ভব হয়নি। GitHub Actions-এ Build ও ফোনে পরীক্ষা করুন।
