# SR Smart Toolbox Pro — Apps Backup & Restore

**নতুন সংস্করণ:** `1.5.14-alpha40` (`versionCode 40`)

## উৎস ও ইন্টিগ্রেশন
আপলোড করা `SR_Apps_Backup_Restore.zip`-এর `ApkPayload.java`, `BackupStore.java`, `InstallReceiver.java`, `ShareProvider.java`, `MainActivity.java` বিশ্লেষণ করে নতুন `AppsBackup*` ক্লাস হিসেবে বর্তমান **SR Smart Toolbox Pro**-তে একীভূত করা হয়েছে। দেওয়া `build.yml` ZIP-এর ভেতরের Workflow-এর সঙ্গে হুবহু মিলেছে। এটি **স্বতন্ত্র Backup APK** বিল্ড করার Workflow। মূল Toolbox-এর GitHub Workflow রেখেই নতুন Backup Tests ও Android Lint Report ধাপ যোগ করা হয়েছে।

## সেকশন কোথায় পাবেন
- **Home → 📦 Apps Backup & Restore**, অথবা **Home-এর ⋮ Menu → Apps Backup & Restore**।
- **Installed:** ইনস্টল থাকা অ্যাপগুলোর নাম, আইকন, ভার্সন ও আকার দেখুন; Search/Sort করে একটি বা একাধিক নির্বাচন করুন।
- **Backup:** প্রথমবার Android Folder Picker-এ একটি Writable Folder (উদাহরণ: `Apps_backup_reinstall`) বেছে নিন। অ্যাপ ফোল্ডারের অনুমতি সংরক্ষণ করবে।
- **Archived:** পূর্বে সংরক্ষিত APK/APKS ব্যাকআপ দেখুন, বাছুন, **Restore**, **Share** কিংবা **Delete** করুন।
- **Settings:** Backup Folder, পুরোনো Version রাখা/না রাখা, System Apps দেখানো, এবং মূল অ্যাপের **Premium/Classic Theme & Sounds** Settings-এ যাওয়ার ব্যবস্থা।

## ইনস্টলযোগ্য ব্যাকআপের জন্য গুরুত্বপূর্ণ
- **একক APK অ্যাপ:** ফোনে ইনস্টল থাকা মূল signed APK-এর একটি byte-identical `.apk` কপি নির্বাচিত ফোল্ডারে রাখা হয়। নতুন কোনো Package ID/Signature বসানো হয় না।
- **Split APK অ্যাপ:** সাধারণ `.apk` (base APK) ছাড়াও `Split backups` ফোল্ডারে মূল APK অংশসহ একটি `.apks` ফাইল রাখা হয়। **শুধু base APK সব ফোনে ইনস্টল নাও হতে পারে।** সম্পূর্ণ Restore-এর জন্য অ্যাপের **Archived → Restore** ব্যবহার করুন।
- Restore Android `PackageInstaller` Session ও প্রতিটি অ্যাপের জন্য Android System Confirmation ব্যবহার করে। **সাইলেন্ট ইনস্টল নয়।** Android 8+ এ প্রয়োজন হলে **Allow from this source** অনুমতি দিন।
- অ্যাপের Private Data, WhatsApp Chat, Password, Login Session, OBB/Extra Game Files, অথবা Google Play Licensing তথ্য **ব্যাকআপ হয় না**। কেবল অ্যাপ ইনস্টলেশন প্যাকেজ সংরক্ষিত হয়। অন্য ফোনে Signature/Android Version/Architecture বা Device Restriction-এর কারণে ইনস্টল ব্যর্থ হতে পারে।
- **Apps Backup থেকে অন্য অ্যাপ সরালে** Android-এর Uninstall Confirmation প্রয়োজন হবে। মূল SR Smart Toolbox Pro অ্যাপকে নিজের Batch Uninstall থেকে বাদ রাখা হয়েছে।
- Device বা Backup Folder-এর জায়গা পর্যাপ্ত থাকতে হবে। Folder Picker-এর Android 11+ Restricted Folder নিয়ম প্রযোজ্য।

## ব্র্যান্ডিং ও প্রিমিয়াম ডিজাইন
- আগের App ID `com.smarttoolbox.pro` ও Gold/Navy Logo অপরিবর্তিত।
- Apps Backup-এর স্ক্রিন মূল অ্যাপের Premium/Classic Theme, Light/Dark রং অনুসরণ করে।
- আগের WhatsApp Scheduler, Notepad, Night Screen, Floating Icon, Video Player ইত্যাদি আগের মতোই সোর্সে রাখা হয়েছে।

## Permission ও Google Play সতর্কতা
- পূর্ণ Installed App List-এর জন্য `QUERY_ALL_PACKAGES` ব্যবহার করা হয়েছে; এই Permission **Google Play-এ কঠোরভাবে সীমাবদ্ধ**। এটি ব্যক্তিগত Sideload Build-এর জন্য যোগ করা হয়েছে; Play-এ প্রকাশের আগে Policy Eligibility ও Manifest পুনর্বিবেচনা প্রয়োজন।
- ব্যবহারকারী নিজে Folder নির্বাচন, Share, Restore ও Uninstall শুরু করেন। কোনো Backups নেটওয়ার্কে আপলোড করার ব্যবস্থা এই সেকশনে যোগ করা হয়নি।
- মূল অ্যাপের `android:allowBackup="false"` অপরিবর্তিত। অ্যাপের নিজস্ব `SharedPreferences`-এ অনুমতি পাওয়া Folder URI ও Backup Settings থাকে।

## যাচাই ও সীমাবদ্ধতা
- ৭১টি Java Source File-এর JDK Compiler AST Syntax/duplicate-field Check: PASS।
- ২৮টি স্থানীয় GitHub Workflow Source/Logic Test: PASS (নতুন Apps Backup Test-সহ)।
- APK Bytes/Complete Split Archive-এর Pure Java Test: PASS; Filename/Paired Archive Logic ১২টি Test: PASS।
- Manifest ও Resource XML: ৬টি Parse PASS; GitHub Workflow YAML/Bash Scripts Syntax: PASS।
- Source ZIP ও Repo ZIP Integrity/Auto-Extract পরীক্ষা প্যাকেজিংয়ে সম্পন্ন।
- **সম্পূর্ণ Android APK Build, Lint বা বাস্তব ফোনে Install/Restore পরীক্ষা এখানে করা হয়নি** (Android SDK/Gradle নেই)। GitHub Actions-এর Build ও Lint Report পরীক্ষা করুন।
- আগের Debug APK অন্য Signing Key দিয়ে তৈরি হলে Update সরাসরি ইনস্টল নাও হতে পারে। নতুন Signing Key ব্যবহার না করে একই Key বজায় রাখা উত্তম।
