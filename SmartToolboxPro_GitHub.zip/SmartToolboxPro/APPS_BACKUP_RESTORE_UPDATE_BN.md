# SR Smart Toolbox Pro — Apps Backup & Restore

**নতুন সংস্করণ:** 1.5.14-alpha40 (`versionCode 40`)

## পূর্বের অ্যাপ অক্ষত

মূল Android প্রজেক্ট 1.5.13-alpha39 থেকে আপডেট করা হয়েছে। Package `com.smarttoolbox.pro`, মূল Launcher Icon, SR Creation Farm / Shahriar Rahman, YouTube / Facebook Branding, Premium/Classic UI, WhatsApp Scheduler, Notepad, Night Screen, Video Player ও Floating Toolbox-এর ফিচার অপসারণ করা হয়নি। শুধুমাত্র Apps Backup & Restore যোগ করা হয়েছে।

## Installed Apps

Home Screen বা ⋮ Menu → **Apps Backup & Restore**। Installed ও Archived দুটি আলাদা Tab। Installed-এ আসল আইকন, নাম, প্যাকেজ, সংস্করণ, APK ফাইলের মোট সাইজ, Update Date, System/User, Archived/Not Archived। Search, ৮ ধরনের Sort, User/System/All Filter, Checkbox, Select All, Deselect All, Refresh, Backup, Share APK এবং Android-এর অনুমতিসাপেক্ষে Uninstall। বড় তালিকায় প্রতি পৃষ্ঠায় ৬০টি অ্যাপ দেখায়, Show More চাপলে পরেরগুলো পাওয়া যায়; Select All পুরো Filtered তালিকা নির্বাচন করে।

## Backup Storage (SAF)

Apps Backup & Restore → Settings → **Choose / Change Storage Folder** → Android File Picker থেকে Internal Storage অথবা সমর্থিত SD Card-এর একটি **লোকাল** ফোল্ডার নির্বাচন করুন → **Use This Folder**। অ্যাপ অনুমতিপ্রাপ্ত ফোল্ডারের ভিতরে `SR_Apps_Backup/` তৈরি করবে। স্টোরেজ Permission আলাদা করে পুরো ফোনের ফাইল দেখতে হবে না। নির্বাচিত ফোল্ডারের URI Permission রিস্টার্টের পরও বহাল রাখার চেষ্টা করে; অনুমতি হারালে নতুন করে Folder নির্বাচন করুন। Cloud Document Provider বাছাই করলে Offline কাজের নিশ্চয়তা নেই, তাই Local Storage/SD Card বেছে নিন।

## আসল .apk + Split APK

একজন বা একাধিক অ্যাপ Select করে **Backup**। প্রতিটি অ্যাপ একটি পৃথক Folder-এ থাকে:

```
SR_Apps_Backup/
  com.example.app__123__TIMESTAMP/
    base.apk
    splits/                   (অ্যাপটি Split APK ব্যবহার করলে)
      split_config.arm64_v8a.apk
      split_config.en.apk
      ...
    icon.png                  (অ্যাপের Original Icon-এর আলাদা PNG কপি)
    backup.json               (নাম, সংস্করণ, সময়, অংশের SHA-256)
```

APK-এর কোনো Bytes পরিবর্তন/পুনরায় Sign করা হয় না। কপি শেষে প্রতিটি ফাইলের SHA-256 আবার মিলিয়ে দেখা হয়। আগের অভিন্ন সংস্করণ ও অভিন্ন Hash থাকলে Duplicate Prevention চালু থাকলে নতুন কপি তৈরি হয় না। Keep Old Version বন্ধ থাকলে **নতুন Backup সফল হওয়ার পর** পুরোনো Folder সরানো হয়। ফাইলের নিজের স্বাক্ষর Android Installer যাচাই করে।

**মনে রাখবেন:** একটি সাধারণ Single-APK অ্যাপের `base.apk` File Manager থেকে সরাসরি Install করা যেতে পারে। Split-নির্ভর অ্যাপের **শুধু `base.apk` সব ফোনে Install হওয়ার উপযোগী নয়**; Restore Tab দিয়ে Base ও সমস্ত Split এক PackageInstaller Session-এ দিতে হয়। File Manager APK-এর Original Icon দেখাবে কি না তা **File Manager-এর নিজস্ব সমর্থনের ওপর নির্ভরশীল**; অ্যাপ আর্কাইভে আলাদা `icon.png` রাখে ও Archived Card-এ আইকন দেখায়।

## Archived

Archived Tab-এ একই অ্যাপের Base+Split **একটি Card** হিসেবে দেখাবে। নাম, Package, Version, Backup Date, APK মোট ফাইল Size, Installed/Not Installed, Split সংখ্যা, Icon। Search, Sort, Select All, Deselect, Refresh, Share, Restore এবং Delete Backup। Delete Backup কোনো Installed App Uninstall করে না।

## Restore

Archived থেকে একাধিক অ্যাপ Select → Restore → Android-এর **Install unknown apps** অনুমতি প্রয়োজন হলে Settings-এ অনুমতি দিন। Android PackageInstaller `MODE_FULL_INSTALL` ব্যবহার করে Base+সব Split একসঙ্গে Stream করে। Installer user confirmation চাইলে Android Installation Screen খুলবে। একাধিক অ্যাপ ক্রমান্বয়ে অনুমতি নিয়ে Restore হয়। ব্যর্থ হলে পরের Backup চলার চেষ্টা করা হয়। আগে Archive SHA-256 Verify হয়। Installed package-এর Signature, SDK, ABI বা split compatibility না মিললে Android Restore প্রত্যাখ্যান করতে পারে। Silent Install দাবি করা হয়নি।

**অন্য অ্যাপের Private Data, Login, Chats, Games Save, Messages ইত্যাদি APK Backup-এ অন্তর্ভুক্ত নয়।** Root ছাড়া সেগুলো নেওয়ার অধিকার নেই। কিছু DRM/Protected/Instant/System APK পাওয়া বা Restore করা সম্ভব নাও হতে পারে।

## Sorting

দুই ট্যাবেই: Name Asc/Desc, Date Asc/Desc, Size Asc/Desc, Not Installed First, Not Archived First। যে Tab-এ কোনো একটি বিষয় সবসময় একই (যেমন Installed Tab-এ সব অ্যাপ Installed), সেই Sort Default Name Order ব্যবহার করে।

## Backup Settings

- Storage Folder Change: SAF, Internal/SD Card।
- Keep Old Version APK: ON/OFF।
- Show System Apps: ON/OFF (ডিফল্ট OFF)।
- Duplicate Backup Prevention: ON/OFF (ডিফল্ট ON)।
- System Default / Light / Dark Appearance: আগের অ্যাপের Global Theme-এর সঙ্গে সংযুক্ত; ব্যবহারকারী পরিবর্তন করলে অ্যাপের অন্যান্য Screen-ও পরিবর্তিত হবে। Premium/Classic নির্বাচন আগের মতোই থাকবে।

## Android Compatibility / Google Play

- **এই মূল অ্যাপের আগের `minSdk 26` অপরিবর্তিত: Android 8.0 এবং পরবর্তী সংস্করণে ইনস্টলযোগ্য। Android 7.0 সমর্থিত বলে দাবি করা হচ্ছে না।** পুরোনো ফিচারের সামঞ্জস্য না ভেঙে এই সীমা রাখা হয়েছে।
- `QUERY_ALL_PACKAGES` বিস্তৃত Installed List-এর মূল কাজের জন্য যুক্ত হয়েছে। Google Play-তে প্রকাশ করলে এই অনুমতির ব্যবহার **Play Policy review/declaration**-এর আওতায় পড়বে। `tools:ignore="QueryAllPackagesPermission"` শুধু নির্দিষ্ট Lint Warning-এর সুনির্দিষ্ট ব্যাখ্যা; Full Lint বন্ধ করা হয়নি।
- `REQUEST_INSTALL_PACKAGES` ও `REQUEST_DELETE_PACKAGES` Android-এর নিয়ম অনুযায়ী আছে। APK Install/Uninstall কখনো নীরবে সম্পন্ন হয় না।
- Split APK Restore, PackageInstaller, SAF-এর কিছু আচরণ ফোনের Android Version, Storage Provider ও OEM অনুযায়ী ভিন্ন হতে পারে।
- Google Play Install/Uninstall ও QUERY_ALL_PACKAGES-এর ওপর নীতিগত সীমাবদ্ধতা রয়েছে। সাইডলোড করা পরীক্ষামূলক APK-তে Permission দিলেও সমস্ত সিস্টেম APK-এর জন্য সফল Backup নিশ্চিত নয়।

## GitHub-এ সরাসরি Build

1. `SmartToolboxPro_GitHub.zip` **Extract না করে** Repository Root-এ আপলোড করুন।
2. `build.yml`-কে `.github/workflows/build.yml` হিসেবে আপলোড করুন। যদি পুরোনো `build-apk.yml` workflow থাকে, সেটি Replace করুন বা মুছে দিন—অন্যথায় দুটি Build চলতে পারে।
3. `Actions → Build SR Smart Toolbox Pro APK → Run workflow`।
4. নতুন Workflow নতুন Source ZIP-কে আগে Extract করে Android Project খুঁজবে; Java 17, Android SDK 36, Build Tools 35.0.0, Gradle 8.11.1 সেটআপ করবে, পুরোনো Source/Java tests, নতুন Backup tests, পুরো Android Lint, এবং Debug APK Build চালাবে। `SR-Smart-Toolbox-Pro-debug-apk` Artifact থেকে APK পাবেন।
5. Lint Error হলে `SR-Smart-Toolbox-Pro-lint-report` Artifact-এ পুরো Log ও XML/HTML Report থাকবে। Build Error হলে আলাদা Build Log Artifact। **Lint বন্ধ করা হয়নি।**

## বাস্তবে কী পরীক্ষা করা যায়নি

এখানে Android SDK/Gradle নেই। ফলে **পূর্ণ `:app:lintDebug`, `:app:assembleDebug`, APK Signature Verification via Android APK Signature Scheme verifier এবং বাস্তব ফোনে Installed/Archived UI, SAF, Split PackageInstaller, Uninstall, Storage Provider/SD Card** পরীক্ষা করা যায়নি। এগুলো GitHub Actions ও বাস্তব ফোনে যাচাই করতে হবে। Source Syntax/AST, Pure JVM Logic, Manifest/XML, Workflow YAML/Bash, ZIP Auto Extraction ও Source Integrity-এর ফল `QA_REPORT_BN.txt`-এ আছে।
