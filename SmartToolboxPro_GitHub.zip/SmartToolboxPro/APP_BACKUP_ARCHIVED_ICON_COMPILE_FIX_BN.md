# SR Smart Toolbox Pro — Archived App Icon Compile Fix

**Version:** 1.5.14-alpha41, `versionCode 41` (previous: 1.5.14-alpha40)

## স্ক্রিনশটের সমস্যার কারণ
GitHub Actions-এ `:app:compileDebugJavaWithJavac` ব্যর্থ হয়েছে। `AppBackupActivity.java`-এর **লাইন 188 ও 301**-এ `a.icon` ব্যবহার করা হয়েছিল, কিন্তু `AppBackupRepository.Archived` মডেলে কোনো `icon` সদস্য ছিল না। ৩টি compiler error একই missing field থেকে তৈরি হয়েছিল। `lintDebug` চলার সময় Compilation হওয়ার কারণে Lint Job-ও ব্যর্থ হয়।

## কী ঠিক করা হয়েছে
- `AppBackupRepository.Archived`-এ `Drawable icon;` যুক্ত করা হয়েছে। Repository-তে আগেই `archiveIcon(Archived)` পদ্ধতি ছিল, যা ইনস্টল করা অ্যাপের Original Icon অথবা আগে Backup রাখা `icon.png` থেকে Icon লোড করে।
- `AppBackupActivity.refresh()`-এর `a.icon=repo.archiveIcon(a)` এবং `archiveCard()`-এর ImageView কোড এখন মডেলের সঙ্গে মিলে যায়।
- `AppBackupArchiveIconSourceTest.java` নামে Java AST Regression Test তৈরি ও GitHub Workflow-এর Backup Source Check-এ যুক্ত হয়েছে। এতে মডেলের Field, Icon Loader, UI Assignment ও UI Read পরীক্ষা হয়।
- Release Version বাড়িয়ে 1.5.14-alpha41 করা হয়েছে, যাতে নতুন APK ইনস্টল করা যায়।
- আগের Package ID, Launcher/Branding, Permissions, Backup/Restore, Split APK Handling, Settings, Premium/Classic Theme এবং অন্যান্য সোর্স অপরিবর্তিত রাখা হয়েছে।
- Original APK ও Original Signature সংক্রান্ত কোড পরিবর্তন করা হয়নি।

## যাচাই
- `JavaSourceSyntaxTest`: সব ৭৪টি Java source-file-এর Syntax/Field Check PASS।
- GitHub Workflow-এর বাস্তবে locally চালানো ২৮টি Source/Logic Step PASS।
- New Archive Icon Java AST Test: ৫টি Check PASS।
- Regression Negative Test: `Drawable icon` বাদ দেওয়া Source-এ Test FAIL (প্রত্যাশিত ফল)।
- Manifest ও ৬টি Android XML parse PASS।
- Workflow YAML ও Bash Syntax PASS; ZIP Archive Integrity PASS।
- ZIP থেকে Extract করে Icon Test এবং Source Verification পুনরায় PASS।

**অসম্পন্ন পরীক্ষা:** এখানে Android SDK/Gradle নেই; পূর্ণ Android `:app:lintDebug`, `:app:assembleDebug` ও Device Test চালানো যায়নি। তাই GitHub Actions-এর পরবর্তী Build ও Lint সফল হয়েছে বলে দাবি করা হচ্ছে না।

## GitHub-এ আপলোড
1. রিপোজিটরির Root-এ **নতুন** `SmartToolboxPro_GitHub.zip` পুরোনোটির পরিবর্তে আপলোড করুন। ZIP Extract করবেন না।
2. `.github/workflows/build.yml`-এ একই Release-এর `build.yml` আপলোড করুন। পুরোনো `build-apk.yml` ও `build.yml` দুটো সক্রিয় থাকলে প্রয়োজনমতো পুরোনো একটি সরিয়ে দিন, যাতে দুটি Build একসঙ্গে না চলে।
3. Commit করে Actions-এ Build চালান। `Archived Icon` Regression Check পাস হওয়ার পরে Lint/Compile Step চলবে।
4. যদি নতুন Error আসে, সম্পূর্ণ Lint Log বা GitHub Build Log দিন।
