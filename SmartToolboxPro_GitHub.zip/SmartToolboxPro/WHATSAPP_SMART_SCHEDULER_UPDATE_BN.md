# WhatsApp Smart Scheduler — Current version 1.5.1-alpha26

প্রচলিত Reminder, Contact Picker, Voice Typing, Daily/Weekly Repeat, Draft via wa.me ফিচার আগের মতো রয়েছে।

নতুন opt-in Experimental Accessibility Automation, encrypted owner-PIN attempt ও 3-second Overlay সম্পর্কে
`WHATSAPP_EXPERIMENTAL_AUTOMATION_BN.md` দেখুন।
