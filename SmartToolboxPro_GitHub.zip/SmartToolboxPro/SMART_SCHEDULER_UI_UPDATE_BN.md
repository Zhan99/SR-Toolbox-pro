# SR Smart Toolbox Pro — Smart Scheduler 1.5.4-alpha30

## নতুন Scheduler UI
অ্যাপ → **WhatsApp Smart Scheduler** → উপরে ডানদিকে **⋮** মেনু।

### ⋮ মেনুর অপশন
- **⚙ Alarm, Notification & Automation Settings**: আগে Scheduler-এর ওপরের দিকে থাকা Alarm, Notification, Accessibility, Experimental Auto-Send, PIN Save/Delete, Overlay এবং Relock সেটিংস এখন একটি আলাদা Settings স্ক্রিনে। সেটিংস পরিবর্তনে পুরোনো শিডিউল ডিলিট হয় না।
- **👥 Recent Recipient Numbers**: সংরক্ষিত নম্বরের তালিকা বড় করে দেখায়।
- **⚡ Quick Message Templates**: প্রস্তুত বাংলা মেসেজ নির্বাচন।
- **🧪 Test after 10 seconds**: বর্তমান মেসেজ + ঠিক একটি বৈধ প্রাপক দিয়ে নতুন একটি এককালীন টেস্ট শিডিউল।

### 👥 Recipient History
- আগের ভার্সনে সংরক্ষিত শিডিউলগুলোর নম্বরও প্রথমবার হিস্টোরিতে আনা হবে।
- নতুন শিডিউল সেভ করার সময় নম্বর লোকাল হিস্টোরিতে সংরক্ষিত হবে (সর্বোচ্চ ৪০টি)।
- **+** : নম্বরটি বর্তমান মেসেজের Recipient ফিল্ডে যুক্ত হবে। এক নম্বর দুইবার যুক্ত হবে না।
- **−** : শুধুমাত্র Recent Recipient History থেকে নম্বর সরবে; চলমান/পুরোনো শিডিউল মুছবে না।
- এই হিস্টোরি **Schedule-এ ব্যবহৃত নম্বরের হিস্টোরি**। WhatsApp message সত্যি Delivered হয়েছে, এমন দাবি করে না।
- হিস্টোরি ফোনের Private App Storage-এ থাকে; ব্যাকআপ পুরোনো অ্যাপের মতোই বন্ধ।

### ⚡ Quick Message Templates
শুভ সকাল, শুভ রাত, ধন্যবাদ, জন্মদিন, মিটিং, পরে কথা, খোঁজখবর, দ্রুত জানাবেন।
মেসেজ আগে লেখা থাকলে **Replace / Append / Cancel** বেছে নিতে হবে, না জিজ্ঞেস করে আগের লেখা মুছবে না।

### 🧪 10-second Test
- **Test in 10 seconds** বাটনটি বর্তমান নম্বর ও মেসেজ দিয়ে নতুন One-Time Schedule তৈরি করে; পুরোনো Schedule Edit না করে নতুন টেস্ট Schedule হিসেবে সেভ করে।
- একটি নম্বরই দেওয়া যাবে।
- **Experimental Auto-Send ON** হলে আগে Confirmation দেখাবে, কারণ এটি আসল WhatsApp Send চেষ্টা করতে পারে।
- **Auto-Send OFF** হলে ১০ সেকেন্ড পরে Reminder/WhatsApp draft path আগের মতো থাকবে।
- Android-এর Exact Alarm permission না থাকলে বা Battery Restriction থাকলে ১০ সেকেন্ডের alarm দেরিতে হতে পারে; এটি নিশ্চিত ডেলিভারি-টাইম নয়।

### ⏳ Schedule Countdown
- প্রতিটি Pending Schedule-এর পাশে Live Countdown: কত দিন/ঘণ্টা/মিনিট/সেকেন্ড বাকি আছে। স্ক্রিন খোলা থাকলে প্রতি সেকেন্ডে আপডেট হয়।
- Pending অথচ সময় পেরিয়ে গেলে লেখা থাকে **Android Alarm অপেক্ষায়**; মেসেজ পাঠানো হয়েছে বলে দেখায় না।
- Paused, Due, Attempted এবং Done-এর জন্য আলাদা Status দেখায়। `Attempted` মানে Accessibility Send চেষ্টা করেছে, WhatsApp Delivered নিশ্চিত নয়।
- Daily/Weekly Repeat-এর পরবর্তী Alarm সময় সংরক্ষিত হলে Countdown সেই সময়ের সঙ্গে আপডেট হয়।

## পুরোনো ফিচার
Experimental WhatsApp Auto-Send / PIN Settings (আগের মতো opt-in), Notification Alarm, Video Player / Library, Floating Toolbox, Themes, Night Screen, Extra Volume, Thermal Monitor এবং QR Scanner রাখা হয়েছে।

## সংক্ষিপ্ত QA
- ৪৪টি Java সোর্সের JDK Compiler AST Syntax / Duplicate Fields পরীক্ষা পাস।
- Scheduler UI ও Recipient History-সহ ৫টি মূল ক্লাস Android Stub Compile Probe পাস।
- Scheduler Display/Timer/Templates: ১৮টি Pure Java Test পাস।
- Recipient Selection `+`/duplicate check: ৮টি Pure Java Test পাস।
- GitHub Workflow-এর ১৭টি লোকাল Source/Logic Validation ধাপ পাস।
- Android XML এবং ZIP Integrity পরীক্ষা।
- **সম্পূর্ণ Android APK Build, WhatsApp UI Automation এবং বাস্তব ফোনের ১০ সেকেন্ডের Test এই পরিবেশে করা যায়নি** (Android SDK/Gradle নেই)। GitHub Actions এবং ফোনে যাচাই করতে হবে।

## GitHub Mobile Upload
Repository root-এর `SmartToolboxPro_GitHub.zip` বদলে নতুন ফাইল আপলোড করুন।
`.github/workflows/build-apk.yml`-ও এই সংস্করণের নতুন Workflow দিয়ে Replace করুন।
Commit → Actions → Build SR Smart Toolbox Pro APK → Build সফল হলে Artifact থেকে APK নিন।
