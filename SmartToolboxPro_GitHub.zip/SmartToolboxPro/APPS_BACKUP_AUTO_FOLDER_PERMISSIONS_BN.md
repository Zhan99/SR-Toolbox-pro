# SR Smart Toolbox Pro 1.5.17-alpha43 — Apps Backup Folder এবং Permission Settings

## ১. ব্যাকআপ কোথায় সংরক্ষিত হবে?

Android 10–16 (API 29+) : `Internal shared storage / Download / App Backup /`।
প্রথমবার কোনো অ্যাপ ব্যাকআপ করলে ফোল্ডারটি নিজে তৈরি হয়। যেমন:

    Download/
      App Backup/
        bKash.apk
        MyApp.apk
        Split backups/
          bKash.apks

একটি APK প্রথমবার ব্যাকআপ করলে এর নাম `AppName.apk` রাখা হয়। একই নামে আগের কপি থাকলে নতুন কপি ভিন্ন নামে সংরক্ষিত হবে—আগেরটি সফল ব্যাকআপের আগে মুছে ফেলা হবে না। Split অ্যাপের Base APK একা ইনস্টল নাও হতে পারে; Archived → Restore থেকে `.apks`-এর সম্পূর্ণ Split সেট ইনস্টল করতে হবে। অ্যাপের ব্যক্তিগত ডেটা/চ্যাট/লগইন এখানে থাকে না।

Android 8–9 (API 26–28) : প্রথম ব্যাকআপে System File Picker খুলবে; সেখানে একটি Parent Folder বেছে নিতে হবে। এরপর এর ভেতর `App Backup` এবং প্রয়োজনে `Split backups` নিজে তৈরি হবে। Android 11+ এর নিরাপত্তা নিয়মে Internal Storage-এর একেবারে Root ফোল্ডারটি Picker দিয়ে নির্বাচন করা যায় না। সেই কারণে অনুমতি ছাড়া Root-এ `App Backup` তৈরি করার প্রতিশ্রুতি নেই।

### Backup Folder নির্বাচন (ঐচ্ছিক)
Apps Backup & Restore → ⋮ → Backup Settings → Backup path: অন্য Parent Folder নির্বাচন করা যায়। আগে নির্বাচিত Folder থাকলে তার পুরোনো ব্যাকআপগুলো অ্যাপের Archived তালিকায় খুঁজে পাওয়া যাবে। নতুন ব্যাকআপ সেখানে `App Backup` সাবফোল্ডারে থাকবে (আগে থেকেই App Backup বাছা থাকলে আরেকটি App Backup যোগ হবে না)। Android 10+ এ `↺ Use automatic Download/App Backup` চাপলে ডিফল্ট লোকেশন আবার চালু হবে। পুরোনো ব্যাকআপ ফাইলগুলো নিজে মুছে যাবে না।

## ২. Home Screen-এর Creator Card
Home Screen-এর বড় Creator/About পরিচিতি অপসারণ করা হয়েছে। এখন Home Screen সরাসরি টুলগুলো দেখায়। Premium Header-এ SR Logo, Opening Animation-এ Branding এবং ⋮ → About Developer আগের মতো থাকবে।

## ৩. Central Permission Settings
Home Screen → ⋮ → 🔐 App Permissions (সব অনুমতি)

প্রতিটি Card-এর উপরে আছে **কোন ফিচারের জন্য:**, পরে Permission-এর Android নাম, কারণ, অনুমতি দেওয়া আছে কি না, এবং অনুমতি দেখুন/পরিবর্তন করুন বাটন (যদি প্রযোজ্য হয়)।

- Floating / Night Screen / Countdown → Draw over other apps
- Night Screen minimum Brightness → Modify System Settings
- WhatsApp Scheduler → Contacts, Exact Alarms, Optional Accessibility
- Full Charge Alert / Scheduler Notifications → Notifications
- Video Player → Video Media Access / Selected Media / Legacy Storage (Android Version অনুযায়ী)
- Apps Backup → Installed Apps Visibility, APK Install, APK Delete, Backup Folder Access
- Volume Booster → Modify Audio Settings
- অন্যান্য → Foreground Service, Media Playback Service, Wake Lock, Boot Completed, Internet
- QR/Barcode Code Scanner → Google Code Scanner নিজস্ব UI ব্যবহৃত হয় (App-এর CAMERA manifest permission নেই)

যেসব অনুমতি Android স্বয়ংক্রিয়ভাবে পরিচালনা করে, সেখানে Runtime ON/OFF সুইচ দেখানো হবে না। Permission Settings কোনো অনুমতি গোপনে চালু করে না: বাটনে চাপলে Android-এর Confirmation/Settings খুলবে।

## ৪. সীমাবদ্ধতা ও পরীক্ষা
- ৮১টি Java Source AST Syntax যাচাই পাস; ৩১টি GitHub Workflow-এর স্থানীয় Source/Unit ধাপ পাস।
- নতুন Auto Folder Logic-এর ১৬টি Pure Java Test পাস; Manifest-এর ১৮/১৮টি অনুমতি Permission UI-তে নথিভুক্ত।
- Source ZIP, Workflow ZIP-only Extraction এবং XML, YAML, Bash Syntax পরীক্ষা পাস।
- **পূর্ণ Android APK Build এবং বাস্তব ফোনে MediaStore/Split Restore/Permission Request UI পরীক্ষা এখানে করা হয়নি।** Android SDK/Gradle নেই।
- কোনো OEM ফাইল ম্যানেজার `Download` ফোল্ডারকে `Downloads` বলে দেখাতে পারে।
