# SR Smart Toolbox Pro — Experimental WhatsApp Automation (1.5.1-alpha26)

**শুধুমাত্র নিজের ফোন ও নিজের সম্মতিপ্রাপ্ত WhatsApp যোগাযোগের জন্য। এটি পরীক্ষামূলক ফিচার।**

## কী নতুন
1. WhatsApp Smart Scheduler → **Experimental Auto-Send & Unlock** সেকশন। ডিফল্ট **OFF**।
2. অপশন চালু করে Accessibility Service-কে Android Settings থেকে ম্যানুয়ালি অনুমতি দিতে হয়।
3. Android 9+ এ Accessibility-এর `GLOBAL_ACTION_LOCK_SCREEN` ব্যবহার করে Lock Screen ফেরানোর চেষ্টা হয়।
4. নির্ধারিত সময়ের **৩ সেকেন্ড আগে** আলাদা Alarm-এ স্ক্রিন চালু/আনলক থাকলে ছোট Overlay Reminder দেখানোর চেষ্টা হয়। `Cancel` চাপলে স্বয়ংক্রিয় পাঠানো বাতিল হয়ে সাধারণ Reminder আসে।
5. সময় হলে অ্যাপ **শুধু অফিসিয়াল `com.whatsapp` অ্যাপ** খুলে পূর্বনির্ধারিত নম্বরের মেসেজ Draft মিলিয়ে Send বাটনে সর্বোচ্চ **একবার** ক্লিক করার চেষ্টা করে। Send Button পাওয়া না গেলে বা Draft না মিললে কিছু পাঠায় না, সাধারণ Reminder দেখায়।
6. ফোন আনলক থাকলে Send-এর পর Back-এর মাধ্যমে আগের অ্যাপে ফেরার চেষ্টা করে। আগের অ্যাপ ফেরেনি বুঝতে পারলে তার Launcher/Task পুনরায় খুলতে পারে। আগের Activity অবস্থান অক্ষত থাকবে—**নিশ্চয়তা নেই**।
7. ফোন আগে লক থাকলে Auto-Unlock চালু, PIN সেভ ও Accessibility অনুমতি থাকা অবস্থায় একটি **পরীক্ষামূলক Keyguard Keypad Attempt** চালায়। Keypad শনাক্ত করা না গেলে বা Unlock ব্যর্থ হলে Abort করে। একাধিক PIN Attempt করে না।
8. ফোন আগে লক থাকলে কাজ শেষে Home → Lock করার চেষ্টা করে। Android 9+ এ Accessibility Global Lock Action উপলভ্য।
9. Send Action সফলভাবে ক্লিক হলে Status **“Auto-send attempted · verify in WhatsApp”** দেখায়; Delivered/Read দাবি করে না।
10. PIN Android Keystore AES-GCM দিয়ে এনক্রিপ্ট করে **শুধু ফোনে** সংরক্ষণ করে। `Delete stored PIN` বাটন ডাটা ও Keystore Key মুছে দেয়। Backup বন্ধ। PIN লগ বা নেটওয়ার্কে পাঠানোর কোড নেই।

## চালু করার নিয়ম
1. অ্যাপ → **WhatsApp Smart Scheduler** → Experimental Auto-Send & Unlock।
2. `Enable experimental automatic WhatsApp Send` চালু করো।
3. `Enable Accessibility Service` → Android Settings-এ **SR Experimental WhatsApp Scheduler** ম্যানুয়ালি অন করো।
4. স্ক্রিনে ৩ সেকেন্ড আগে Banner পেতে `Allow 3s on-screen overlay`-এ যাও এবং Display over other apps চালু রাখো।
5. Precise Alarm ও Notifications অনুমতি চালু করো।
6. PIN Attempt পরীক্ষা করতে চাইলে (ঐচ্ছিক) নিজের PIN সেভ করে `Attempt owner PIN unlock` চালু করো।
7. `If originally locked: Home → Lock again` ON রাখতে পারো।
8. প্রথমে নিজের নম্বরে একটি স্বল্প-সময়ের Schedule তৈরি করে ফোন আনলক অবস্থায় পরীক্ষা করো।

## গুরুত্বপূর্ণ বাস্তব সীমা
- **Android-এর নিরাপদ Lock Screen খোলার জন্য কোনো সাধারণ অ্যাপকে গ্যারান্টিযুক্ত API দেওয়া হয় না।** Android/OEM নিরাপত্তার কারণে PIN-Keypad Accessibility-তে না-ও দেখা যেতে পারে। User-supplied সঠিক PIN ছাড়া এই কোড Lock ভাঙে না। একবার চেষ্টা ব্যর্থ হলে বন্ধ হয়।
- পরীক্ষামূলক PIN প্রবেশ ব্যর্থ হলে ভুল PIN বারবার চেষ্টা করে ফোন Lockout হওয়ার ঝুঁকি কমাতে stored PIN মুছে দেওয়া ও Lock Attempt OFF করা হয়।
- Android 8.x-এ নিজের ফোন আবার Lock করা নিশ্চিত করার API নেই; পুনরায় Lock করার সেটিং ON থাকলে Secure Auto-Unlock চেষ্টা বাদ দিয়ে Manual Reminder দেওয়া হয়।
- ফোন Reboot হওয়ার পর প্রথম Unlock-এর আগে Keystore/Service/Alarm উপযোগী নাও থাকতে পারে।
- Android AlarmManager ও Battery Optimization-এর কারণে নির্ধারিত সময় ও “৩ সেকেন্ড আগে” Banner ঠিক সময়ে নাও আসতে পারে।
- Android Background Activity Launch নিয়ম, WhatsApp UI পরিবর্তন এবং নোটিফিকেশন/Overlay অনুমতির কারণে Auto Send ব্যর্থ হতে পারে।
- WhatsApp নিজের Help Center-এ অননুমোদিত automated messaging এড়াতে বলেছে। ব্যক্তিগত WhatsApp Account সীমাবদ্ধ/বন্ধ হতে পারে।
- এই অ্যাপ **SMS/MMS পাঠায় না**। এটি শুধু Official WhatsApp-এর UI নিয়ে কাজ করার চেষ্টা করে।
- যদি Accessibility কাজ না করে, Scheduler-এর `Open WhatsApp` Notification থেকে Draft খুলে **নিজে Send** করতে পারবে।

## QA সীমা
Java AST, XML, YAML, Existing UI Tests ও ১৯টি AutomationRules Test লোকালভাবে পাস করেছে। **সম্পূর্ণ Android APK Build বা বাস্তব ফোনে Locked-Screen/WhatsApp UI automation পরীক্ষা এই পরিবেশে হয়নি।** GitHub Actions-এ `:app:assembleDebug` এবং নিজের ফোনে পরীক্ষার পরেই নির্ভরযোগ্যতা জানা যাবে।
