#!/usr/bin/env python3
"""Guard SR Toolbox against Kotlin 1.8+/1.6.21 duplicate-class regressions.
Static-only guard. The workflow also checks Gradle's resolved runtime graph and
runs :app:checkDebugDuplicateClasses with a real Android SDK on GitHub Actions.
"""
from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
gradle = (root / 'app/build.gradle').read_text(encoding='utf-8')
workflow = (root / '.github/workflows/build-apk.yml').read_text(encoding='utf-8')

checks = {
    'all-config exclusion': 'configurations.configureEach' in gradle,
    'exclude jdk7': bool(re.search(r"exclude\s+group:\s*'org[.]jetbrains[.]kotlin',\s*module:\s*'kotlin-stdlib-jdk7'", gradle)),
    'exclude jdk8': bool(re.search(r"exclude\s+group:\s*'org[.]jetbrains[.]kotlin',\s*module:\s*'kotlin-stdlib-jdk8'", gradle)),
    'keep stdlib 1.8.22+': "implementation 'org.jetbrains.kotlin:kotlin-stdlib:1.8.22'" in gradle,
    'do not add old stdlib artifacts': not bool(re.search(r"(?m)^\s*(?:implementation|api|runtimeOnly)\s+['\"]org[.]jetbrains[.]kotlin:kotlin-stdlib-jdk(?:7|8)", gradle)),
    'gradle runtime classpath check': 'debugRuntimeClasspath' in workflow,
    'resolved JDK variants check': 'kotlin-stdlib-jdk(7|8)' in workflow,
    'Android duplicate-class task': ':app:checkDebugDuplicateClasses' in workflow,
    'no Video Player reintroduction': 'media3' not in gradle,
    'preserve core': "implementation 'androidx.core:core:1.15.0'" in gradle,
    'preserve QR camera scanner': "implementation 'com.google.android.gms:play-services-code-scanner:16.1.0'" in gradle,
    'preserve Gallery decoder': "implementation 'com.google.mlkit:barcode-scanning:17.3.0'" in gradle,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ' Kotlin dependency guard: ' + name)
assert all(checks.values()), 'Kotlin dependency regression detected'
print(f'PASS: {len(checks)} checks')
