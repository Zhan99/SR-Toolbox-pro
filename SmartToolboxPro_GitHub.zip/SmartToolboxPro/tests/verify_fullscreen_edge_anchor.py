#!/usr/bin/env python3
"""Regression guard for landscape immersive edge-tab positioning.

Cannot replace an Android device test. Checks the production code actually uses
WindowManager gravity for both screen edges, not a width derived from the
non-immersive available content metrics.
"""
from pathlib import Path
import re

src = (Path('app/src/main/java/com/smarttoolbox/pro') / 'FloatingControlService.java').read_text()


def method(name):
    m = re.search(r'\b(?:void|DisplayMetrics)\s+' + re.escape(name) + r'\s*\([^)]*\)\s*\{', src)
    assert m, f'{name} is missing'
    start = m.end()
    level = 1
    i = start
    while level and i < len(src):
        if src[i] == '{':
            level += 1
        elif src[i] == '}':
            level -= 1
        i += 1
    assert level == 0, f'Cannot parse {name}'
    return src[start:i-1]

checks = 0

def check(condition, message):
    global checks
    checks += 1
    assert condition, message

anchor = method('anchorEdgeWindow')
check('Gravity.TOP | (left ? Gravity.LEFT : Gravity.RIGHT)' in anchor, 'Must use absolute LEFT/RIGHT gravity')
check('edgeParams.x = 0;' in anchor, 'A gravity anchored overlay must use zero horizontal inset')
check('FloatingEdgeGeometry.x(' not in anchor, 'Must not compute right X from app width')
metrics = method('physicalScreenMetrics')
check('.getRealMetrics(result)' in metrics, 'Use physical display metrics for drag / vertical fraction')
for name in ('alignEdgeHandleToDisplay', 'showEdgeHandle', 'moveTouchedEdgeTab'):
    body = method(name)
    arg = 'left' if name == 'alignEdgeHandleToDisplay' else 'leftSide' if name == 'showEdgeHandle' else 'edgeDockLeftDuringDrag'
    check(f'anchorEdgeWindow({arg});' in body, f'{name} must anchor the real window edge')
    check('FloatingEdgeGeometry.x(' not in body, f'{name} should not compute x from getMetrics()')
show = method('showEdgeHandle')
check('LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES' in show, 'Allow fullscreen short-edge cutouts')
check('SidebarInputPolicy.edgeTouchWidthDp(edgeWidthDp)' in show, 'Preserve narrow tap pass-through area')
check('FLAG_NOT_TOUCH_MODAL' in show, 'Preserve background app touch delivery outside strip')
check('FLAG_LAYOUT_IN_SCREEN' in show, 'Window must be laid out in display frame')
check('edgeHandle.setOnTouchListener' in show, 'Swipe / hold touch handler must remain installed')
finish = method('finishEdgeTabDrag')
check('boolean left = edgeDockLeftDuringDrag;' in finish, 'Do not derive chosen side from x=0 after RIGHT anchoring')
check('putBoolean("floating.edge.left", left)' in finish, 'Persist chosen side')
check('EDGE_CENTER_FRACTION' in finish, 'Persist relative vertical position')
sync = method('syncGlobalPortraitEdge')
check('if (edgeHandle != null) alignEdgeHandleToDisplay();' in sync, 'Realign on full-screen change while edge is visible')
check('portraitMonitorHandler.postDelayed(this, 1800L)' in src, 'Keep fallback immersive screen monitor')
check('void onConfigurationChanged(Configuration newConfig)' in src, 'Listen for portrait/landscape changes')
check('edgeParams.x = FloatingEdgeGeometry.x(' not in src, 'No remaining app-width based edge X computations')
# Regression example: 2400px real screen, 2220px non-fullscreen app metrics.
# Old code calculated 2220 - 24 = 2196 => 180px gap to physical edge.
real_width, app_width, bar_width = 2400, 2220, 24
check(real_width - (app_width - bar_width) - bar_width == 180,
      'Fixture should reproduce the visible landscape gap')
check('edgeParams.x = 0;' in anchor and 'Gravity.RIGHT' in anchor,
      'New anchor must be independent of the app viewport width')
print(f'{checks} immersive landscape fullscreen edge-anchor checks passed')
