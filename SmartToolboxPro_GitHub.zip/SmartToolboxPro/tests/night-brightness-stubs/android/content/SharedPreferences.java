package android.content;

import java.util.HashMap;
import java.util.Map;

public final class SharedPreferences {
    private final Map<String, Object> values = new HashMap<>();
    public boolean getBoolean(String key, boolean fallback) {
        Object value = values.get(key); return value instanceof Boolean ? (Boolean)value : fallback;
    }
    public int getInt(String key, int fallback) {
        Object value = values.get(key); return value instanceof Integer ? (Integer)value : fallback;
    }
    public Editor edit() { return new Editor(); }
    public final class Editor {
        private final Map<String, Object> edits = new HashMap<>();
        public Editor putBoolean(String key, boolean value) { edits.put(key, value); return this; }
        public Editor putInt(String key, int value) { edits.put(key, value); return this; }
        public Editor remove(String key) { edits.put(key, null); return this; }
        public boolean commit() {
            for (Map.Entry<String,Object> e : edits.entrySet()) {
                if (e.getValue() == null) values.remove(e.getKey());
                else values.put(e.getKey(), e.getValue());
            }
            return true;
        }
    }
}
