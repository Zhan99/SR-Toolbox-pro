package com.smarttoolbox.pro;

import android.content.Context;
import android.content.ContentResolver;

public final class NightBrightnessControllerTest {
    private static int checks;
    private static void verify(boolean result, String label) {
        checks++; if (!result) throw new AssertionError(label);
    }
    public static void main(String[] args) {
        Context initial = new Context();
        ContentResolver device = initial.getContentResolver();
        verify(device.brightness == 140 && device.mode == 1, "fixture adaptive mode");
        verify(NightBrightnessController.hasPermission(initial), "initial grant");
        verify(!NightBrightnessController.hasSnapshot(initial), "no backup yet");
        verify(NightBrightnessController.applyMinimum(initial), "apply authorized");
        verify(device.brightness == 1, "physical brightness minimum");
        verify(device.mode == 0, "adaptive mode temporarily manual");
        verify(NightBrightnessController.hasSnapshot(initial), "snapshot persisted");
        verify(NightBrightnessController.applyMinimum(initial), "repeated start idempotent");
        NightBrightnessController.restore(initial);
        verify(device.brightness == 140, "original brightness restored");
        verify(device.mode == 1, "adaptive mode restored");
        verify(!NightBrightnessController.hasSnapshot(initial), "backup removed on restore");
        NightBrightnessController.restore(initial);
        verify(device.brightness == 140, "duplicate restore idempotent");

        Context denied = new Context(); denied.writeSettingsPermission = false;
        verify(!NightBrightnessController.applyMinimum(denied), "no permission no apply");
        verify(denied.getContentResolver().brightness == 140, "no unauthorized change");
        verify(!NightBrightnessController.hasSnapshot(denied), "no backup from denied");

        Context revoked = new Context();
        verify(NightBrightnessController.applyMinimum(revoked), "apply then revoke");
        revoked.writeSettingsPermission = false;
        NightBrightnessController.restore(revoked);
        verify(revoked.getContentResolver().brightness == 1, "cannot restore without grant");
        verify(NightBrightnessController.hasSnapshot(revoked), "keep snapshot when revoked");
        revoked.writeSettingsPermission = true;
        NightBrightnessController.restore(revoked);
        verify(revoked.getContentResolver().brightness == 140, "restores after regrant");
        verify(!NightBrightnessController.hasSnapshot(revoked), "snapshot cleared afterward");

        Context userChanged = new Context();
        verify(NightBrightnessController.applyMinimum(userChanged), "apply before user change");
        userChanged.getContentResolver().brightness = 80;
        NightBrightnessController.restore(userChanged);
        verify(userChanged.getContentResolver().brightness == 80, "respect manual user adjustment");
        verify(!NightBrightnessController.hasSnapshot(userChanged), "manual change clears backup");

        Context userAdaptive = new Context();
        verify(NightBrightnessController.applyMinimum(userAdaptive), "apply before automatic switch");
        userAdaptive.getContentResolver().mode = 1;
        NightBrightnessController.restore(userAdaptive);
        verify(userAdaptive.getContentResolver().mode == 1, "respect user mode adjustment");
        verify(!NightBrightnessController.hasSnapshot(userAdaptive), "mode change clears backup");

        Context fail = new Context();
        fail.getContentResolver().failBrightnessWrite = true;
        verify(!NightBrightnessController.applyMinimum(fail), "failed brightness update reported");
        verify(fail.getContentResolver().mode == 1, "failed brightness update rolls back mode");
        verify(!NightBrightnessController.hasSnapshot(fail), "failed update rolls back snapshot");

        System.out.println(checks + " Night Screen controller/restore checks passed");
    }
}
