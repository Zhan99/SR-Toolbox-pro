package com.smarttoolbox.pro;

public final class VideoFreshnessLogicTest {
    private static int checked;
    static void check(boolean ok, String what){checked++;if(!ok)throw new AssertionError(what);}
    public static void main(String[] args) {
        check(!VideoFreshnessLogic.markNew(false,false,false),"first scan baseline");
        check(!VideoFreshnessLogic.markNew(false,true,false),"baseline known");
        check(VideoFreshnessLogic.markNew(true,false,false),"new download");
        check(!VideoFreshnessLogic.markNew(true,true,false),"old known");
        check(!VideoFreshnessLogic.markNew(true,false,true),"already played");
        check(VideoFreshnessLogic.folderNewCount(0,true)==1,"first new item");
        check(VideoFreshnessLogic.folderNewCount(2,true)==3,"increment folder count");
        check(VideoFreshnessLogic.folderNewCount(2,false)==2,"no new item");
        check(VideoFreshnessLogic.folderNewCount(-10,true)==1,"safe negative input");
        System.out.println(checked+" video library NEW badge tests passed");
    }
}
