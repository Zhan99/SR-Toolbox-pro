package com.smarttoolbox.pro;

public final class AppsBackupArchiveLogicTest {
    private static int checks;
    private static void check(boolean yes,String reason){checks++;if(!yes)throw new AssertionError(reason);}
    public static void main(String[] args){
        check(AppsBackupArchiveLogic.isApk("Example.apk"),"apk recognized");
        check(AppsBackupArchiveLogic.isApk("Example.APK"),"apk case insensitive");
        check(AppsBackupArchiveLogic.isApks("Example.apks"),"apks recognized");
        check(AppsBackupArchiveLogic.isApks("Example.APKS"),"apks case insensitive");
        check(!AppsBackupArchiveLogic.isApk("Example.apks"),"apks not standalone apk");
        check(!AppsBackupArchiveLogic.supported("Example.zip"),"other archives excluded");
        check(!AppsBackupArchiveLogic.supported(null),"null excluded");
        check(AppsBackupArchiveLogic.paired("A__pkg__1__1.apk","A__pkg__1__1.apks"),"base/full pair");
        check(!AppsBackupArchiveLogic.paired("A__pkg__1__1.apk","A__pkg__2__2.apks"),"different version");
        check(!AppsBackupArchiveLogic.paired("A__pkg__1__1.apk","A__pkg__1__1.zip"),"unsupported full type");
        check("Example".equals(AppsBackupArchiveLogic.stem("Example.apk")),"stem");
        check("Example".equals(AppsBackupArchiveLogic.stem("Example")),"no extension stem");
        System.out.println(checks+" apps backup filename format tests passed");
    }
}
