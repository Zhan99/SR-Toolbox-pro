package com.smarttoolbox.pro;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class SchedulerEditPlanLogicTest {
    private static int checks;
    private static void check(boolean yes, String message) {
        checks++; if (!yes) throw new AssertionError(message);
    }
    private static Map<String,String> existing() {
        Map<String,String> m = new LinkedHashMap<>();
        m.put("8801711111111", "id_A"); m.put("8801811111111", "id_B");
        m.put("8801911111111", "id_C"); return m;
    }
    public static void main(String[] args) {
        Map<String,String> old = existing();
        List<String> same = new ArrayList<>(old.keySet());
        SchedulerEditPlanLogic.Plan p = SchedulerEditPlanLogic.create(old, same);
        check(p != null, "same group valid");
        check(p.preservedIds.size() == 3, "all three ids preserved");
        check(p.addedPhones.isEmpty(), "no duplicate records for editing same phones");
        check(p.removedPhones.isEmpty(), "nothing removed");
        check("id_A".equals(p.existingIdFor("8801711111111")), "id A remains stable");
        check("id_B".equals(p.existingIdFor("8801811111111")), "id B remains stable");
        check("id_C".equals(p.existingIdFor("8801911111111")), "id C remains stable");
        List<String> mixed = Arrays.asList("8801911111111", "8801711111111", "8801611111111");
        p=SchedulerEditPlanLogic.create(old,mixed);
        check(p != null, "mixed group valid");
        check("id_C".equals(p.existingIdFor("8801911111111")), "reorder preserves id");
        check("id_A".equals(p.existingIdFor("8801711111111")), "second preserved id");
        check(p.existingIdFor("8801611111111")==null, "new phone needs exactly one new id");
        check(p.addedPhones.equals(Collections.singletonList("8801611111111")), "only added phone gets new record");
        check(p.removedPhones.equals(Collections.singletonList("8801811111111")), "removed phone alarm canceled");
        check(p.requestedPhones.equals(mixed), "new order maintained");
        check(SchedulerEditPlanLogic.create(old,Arrays.asList("a", "a"))==null,"duplicates rejected");
        check(SchedulerEditPlanLogic.create(old,Collections.singletonList("a"))==null,"group needs two members");
        check(SchedulerEditPlanLogic.create(old,Collections.nCopies(21,"a"))==null,"max group size");
        check(SchedulerEditPlanLogic.create(Collections.emptyMap(),same)==null,"must edit existing batch");
        check(SchedulerEditPlanLogic.create(old,null)==null,"null safe");
        check(SchedulerEditPlanLogic.create(old,Arrays.asList("a",null))==null,"null phone rejected");
        check(SchedulerEditPlanLogic.create(old,Arrays.asList("a",""))==null,"blank phone rejected");
        check(SchedulerEditPlanLogic.create(old,Arrays.asList("a","b"))!=null,"completely replaced membership valid");
        check(old.size()==3 && "id_B".equals(old.get("8801811111111")),"old plan immutable source");
        System.out.println(checks+" in-place group edit identity checks passed");
    }
}
