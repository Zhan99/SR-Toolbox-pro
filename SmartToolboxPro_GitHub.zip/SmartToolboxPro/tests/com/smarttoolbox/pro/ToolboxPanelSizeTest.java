package com.smarttoolbox.pro;

public final class ToolboxPanelSizeTest {
    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        require(ToolboxPanelSize.clampWidthDp(292) == 292, "default width");
        require(ToolboxPanelSize.clampWidthDp(60) == 176, "minimum width");
        require(ToolboxPanelSize.clampWidthDp(600) == 440, "maximum width");
        require(ToolboxPanelSize.clampHeightDp(580) == 580, "default height");
        require(ToolboxPanelSize.clampHeightDp(40) == 185, "minimum height");
        require(ToolboxPanelSize.clampHeightDp(999) == 760, "maximum height");
        require(ToolboxPanelSize.fitToScreenPx(880, 720, 12) == 696, "narrow device width fit");
        require(ToolboxPanelSize.fitToScreenPx(400, 1080, 12) == 400, "requested width fit");
        require(ToolboxPanelSize.fitToScreenPx(900, 720, 16) == 688, "short device height fit");
        require(ToolboxPanelSize.fitToScreenPx(500, 320, 16) == 288, "smaller phone screen");
        require(ToolboxPanelSize.clampTopY(500, 720, 600, 8) == 112, "panel stays on screen");
        require(ToolboxPanelSize.clampTopY(-40, 720, 600, 8) == 8, "minimum panel top");
        require(ToolboxPanelSize.clampTopY(50, 400, 380, 8) == 12, "short screen panel top");
        System.out.println("13 toolbox panel sizing checks passed");
    }
}
