package com.smarttoolbox.pro;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Random;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public final class ApkArchiveWriterTest {
    private static int checks;
    private static void check(boolean valid, String name) { checks++; if (!valid) throw new AssertionError(name); }

    public static void main(String[] args) throws Exception {
        File dir = Files.createTempDirectory("sr-original-apks").toFile();
        byte[] base = new byte[117_000];
        byte[] feature = new byte[33_000];
        byte[] config = new byte[19_000];
        new Random(251).nextBytes(base);
        new Random(997).nextBytes(feature);
        new Random(991).nextBytes(config);
        File baseFile = new File(dir, "base.apk");
        File featureFile = new File(dir, "feature.apk");
        File configFile = new File(dir, "config.apk");
        Files.write(baseFile.toPath(), base);
        Files.write(featureFile.toPath(), feature);
        Files.write(configFile.toPath(), config);
        try {
            ByteArrayOutputStream single = new ByteArrayOutputStream();
            ApkArchiveWriter.write(baseFile.getPath(), null, "{}", single);
            check(Arrays.equals(base, single.toByteArray()), "Single APK must be byte-for-byte identical");
            check(!Arrays.equals(config, single.toByteArray()), "Single APK not random file");
            ByteArrayOutputStream bundle = new ByteArrayOutputStream();
            ApkArchiveWriter.write(baseFile.getPath(), new String[]{featureFile.getPath(), configFile.getPath()},
                    "{\"packageName\":\"com.example.test\"}", bundle);
            check(bundle.size() > base.length, "Bundled APK should include all original files");
            int count = 0;
            try (ZipInputStream zip = new ZipInputStream(
                    new java.io.ByteArrayInputStream(bundle.toByteArray()))) {
                ZipEntry entry;
                while ((entry = zip.getNextEntry()) != null) {
                    ByteArrayOutputStream entryBytes = new ByteArrayOutputStream();
                    byte[] buf = new byte[4096];
                    int n;
                    while ((n = zip.read(buf)) != -1) entryBytes.write(buf, 0, n);
                    switch (entry.getName()) {
                        case "info.json":
                            check(entryBytes.toString("UTF-8").contains("com.example.test"), "Metadata preserved"); break;
                        case "base.apk":
                            check(Arrays.equals(base, entryBytes.toByteArray()), "base split identical"); break;
                        case "split_000.apk":
                            check(Arrays.equals(feature, entryBytes.toByteArray()), "feature split identical"); break;
                        case "split_001.apk":
                            check(Arrays.equals(config, entryBytes.toByteArray()), "configuration split identical"); break;
                        default: throw new AssertionError("Unexpected zip entry " + entry.getName());
                    }
                    count++; zip.closeEntry();
                }
            }
            check(count == 4, "Metadata + all 3 original APK files");
            boolean failed = false;
            try {
                ApkArchiveWriter.write(baseFile.getPath(), new String[]{"/missing/never.apk"}, "{}",
                        new ByteArrayOutputStream());
            } catch (java.io.IOException expected) { failed = true; }
            check(failed, "Incomplete split backup must be refused");
            failed = false;
            try { ApkArchiveWriter.write("/missing/base.apk", null, "{}", new ByteArrayOutputStream()); }
            catch (java.io.IOException expected) { failed = true; }
            check(failed, "Missing base APK must be refused");
        } finally {
            baseFile.delete(); featureFile.delete(); configFile.delete(); dir.delete();
        }
        System.out.println(checks + " original APK binary fidelity / split bundle tests passed");
    }
}
