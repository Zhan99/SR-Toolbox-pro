package com.smarttoolbox.pro;

public final class GlobalFeedbackInputTest {
    private static int checks;
    private static void ok(boolean actual, String what) {
        checks++; if (!actual) throw new AssertionError(what);
    }
    public static void main(String[] args) {
        for (boolean global : new boolean[]{false, true}) {
            for (boolean local : new boolean[]{false, true}) {
                for (boolean system : new boolean[]{false, true}) {
                    ok(FeedbackPolicy.vibrate(global, local, system) == (global && local && system),
                            "sound-independent global + local + Android haptic policy");
                }
            }
        }
        for (int dp = 6; dp <= 26; dp++) {
            ok(SidebarInputPolicy.edgeTouchWidthDp(dp) == dp,
                    "no transparent intercepting halo around visible strip");
        }
        ok(SidebarInputPolicy.edgeTouchWidthDp(2) == 6, "minimum visible tab");
        ok(SidebarInputPolicy.edgeTouchWidthDp(55) == 26, "maximum visible tab");
        ok(!SidebarInputPolicy.mayOpenFromTap(false, true, true), "swipe-only tap cannot open");
        ok(!SidebarInputPolicy.mayOpenFromTap(true, false, false), "disabled menu cannot open");
        ok(SidebarInputPolicy.mayOpenFromTap(true, false, true), "tap-enabled menu can open");
        ok(!SidebarInputPolicy.mayOpenFromTap(true, true, true),
                "swipe-only edge wins even when tap mode is enabled");
        System.out.println(checks + " global vibration / minimized sidebar touch tests PASS");
    }
}
