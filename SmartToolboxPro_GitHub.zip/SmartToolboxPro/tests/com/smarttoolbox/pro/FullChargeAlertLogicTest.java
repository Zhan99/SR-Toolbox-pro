package com.smarttoolbox.pro;

public final class FullChargeAlertLogicTest {
    private static int checks;
    private static void check(boolean pass, String label) {
        checks++; if (!pass) throw new AssertionError(label);
    }
    private static int decide(boolean enabled, int plugged, int status, int level, int scale,
                              boolean announced) {
        return FullChargeAlertLogic.decision(enabled, plugged, status, level, scale, announced);
    }
    public static void main(String[] args) {
        check(FullChargeAlertLogic.isPowered(1), "AC power");
        check(FullChargeAlertLogic.isPowered(2), "USB power");
        check(FullChargeAlertLogic.isPowered(4), "wireless power");
        check(!FullChargeAlertLogic.isPowered(0), "disconnected");
        check(!FullChargeAlertLogic.isPowered(-1), "invalid plug");
        check(FullChargeAlertLogic.isFull(5, 99, 100), "Android reported FULL");
        check(FullChargeAlertLogic.isFull(2, 100, 100), "100 percent charging");
        check(!FullChargeAlertLogic.isFull(2, 99, 100), "99 percent");
        check(!FullChargeAlertLogic.isFull(2, 100, 0), "zero scale");
        check(!FullChargeAlertLogic.isFull(2, -1, 100), "invalid level");
        check(FullChargeAlertLogic.percent(50, 100) == 50, "half");
        check(FullChargeAlertLogic.percent(100, 100) == 100, "full");
        check(FullChargeAlertLogic.percent(-1, 100) == -1, "unknown");
        check(FullChargeAlertLogic.percent(100, 0) == -1, "invalid scale");
        check(FullChargeAlertLogic.percent(200, 100) == 100, "clamped above");
        check(decide(true, 1, 2, 100, 100, false) == FullChargeAlertLogic.ANNOUNCE_ONCE,
                "100% on charger announces");
        check(decide(true, 4, 5, 98, 100, false) == FullChargeAlertLogic.ANNOUNCE_ONCE,
                "FULL flag on wireless announces");
        check(decide(true, 1, 2, 99, 100, false) == FullChargeAlertLogic.IGNORE,
                "99% not announced");
        check(decide(true, 1, 2, 100, 100, true) == FullChargeAlertLogic.IGNORE,
                "repeat event suppressed");
        check(decide(true, 1, 5, 100, 100, true) == FullChargeAlertLogic.IGNORE,
                "repeat FULL status suppressed");
        check(decide(true, 0, 5, 100, 100, true) == FullChargeAlertLogic.RESET_SESSION,
                "unplug at full resets");
        check(decide(true, 0, 2, 75, 100, false) == FullChargeAlertLogic.RESET_SESSION,
                "unplug at 75 resets");
        check(decide(false, 1, 5, 100, 100, false) == FullChargeAlertLogic.IGNORE,
                "disabled never alerts");
        check(decide(false, 0, 5, 100, 100, true) == FullChargeAlertLogic.IGNORE,
                "disabled unaffected");
        check(decide(true, 1, -1, -1, 100, false) == FullChargeAlertLogic.IGNORE,
                "unknown battery no alarm");
        int first = decide(true, 1, 2, 100, 100, false);
        int duplicate = decide(true, 1, 2, 100, 100, first == FullChargeAlertLogic.ANNOUNCE_ONCE);
        int reset = decide(true, 0, 5, 100, 100, true);
        int next = decide(true, 1, 5, 100, 100, reset != FullChargeAlertLogic.RESET_SESSION);
        check(first == FullChargeAlertLogic.ANNOUNCE_ONCE, "first charged session");
        check(duplicate == FullChargeAlertLogic.IGNORE, "no duplicate in a session");
        check(reset == FullChargeAlertLogic.RESET_SESSION, "reset charging session");
        check(next == FullChargeAlertLogic.ANNOUNCE_ONCE, "second plugged session");
        System.out.println(checks + " full-charge voice alert logic tests passed");
    }
}
