package com.smarttoolbox.pro;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Arrays;

/** Streams synthetic unsigned APK-like ZIP bytes; no claims about real APK signatures. */
public final class ApkStreamIntegrityTest {
    private static int checks;
    private static void check(boolean ok,String msg) {checks++;if(!ok)throw new AssertionError(msg);}
    public static void main(String[] args)throws Exception {
        byte[] original=new byte[500123];
        for(int i=0;i<original.length;i++)original[i]=(byte)((i*251+71)&0xff);
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        ApkStreamIntegrity.Result result=ApkStreamIntegrity.copy(new ByteArrayInputStream(original),out);
        byte[] restored=out.toByteArray();
        check(restored.length==original.length,"unchanged size");
        check(Arrays.equals(original,restored),"byte-for-byte copy");
        check(result.bytes==original.length,"stream count");
        check(result.sha256.equals(ApkStreamIntegrity.sha256(new ByteArrayInputStream(original))),"source digest");
        check(result.sha256.equals(ApkStreamIntegrity.sha256(new ByteArrayInputStream(restored))),"destination digest");
        restored[12345]^=1;
        check(!result.sha256.equals(ApkStreamIntegrity.sha256(new ByteArrayInputStream(restored))),"tampering detected");
        byte[] empty=new byte[0];
        check(ApkStreamIntegrity.sha256(new ByteArrayInputStream(empty)).length()==64,"empty SHA-256");
        boolean throwsError=false;
        try{ApkStreamIntegrity.copy(null,new ByteArrayOutputStream());}catch(java.io.IOException e){throwsError=true;}
        check(throwsError,"invalid streams refused");
        System.out.println(checks+" byte-exact APK stream/integrity checks passed");
    }
}
