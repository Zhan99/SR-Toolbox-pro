package com.smarttoolbox.pro;

public final class GroupQueueLogicTest {
    private static int checked;
    private static void assertThat(boolean condition, String reason) {
        checked++; if (!condition) throw new AssertionError(reason);
    }
    public static void main(String[] args) {
        assertThat(GroupQueueLogic.mayQueue("family", "family", false, 0), "same group queued");
        assertThat(GroupQueueLogic.mayQueue("family", "family", false, 18), "last slot");
        assertThat(!GroupQueueLogic.mayQueue("family", "family", false, 19), "limit 20");
        assertThat(!GroupQueueLogic.mayQueue("family", "work", false, 0), "unrelated batch fallback");
        assertThat(!GroupQueueLogic.mayQueue("family", "family", true, 0), "no duplicates");
        assertThat(!GroupQueueLogic.mayQueue("", "family", false, 0), "no running group");
        assertThat(!GroupQueueLogic.mayQueue(null, "family", false, 0), "null safe");
        assertThat(!GroupQueueLogic.mayQueue("family", null, false, 0), "incoming null safe");
        assertThat(!GroupQueueLogic.mayQueue("family", "family", false, -1), "negative count");
        System.out.println(checked + " broadcast queue tests passed");
    }
}
