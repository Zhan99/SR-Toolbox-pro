package com.smarttoolbox.pro;

public final class ApkBackupLogicTest {
    private static int checks = 0;
    private static void verify(boolean yes, String message) {
        checks++; if (!yes) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        verify("com.example.app".equals(ApkBackupLogic.safeName("com.example.app")), "package name");
        verify("a_b".equals(ApkBackupLogic.safeName("a/b")), "unsafe slash");
        verify(!ApkBackupLogic.safeName("../secret").contains("..") && !ApkBackupLogic.safeName("../secret").contains("/"), "path traversal");
        verify("unknown".equals(ApkBackupLogic.safeName(null)), "null safe");
        verify(ApkBackupLogic.safeName("x".repeat(200)).length() == 96, "filename bound");
        verify(!ApkBackupLogic.isSplit(null), "null split");
        verify(!ApkBackupLogic.isSplit(new String[]{}), "empty split");
        verify(ApkBackupLogic.isSplit(new String[]{"/data/app/split_config.apk"}), "split present");
        verify(!ApkBackupLogic.isSplit(new String[]{null, ""}), "no valid splits");
        verify(ApkBackupLogic.fileName("com.test", 12, false, 999).endsWith(".apk"), "single original APK");
        verify(ApkBackupLogic.fileName("com.test", 12, true, 999).endsWith(".apks"), "split container");
        verify(!ApkBackupLogic.fileName("a", -4, false, -1).contains("--"), "negative safe");
        verify(ApkBackupLogic.isRestorableFile("SAMPLE.APK"), "case insensitive apk");
        verify(ApkBackupLogic.isRestorableFile("x.apks"), "split container recognized");
        verify(!ApkBackupLogic.isRestorableFile("x.zip"), "unrelated zip rejected");
        verify(!ApkBackupLogic.isRestorableFile(null), "null archive rejected");
        verify(ApkBackupLogic.matches("WhatsApp", "com.whatsapp", "what"), "label search");
        verify(ApkBackupLogic.matches("Messenger", "com.facebook.katana", "KATANA"), "package search");
        verify(!ApkBackupLogic.matches("One", "a.b.c", "other"), "search negative");
        verify(ApkBackupLogic.matches("One", "a.b.c", " "), "empty search");
        verify(ApkBackupLogic.inCategory(false, 0), "all user");
        verify(ApkBackupLogic.inCategory(true, 0), "all system");
        verify(ApkBackupLogic.inCategory(false, 1), "user filter");
        verify(!ApkBackupLogic.inCategory(true, 1), "system excluded");
        verify(ApkBackupLogic.inCategory(true, 2), "system filter");
        verify(!ApkBackupLogic.inCategory(false, 2), "user excluded");
        verify(ApkBackupLogic.canUninstall(false, "app", "self"), "user uninstallable");
        verify(!ApkBackupLogic.canUninstall(true, "app", "self"), "system app guarded");
        verify(!ApkBackupLogic.canUninstall(false, "self", "self"), "self removal guarded");
        verify("0 B".equals(ApkBackupLogic.fileSize(-1)), "negative file size");
        verify("1.0 KB".equals(ApkBackupLogic.fileSize(1024)), "KB format");
        verify("1.0 MB".equals(ApkBackupLogic.fileSize(1048576)), "MB format");
        verify(ApkBackupLogic.permittedApkZipEntry("base.apk"), "base valid");
        verify(ApkBackupLogic.permittedApkZipEntry("split_000.apk"), "split valid");
        verify(!ApkBackupLogic.permittedApkZipEntry("../base.apk"), "zip traversal denied");
        verify(!ApkBackupLogic.permittedApkZipEntry("notes.txt"), "arbitrary zip denied");
        System.out.println(checks + " APK backup/restore policy regression checks passed");
    }
}
