package com.smarttoolbox.pro;

import java.time.LocalDate;
import java.time.YearMonth;
import java.time.ZoneId;
import java.time.LocalDateTime;

public final class SchedulerInboxLogicTest {
    static int checks;
    static void check(boolean ok, String reason) {
        checks++; if (!ok) throw new AssertionError(reason);
    }
    static long ms(int y,int m,int d,int hour,ZoneId zone) {
        return LocalDateTime.of(y,m,d,hour,0).atZone(zone).toInstant().toEpochMilli();
    }
    public static void main(String[] args) {
        ZoneId zone=ZoneId.of("Asia/Dhaka");
        LocalDate today=LocalDate.of(2026,11,24);
        long past=ms(2026,11,20,10,zone), now=ms(2026,11,24,8,zone), future=ms(2026,12,3,15,zone);
        check(SchedulerInboxLogic.onDate(past,0,LocalDate.of(2026,11,20),zone),"past day marked");
        check(!SchedulerInboxLogic.onDate(past,0,today,zone),"past day not today");
        check(SchedulerInboxLogic.onDate(future,0,LocalDate.of(2026,12,3),zone),"future marked");
        check(SchedulerInboxLogic.onDate(past,now,today,zone),"triggered today marked too");
        check(SchedulerInboxLogic.onDate(now,0,today,zone),"today schedule");
        check(!SchedulerInboxLogic.onDate(0,0,today,zone),"empty record not marked");
        check(!SchedulerInboxLogic.onDate(past,now,null,zone),"null date safe");
        check(!SchedulerInboxLogic.showSelectedDay(null,today),"default today only");
        check(!SchedulerInboxLogic.showSelectedDay(today,today),"today click no duplicate list");
        check(SchedulerInboxLogic.showSelectedDay(today.minusDays(2),today),"past opens");
        check(SchedulerInboxLogic.showSelectedDay(today.plusDays(2),today),"future opens");
        check(SchedulerInboxLogic.monthFor(today,YearMonth.of(2026,10)).equals(YearMonth.of(2026,11)),"selected month");
        check(SchedulerInboxLogic.monthFor(null,YearMonth.of(2026,10)).equals(YearMonth.of(2026,10)),"preserve month");
        check(SchedulerInboxLogic.onDate(ms(2026,12,31,23,zone),0,LocalDate.of(2026,12,31),zone),"year boundary");
        System.out.println(checks+" scheduler inbox calendar checks passed");
    }
}
