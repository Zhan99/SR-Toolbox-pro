package com.smarttoolbox.pro;

public final class ApkBackupRulesTest {
    static int checks;
    static void yes(boolean x, String why) { checks++; if(!x) throw new AssertionError(why); }
    public static void main(String[] args) {
        yes(ApkBackupRules.safePart(null).equals("unknown"), "null");
        yes(ApkBackupRules.safePart("a/b?*c").equals("a_b__c"), "unsafe chars");
        yes(!ApkBackupRules.safePart("../../secret").contains(".."), "traversal");
        yes(ApkBackupRules.safePart(".").equals("unknown"), "dot");
        yes(ApkBackupRules.safePart("a".repeat(200)).length()==100, "limit");
        yes(ApkBackupRules.archiveFolder("com.test.app",34,100).equals("com.test.app__34__100"),"archive name");
        yes(ApkBackupRules.duplicate("com.x",1,"AbC","com.x",1,"abc"),"same bytes");
        yes(!ApkBackupRules.duplicate("com.x",1,"a","com.x",2,"a"),"other version");
        yes(!ApkBackupRules.duplicate("com.x",1,"a","com.y",1,"a"),"other app");
        yes(!ApkBackupRules.duplicate("com.x",1,"", "com.x",1,""),"no digest");
        yes(ApkBackupRules.SORT_LABELS.length==8,"sorting choices");
        yes(ApkBackupRules.validArchivePart("base.apk"),"base APK path");
        yes(ApkBackupRules.validArchivePart("splits/split_config.en.apk"),"split APK path");
        yes(!ApkBackupRules.validArchivePart("splits/../../private.apk"),"split traversal rejected");
        yes(!ApkBackupRules.validArchivePart("icon.png"),"metadata not an APK part");
        yes(!ApkBackupRules.validArchivePart(null),"null APK part");
        yes(ApkBackupRules.compare(0,"Alpha","Zulu",0,0,0,0,true,true,true,true)<0,"asc");
        yes(ApkBackupRules.compare(1,"Alpha","Zulu",0,0,0,0,true,true,true,true)>0,"desc");
        yes(ApkBackupRules.compare(2,"A","B",1,2,0,0,true,true,true,true)<0,"date oldest");
        yes(ApkBackupRules.compare(3,"A","B",1,2,0,0,true,true,true,true)>0,"date newest");
        yes(ApkBackupRules.compare(4,"A","B",0,0,1,2,true,true,true,true)<0,"size small");
        yes(ApkBackupRules.compare(5,"A","B",0,0,1,2,true,true,true,true)>0,"size big");
        yes(ApkBackupRules.compare(6,"A","B",0,0,0,0,false,true,true,true)<0,"not installed first");
        yes(ApkBackupRules.compare(7,"A","B",0,0,0,0,true,true,false,true)<0,"not archived first");
        System.out.println(checks+" archive name / duplicate / sort checks passed");
    }
}
