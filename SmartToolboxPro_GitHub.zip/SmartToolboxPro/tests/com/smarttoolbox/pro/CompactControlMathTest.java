package com.smarttoolbox.pro;

public final class CompactControlMathTest {
    private static int checks;
    private static void check(boolean value, String message) {
        if (!value) throw new AssertionError(message);
        checks++;
    }
    public static void main(String[] args) {
        check(CompactControlMath.levelFromTouch(-30, 300, 12, 95) == 0, "left clamped");
        check(CompactControlMath.levelFromTouch(330, 300, 12, 95) == 95, "right clamped");
        check(CompactControlMath.levelFromTouch(150, 300, 12, 1000) == 500, "middle level");
        check(CompactControlMath.levelFromTouch(150, 300, 12, 95) == 48, "night level");
        check(CompactControlMath.levelFromTouch(20, 0, 12, 95) >= 0, "tiny view safe");
        check(CompactControlMath.isHorizontalDrag(30, 2, 8), "horizontal dragging");
        check(!CompactControlMath.isHorizontalDrag(3, 2, 8), "tap is not drag");
        check(!CompactControlMath.isHorizontalDrag(20, 40, 8), "vertical scroll is not slider");
        check(CompactControlMath.isHorizontalDrag(-31, 8, 8), "negative drag");
        check(CompactControlMath.panelHeight(550, 250, 800, 16) == 250, "height cap");
        check(CompactControlMath.panelHeight(180, 250, 800, 16) == 180, "natural height");
        check(CompactControlMath.panelHeight(1200, 700, 640, 16) == 608, "screen cap");
        System.out.println(checks + " compact control and height geometry checks passed");
    }
}
