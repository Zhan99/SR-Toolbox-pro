package com.smarttoolbox.pro;

public final class GalleryBarcodeResultLogicTest {
    private static int checks;
    private static void eq(String actual,String expected,String msg) {
        checks++; if (!expected.equals(actual)) throw new AssertionError(msg+": "+actual);
    }
    public static void main(String[] args) {
        eq(GalleryBarcodeResultLogic.status(true,0,false),"Image selection cancelled.","cancel");
        eq(GalleryBarcodeResultLogic.status(true,4,true),"Image selection cancelled.","cancel priority");
        eq(GalleryBarcodeResultLogic.status(false,0,false),"No QR code or barcode found in this image.","empty");
        eq(GalleryBarcodeResultLogic.status(false,-1,false),"No QR code or barcode found in this image.","invalid count");
        eq(GalleryBarcodeResultLogic.status(false,3,false),"A barcode was detected but it has no readable text.","binary barcode");
        eq(GalleryBarcodeResultLogic.status(false,1,true),"Gallery image scan successful.","valid QR");
        eq(GalleryBarcodeResultLogic.status(false,5,true),"Gallery image scan successful.","multiple results");
        System.out.println(checks+" gallery barcode status tests passed");
    }
}
