package com.smarttoolbox.pro;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
public class AppsBackupPayloadTest {
    private static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
    public static void main(String[] args) throws Exception {
        Path dir=Files.createTempDirectory("apk-payload-test");
        Path a=dir.resolve("base.apk"), b=dir.resolve("config.apk");
        byte[] base=new byte[131091], split=new byte[70001];
        new Random(123).nextBytes(base);new Random(456).nextBytes(split);
        try {
            Files.write(a,base);Files.write(b,split);
            String[] paths={a.toString(),b.toString()};
            ByteArrayOutputStream out=new ByteArrayOutputStream();
            AppsBackupPayload.writeBase(paths,out);
            check(Arrays.equals(base,out.toByteArray()),"base APK bytes changed");
            out.reset();AppsBackupPayload.writeFull(new String[]{paths[0]},out);
            check(Arrays.equals(base,out.toByteArray()),"ordinary APK bytes changed");
            out.reset();AppsBackupPayload.writeFull(paths,out);
            try(ZipInputStream zip=new ZipInputStream(new ByteArrayInputStream(out.toByteArray()))) {
                check("base.apk".equals(zip.getNextEntry().getName()),"missing base");
                check(Arrays.equals(base,zip.readAllBytes()),"base archive bytes changed");
                check("split_1.apk".equals(zip.getNextEntry().getName()),"missing split");
                check(Arrays.equals(split,zip.readAllBytes()),"split archive bytes changed");
                check(zip.getNextEntry()==null,"unexpected archive part");
            }
            try { AppsBackupPayload.writeBase(new String[0],out);throw new AssertionError("empty paths accepted"); } catch(IOException expected) {}
            try { AppsBackupPayload.writeFull(new String[]{paths[0],dir.resolve("missing.apk").toString()},out);throw new AssertionError("missing split accepted"); } catch(IOException expected) {}
            System.out.println("PASS: raw base, standalone APK, full split archive, invalid paths");
        } finally { Files.deleteIfExists(a);Files.deleteIfExists(b);Files.deleteIfExists(dir); }
    }
}
