package com.smarttoolbox.pro;

import java.time.LocalDateTime;
import java.time.ZoneId;

public final class SchedulerSectionLogicTest {
    private static int checks;
    private static void check(boolean yes, String label) {
        checks++;
        if (!yes) throw new AssertionError(label);
    }
    private static long ms(int year,int month,int day,int hour,int minute,ZoneId zone) {
        return LocalDateTime.of(year,month,day,hour,minute).atZone(zone).toInstant().toEpochMilli();
    }
    public static void main(String[] args) {
        ZoneId dhaka = ZoneId.of("Asia/Dhaka");
        long now = ms(2026,11,15,12,41,dhaka);
        check(SchedulerSectionLogic.TODAY.equals(SchedulerSectionLogic.sectionFor("pending",ms(2026,11,15,13,0,dhaka),now,dhaka)),"today pending");
        check(SchedulerSectionLogic.TOMORROW.equals(SchedulerSectionLogic.sectionFor("pending",ms(2026,11,16,1,0,dhaka),now,dhaka)),"tomorrow");
        check(SchedulerSectionLogic.UPCOMING.equals(SchedulerSectionLogic.sectionFor("pending",ms(2026,11,17,0,0,dhaka),now,dhaka)),"future");
        check(SchedulerSectionLogic.HISTORY.equals(SchedulerSectionLogic.sectionFor("pending",ms(2026,11,15,12,40,dhaka),now,dhaka)),"overdue pending not counted as future");
        check(SchedulerSectionLogic.HISTORY.equals(SchedulerSectionLogic.sectionFor("done",ms(2026,11,16,1,0,dhaka),now,dhaka)),"done regardless date");
        check(SchedulerSectionLogic.HISTORY.equals(SchedulerSectionLogic.sectionFor("attempted",ms(2026,11,15,14,0,dhaka),now,dhaka)),"attempted not claimed delivered");
        check(SchedulerSectionLogic.HISTORY.equals(SchedulerSectionLogic.sectionFor("due",now+1000,now,dhaka)),"due");
        check(SchedulerSectionLogic.PAUSED.equals(SchedulerSectionLogic.sectionFor("paused",now-1000,now,dhaka)),"paused even if old");
        check(SchedulerSectionLogic.HISTORY.equals(SchedulerSectionLogic.sectionFor("unknown",now+1000,now,dhaka)),"unknown safe");
        check(SchedulerSectionLogic.TODAY.equals(SchedulerSectionLogic.sectionFor("pending",ms(2026,11,15,23,59,dhaka),now,dhaka)),"same day late");
        check(SchedulerSectionLogic.TOMORROW.equals(SchedulerSectionLogic.sectionFor("pending",ms(2026,11,16,0,0,dhaka),now,dhaka)),"midnight boundary");
        check(SchedulerSectionLogic.TOMORROW.equals(SchedulerSectionLogic.sectionFor("pending",ms(2027,1,1,0,0,dhaka),ms(2026,12,31,23,59,dhaka),dhaka)),"year boundary");
        ZoneId ny = ZoneId.of("America/New_York");
        check(SchedulerSectionLogic.TOMORROW.equals(SchedulerSectionLogic.sectionFor("pending",ms(2026,3,8,4,0,ny),ms(2026,3,7,22,0,ny),ny)),"DST change next calendar day");
        check(SchedulerSectionLogic.ORDER.size()==5,"all five groups present");
        check(SchedulerSectionLogic.defaultExpanded(SchedulerSectionLogic.TODAY),"today opens by default");
        check(!SchedulerSectionLogic.defaultExpanded(SchedulerSectionLogic.HISTORY),"history folded by default");
        check(SchedulerSectionLogic.mostRecentFirst(SchedulerSectionLogic.HISTORY),"history reverse sort");
        check(!SchedulerSectionLogic.mostRecentFirst(SchedulerSectionLogic.TOMORROW),"future ascending");
        for (String id: SchedulerSectionLogic.ORDER) {
            check(!SchedulerSectionLogic.title(id).isEmpty(),"title " + id);
            check(!SchedulerSectionLogic.icon(id).isEmpty(),"icon " + id);
        }
        System.out.println(checks+" scheduler section classification checks passed");
    }
}
