package com.smarttoolbox.pro;

public final class AppsBackupFolderLogicTest {
    private static int checks;
    private static void yes(boolean ok,String why){checks++;if(!ok)throw new AssertionError(why);}
    public static void main(String[] args){
        yes(!AppsBackupFolderLogic.publicStorageAvailable(28),"Android 9 uses folder picker");
        yes(AppsBackupFolderLogic.publicStorageAvailable(29),"Android 10 public Download");
        yes(AppsBackupFolderLogic.publicStorageAvailable(35),"Android 15 public Download");
        yes("App Backup".equals(AppsBackupFolderLogic.FOLDER),"root folder name");
        yes("Split backups".equals(AppsBackupFolderLogic.SPLIT),"split folder name");
        yes(AppsBackupFolderLogic.isAppFolder("App Backup"),"avoid nested folder");
        yes(AppsBackupFolderLogic.isAppFolder("app backup"),"case-independent folder");
        yes(!AppsBackupFolderLogic.isAppFolder("Downloads"),"parent distinct");
        String stem=AppsBackupFolderLogic.uniqueStem("bKash","com.bkash.customer",42,"5.0",123456L);
        yes(stem.startsWith("bKash__com.bkash.customer__42__5.0-"),"readable filename");
        yes(stem.endsWith("123456"),"timestamp avoids collision");
        yes(AppsBackupArchiveLogic.paired(stem+".apk",stem+".apks"),"base/split match");
        yes("App".equals(AppsBackupFolderLogic.safe(null,"App")),"null safe");
        yes("App".equals(AppsBackupFolderLogic.safe(" ","App")),"empty safe");
        yes(!AppsBackupFolderLogic.safe("a/b:c","App").contains("/"),"bad path removed");
        yes(AppsBackupFolderLogic.safe("a".repeat(100),"App").length()==48,"name capped");
        yes(!AppsBackupFolderLogic.uniqueStem("Example","x",1,"v",999).equals(
                AppsBackupFolderLogic.uniqueStem("Example","x",1,"v",1000)),"unique per time");
        System.out.println(checks+" public backup folder and filename tests passed");
    }
}
