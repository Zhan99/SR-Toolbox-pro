package com.smarttoolbox.pro;

public final class BatteryFullAlertLogicTest {
    private static int count;
    private static void ok(boolean condition, String label) {
        count++;
        if (!condition) throw new AssertionError(label);
    }
    public static void main(String[] args) {
        ok(BatteryFullAlertLogic.isFull(100, 100, 5, 5), "full status");
        ok(BatteryFullAlertLogic.isFull(100, 100, 2, 5), "level 100");
        ok(BatteryFullAlertLogic.isFull(1000, 1000, 2, 5), "scaled 100");
        ok(!BatteryFullAlertLogic.isFull(99, 100, 2, 5), "99 not full");
        ok(!BatteryFullAlertLogic.isFull(-1, -1, 2, 5), "unknown level not full");
        ok(!BatteryFullAlertLogic.isFull(100, 0, 2, 5), "invalid scale");
        ok(!BatteryFullAlertLogic.shouldAnnounce(true, false, true, false), "unplugged no voice");
        ok(!BatteryFullAlertLogic.shouldAnnounce(true, true, false, false), "charging not full");
        ok(!BatteryFullAlertLogic.shouldAnnounce(false, true, true, false), "opt-out no voice");
        ok(!BatteryFullAlertLogic.shouldAnnounce(true, true, true, true), "already spoken no repeat");
        ok(BatteryFullAlertLogic.shouldAnnounce(true, true, true, false), "new full charge once");
        boolean alerted=false;
        alerted=BatteryFullAlertLogic.shouldAnnounce(true,true,true,alerted);
        ok(alerted, "initial full charge transition");
        ok(BatteryFullAlertLogic.nextAnnouncedState(true,true,alerted), "persist latch on same charge");
        ok(!BatteryFullAlertLogic.shouldAnnounce(true,true,true,alerted), "duplicate broadcast silent");
        alerted=BatteryFullAlertLogic.nextAnnouncedState(false,true,alerted);
        ok(!alerted, "unplug resets");
        ok(BatteryFullAlertLogic.shouldAnnounce(true,true,true,alerted), "replug full retriggers");
        alerted=true;
        alerted=BatteryFullAlertLogic.nextAnnouncedState(true,false,alerted);
        ok(!alerted, "level below full rearms");
        ok(BatteryFullAlertLogic.shouldAnnounce(true,true,true,alerted), "reached 100 from 99");
        ok(!BatteryFullAlertLogic.nextAnnouncedState(false,false,true), "unplug low resets");
        ok(!BatteryFullAlertLogic.nextAnnouncedState(true,true,false), "unlatched remains unlatched");
        System.out.println(count + " full-charge Bengali alert logic tests passed");
    }
}
