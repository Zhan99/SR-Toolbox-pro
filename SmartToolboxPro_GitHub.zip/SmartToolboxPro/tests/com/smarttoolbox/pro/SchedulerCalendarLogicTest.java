package com.smarttoolbox.pro;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Set;

public final class SchedulerCalendarLogicTest {
    private static int tests;
    private static void check(boolean value, String title) {
        tests++; if (!value) throw new AssertionError(title);
    }
    private static long at(ZoneId z, int y, int m, int d, int h, int min) {
        return LocalDateTime.of(y,m,d,h,min).atZone(z).toInstant().toEpochMilli();
    }
    public static void main(String[] args) {
        ZoneId dhaka = ZoneId.of("Asia/Dhaka");
        long yesterday = at(dhaka, 2026,11,23,18,30);
        long todayMorning = at(dhaka,2026,11,24,8,20);
        long todayLate = at(dhaka,2026,11,24,19,0);
        check(SchedulerCalendarLogic.futureWithOriginalTime(yesterday,todayMorning,60_000,dhaka)
                == at(dhaka,2026,11,24,18,30), "past date becomes today with same time");
        check(SchedulerCalendarLogic.futureWithOriginalTime(yesterday,todayLate,60_000,dhaka)
                == at(dhaka,2026,11,25,18,30), "time elapsed -> tomorrow same time");
        long future = at(dhaka,2026,12,1,7,45);
        check(SchedulerCalendarLogic.futureWithOriginalTime(future,todayMorning,60_000,dhaka)
                == future,"future schedule unchanged");
        check(SchedulerCalendarLogic.futureWithOriginalTime(yesterday,
                at(dhaka,2026,11,24,18,29),60_000,dhaka)
                == at(dhaka,2026,11,25,18,30),"minute lead required");
        check(SchedulerCalendarLogic.futureWithOriginalTime(yesterday,
                at(dhaka,2026,11,24,18,28),60_000,dhaka)
                == at(dhaka,2026,11,24,18,30),"2-minute lead allowed");
        check(SchedulerCalendarLogic.futureWithOriginalTime(at(dhaka,2025,12,31,23,45),
                at(dhaka,2026,12,31,12,0),60_000,dhaka)
                == at(dhaka,2026,12,31,23,45),"year boundary preserves clock");
        long[] scheduled={yesterday,at(dhaka,2026,11,22,8,0),yesterday};
        long[] triggered={0,at(dhaka,2026,11,24,7,0),0};
        Set<LocalDate> dots=SchedulerCalendarLogic.markedDates(scheduled,triggered,dhaka);
        check(dots.size()==3,"unique marked days from schedules and triggers");
        check(dots.contains(LocalDate.of(2026,11,23)),"past message marked");
        check(dots.contains(LocalDate.of(2026,11,22)),"another past message marked");
        check(dots.contains(LocalDate.of(2026,11,24)),"repeating trigger day marked");
        check(SchedulerCalendarLogic.markedDates(null,null,dhaka).isEmpty(),"null lists safe");
        check(SchedulerCalendarLogic.markedDates(new long[]{0,-1},new long[]{0},dhaka).isEmpty(),"zero timestamps skipped");
        check(SchedulerCalendarLogic.toLocalDate(yesterday,dhaka).equals(LocalDate.of(2026,11,23)),"local calendar conversion");
        ZoneId ny=ZoneId.of("America/New_York");
        check(SchedulerCalendarLogic.futureWithOriginalTime(at(ny,2026,3,7,9,15),
                at(ny,2026,3,8,8,0),60_000,ny)==at(ny,2026,3,8,9,15),
                "DST spring day correct local time");
        check(SchedulerCalendarLogic.futureWithOriginalTime(at(ny,2026,11,1,19,15),
                at(ny,2026,11,2,10,0),60_000,ny)==at(ny,2026,11,2,19,15),
                "DST fall day local time");
        System.out.println(tests+" calendar marked-date and history rebasing tests passed");
    }
}
