package com.smarttoolbox.pro;

public final class BubbleSlideLogicTest {
    private static void ok(boolean condition, String what) {
        if (!condition) throw new AssertionError(what);
    }
    public static void main(String[] args) {
        ok(BubbleSlideLogic.revealStartX(true, 400, 60) == -30, "left edge entry");
        ok(BubbleSlideLogic.revealStartX(false, 400, 60) == 370, "right edge entry");
        ok(BubbleSlideLogic.interpolate(-30, 5, 0f) == -30, "left initial");
        ok(BubbleSlideLogic.interpolate(-30, 5, 1f) == 5, "left final");
        ok(BubbleSlideLogic.interpolate(370, 335, 0.5f) == 353, "right halfway");
        ok(BubbleSlideLogic.interpolate(-30, 5, -2f) == -30, "low clamp");
        ok(BubbleSlideLogic.interpolate(-30, 5, 5f) == 5, "high clamp");
        ok(Math.abs(BubbleSlideLogic.alpha(.4f, .8f, .5f) - .6f) < .001f, "alpha fade");
        System.out.println("8 bubble slide animation checks passed");
    }
}
