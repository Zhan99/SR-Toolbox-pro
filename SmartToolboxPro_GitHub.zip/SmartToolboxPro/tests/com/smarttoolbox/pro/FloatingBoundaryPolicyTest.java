package com.smarttoolbox.pro;
public final class FloatingBoundaryPolicyTest {
    private static int tested;
    private static void check(boolean yes,String title){ tested++; if(!yes) throw new AssertionError(title); }
    public static void main(String[] args){
        check(FloatingBoundaryPolicy.shouldAutoDock(true,false,false,false),"border default");
        check(!FloatingBoundaryPolicy.shouldAutoDock(true,true,false,false),"manual override wins");
        check(!FloatingBoundaryPolicy.shouldAutoDock(true,false,true,false),"panel protects");
        check(!FloatingBoundaryPolicy.shouldAutoDock(true,false,false,true),"touch protects");
        check(!FloatingBoundaryPolicy.shouldAutoDock(false,false,false,false),"explicit auto-hide off");
        check(FloatingBoundaryPolicy.edgeX(5,50,400)==0,"near left");
        check(FloatingBoundaryPolicy.edgeX(340,50,400)==350,"near right");
        check(FloatingBoundaryPolicy.edgeX(200,50,400)==350,"center prefers right");
        check(FloatingBoundaryPolicy.edgeX(0,48,0)==0,"zero display safe");
        check(FloatingBoundaryPolicy.clamp(-8,48,400)==0,"left clamp");
        check(FloatingBoundaryPolicy.clamp(450,48,400)==352,"right clamp");
        check(FloatingBoundaryPolicy.clamp(190,48,400)==190,"manual interior position allowed");
        check(FloatingBoundaryPolicy.clamp(190,48,20)==0,"small display safe");
        check(FloatingBoundaryPolicy.PREF_MANUAL_POSITION.contains("manual_position"),"stable persistent flag");
        System.out.println(tested+" border/manual position tests passed");
    }
}
