package com.smarttoolbox.pro;
public final class SwipeVibrationLogicTest {
    private static int cases;
    private static void check(boolean outcome,String label) {
        cases++;
        if (!outcome) throw new AssertionError(label);
    }
    public static void main(String[] args) {
        check(SwipeVibrationLogic.shouldVibrate(true,true,true,false,true),"swipe opens and vibrates");
        check(!SwipeVibrationLogic.shouldVibrate(false,true,true,false,true),"app setting off");
        check(!SwipeVibrationLogic.shouldVibrate(true,false,true,false,true),"menu disabled");
        check(!SwipeVibrationLogic.shouldVibrate(true,true,false,false,true),"tap no vibration");
        check(!SwipeVibrationLogic.shouldVibrate(true,true,true,true,true),"drag no vibration");
        check(!SwipeVibrationLogic.shouldVibrate(true,true,true,false,false),"system haptics disabled");
        check(SwipeVibrationLogic.PREF.startsWith("floating."),"preference namespace");
        System.out.println(cases+" swipe vibration gating tests passed");
    }
}
