package com.smarttoolbox.pro;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class SchedulerBatchUiLogicTest {
    private static int checks;
    private static void expect(boolean pass, String label) {
        checks++; if (!pass) throw new AssertionError(label);
    }
    public static void main(String[] args) {
        expect("group:abc".equals(SchedulerBatchUiLogic.cardKey("a", "abc")), "one group key");
        expect("group:abc".equals(SchedulerBatchUiLogic.cardKey("b", "abc")), "same group one key");
        expect(!SchedulerBatchUiLogic.cardKey("a", "abc").equals(SchedulerBatchUiLogic.cardKey("c", "xyz")), "different batch");
        expect("single:a".equals(SchedulerBatchUiLogic.cardKey("a", "")), "single empty batch");
        expect("single:a".equals(SchedulerBatchUiLogic.cardKey("a", null)), "single null batch");
        expect(!SchedulerBatchUiLogic.cardKey("a", "").equals(SchedulerBatchUiLogic.cardKey("b", "")), "different singles");
        List<Long> times = Arrays.asList(100L,120L,110L);
        expect(SchedulerBatchUiLogic.representativeIndex(Arrays.asList("done","pending","attempted"),times)==1,"mixed remains active");
        expect(SchedulerBatchUiLogic.representativeIndex(Arrays.asList("pending","pending","done"),times)==0,"earliest pending");
        expect(SchedulerBatchUiLogic.representativeIndex(Arrays.asList("attempted","paused","done"),times)==1,"paused next");
        expect(SchedulerBatchUiLogic.representativeIndex(Arrays.asList("done","attempted","due"),times)==1,"latest history");
        expect(SchedulerBatchUiLogic.representativeIndex(Collections.emptyList(),Collections.emptyList())==-1,"empty safe");
        expect(SchedulerBatchUiLogic.representativeIndex(Arrays.asList("done"),Collections.emptyList())==-1,"mismatch safe");
        expect(SchedulerBatchUiLogic.representativeIndex(null,null)==-1,"null safe");
        for (String status : Arrays.asList("pending","paused","due","attempted","done","other")) {
            expect(!SchedulerBatchUiLogic.statusShort(status).isEmpty(),"label " + status);
        }
        expect(SchedulerBatchUiLogic.statusShort("attempted").contains("not confirmed"),"attempted not delivered");
        expect(SchedulerBatchUiLogic.countStatus(Arrays.asList("done","pending","pending"),"pending")==2,"pending count");
        expect(SchedulerBatchUiLogic.countStatus(null,"pending")==0,"null count");
        System.out.println(checks + " grouped scheduler card assertions passed");
    }
}
