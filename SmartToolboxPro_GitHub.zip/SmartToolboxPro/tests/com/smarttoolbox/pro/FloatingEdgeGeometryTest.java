package com.smarttoolbox.pro;

public final class FloatingEdgeGeometryTest {
    private static int checks;
    private static void eq(int a,int b,String msg) {
        checks++; if (a != b) throw new AssertionError(msg+" expected "+b+" got "+a);
    }
    private static void check(boolean yes,String msg) {
        checks++; if(!yes) throw new AssertionError(msg);
    }
    public static void main(String[] args) {
        // Both device orientations, left/right sides and multiple tab sizes.
        eq(FloatingEdgeGeometry.x(true,1080,100),0,"portrait left");
        eq(FloatingEdgeGeometry.x(false,1080,100),980,"portrait right");
        eq(FloatingEdgeGeometry.x(true,2400,100),0,"landscape left");
        eq(FloatingEdgeGeometry.x(false,2400,100),2300,"landscape right");
        eq(FloatingEdgeGeometry.x(false,720,120),600,"small display right");
        eq(FloatingEdgeGeometry.x(false,20,100),0,"oversize tab clamps");
        eq(FloatingEdgeGeometry.x(true,20,100),0,"oversize left");
        eq(FloatingEdgeGeometry.y(350,2400,200,8),350,"portrait y");
        eq(FloatingEdgeGeometry.y(350,1080,200,8),350,"landscape y");
        eq(FloatingEdgeGeometry.y(-100,1080,200,8),8,"top clamp");
        eq(FloatingEdgeGeometry.y(9999,1080,200,8),872,"bottom clamp");
        eq(FloatingEdgeGeometry.y(9999,300,500,8),0,"oversize clamps");
        eq(FloatingEdgeGeometry.y(7,300,100,-1),7,"bad margin safe");
        check(FloatingEdgeGeometry.leftForDrop(20,1080),"drag near left");
        check(!FloatingEdgeGeometry.leftForDrop(1000,1080),"drag near right");
        check(FloatingEdgeGeometry.leftForDrop(500,1080),"midpoint left");
        check(!FloatingEdgeGeometry.leftForDrop(540,1080),"midpoint right");
        check(FloatingEdgeGeometry.leftForDrop(100,2400),"landscape left");
        check(!FloatingEdgeGeometry.leftForDrop(2300,2400),"landscape right");
        System.out.println(checks+" portrait landscape edge-docking tests passed");
    }
}
