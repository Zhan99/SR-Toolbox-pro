package com.smarttoolbox.pro;

public final class FloatingEdgeGeometryTest {
    private static int checks;
    private static void eq(int a,int b,String msg) {
        checks++; if (a != b) throw new AssertionError(msg+" expected "+b+" got "+a);
    }
    private static void check(boolean yes,String msg) {
        checks++; if(!yes) throw new AssertionError(msg);
    }
    public static void main(String[] args) {
        // Both device orientations, left/right sides and multiple tab sizes.
        eq(FloatingEdgeGeometry.x(true,1080,100),0,"portrait left");
        eq(FloatingEdgeGeometry.x(false,1080,100),980,"portrait right");
        eq(FloatingEdgeGeometry.x(true,2400,100),0,"landscape left");
        eq(FloatingEdgeGeometry.x(false,2400,100),2300,"landscape right");
        eq(FloatingEdgeGeometry.x(false,720,120),600,"small display right");
        eq(FloatingEdgeGeometry.x(false,20,100),0,"oversize tab clamps");
        eq(FloatingEdgeGeometry.x(true,20,100),0,"oversize left");
        eq(FloatingEdgeGeometry.y(350,2400,200,8),350,"portrait y");
        eq(FloatingEdgeGeometry.y(350,1080,200,8),350,"landscape y");
        eq(FloatingEdgeGeometry.y(-100,1080,200,8),8,"top clamp");
        eq(FloatingEdgeGeometry.y(9999,1080,200,8),872,"bottom clamp");
        eq(FloatingEdgeGeometry.y(9999,300,500,8),0,"oversize clamps");
        eq(FloatingEdgeGeometry.y(7,300,100,-1),7,"bad margin safe");
        check(FloatingEdgeGeometry.leftForDrop(20,1080),"drag near left");
        check(!FloatingEdgeGeometry.leftForDrop(1000,1080),"drag near right");
        check(FloatingEdgeGeometry.leftForDrop(500,1080),"midpoint left");
        check(!FloatingEdgeGeometry.leftForDrop(540,1080),"midpoint right");
        check(FloatingEdgeGeometry.leftForDrop(100,2400),"landscape left");
        check(!FloatingEdgeGeometry.leftForDrop(2300,2400),"landscape right");
        eq(FloatingEdgeGeometry.centerForFraction(0.25f,2400),600,"portrait quarter-screen");
        eq(FloatingEdgeGeometry.centerForFraction(0.25f,1080),270,"landscape same relative quarter-height");
        eq(FloatingEdgeGeometry.centerForFraction(0.75f,1080),810,"landscape three quarters");
        eq(FloatingEdgeGeometry.centerForFraction(0.75f,2400),1800,"portrait three quarters");
        eq(FloatingEdgeGeometry.centerForFraction(-1.0f,1080),0,"bad negative ratio clamps");
        eq(FloatingEdgeGeometry.centerForFraction(2.0f,1080),1080,"bad large ratio clamps");
        eq(FloatingEdgeGeometry.centerForFraction(Float.NaN,1000),500,"NaN uses middle");
        eq(FloatingEdgeGeometry.centerForFraction(0.5f,-1),0,"empty display safe");
        check(Math.abs(FloatingEdgeGeometry.centerFraction(600,2400)-0.25f)<0.001f,"save quarter in portrait");
        check(Math.abs(FloatingEdgeGeometry.centerFraction(270,1080)-0.25f)<0.001f,"save quarter in landscape");
        check(Math.abs(FloatingEdgeGeometry.centerFraction(99999,1080)-1f)<0.001f,"large center clamps");
        check(Math.abs(FloatingEdgeGeometry.centerFraction(-20,1080))<0.001f,"negative center clamps");
        check(Math.abs(FloatingEdgeGeometry.centerFraction(0,0)-0.5f)<0.001f,"zero display safe");
        check(FloatingEdgeGeometry.x(true,1080,70)==0,"selected left stays left after rotate");
        check(FloatingEdgeGeometry.x(true,2400,70)==0,"selected left stays left on landscape");
        check(FloatingEdgeGeometry.x(false,1080,70)==1010,"selected right stays right on portrait");
        check(FloatingEdgeGeometry.x(false,2400,70)==2330,"selected right stays right on landscape");
        System.out.println(checks+" portrait landscape edge-docking tests passed");
    }
}
