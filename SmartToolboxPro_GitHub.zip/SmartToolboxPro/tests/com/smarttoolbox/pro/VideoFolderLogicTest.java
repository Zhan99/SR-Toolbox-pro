package com.smarttoolbox.pro;
public final class VideoFolderLogicTest {
    static void check(boolean cond, String reason) { if (!cond) throw new AssertionError(reason); }
    public static void main(String[] args) {
        check("Camera".equals(VideoFolderLogic.displayName("DCIM/Camera/")),"Camera folder label");
        check("Download 01".equals(VideoFolderLogic.displayName("Movies/Download 01/")),"Download folder label");
        check("WhatsApp Video".equals(VideoFolderLogic.displayName("Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Video/")),"WhatsApp label");
        check("Other videos".equals(VideoFolderLogic.folderKey(null)),"Unknown folder fallback");
        check("Other videos".equals(VideoFolderLogic.folderKey("  ")),"Blank folder fallback");
        check(VideoFolderLogic.sameFolder("Movies/Islamic/", "movies/islamic"),"Case-insensitive same folder");
        check(!VideoFolderLogic.sameFolder("Movies/Islamic", "Download/Islamic"),"Separate paths with same short name");
        check("Camera".equals(VideoFolderLogic.displayName("DCIM\\Camera\\")),"Windows-like separators");
        System.out.println("VideoFolderLogicTest: 8 checks PASS");
    }
}
