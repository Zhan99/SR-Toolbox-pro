package com.smarttoolbox.pro;

public final class UpdateKitLogicTest {
    private static int count;
    private static void verify(boolean result, String description) {
        count++;
        if (!result) throw new AssertionError(description);
    }
    public static void main(String[] args) {
        verify("Meeting reminder".equals(SchedulerNoteLogic.title("  Meeting   reminder  ")),
                "normalize title spaces");
        verify(SchedulerNoteLogic.title(null).isEmpty(), "null title");
        verify(SchedulerNoteLogic.title("x".repeat(100)).length() == 80, "title cap");
        verify(!SchedulerNoteLogic.valid("   "), "blank note rejected");
        verify(SchedulerNoteLogic.valid("Please call"), "valid note");
        verify(SchedulerNoteLogic.body(null).isEmpty(), "null body");
        verify(SchedulerNoteLogic.body("x".repeat(13000)).length() == 12000, "body cap");
        verify(SchedulerNoteLogic.preview("A\n B").equals("A B"), "preview whitespace");
        verify(SchedulerNoteLogic.preview("x".repeat(100)).endsWith("…"), "preview crop");
        verify(SchedulerNoteLogic.matches("Hello", "my body", " HEL "), "title search");
        verify(SchedulerNoteLogic.matches("Hello", "my body", "BODY"), "body search");
        verify(!SchedulerNoteLogic.matches("Hello", "my body", "absent"), "search miss");
        System.out.println(count + " local scheduler notepad logic tests PASS");
    }
}
