package com.smarttoolbox.pro;

public final class AutomationRulesTest {
    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        check(AutomationRules.validPin("1234".toCharArray()), "valid four digit pin");
        check(AutomationRules.validPin("123456789012".toCharArray()), "valid 12 digit pin");
        check(!AutomationRules.validPin("12".toCharArray()), "short pin");
        check(!AutomationRules.validPin("123a".toCharArray()), "non numeric pin");
        check(!AutomationRules.validPin(null), "null pin");
        check(AutomationRules.preAlertAt(123000L) == 120000L, "3 second preview");
        check(!AutomationRules.isDue(123000L, 122999L), "not yet due");
        check(AutomationRules.isDue(123000L, 123000L), "due");
        check(!AutomationRules.canAttemptSend(false, true, true, true), "opt out");
        check(!AutomationRules.canAttemptSend(true, false, true, true), "service disabled");
        check(AutomationRules.canAttemptSend(true, true, true, false), "unlocked");
        check(!AutomationRules.canAttemptSend(true, true, false, false), "locked not allowed");
        check(AutomationRules.canAttemptSend(true, true, false, true), "experimental locked");
        check(AutomationRules.shouldRelock(true, true), "relock when originally locked");
        check(!AutomationRules.shouldRelock(false, true), "do not relock originally unlocked");
        check(AutomationRules.shouldRestoreApp(false), "restore active app");
        check(!AutomationRules.shouldRestoreApp(true), "home and lock instead");
        check("com.whatsapp".equals(AutomationRules.packageToAutomate()), "official WhatsApp only");
        check(AutomationRules.MAX_PIN_ATTEMPTS_PER_SCHEDULE == 1, "no PIN retry");
        System.out.println("19 automation policy assertions passed");
    }
}
