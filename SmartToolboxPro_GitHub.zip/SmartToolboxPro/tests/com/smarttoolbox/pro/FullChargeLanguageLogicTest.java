package com.smarttoolbox.pro;

public final class FullChargeLanguageLogicTest {
    private static int count;
    private static void check(boolean value, String why) {
        count++;
        if (!value) throw new AssertionError(why);
    }
    public static void main(String[] args) {
        check("bn".equals(FullChargeLanguageLogic.normalize(null)),"null defaults Bengali");
        check("bn".equals(FullChargeLanguageLogic.normalize("random")),"unknown defaults Bengali");
        check("en".equals(FullChargeLanguageLogic.normalize("EN")),"English case insensitive");
        check("both".equals(FullChargeLanguageLogic.normalize("BOTH")),"both case insensitive");
        check(FullChargeLanguageLogic.speech("bn").contains("ব্যাটারি"),"Bengali speech");
        check(FullChargeLanguageLogic.speech("en").contains("fully charged"),"English speech");
        check(FullChargeLanguageLogic.speech("both").contains("ব্যাটারি"),"bilingual Bengali");
        check(FullChargeLanguageLogic.speech("both").contains("Please unplug"),"bilingual English");
        check(!FullChargeLanguageLogic.speech("en").contains("ব্যাটারি"),"English only");
        check(!FullChargeLanguageLogic.speech("bn").contains("Please unplug"),"Bengali only");
        check(FullChargeLanguageLogic.fullTitle("en").contains("charged"),"English notification title");
        check(FullChargeLanguageLogic.fullTitle("bn").contains("ব্যাটারি"),"Bengali notification title");
        check(FullChargeLanguageLogic.fullTitle("both").contains("Battery"),"bilingual title");
        check(FullChargeLanguageLogic.monitorTitle("en").contains("SR"),"brand in English title");
        check(FullChargeLanguageLogic.monitorTitle("both").contains("চার্জ"),"bilingual branding");
        check(FullChargeLanguageLogic.monitoring("bn").contains("১০০%"),"Bengali monitor info");
        check(FullChargeLanguageLogic.monitoring("en").contains("100%"),"English monitor info");
        check(FullChargeLanguageLogic.progress("en",true,false).contains("Charging"),"English charging");
        check(FullChargeLanguageLogic.progress("en",false,false).contains("disconnected"),"English unplugged");
        check(FullChargeLanguageLogic.progress("bn",false,false).contains("নেই"),"Bengali unplugged");
        check(FullChargeLanguageLogic.progress("both",true,true).contains(" / "),"bilingual full status");
        check(FullChargeLanguageLogic.stop("en").contains("Stop"),"English notification action");
        check(FullChargeLanguageLogic.stop("bn").contains("বন্ধ"),"Bengali notification action");
        check(FullChargeLanguageLogic.stop("both").contains("Stop"),"bilingual notification action");
        System.out.println(count+" full-charge language tests passed");
    }
}
