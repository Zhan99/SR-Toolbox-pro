package com.smarttoolbox.pro;

public final class FloatingIdleLogicTest {
    static int checks;
    static void check(boolean ok,String reason) {checks++;if (!ok)throw new AssertionError(reason);}
    public static void main(String[] args) {
        check(FloatingIdleLogic.idleTimeoutMs(1)==1000L,"one second");
        check(FloatingIdleLogic.idleTimeoutMs(4)==4000L,"default");
        check(FloatingIdleLogic.idleTimeoutMs(30)==30000L,"thirty second");
        check(FloatingIdleLogic.idleTimeoutMs(60)==60000L,"one minute");
        check(FloatingIdleLogic.idleTimeoutMs(0)==1000L,"lower guard");
        check(FloatingIdleLogic.idleTimeoutMs(100)==60000L,"upper guard");
        check(FloatingIdleLogic.clampEdgeHeight(92)==92,"default vertical size");
        check(FloatingIdleLogic.clampEdgeHeight(0)==64,"minimum vertical size");
        check(FloatingIdleLogic.clampEdgeHeight(160)==136,"maximum vertical size");
        check(!FloatingIdleLogic.holdFeedbackAllowed(1999,false,true,false),"must hold 2s");
        check(FloatingIdleLogic.holdFeedbackAllowed(2000,false,true,false),"vibrate after 2s");
        check(!FloatingIdleLogic.holdFeedbackAllowed(2000,true,true,false),"no vib swipe");
        check(!FloatingIdleLogic.holdFeedbackAllowed(2200,false,false,false),"no vib after release");
        check(!FloatingIdleLogic.holdFeedbackAllowed(2200,false,true,true),"no repeat vib");
        check(FloatingIdleLogic.holdFeedbackAllowed(2100,false,true,false),"late callback");
        System.out.println(checks+" floating idle, vertical bar, hold vibration checks passed");
    }
}
