package com.smarttoolbox.pro;

import com.sun.source.tree.AssignmentTree;
import com.sun.source.tree.ClassTree;
import com.sun.source.tree.CompilationUnitTree;
import com.sun.source.tree.MemberSelectTree;
import com.sun.source.tree.MethodTree;
import com.sun.source.tree.Tree;
import com.sun.source.tree.VariableTree;
import com.sun.source.util.JavacTask;
import com.sun.source.util.TreeScanner;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;

/** Compile-time regression guard for the Archived.icon member used by the UI. */
public final class AppBackupArchiveIconSourceTest {
    private static void require(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
    }

    public static void main(String[] args) throws Exception {
        require(args.length == 2, "Pass AppBackupRepository.java and AppBackupActivity.java");
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        require(compiler != null, "JDK compiler required");
        try (StandardJavaFileManager manager = compiler.getStandardFileManager(
                null, null, StandardCharsets.UTF_8)) {
            List<File> sources = Arrays.asList(Path.of(args[0]).toFile(), Path.of(args[1]).toFile());
            Iterable<? extends JavaFileObject> files = manager.getJavaFileObjectsFromFiles(sources);
            JavacTask parser = (JavacTask) compiler.getTask(null, manager, null,
                    Arrays.asList("-proc:none", "-encoding", "UTF-8"), null, files);
            boolean hasArchivedClass = false;
            boolean hasArchivedIcon = false;
            boolean hasIconLoader = false;
            boolean archiveIconAssigned = false;
            int archiveUiReferences = 0;
            for (CompilationUnitTree unit : parser.parse()) {
                String filename = Path.of(unit.getSourceFile().toUri()).getFileName().toString();
                for (Tree t : unit.getTypeDecls()) {
                    if (!(t instanceof ClassTree)) continue;
                    ClassTree top = (ClassTree) t;
                    for (Tree member : top.getMembers()) {
                        if ("AppBackupRepository.java".equals(filename) && member instanceof ClassTree
                                && ((ClassTree) member).getSimpleName().contentEquals("Archived")) {
                            hasArchivedClass = true;
                            ClassTree model = (ClassTree) member;
                            for (Tree field : model.getMembers()) {
                                if (field instanceof VariableTree) {
                                    VariableTree v = (VariableTree) field;
                                    if (v.getName().contentEquals("icon")
                                            && v.getType().toString().equals("Drawable")) {
                                        hasArchivedIcon = true;
                                    }
                                }
                            }
                        }
                        if ("AppBackupRepository.java".equals(filename) && member instanceof MethodTree) {
                            MethodTree m = (MethodTree) member;
                            if (m.getName().contentEquals("archiveIcon") && m.getReturnType() != null
                                    && m.getReturnType().toString().equals("Drawable")) {
                                hasIconLoader = true;
                            }
                        }
                        if ("AppBackupActivity.java".equals(filename) && member instanceof MethodTree) {
                            MethodTree m = (MethodTree) member;
                            if (m.getName().contentEquals("refresh")) {
                                final boolean[] found = {false};
                                new TreeScanner<Void, Void>() {
                                    @Override public Void visitAssignment(AssignmentTree node, Void unused) {
                                        if (node.getVariable().toString().equals("a.icon")
                                                && node.getExpression().toString().contains("repo.archiveIcon(a)")) {
                                            found[0] = true;
                                        }
                                        return super.visitAssignment(node, unused);
                                    }
                                }.scan(m.getBody(), null);
                                if (found[0]) archiveIconAssigned = true;
                            }
                            if (m.getName().contentEquals("archiveCard")) {
                                final int[] found = {0};
                                new TreeScanner<Void, Void>() {
                                    @Override public Void visitMemberSelect(MemberSelectTree node, Void unused) {
                                        if (node.toString().equals("a.icon")) found[0]++;
                                        return super.visitMemberSelect(node, unused);
                                    }
                                }.scan(m.getBody(), null);
                                archiveUiReferences += found[0];
                            }
                        }
                    }
                }
            }
            require(hasArchivedClass, "AppBackupRepository.Archived model missing");
            require(hasArchivedIcon, "Archived must declare Drawable icon (prevents cannot find symbol)");
            require(hasIconLoader, "AppBackupRepository.archiveIcon must return Drawable");
            require(archiveIconAssigned, "Archived icon must be loaded in refresh");
            require(archiveUiReferences >= 2, "Archived UI must read icon when building a card");
            System.out.println("PASS 5 archived icon model/loader/UI Java AST checks");
        }
    }
}
