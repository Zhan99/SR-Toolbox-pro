# Kotlin Duplicate Class — GitHub Build Fix (1.5.24-alpha50)

## সমস্যাটি কী ছিল?
GitHub Actions-এর `:app:checkDebugDuplicateClasses` Android task-এ `kotlin-stdlib:1.8.22`-এর
সঙ্গে পুরোনো `kotlin-stdlib-jdk7:1.6.21` এবং `kotlin-stdlib-jdk8:1.6.21` মিলে একই
Kotlin classes দুই জায়গায় পাচ্ছিল। এটি Java source-এর ডুপ্লিকেট নয়।

## ঠিক করা হয়েছে
- `app/build.gradle`: সমস্ত configuration থেকে পুরোনো JDK7/JDK8 split Kotlin libraries বাদ।
- Unified `org.jetbrains.kotlin:kotlin-stdlib:1.8.22` স্পষ্টভাবে রাখা হয়েছে। Gradle প্রয়োজনে
  আরো নতুন compatible version বেছে নিতে পারবে।
- Workflow-এ `debugRuntimeClasspath` dependency graph পরীক্ষা করে পুরোনো variants পাওয়া
  গেলে আগেই ব্যর্থ হবে; এরপর `:app:checkDebugDuplicateClasses` চালাবে।
- `tests/verify_kotlin_dependency_policy.py`: ১২টি স্থানীয় Static Regression Test।
- ব্যর্থ হলে Kotlin runtime classpath report Artifacts-এ তোলার ব্যবস্থা।
- Video Player বাদই আছে; অন্য অ্যাপ ফিচার ও branding অপরিবর্তিত।

## GitHub-এ আপলোড
1. `SmartToolboxPro_GitHub.zip` পুরোনোটির জায়গায় দাও।
2. `.github/workflows/build-apk.yml` নতুন YAML দিয়ে Replace করো।
3. Commit করে Actions → Build SR Smart Toolbox Pro APK চালাও।
4. `Guard resolved Kotlin runtime classpath` এবং `Check duplicate Android classes` PASS
   কি না দেখো। অন্য কোনো Error এলে পূর্ণ লগ দাও।

## সীমাবদ্ধতা
এই পরিবেশে Android SDK/Gradle নেই। তাই সম্পূর্ণ Android APK Build যাচাই হয়নি;
GitHub Actions-এ runtime dependency resolution ও APK assembly যাচাই করতে হবে।
