# SR Smart Toolbox Pro — 1.5.15-alpha41

## 🔋 Full Charge Bangla Voice Alert
Home Screen-এর ওপরের ডানপাশে **⋮ Three Dot → 🔋 Full Charge Bengali Voice Alert** খুলুন।

- **বাংলা ফুল চার্জ ভয়েস — চালু/বন্ধ** সুইচ। প্রথমে OFF থাকে; ব্যবহারকারী নিজে ON করবেন।
- **Test Bangla Voice** চাপলে একটি নমুনা বাংলা বাক্য বাজবে (চালু থাকলে)।
- **Android TTS Voice Settings** দিয়ে ফোনের Bengali Text-to-Speech Voice ইনস্টল/নির্বাচন করতে পারবেন।
- ফোন চার্জে থাকলে ব্যাটারি ১০০% বা Android BATTERY_STATUS_FULL হলে:
  **“ব্যাটারি ফুল চার্জ হয়েছে, চার্জ থেকে খুলুন।”**
- একবার ১০০% হওয়ায় একবারই শোনাবে; বারবার Battery Broadcast-এ পুনরাবৃত্তি করবে না। চার্জ খুললে বা চার্জের মাত্রা আবার ১০০%-এর নিচে নামলে পুনরায় প্রস্তুত হবে।
- চালু থাকলে একটি Ongoing Foreground Notification দেখা যাবে; Notification-এর **বন্ধ করুন** বাটন থেকেও বন্ধ করতে পারবেন।
- ফোন Restart / App Update-এর পরে Enabled থাকলে পুনরায় Monitor চালু করার চেষ্টা হবে। Android/OEM Background Restriction-এর কারণে এটি ব্যর্থ/দেরি হতে পারে; অ্যাপ খুললে আবার চেষ্টা হবে।
- ফোনে Bangla TTS Voice নেই, মিডিয়া ভলিউম শূন্য, DND/Silent policy, Battery Saver বা Android Foreground Service Restriction থাকলে শোনা নাও যেতে পারে।
- এই ফিচার চার্জার **নিজে থেকে বিচ্ছিন্ন করে না**, শুধু Voice ও Notification দিয়ে সতর্ক করে।

### প্রযুক্তিগত বিষয়
- Running Service-এ `Intent.ACTION_BATTERY_CHANGED` Dynamic Receiver ব্যবহার করা হয়েছে, Manifest-এ ACTION_BATTERY_CHANGED ব্যবহার হয়নি।
- Android 14+ এর জন্য Foreground Service-এর `specialUse` টাইপ আগের প্রজেক্টের মতো ব্যবহার হয়েছে। Play Store প্রকাশের ক্ষেত্রে এই টাইপের যুক্তি/অনুমোদন যাচাই করতে হবে।
- Permissions: আগের `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_SPECIAL_USE`, `POST_NOTIFICATIONS`, `RECEIVE_BOOT_COMPLETED` ব্যবহৃত; আলাদা অপ্রয়োজনীয় Permission নেই।
- Local Pure Java Logic Test এবং GitHub Workflow Static Checks রয়েছে। আসল ফোনে Voice, Background Monitoring এবং Build পরীক্ষা বাকি।
