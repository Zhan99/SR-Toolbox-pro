# SR Smart Toolbox Pro — New Icon Update

**Version: 1.5.16-alpha42** · Developer: **Shahriar Rahman** · Brand: **SR Creation Farm**

আপনার নির্বাচিত নীল-সোনালি SR লোগোটি হুবহু ব্যবহার করা হয়েছে (কেবল Android উপযোগী 512 × 512 রিসাইজ)।

এই লোগো তিন জায়গায় একরকম রাখা হয়েছে:

1. **Android Launcher Icon** — `app/src/main/res/drawable-nodpi/ic_launcher.png`
2. **Opening Branding Animation** — `app/src/main/res/drawable-nodpi/sr_premium_logo.png`
3. **Premium Home Screen Branding** — একই `sr_premium_logo.png`।

মূল 1254 × 1254 ছবিটি `ARTWORK_SR_NEW_ICON.png` নামে সোর্স ZIP-এ রাখা আছে।

**অপরিবর্তিত:** `applicationId 'com.smarttoolbox.pro'`, আগের সব ফিচার, অনুমতি ও সেটিংস। পুরোনো অ্যাপের ওপর আপডেট হিসেবে ইনস্টল করার উদ্দেশ্যে `versionCode` 41 থেকে 42 করা হয়েছে।

GitHub-এ `SmartToolboxPro_GitHub.zip` এবং তার সঙ্গে দেওয়া `.github/workflows/build-apk.yml` একই রিলিজ থেকে Replace করুন। GitHub Actions-এ Android APK Build চালাতে হবে; এখানে সম্পূর্ণ Android SDK/Gradle Build পরীক্ষা করা হয়নি।
