# SR Smart Toolbox Pro — Smart Three-Dot Menu (1.4.3-alpha18)

## নতুন হোম স্ক্রিন
- ডানদিকে উপরে **⋮** মেনু।
- পাঁচটি মূল টুল: Night Screen, Extra Volume, Thermal Monitor, QR / Barcode Scanner, SR Video Player।
- আগের Developer & Brand, Floating Icon Settings ও Notification Controls-এর আলাদা হোম কার্ড সরানো হয়েছে।
- হোম স্ক্রিন এখন ছোট, পরিষ্কার ও টুল-কেন্দ্রিক।

## ⋮ Menu Structure

**SETTINGS**
- ◉ Floating Icon Settings → FloatingIconSettingsActivity
- 🔔 Notification Controls → NotificationControlsActivity
- ⚙ Android App Settings → ফোনের নিজস্ব App Info/Settings পেজ

**ABOUT**
- 👤 About Shahriar Rahman → AboutDeveloperActivity (YouTube ও Facebook লিংকসহ)

## Technical notes
- Android PopupMenu ব্যবহার করা হয়েছে। আলাদা Home Settings / About Activity মুছে দেওয়া হয়নি।
- অন্য টুলের Service, Manifest Permission, QR Scanner, Video Library/Resume ও Media3 Player বদলানো হয়নি।
- `applicationId` অপরিবর্তিত; versionCode 18, versionName 1.4.3-alpha18।
- Java, XML, YAML ও GitHub Actions-এর স্ট্যাটিক পরীক্ষা করা হয়েছে। Android SDK / Gradle না থাকায় সম্পূর্ণ APK Build GitHub Actions-এ চালাতে হবে।
