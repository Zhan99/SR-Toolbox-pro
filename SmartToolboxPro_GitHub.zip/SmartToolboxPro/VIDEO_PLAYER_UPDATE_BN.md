# SR Video Player — Version 1.4.3-alpha18

## নতুন UI — সরবরাহ করা Reference-এর মতো
1. Full-screen black video canvas; video playback শুরু হলে landscape immersive mode.
2. Transparent top gradient with back button, video title, audio track, subtitle, HW decoder info and overflow menu.
3. Quick action row: speed, frame screenshot, audio-only toggle and orientation.
4. Left-side display control opens player-window brightness and system media-volume sliders.
5. Bottom gradient with elapsed time, seek bar and remaining time.
6. Large Previous / Play-Pause / Next transport controls.
7. Lock, aspect-ratio and Picture-in-Picture buttons.
8. Playback চলাকালে 3.2 seconds পর controls auto-hide; screen tap করলে আবার দেখা যায়.
9. Double-tap left/right side to seek 10 seconds backward/forward.
10. Vertical swipe on left adjusts player brightness; vertical swipe on right adjusts media volume.
11. Horizontal swipe seeks through the current video.
12. SurfaceView frame screenshot is saved to Pictures / SR Smart Toolbox where PixelCopy is available.

## Playback features retained
- Local one/multiple video selection through Android Storage Access Framework.
- Playlist / queue with previous and next.
- HTTPS / RTSP network playback; HLS (.m3u8), DASH (.mpd) and SmoothStreaming modules.
- Common containers including MP4, Matroska/MKV, WebM, AVI, MPEG-TS, MPEG-PS and FLV when contained codecs are supported.
- Playback speed from 0.5x to 3x, repeat, shuffle and queue selection.
- Audio track and embedded subtitle selection.
- External SRT, VTT, ASS/SSA and TTML subtitle loading.
- Fit, Fill and Zoom/Crop aspect ratio.
- Picture-in-Picture, background audio through MediaSessionService, sleep timer, favorites, history and resume point.
- Screen-control lock and orientation toggle.

## Compatibility and safety
- Android 8.0+ (minSdk 26).
- The manual file picker uses Android Storage Access Framework without broad permission. The full phone library additionally requests Android video access permission from the user.
- Device codec and decoder support varies. A container extension does not guarantee all codecs inside it can be decoded.
- PixelCopy screenshot requires an available SurfaceView and a ready video frame; some devices / render paths may reject capture.
- PiP and background playback depend on Android version and device policy.

## Build
- AndroidX Media3 1.11.1.
- AGP 8.10.0, Gradle 8.11.1, compileSdk 36, JDK 17.
- Version: 1.4.3-alpha18 (versionCode 18).

## নতুন ফোন Video Library + Resume
- ফোনের ভিডিওগুলো MediaStore থেকে অ্যাপের মধ্যে তালিকায় পাওয়া যাবে (Android permission অনুযায়ী)।
- ভিডিও Search, Folder filter, Newest / Name A–Z / Longest Sort।
- ভিডিওতে Tap করলে আগে যেখানে বন্ধ হয়েছিল, সেখান থেকে স্বয়ংক্রিয় Resume।
- Long Press করলে Start from beginning অপশন।
- শেষের কাছাকাছি পৌঁছানো ভিডিও শুরু থেকে চলবে; প্রতিটি ভিডিওর Bookmark আলাদা।
