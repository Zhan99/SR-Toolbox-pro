# SR Smart Toolbox Pro — Compact Floating Toolbox

**Version:** 1.4.9-alpha24 (`versionCode 24`)

## নতুন রঙিন কন্ট্রোল বার
Night Screen, Thermal Monitor এবং Volume Boost-এর প্রতিটির জন্য **একটি করে রঙিন বার**:
- **Tap:** বারটির যেকোনো জায়গায় চাপ দিলে ON/OFF হবে। **Green = ON**, **Gray = OFF**।
- **Slide:** Night Screen ও Volume Boost বারের ওপর বামে/ডানে আঙুল টেনে Darkness/Extra Gain কমানো-বাড়ানো যাবে। বারেই বর্তমান Percentage/dB লেখা থাকে। নিচে আলাদা Slider নেই।
- **Thermal:** একই বারে চালু/বন্ধ ও লাইভ ব্যাটারি তাপমাত্রা; নিচের আলাদা তাপমাত্রার Description সরানো হয়েছে।
- **Phone Volume:** ছোট সারিতে ফোনের Media Volume `−` / `+` রাখা হয়েছে। এটি Extra Gain-এর থেকে আলাদা।
- **Scanner / Video Player:** দুইটি সরু Action Row।

## ছোট Toolbox-এ সব কন্ট্রোল
- Home → ⋮ → Floating Icon Settings → **Toolbox panel size**।
- Width: 220–440 dp; Maximum height: 240–760 dp।
- প্যানেলের বাইরের অংশে কোনো বাটন, কার্ড বা Text দেখা যাবে না। Rounded clipping যোগ করা হয়েছে।
- নির্বাচিত Height খুব ছোট হলে কন্ট্রোলের কোনো অংশ **প্যানেলের বাইরে নয়**, বরং প্যানেলের **ভেতরে স্ক্রল** করে দেখা যাবে। সব কন্ট্রোল একসঙ্গে 240 dp-এ পড়ার মতো রাখা সম্ভব নয়, তাই স্ক্রল করা প্রয়োজন হতে পারে।
- Floating Icon-এর নিজস্ব Size Setting আলাদা রয়েছে।

## অটোমেশন ও অ্যানিমেশন
Edge Swipe Reveal/Hide Animation, তিন সেকেন্ডের Panel Timeout, বাইরে Tap করে বন্ধ, ON/OFF Services এবং আগের Video Player, Notification Controls, Theme Settings অক্ষত রাখা হয়েছে।

## পরীক্ষা
- 12টি CompactControlMathTest পাস।
- Android stub-ভিত্তিক CompactFeatureBar Java Compile ও Tap/Drag Interaction Probe পাস।
- GitHub Actions-এর পুরোনো slider-ভিত্তিক assertion সরিয়ে Compact Control-এর assertion যুক্ত করা হয়েছে।
- Full Android SDK Build / ডিভাইসে UI পরীক্ষা এখানে সম্ভব হয়নি; GitHub Actions-এ চালাতে হবে।
