# SR Smart Toolbox Pro — v1.5.24-alpha50

**Developer:** Shahriar Rahman  
**Brand:** SR Creation Farm  
**YouTube:** https://www.youtube.com/@SRCreation-farm  
**Facebook:** https://fb.com/srcreation.farm

## v1.5.24-alpha50 — GitHub Build Kotlin Duplicate-Class Hotfix

GitHub-এ `kotlin-stdlib:1.8.22` ও পুরোনো `kotlin-stdlib-jdk7/jdk8:1.6.21` একসঙ্গে থাকায় `:app:checkDebugDuplicateClasses` ব্যর্থ হচ্ছিল। `app/build.gradle`-এ পুরোনো split jars সব configuration থেকে বাদ দেওয়া হয়েছে। `build-apk.yml`-এ runtime dependency check এবং `tests/verify_kotlin_dependency_policy.py`-তে ১২টি policy-check যুক্ত হয়েছে। বিস্তারিত `KOTLIN_DUPLICATE_CLASSES_FIX_BN.md`।

**স্থানীয় পরীক্ষা:** ৩৩/৩৩টি Source/Logic ধাপ পাস। পূর্ণ APK Build/Gradle dependency resolution এখানে হয়নি; GitHub Actions-এ যাচাই হবে।

## বর্তমান ফিচার

- **WhatsApp Smart Scheduler:** Today/Calendar collapsible sections, history dots, single/group scheduling, contact pick, notes, same-record Edit→Save Changes, opt-in Accessibility-based send.
- **Apps Backup & Restore:** APK ও split `.apks` backup, Downloads/App Backup folder, batch selection, restore/install confirmation, share.
- **Floating Toolbox:** border-following vertical bar in Portrait/Landscape, auto-hide, swipe-only hidden bar, tap/swipe settings, 2-second hold/drag, floating panel resize, thermal/brightness/audio/QR shortcuts.
- **Full Charge Voice Alert:** Bengali/English/both, ringtone volume, offline audio fallback, one notification per charging session, voice preview.
- **QR / Barcode Scanner:** camera scan এবং Gallery থেকে QR/Barcode ছবি বেছে scan (on-device decoder).
- **Night Screen:** dim overlay, minimum system brightness when allowed, restore original brightness.
- **System-Wide Extra Volume:** output gain, 5-band equalizer, bass/virtualizer (where supported).
- **Thermal Monitor:** battery temperature / Android thermal status.
- **Theme Studio:** Premium/Classic, 9 palettes, System/Light/Dark, Sound ON/OFF, Vibration ON/OFF, motion and original 4 sound packs.
- **Permission Settings:** কোন ফিচারের জন্য কোন Android Permission প্রয়োজন তার ব্যাখ্যা।

**Removed in v1.5.23:** সম্পূর্ণ SR Video Player এবং সব প্লেব্যাক-সংক্রান্ত ফাংশন/Dependency/Permissions। ফোনে থাকা কোনো ভিডিও বা ব্যক্তিগত ফাইল মুছে ফেলা হয় না।

## নতুন Sidebar আচরণ

`Floating Icon Settings → Swipe to Open ON` থাকলে লুকানো লম্বালম্বি Bar শুধু Swipe-এ খুলবে—`Tap to Open` আলাদা ON থাকলেও Hidden Bar-এর Tap-এ খুলবে না। দৃশ্যমান Strip-এর বাইরের 44dp Invisible Touch Target সরানো হয়েছে। তাই পাশের App UI Tap গ্রহণ করতে পারবে। **Strip-এর ঠিক ওপরের Tap Android Overlay গ্রহণ করে; নিচের অ্যাপে ফরওয়ার্ড করা সম্ভব নয়।**

## Sound ও Vibration

`Home → ⋮ → Premium / Classic & Sounds`

- **Interface Sound ON/OFF** — UI tap/open/success cue-এর নিয়ন্ত্রণ।
- **Interface Vibration ON/OFF** — UI button, navigation, Floating Swipe/Hold-এর কম্পন নিয়ন্ত্রণ।
- দুটো সম্পূর্ণ আলাদা; শুধু Sound OFF করে Vibration ON রাখা সম্ভব।
- Floating Settings-এর Swipe/Hold Vibration আলাদা ON/OFF থাকবে, কিন্তু Global Vibration OFF থাকলে তা কার্যকর হবে না।
- Battery Full Alert voice-এর নিজস্ব enable/language/volume আচরণ আগের মতো থাকবে; UI Sound toggle সেটি বন্ধ করে না।

## GitHub-এ APK তৈরি

**GitHub repo root-এ:**

1. `SmartToolboxPro_GitHub.zip` (এই রিলিজের Android source ZIP)
2. `.github/workflows/build-apk.yml` (এই রিলিজের matching workflow)

GitHub → Actions → **Build SR Smart Toolbox Pro APK** → Run workflow / Commit → APK Artifact download.
`Smart-Toolbox-Pro-main.zip` ফাইলটিও সরাসরি Repository হিসেবে Extract করে upload করা যায়।

## পরীক্ষা / সীমাবদ্ধতা

Source ZIP ও Workflow-এর ৩২টি স্থানীয় যাচাই পাস, Android XML parse ও Java AST checks পাস। এই পরিবেশে **Android SDK/Gradle অনুপস্থিত**, তাই সম্পূর্ণ Gradle Build/Android lint/ডিভাইসে Gesture পরীক্ষা করা হয়নি। GitHub Actions ও বাস্তব ফোনে নিশ্চিত করতে হবে। বিস্তারিত `QA_REPORT_BN.txt` ও `VIDEO_PLAYER_REMOVAL_AND_FEEDBACK_BN.md`-তে।
