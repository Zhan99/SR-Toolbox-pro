## সর্বশেষ আপডেট — 1.5.18-alpha44 : Floating Swipe Vibration + বাংলা/English Charge Voice
- Floating Icon Settings: **Swipe Vibration** আলাদা ON/OFF; Swipe দিয়ে Menu খোলা হলে হালকা কম্পন। Tap বা ২ সেকেন্ড Hold-Drag-এ কম্পন হবে না।
- Full Charge Voice Alert: **বাংলা / English / উভয় ভাষা**। Full Notification Title, Text ও Monitoring Status ভাষা অনুযায়ী।
- ফোনে উন্নত অফলাইন TTS Voice থাকলে সেটি ব্যবহার; না থাকলে অ্যাপের সাথে থাকা Bengali ও English অফলাইন অডিও। Preview এবং TTS পছন্দের সুইচ।
- বিস্তারিত: `SWIPE_VIBRATION_BILINGUAL_CHARGE_BN.md`।

## পূর্ববর্তী আপডেট — 1.5.17-alpha43 : Auto App Backup Folder + Permissions Center
- প্রথম APK ব্যাকআপে Android 10+ এ **Download/App Backup/** ফোল্ডার স্বয়ংক্রিয়ভাবে তৈরি হবে। `bKash.apk`-এর মতো সহজ নাম প্রথমবার ব্যবহার হবে; পরবর্তী একই নামের ব্যাকআপে অনন্য নাম হবে।
- Split APK হলে মূল ফোল্ডারে Base `.apk`, আর `Download/App Backup/Split backups/`-এ সম্পূর্ণ `.apks` আর্কাইভ থাকবে। Restore করতে অবশ্যই `.apks` ব্যবহার করুন।
- Android 8–9 বা নিজের পছন্দের অন্য Backup Folder হলে একবার System Folder Picker থেকে Parent Folder বেছে নিতে হবে; `App Backup` সাবফোল্ডার নিজে তৈরি হবে।
- Home Screen থেকে বড় Creator/About পরিচিতির Hero Card সরানো হয়েছে; Premium Header Icon ও Opening Animation অক্ষত, `About Developer` এখনও ⋮ Menu-তে।
- **Home → ⋮ → App Permissions (সব অনুমতি)**: Manifest-এর সব অনুমতির উদ্দেশ্য, কোন ফিচারের জন্য, বর্তমান অবস্থা ও অনুমতি দেওয়ার/Settings খোলার পথ এক জায়গায়।
- আগের Backup, WhatsApp Scheduler, Floating Icon, Full Charge Voice, Theme, Video Player এবং অন্যান্য ফিচার সংরক্ষিত।
- বিস্তারিত `APPS_BACKUP_AUTO_FOLDER_PERMISSIONS_BN.md`।

## সর্বশেষ আপডেট — 1.5.16-alpha42 : Calendar History Dots + Same-Time Edit + Border Icon
- WhatsApp Scheduler-এর ক্যালেন্ডারে সেভ থাকা মেসেজ/History-র তারিখে **● ডট**; মাস পরিবর্তন ও তারিখ নির্বাচন।
- গতকালের মেসেজ **Edit/Reuse** করলে আগের ঘণ্টা-মিনিট রেখে আজকের উপযুক্ত সময় (সময় পেরিয়ে গেলে আগামীকাল) নির্বাচন।
- Floating Icon ডিফল্টভাবে সব অ্যাপে স্ক্রিনের বর্ডারে থাকবে; **২ সেকেন্ড Hold + Drag** করলে ম্যানুয়াল অবস্থান অগ্রাধিকার পাবে।
- Floating Icon Settings-এ **Reset icon to screen border** বাটন।
- বিস্তারিত: `CALENDAR_DOTS_TIME_REUSE_BORDER_ICON_BN.md`।

## পূর্ববর্তী আপডেট — 1.5.15-alpha41 : Full Charge বাংলা Voice Alert
- **Home → ⋮ → 🔋 Full Charge বাংলা Voice Alert**: একবার ON করুন; ব্যাটারি চার্জে থেকে ১০০% হলে **“ব্যাটারি ফুল চার্জ হয়েছে, চার্জ থেকে খুলুন।”** অফলাইন বাংলা ভয়েস বলবে।
- একই চার্জিং সেশনে একবার, চার্জার খুললে Reset; Notification থেকে বন্ধ করা যাবে।
- Bengali Voice Preview, বর্তমান ব্যাটারি শতাংশ, Notification Permission/Service Status নির্দেশনা।
- ফোন রিস্টার্টে পুনরায় মনিটর চালুর চেষ্টা; Android/OEM Background Limitations প্রযোজ্য।
- বিস্তারিত: `FULL_CHARGE_BENGALI_VOICE_BN.md`।

## সর্বশেষ আপডেট — 1.5.14-alpha40 : 📦 Apps Backup & Restore
- Home Screen ও ⋮ Menu থেকে Installed Apps Backup সেকশন খোলা যায়।
- ফোনের Apps থেকে মূল `.apk` Backup; Split Apps-এর জন্য `Split backups` ফোল্ডারে পূর্ণ `.apks` Archive।
- একটি/একাধিক অ্যাপ নির্বাচন, Search/Sort, Backup, Archived History, Restore (Android System Confirmation), Share, Delete/Uninstall।
- Premium/Classic Theme অনুসরণ করে; আগের Android App ID ও ফিচার সংরক্ষিত আছে।
- বিস্তারিত: `APPS_BACKUP_RESTORE_UPDATE_BN.md`।

## পূর্ববর্তী আপডেট — 1.5.13-alpha39 : Premium UI, Classic UI & Custom Sound
- Gold-and-Navy SR Premium Logo: Launcher, Opening Animation এবং Premium Home Card।
- Smart Theme Studio-তে **Premium / Classic** Interface নির্বাচন। Classic Mode-এ পুরোনো ডিজাইন, Theme Palette ও Light/Dark Setting অক্ষত।
- ৪টি Original UI Sound Style: Soft, Digital, Crystal, Arcade — Tap, Navigate, Success, Intro।
- **Sound ON/OFF** (OFF করলে চলমান সাউন্ডও বন্ধ) এবং **Animation ON/OFF**।
- বিস্তারিত: `PREMIUM_UI_SOUND_UPDATE_BN.md`।

## পূর্ববর্তী আপডেট — 1.5.13-alpha39
- App Launcher-এ স্বয়ংক্রিয় SR Creation Farm Opening Branding Animation; আলাদা Settings নেই।
- WhatsApp Scheduler-এ পুরো Broadcast Group **একটি Group Card** হিসেবে; নাম, সব নম্বর, সদস্য Status, Edit/Reuse ও Delete Group।
- Scheduler Folders-এ আলাদা আলাদা প্রাপককে গোনা হবে না; একটি Group একটি কার্ড।
- বিস্তারিত: `OPENING_BRANDING_GROUP_CARD_BN.md`।

## সর্বশেষ আপডেট — 1.5.11-alpha37 : Floating Tap / Swipe আলাদা ও ২ সেকেন্ড Hold-to-Move
- Floating Icon Settings-এ **Tap to Open** এবং **Swipe to Open** দুটি স্বতন্ত্র ON/OFF সুইচ।
- আইকন এবং Edge Bar—দুটিই **২ সেকেন্ড স্থির চেপে ধরে তারপর Drag** করলে সরবে।
- Swipe যেন ভুলে Drag না হয়, তাই ২ সেকেন্ডের আগের Movement আলাদা ট্র্যাক করা হয়।
- আগের সব ফিচার অক্ষত। বিস্তারিত `FLOATING_TAP_SWIPE_2S_DRAG_UPDATE_BN.md`।

## সর্বশেষ আপডেট — 1.5.10-alpha36: Night Screen Extra Dark + Minimum Brightness
- Night Screen ON করলে আগের Black Overlay-এর সঙ্গে অনুমতি থাকলে **System Brightness সর্বনিম্ন 1/255** হবে।
- আগের Brightness/Auto-Brightness সংরক্ষণ ও OFF করলে Restore; User নিজে পরিবর্তন করলে তার নতুন Settings অক্ষত রাখা।
- Night Screen-এর নিজস্ব Status/Navigation Bar কালো; অন্য অ্যাপের System Notification Bar সরাসরি কভার করা যায় না।
- Android 12+ Touch Pass-through সুরক্ষা, Night Screen Notification-এ Turn off & restore।
- ৫০টি নতুন Brightness Policy/Controller Test; বিস্তারিত `NIGHT_SCREEN_MIN_BRIGHTNESS_BN.md`।

## সর্বশেষ আপডেট — 1.5.9-alpha35: Floating Bar Slide → Quick Menu
- Home Screen ও অন্য সব অ্যাপের ওপর Floating Edge Bar-এ Tap/Slide করলে Quick Controls Menu খোলার Touch Flow মেরামত।
- Swipe চলাকালে Edge Handle আর সরবে না; Gesture শেষে Menu Open।
- Edge Tab-এর বড় 44×92dp Touch Area, বাম/ডান ও ওপর/নিচের Slide সমর্থন।
- ST Bubble-এ দ্রুত Slide করলে Menu; Hold + Drag করলে আইকন সরানো।
- Animation শেষ হওয়ার সময় বাধা এলে একবার Menu Open fallback।
- বাস্তব সীমা ও ব্যবহারের বিস্তারিত: `FLOATING_BAR_SWIPE_RELIABILITY_BN.md`।

## সর্বশেষ আপডেট — 1.5.8-alpha34 : Global Portrait Edge (ALL Apps)
- **Floating Icon Settings → Portrait Edge — ALL apps** চালু থাকলে YouTube, Gallery, অন্য Video Player, Browser বা Home Screen—**যে কোনো Portrait Screen**-এ Floating Icon বাম বা ডান কিনারায় থাকবে।
- Landscape-এ পূর্বের Bubble Position ফেরানোর চেষ্টা, পুরোনো Hidden/Off অবস্থার সুরক্ষা ও Edge Swipe/Tab Control সংরক্ষিত।
- All Apps Mode OFF করলে আগের কেবল নিজস্ব Video Player-এর Playback-ভিত্তিক fallback কাজ করবে।
- ভিডিও শনাক্ত না করে Orientation শনাক্ত করা হয়, তাই Portrait-এ ভিডিও না থাকলেও Icon Edge-এ থাকবে।
- বিস্তারিত: `GLOBAL_PORTRAIT_EDGE_ALL_APPS_BN.md`।

## সর্বশেষ আপডেট — 1.5.7-alpha33 : Scheduler Notepad + Portrait Video Edge
- Auto Scheduler-এর **📝 Notepad** (উপরের ⋮ মেনু এবং মেসেজ ফর্ম থেকে)। নোট তৈরি, এডিট, ডিলিট, সার্চ এবং সরাসরি মেসেজে যুক্ত করার সুবিধা।
- মেসেজ আগে লেখা থাকলে **Replace / Append / Cancel**। নোট ফোনের private app storage-এ সংরক্ষিত থাকে; অ্যাপের Backup আগের মতো বন্ধ।
- নিজস্ব Video Player-এ ভিডিও **Portrait-এ চলতে থাকলে** Floating Icon কিনারার পাতলা, Swipeable Edge Tab হয়ে থাকবে। Pause/Stop/Landscape/PiP-এ আগের অবস্থায় ফিরে যাবে; ব্যবহারকারী সরিয়ে দিলে তার নতুন অবস্থাকে সম্মান করবে।
- Floating Icon Settings → **Portrait video-তে floating icon কিনারায় রাখুন** অন/অফ।
- বিস্তারিত: `NOTEPAD_PORTRAIT_EDGE_UPDATE_BN.md`।

## সর্বশেষ আপডেট — 1.5.6-alpha32 : Scheduler Inbox Folders
- WhatsApp Smart Scheduler-এর লম্বা তালিকা এখন ৫টি Collapsible Folder: আজ, আগামীকাল, পরবর্তী দিন, সময় পেরিয়েছে/History, Paused।
- প্রতিটি ফোল্ডারে মেসেজ সংখ্যা, খোলা/বন্ধ করার ব্যবস্থা; আজকের ফোল্ডার ডিফল্ট খোলা।
- ফোনের Local Date দিয়ে আজ/আগামীকাল নির্ধারণ; পরের তারিখ ও History আলাদা, কোনো Attempted message-কে Delivered বলা হচ্ছে না।
- আগের Schedule, Group Batch, Live Countdown, Edit/Reuse ও Auto Reminder ডেটা অক্ষত।
- বিস্তারিত: `SCHEDULER_INBOX_FOLDERS_BN.md`।

## সর্বশেষ আপডেট — 1.5.5-alpha31
- Contacts থেকে একটি নম্বর বা অনুমতি নিয়ে একাধিক নম্বর নির্বাচন।
- Group/Broadcast mode-এ আলাদা **Group Name**। একই মেসেজের সব প্রাপক একই সময়ে `due` হবে; আর ইচ্ছাকৃত ৬০ সেকেন্ড ব্যবধান নেই।
- আলাদা WhatsApp চ্যাটগুলোতে একটির পর আরেকটি Auto-Send চেষ্টা করা যায়; **সবাইকে একই মুহূর্তে ডেলিভারি নিশ্চিত নয়**। কোনো চেষ্টা আটকে গেলে সংশ্লিষ্ট Manual Reminder থাকে।
- Scheduler-এর History-তে **Edit message & schedule again** — পুরোনো পাঠানোর চেষ্টা/সেন্ট মার্কের রেকর্ড অক্ষত রেখে নতুন Schedule তৈরি।
- Group Name, Member Position ও Countdown শিডিউল কার্ডে দেখা যাবে।
- Pure Java Group Time & Queue Test এবং GitHub Source Checks যুক্ত।


## পূর্ববর্তী আপডেট — 1.5.4-alpha30
- Quick Message Template যোগ / এডিট / ডিলিট।
- Single এবং Group/Broadcast mode; সর্বোচ্চ ২০টি manually selected contact, প্রতিটি আলাদা WhatsApp chat-এ একই সময়ে schedule (WhatsApp UI sequential)।
- Smart Theme Studio: ৯টি palette এবং System/Light/Dark appearance mode।
- Scheduler row preview-এর missing `messagePreview(String, int)` compile error ঠিক করা হয়েছে; preview regression tests ও CI guard যোগ হয়েছে।

# SR Smart Toolbox Pro — Version 1.5.10-alpha36

**Created by Shahriar Rahman**  
**YouTube:** https://www.youtube.com/@SRCreation-farm  
**Facebook:** https://fb.com/srcreation.farm

## New 1.5.4-alpha30 — Foreground Return & 3→2→1 Send Preview
- যেই অ্যাপ সামনে ছিল, WhatsApp Auto-Send Attempt শেষে প্রথমে Android BACK ব্যবহার করে সেই অ্যাপে ফেরার চেষ্টা। Home Screen সামনে থাকলে Home-এই ফেরা, পুরোনো অ্যাপ না খোলা।
- Screen ON + unlocked হলে পাঠানোর চেষ্টা শুরুর আগে দৃশ্যমান `৩ → ২ → ১` Countdown ও Cancel। Pre-Alert Alarm দেরি করলে Due Time-এ সম্পূর্ণ Countdown দেখিয়ে তারপর চেষ্টা।
- প্রতিটি Pending Schedule Card-এ নির্ধারিত পাঠানোর সময় ও বাকি দিনের/ঘণ্টার/মিনিটের/সেকেন্ডের কাউন্টডাউন।
- Android-এর কারণে Task বা নির্দিষ্ট পুরোনো স্ক্রিন পুনরুদ্ধারের নিশ্চয়তা নেই; WhatsApp Accessibility Click ডেলিভারির প্রমাণ নয়।
- Foreground + Countdown-এ ২৩টি নতুন Pure-Java Test।

## New v1.5.4-alpha30 — Smart Scheduler Menu / History / Templates / Countdown
- Scheduler-এর **⋮ Three-Dot Menu → Settings**-এ Alarm, Notification এবং Experimental Auto-Send & Unlock-এর সেটিংস। পুরোনো শিডিউল সংরক্ষিত থাকবে।
- Recent Recipient History: **+** দিয়ে বর্তমান প্রাপক তালিকায় যোগ, **−** দিয়ে শুধু হিস্টোরি থেকে বাদ। হিস্টোরি Delivery Confirmation নয়।
- ৮টি বাংলা Quick Message Template; আগে লেখা টেক্সট থাকলে Replace/Append/Cancel।
- **10-second Test**: ঠিক একটি নম্বর ও মেসেজের নতুন এককালীন শিডিউল; Experimental Auto-Send ON থাকলে Confirm চাইবে। Android Alarm দেরি করতে পারে।
- প্রতিটি Pending Schedule-এর নিচে লাইভ Remaining Time; Pause/Due/Attempted-এর জন্য আলাদা Status।
- সম্পূর্ণ তথ্য: `SMART_SCHEDULER_UI_UPDATE_BN.md`।

## New v1.4.9-alpha24 — Compact Floating Quick Toolbox
- **পুরো রঙিন বারটাই ON/OFF:** Night Screen, Thermal Monitor ও Volume Boost-এর আলাদা ON/OFF Button সরানো হয়েছে। ধূসর = OFF, সবুজ = ON। বারটি ট্যাপ করলেই টগল হবে।
- **একই বারে Drag:** Night Screen-এর Darkness (০–৯৫%) এবং Volume Boost-এর Extra Gain (+0.0–10.0 dB) অনুভূমিকভাবে আঙুল টেনে পরিবর্তন করা যায়। আর নিচে আলাদা Darkness/Boost Slider নেই। Drag করতে করতে ভুল করে ফিচার ON/OFF হবে না। বন্ধ অবস্থায়ও লেভেল সেট করে পরে Tap করে চালু করা যায়।
- Thermal Monitor-এর লাইভ ব্যাটারি তাপমাত্রা একই বারে দেখানো হয় (আলাদা নিচের Description নেই)।
- ফোনের নিজস্ব Media Volume-এর `−` ও `+` ছোট কমপ্যাক্ট সারিতে রাখা হয়েছে, Extra Gain-এর থেকে আলাদা।
- QR/Barcode Scanner ও Video Player-কে সরু Action Row করা হয়েছে।
- 220–440 dp Width এবং 240–760 dp Height Settings আগের মতো আছে। প্যানেলের বাইরে কোনো কন্ট্রোল দেখাবে না: Rounded Outline Clipping, `ScrollView` এবং Screen Height Clamp দেওয়া হয়েছে। খুব ছোট করলে একই প্যানেলের ভেতর **উল্লম্বভাবে স্ক্রল** করে বাকি কন্ট্রোল পাওয়া যাবে; অপাঠ্য করে সব একসঙ্গে গুঁজে রাখা হয়নি।
- Edge Swipe Animation, 3-second Panel Auto Close, Tap Outside Close এবং Auto-hide আগের মতো আছে।

## Previous feature — Immersive Notification Bar and Background Audio on Demand
- ভিডিও খুলে Play করলে Android Immersive Mode চালু হয়ে Status/Notification Bar (এবং Navigation Bar) লুকায়। স্ক্রিনের উপর থেকে Swipe করলে System Bar অল্প সময়ের জন্য ফিরে আসে, পরে Android নিজে থেকে আবার লুকায়।
- AndroidX WindowInsetsControllerCompat দিয়ে `BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE` ব্যবহার করা হয়েছে; অন্য অ্যাপের Notification বন্ধ করা হয় না।
- Player-এর সাধারণ **Back** (স্ক্রিনের Back, Android Back Gesture) চাপলে Playback ও Audio দুটোই Stop হয় এবং Resume Position সংরক্ষিত থাকে।
- Player-এর **🎵 Background Audio** বাটনে চাপ দিলে ভিডিওর Player Activity বন্ধ হয়, কিন্তু Audio MediaSessionService-এ চলতে থাকে। আগে Pause থাকলে বাটন চাপলে Audio Play শুরু হয়।
- 🎵 বাটনের পর Media3-এর Media Notification থেকে Pause/Resume করা যাবে (নোটিফিকেশন Android অনুমতি/নিয়ম সাপেক্ষ)। পরে অ্যাপের Player-এ ফিরলে Stop করা যাবে।
- আগের **Audio-only display** (Player-এর ভেতরে ভিডিও লুকিয়ে অডিও চালানো) ফিচার Overflow Menu-তে রাখা হয়েছে।
- আগের PiP, Video Library, Folder, Theme, Resume, Floating Icon ও Toolbox sizing অপরিবর্তিত।

## Previous feature — Resizable Floating Toolbox Panel
- Home screen-এর **⋮ → Floating Icon Settings → Toolbox panel size** সেকশন থেকে Quick Control Panel-এর প্রস্থ ও সর্বোচ্চ উচ্চতা পরিবর্তন করা যায়।
- **Toolbox width:** 220–440 dp (default 292 dp)।
- **Maximum toolbox height:** 240–760 dp (default 580 dp)।
- Width/Height Slider ছেড়ে দিলে সেটিংস সংরক্ষিত হয় এবং Floating Control Service refresh হয়; পরেরবার প্যানেল খোলার সময় নতুন আকার দেখা যায়।
- Panel স্ক্রিনের বাইরে যাবে না; ছোট স্ক্রিনে নিজে থেকে ফিট হয়। প্রয়োজন হলে প্যানেলের ভেতর স্ক্রল করা যায়।
- **Reset toolbox size** বাটনে ডিফল্ট 292 × 580 dp-এ ফেরানো যায়।
- Floating **icon size** (24–76 dp) এবং Toolbox **panel size** আলাদাভাবে নিয়ন্ত্রিত হয়।
- আগের Auto-hide, 3-second panel close, swipe animation এবং সব টুল অপরিবর্তিত।

## New v1.4.6-alpha21 — Video Thumbnail List + Continue Last Video
- Folder video list now includes actual thumbnails, black duration overlays, titles and a three-dot options menu (Continue / Restart / Details).
- A floating Play (▶) button at the bottom right reopens the last watched video from its saved position, without a file picker.
- Thumbnail loading is asynchronous with bounded memory and recycled-image safety.
- Each video's independent resume position remains stored on-device.

## App identity
- App name: **SR Smart Toolbox Pro**
- Application ID: `com.smarttoolbox.pro` (unchanged for update compatibility)
- Developer / brand owner: Shahriar Rahman
- Version: `1.5.7-alpha33` (`versionCode 33`)

## Features
- Night Screen with extra darkness and warm filter.
- System-wide Extra Volume, five-band equalizer, Bass Boost and Virtualizer where supported.
- Native media volume +/- controls in the floating panel.
- Thermal Monitor.
- QR / Barcode Scanner with copy, share and safe web-link opening.
- Floating edge sidebar and 3-second Quick Panel auto-close.
- Android Notification Controls (now accessed through the top-right three-dot menu).
- SR Video Library: phone video list, search by video/folder name, folder filter, sort by newest/name/duration and per-video resume status (requires user-granted video permission).
- SR Video Player (new): local multi-select playlist, secure HTTPS / RTSP streams, HLS, DASH and SmoothStreaming modules, playback speed, repeat, shuffle, seek gestures, external subtitles, audio/subtitle track selection, aspect ratio, full-screen landscape mode, brightness and media-volume sliders, PiP, background audio playback notification (video remains visible in PiP), service-based sleep timer, favorites, history and resume point.
- Player UI: supplied MX Player reference-inspired full-screen black layout, transparent top/bottom controls, auto-hide, custom seek bar, previous/play-pause/next, tap-to-show, double-tap seek, swipe brightness/volume/seek, screenshot, audio-only, lock, aspect ratio and PiP.

## Video format support — important
The player uses AndroidX Media3 ExoPlayer 1.11.1. Media3 extractors cover containers including MP4, WebM, Matroska/MKV, AVI, MPEG-TS, MPEG-PS, FLV, Ogg, WAV and FLAC, plus HLS/DASH/SmoothStreaming with their matching modules. Actual playback still depends on the audio/video codecs and profiles supported by the Android device; a recognized container does not guarantee every codec inside it. A clear playback error is shown when the file, codec, network, or device decoder is unsupported.

External subtitles: SRT, WebVTT, SSA/ASS and TTML.

Network URLs: HTTPS and RTSP are accepted. Cleartext HTTP URLs are intentionally rejected for safer network handling.

## Video Player architecture
- `VideoPlayerActivity` provides the SR-styled player interface.
- `VideoPlaybackService` hosts ExoPlayer + MediaSessionService so audio/media playback can continue outside the Activity.
- `MediaController` connects the UI to the service and is released with the Activity lifecycle.
- The Video Library queries Android MediaStore after the user grants video access; Android 14+ also supports selecting a limited set of videos. Separately, the system file picker can open video/subtitle documents without broad storage permission.
- Picture-in-Picture is declared as optional and only starts on supported Android devices.

## Build toolchain
- JDK 17
- Android Gradle Plugin 8.10.0
- Gradle 8.11.1
- compileSdk 36, targetSdk 35, minSdk 26
- Android SDK platform 36 and build-tools 35.0.0
- AndroidX Media3 1.11.1 (stable)

## GitHub Actions build
The repository workflow accepts the root source ZIP (`SmartToolboxPro_GitHub.zip`) and extracts the Android project before building. It runs pure-Java tests and source checks, then executes `:app:assembleDebug`. On success, download the `SR-Smart-Toolbox-Pro-debug-apk` artifact from Actions.

## Verification limits
ZIP integrity, source wiring, XML, workflow syntax, and pure-Java helper tests were checked in this workspace. This workspace does not have Android SDK / Gradle installed, so a full APK compile, install, real video playback, codec compatibility, PiP, and background playback still need to be verified by GitHub Actions and on a physical Android device.

## প্রতিটি ভিডিওর Resume Playback
- MediaStore থেকে ফোনে ইনডেক্স করা ভিডিওগুলো অ্যাপের লাইব্রেরিতে দেখা যাবে; অনুমতির ওপর নির্ভর করে সবগুলো অথবা শুধু নির্বাচিত ভিডিও দেখা যাবে।
- ভিডিওর নাম, ফোল্ডার ও দৈর্ঘ্য দেখাবে; সার্চ, ফোল্ডার ফিল্টার এবং Sort থাকবে।
- প্রতিটি ভিডিও আলাদাভাবে শেষ দেখা অবস্থান মনে রাখবে। ভিডিওতে ট্যাপ করলে মাঝপথে থাকলে আগের অবস্থান থেকে চালু হবে।
- কোনো ভিডিওতে Long Press করলে Start from beginning নির্বাচন করা যাবে।
- ভিডিও প্রায় শেষ হয়ে গেলে পরেরবার শুরু থেকে চলবে।
- ভিডিও বন্ধ করে বের হওয়ার সময় অবস্থান সংরক্ষণ হয়; প্লে চলার সময় নিয়মিত সংরক্ষণ হয়।
- Android 13+ এ READ_MEDIA_VIDEO অনুমতি, Android 14+ এ Selected Video Access অথবা All Video Access, পুরোনো Android এ READ_EXTERNAL_STORAGE প্রয়োজন।
- কোনো ভিডিও MediaStore-এ ইনডেক্স না হলে, সিস্টেম File Picker দিয়ে খোলা যাবে।

## Home Screen / ⋮ Smart Menu
The home page now focuses on Night Screen, System-Wide Extra Volume, Thermal Monitor, QR / Barcode Scanner and SR Video Player. Tap **⋮** at the top-right for **Floating Icon Settings**, **Notification Controls**, **Android App Settings** and **About Shahriar Rahman**. The previous standalone settings/notification/About home cards have been removed without deleting their underlying screens. The app ID remains `com.smarttoolbox.pro` so update compatibility is preserved, subject to signing.

## New in 1.4.6-alpha21: Smart folder browser & Theme Settings
- Video Player now opens in Folders view with folder cards, counts, search, folder list/grid toggle and filtered videos.
- All Videos and Continue Watching shortcuts; persistent per-video resume positions unchanged.
- Theme Settings in home ⋮ menu offers Midnight Gold, Ocean Blue, Emerald Green, Royal Purple and Light Day.
- Theme choice is saved across app restarts; immersive video background remains black by design.

## 1.4.6-alpha21 — Video Library Compile Fix + Animated Floating Icon
- Fixed missing `status` and `adapter` fields in `VideoLibraryActivity` that caused repeated `cannot find symbol` errors.
- Added native swipe-reveal slide/fade/scale animation for the floating icon from either edge (270ms) and a quick panel slide/fade (200ms).
- Retained the 3-second quick-panel timeout and independent floating icon auto-hide preferences.
- Added source-AST regression tests to GitHub Actions before compiling APK.
- See `VIDEO_LIBRARY_ANIMATION_FIX_BN.md`.


## নতুন: WhatsApp Smart Scheduler (1.5.0-alpha25)
- Home screen এবং Three-dot menu থেকে Scheduler খোলা যাবে।
- Contacts picker, বাংলা/English voice typing, একাধিক নম্বর, তারিখ/সময়, quick time এবং দৈনিক/সাপ্তাহিক repeat।
- নির্ধারিত সময়ে notification; notification থেকে WhatsApp-এ pre-filled message draft খুলবে।
- Android exact-alarm access থাকলে নির্দিষ্ট সময়ের alarm; না থাকলে inexact reminder fallback।
- Reboot বা app update-এর পর pending reminder পুনরায় schedule হয়।
- WhatsApp-এ চূড়ান্ত Send action ব্যবহারকারী নিজে নিশ্চিত করবেন; lock-screen PIN automation বা Accessibility দিয়ে Send চাপানো নেই।


## New: Experimental WhatsApp Auto-Send and PIN Attempt (1.5.1-alpha26)
- Smart Scheduler-এ opt-in Accessibility Automation সেকশন (ডিফল্ট OFF)।
- নির্ধারিত সময়ের ৩ সেকেন্ড আগে Overlay Reminder ও Cancel (প্রয়োজনীয় Android Permission সাপেক্ষ)।
- Official `com.whatsapp`-এ পূর্বনির্ধারিত Draft মিললে Send UI সর্বোচ্চ একবার ক্লিক করার চেষ্টা।
- PIN স্থানীয় Android Keystore AES-GCM-এ encrypted; পরীক্ষামূলক Keyguard Attempt সর্বোচ্চ একবার, ব্যর্থ হলে manual reminder।
- ফোন আগে লক থাকলে Home → Lock, অন্যথায় আগের অ্যাপে ফেরার best-effort ব্যবস্থা।
- WhatsApp UI পরিবর্তন/Android restriction-এর কারণে কোনো স্বয়ংক্রিয় ধাপের সফলতা নিশ্চিত নয়।
- বিস্তারিত: `WHATSAPP_EXPERIMENTAL_AUTOMATION_BN.md`।
