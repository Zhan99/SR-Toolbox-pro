# SR Smart Toolbox Pro — Branding Update

## Brand identity
- App name: SR Smart Toolbox Pro
- Creator / Brand Owner: Shahriar Rahman
- YouTube: @SRCreation-farm — https://www.youtube.com/@SRCreation-farm
- Facebook: fb.com/srcreation.farm — https://fb.com/srcreation.farm

## In-app branding
- Launcher label and app home title use SR Smart Toolbox Pro.
- Launcher icon is a custom SR monogram.
- Home screen has a Developer & Brand card.
- About the Developer page contains profile details and YouTube / Facebook buttons.
- Credits identify Shahriar Rahman as creator / brand owner.

## Compatibility
The Android applicationId remains `com.smarttoolbox.pro`; it is deliberately unchanged so the branded release can update an already-installed Smart Toolbox Pro build rather than install as a different app.

## Release
Version: 1.3.1-alpha14 (versionCode 14).
