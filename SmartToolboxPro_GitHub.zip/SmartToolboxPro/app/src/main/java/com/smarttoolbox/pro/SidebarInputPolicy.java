package com.smarttoolbox.pro;

/** Only the visibly occupied bar can receive overlay touches. No invisible hit slop. */
public final class SidebarInputPolicy {
    private SidebarInputPolicy() { }

    public static int edgeTouchWidthDp(int visibleWidthDp) {
        return Math.max(6, Math.min(26, visibleWidthDp));
    }

    /** Taps never open an explicitly swipe-only collapsed sidebar. */
    public static boolean mayOpenFromTap(boolean tapToOpen, boolean swipeToOpen,
                                         boolean panelEnabled) {
        return tapToOpen && !swipeToOpen && panelEnabled;
    }
}
