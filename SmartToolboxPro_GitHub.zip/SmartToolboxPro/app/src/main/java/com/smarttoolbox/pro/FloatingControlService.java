package com.smarttoolbox.pro;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.view.animation.DecelerateInterpolator;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.res.Configuration;
import android.hardware.display.DisplayManager;
import android.content.pm.ServiceInfo;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.media.AudioManager;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.IBinder;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

public class FloatingControlService extends Service {
    private static final String PORTRAIT_ALL_APPS = "floating.portrait_anywhere.edge";
    private static final String GLOBAL_EDGE_MOVED = "floating.global_portrait.moved_icon";
    private static final String EDGE_CENTER_FRACTION = "floating.edge.y_fraction";
    private boolean globalPortraitEdgeActive;
    private DisplayManager portraitDisplayManager;
    private final Handler portraitMonitorHandler = new Handler(Looper.getMainLooper());
    private final Runnable portraitMonitorTick = new Runnable() {
        @Override public void run() {
            syncGlobalPortraitEdge();
            // A low-frequency fallback for OEMs that do not deliver display callbacks.
            portraitMonitorHandler.postDelayed(this, 1800L);
        }
    };
    private final DisplayManager.DisplayListener portraitDisplayListener =
            new DisplayManager.DisplayListener() {
                @Override public void onDisplayAdded(int displayId) { }
                @Override public void onDisplayRemoved(int displayId) { }
                @Override public void onDisplayChanged(int displayId) {
                    portraitMonitorHandler.postDelayed(() -> syncGlobalPortraitEdge(), 120L);
                }
            };

    public static final String ACTION_SHOW = "com.smarttoolbox.pro.FLOAT_SHOW";
    public static final String ACTION_REFRESH = "com.smarttoolbox.pro.FLOAT_REFRESH";
    public static final String ACTION_HIDE = "com.smarttoolbox.pro.FLOAT_HIDE";

    private static final String CHANNEL_ID = "floating_controls";
    private static final int NOTIFICATION_ID = 2401;
    // Floating quick controls close after 3 seconds of inactivity.
    private static final long PANEL_IDLE_TIMEOUT_MS = 3000L;

    private WindowManager windowManager;
    private TextView bubble;
    private ScrollView panel;
    private LinearLayout panelContent;
    private FrameLayout edgeHandle;
    private CompactFeatureBar thermalReadout;
    private WindowManager.LayoutParams edgeParams;
    private Runnable thermalReadoutRunnable;
    private final Handler sliderHandler = new Handler(Looper.getMainLooper());
    private final Handler autoHideHandler = new Handler(Looper.getMainLooper());
    private Runnable pendingNightUpdate;
    private Runnable pendingAudioUpdate;
    private Runnable autoHideRunnable;
    private Runnable panelAutoCloseRunnable;
    private final Handler holdHapticHandler = new Handler(Looper.getMainLooper());
    private Runnable holdHapticRunnable;
    private boolean holdHapticPlayed;
    private WindowManager.LayoutParams bubbleParams;
    private WindowManager.LayoutParams panelParams;
    private boolean autoHidden;
    private int touchSlop;
    private float downRawX;
    private float downRawY;
    private int downX;
    private int downY;
    private boolean dragged;
    private boolean bubbleMovedBeforeHold;
    private boolean floatingTouchActive;
    private long bubbleTouchDownTime;
    private boolean bubbleTouchOnLeft;
    private float edgeTouchStartX;
    private float edgeTouchStartY;
    private boolean edgeMovedBeforeHold;
    private boolean edgeDockLeftDuringDrag;
    private boolean edgeDragging;
    private long edgeTouchDownTime;
    private int edgeDownX;
    private int edgeDownY;
    private ValueAnimator bubbleRevealAnimator;
    private final Handler gestureFallbackHandler = new Handler(Looper.getMainLooper());
    private Runnable pendingGestureOpenFallback;

    public static boolean hasOverlayPermission(Context context) {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(context);
    }

    public static boolean start(Context context) {
        if (!hasOverlayPermission(context)) return false;
        android.content.SharedPreferences prefs = context.getSharedPreferences("tool_state", MODE_PRIVATE);
        if (!prefs.getBoolean("floating.enabled", true)) return false;
        prefs.edit().putBoolean("floating.hidden", false)
                .putBoolean("floating.auto_hidden", false).apply();
        Intent intent = new Intent(context, FloatingControlService.class);
        intent.setAction(ACTION_SHOW);
        ContextCompat.startForegroundService(context, intent);
        return true;
    }

    public static void refresh(Context context) {
        Intent intent = new Intent(context, FloatingControlService.class);
        intent.setAction(ACTION_REFRESH);
        android.content.SharedPreferences prefs = context.getSharedPreferences("tool_state", MODE_PRIVATE);
        boolean hidden = prefs.getBoolean("floating.hidden", false);
        boolean enabled = prefs.getBoolean("floating.enabled", true);
        // The floating sidebar is an independent user-controlled feature.
        // It remains available even when every toolbox feature is OFF.
        if (hidden || !enabled || !hasOverlayPermission(context)) {
            context.stopService(new Intent(context, FloatingControlService.class));
        } else {
            ContextCompat.startForegroundService(context, intent);
        }
    }

    public static boolean anyFeatureActive(Context context) {
        boolean night = context.getSharedPreferences("night", MODE_PRIVATE).getBoolean("active", false);
        boolean thermal = context.getSharedPreferences("tool_state", MODE_PRIVATE).getBoolean("thermal.active", false);
        boolean audio = context.getSharedPreferences("tool_state", MODE_PRIVATE).getBoolean("audio.active", false);
        boolean scanner = context.getSharedPreferences("tool_state", MODE_PRIVATE).getBoolean("scanner.active", false);
        return night || thermal || audio || scanner;
    }

    @Override public void onCreate() {
        super.onCreate();
        ThemeManager.initialize(this);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        touchSlop = ViewConfiguration.get(this).getScaledTouchSlop();
        createNotificationChannel();
        portraitDisplayManager = (DisplayManager) getSystemService(DISPLAY_SERVICE);
        if (portraitDisplayManager != null) {
            portraitDisplayManager.registerDisplayListener(portraitDisplayListener, portraitMonitorHandler);
        }
        portraitMonitorHandler.postDelayed(portraitMonitorTick, 800L);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_REFRESH : intent.getAction();

        if (ACTION_HIDE.equals(action)) {
            getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                    .putBoolean("floating.hidden", true).putBoolean("floating.enabled", false)
                    .putBoolean(GLOBAL_EDGE_MOVED, false).apply();
            removePanelAndBubble();
            stopForeground(true);
            stopSelf(startId);
            return START_NOT_STICKY;
        }

        if (!hasOverlayPermission(this)) {
            removePanelAndBubble();
            stopForeground(true);
            stopSelf(startId);
            return START_NOT_STICKY;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIFICATION_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, buildNotification());
        }

        android.content.SharedPreferences floatingPrefs = getSharedPreferences("tool_state", MODE_PRIVATE);
        boolean hidden = floatingPrefs.getBoolean("floating.hidden", false);
        boolean enabled = floatingPrefs.getBoolean("floating.enabled", true);
        if (hidden || !enabled) {
            removePanelAndBubble();
            stopForeground(true);
            stopSelf(startId);
            return START_NOT_STICKY;
        }

        boolean panelWasOpen = panel != null;
        boolean autoHideEnabled = floatingPrefs.getBoolean("floating.auto_hide", true);
        boolean savedAsAutoHidden = floatingPrefs.getBoolean("floating.auto_hidden", false);
        // Preserve the edge tab across ordinary refreshes and service restarts.
        // ACTION_SHOW is an explicit request to reveal the full icon.
        if (savedAsAutoHidden && autoHideEnabled && !ACTION_SHOW.equals(action)) {
            if (edgeHandle != null && bubble == null) return START_STICKY;
            removePanelAndBubble();
            autoHidden = true;
            showEdgeHandleFromSavedPosition();
            syncGlobalPortraitEdge();
            return START_STICKY;
        }

        if (ACTION_SHOW.equals(action) || !autoHideEnabled) {
            floatingPrefs.edit().putBoolean("floating.auto_hidden", false).apply();
            autoHidden = false;
        }

        boolean nightIsActive = getSharedPreferences("night", MODE_PRIVATE).getBoolean("active", false);
        if ((ACTION_SHOW.equals(action) || ACTION_REFRESH.equals(action) || nightIsActive) && bubble != null) {
            // Re-add after settings changes or Night Screen overlay so size, opacity and z-order refresh.
            removePanelAndBubble();
        }
        ensureBubble();
        if (panelWasOpen && getSharedPreferences("tool_state", MODE_PRIVATE)
                .getBoolean("floating.panel.enabled", true)) showPanel();
        syncGlobalPortraitEdge();
        return START_STICKY;
    }

    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        portraitMonitorHandler.postDelayed(this::syncGlobalPortraitEdge, 120L);
        portraitMonitorHandler.postDelayed(this::syncGlobalPortraitEdge, 420L);
    }

    private boolean isDisplayPortrait() {
        if (windowManager == null) return false;
        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(metrics);
        return GlobalPortraitEdgeLogic.isPortrait(metrics.widthPixels, metrics.heightPixels,
                getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT);
    }

    private boolean allAppsPortraitEnabled() {
        return getSharedPreferences("tool_state", MODE_PRIVATE)
                .getBoolean(PORTRAIT_ALL_APPS, true);
    }

    private boolean manuallyPositioned() {
        return getSharedPreferences("tool_state", MODE_PRIVATE)
                .getBoolean(FloatingBoundaryPolicy.PREF_MANUAL_POSITION, false);
    }

    private boolean forcedPortraitNow() {
        return !manuallyPositioned() && allAppsPortraitEnabled() && isDisplayPortrait();
    }

    private void alignEdgeHandleToDisplay() {
        if (edgeHandle == null || edgeParams == null || windowManager == null) return;
        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(metrics);
        android.content.SharedPreferences prefs = getSharedPreferences("tool_state", MODE_PRIVATE);
        boolean left = prefs.getBoolean("floating.edge.left", true);
        float fraction = prefs.getFloat(EDGE_CENTER_FRACTION,
                FloatingEdgeGeometry.centerFraction(
                        prefs.getInt("floating.edge.y", metrics.heightPixels / 3),
                        metrics.heightPixels));
        int wantedCenter = FloatingEdgeGeometry.centerForFraction(fraction, metrics.heightPixels);
        edgeParams.x = FloatingEdgeGeometry.x(left, metrics.widthPixels, edgeParams.width);
        edgeParams.y = FloatingEdgeGeometry.y(wantedCenter - edgeParams.height / 2,
                metrics.heightPixels, edgeParams.height, dp(8));
        try { windowManager.updateViewLayout(edgeHandle, edgeParams); }
        catch (RuntimeException ignored) { /* The overlay may have been removed. */ }
    }

    private void syncGlobalPortraitEdge() {
        if (windowManager == null || !hasOverlayPermission(this) || floatingTouchActive) return;
        android.content.SharedPreferences prefs = getSharedPreferences("tool_state", MODE_PRIVATE);
        if (!prefs.getBoolean("floating.enabled", true)
                || prefs.getBoolean("floating.hidden", false)) return;
        // The narrow collapsed bar remains docked on the last selected screen edge.
        // Resize/re-align on every orientation change; never override manual side/Y.
        if (edgeHandle != null) alignEdgeHandleToDisplay();
        if (bubble != null && panel == null && bubbleRevealAnimator == null
                && autoHideRunnable == null && isAutoHideEnabled()) scheduleAutoHide();
    }

    private void ensureBubble() {
        if (bubble != null) return;
        cancelAutoHide();
        removeEdgeHandle();
        autoHidden = false;
        getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                .putBoolean("floating.auto_hidden", false).apply();

        android.content.SharedPreferences prefs = getSharedPreferences("tool_state", MODE_PRIVATE);
        int sizeDp = Math.max(24, Math.min(76, prefs.getInt("floating.size", 54)));
        int opacity = Math.max(30, Math.min(100, prefs.getInt("floating.opacity", 100)));

        bubble = new TextView(this);
        bubble.setText("ST");
        bubble.setContentDescription("SR Smart Toolbox. Tap or swipe to open when enabled. Hold 2 seconds then drag to move.");
        bubble.setTextColor(ThemeManager.isLight(this) ? Color.WHITE : Color.rgb(18, 23, 30));
        bubble.setTextSize(Math.max(12, Math.min(18, sizeDp * 0.28f)));
        bubble.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        bubble.setGravity(Gravity.CENTER);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(Ui.ACCENT);
        circle.setStroke(dp(2), Ui.isPremium() ? Ui.shade(Ui.ACCENT, Color.WHITE, .57f) : Ui.TEXT);
        bubble.setBackground(circle);
        bubble.setAlpha(opacity / 100f);
        bubble.setElevation(dp(8));

        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(metrics);
        int sizePx = dp(sizeDp);
        bubbleParams = new WindowManager.LayoutParams(
                sizePx, sizePx,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.START;

        int savedX = prefs.getInt("floating.x", -1);
        int savedY = prefs.getInt("floating.y", -1);
        bubbleParams.x = savedX >= 0
                ? Math.max(0, Math.min(metrics.widthPixels - sizePx, savedX))
                : Math.max(0, metrics.widthPixels - sizePx);
        if (!prefs.getBoolean(FloatingBoundaryPolicy.PREF_MANUAL_POSITION, false)) {
            bubbleParams.x = FloatingBoundaryPolicy.edgeX(bubbleParams.x, sizePx,
                    metrics.widthPixels);
        }
        bubbleParams.y = savedY >= 0
                ? Math.max(0, Math.min(metrics.heightPixels - sizePx, savedY))
                : Math.max(dp(90), metrics.heightPixels / 3);

        bubble.setOnTouchListener((view, event) -> handleBubbleTouch(event));
        try {
            windowManager.addView(bubble, bubbleParams);
            scheduleAutoHide();
        } catch (Exception e) {
            bubble = null;
            bubbleParams = null;
            stopSelf();
        }
    }

    private boolean handleBubbleTouch(MotionEvent event) {
        if (bubbleParams == null) return true;
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                cancelBubbleRevealAnimation();
                cancelAutoHide();
                floatingTouchActive = true;
                downRawX = event.getRawX();
                downRawY = event.getRawY();
                downX = bubbleParams.x;
                downY = bubbleParams.y;
                bubbleTouchDownTime = event.getEventTime();
                bubbleMovedBeforeHold = false;
                dragged = false;
                beginHoldHaptic(false);
                return true;
            case MotionEvent.ACTION_MOVE:
                float dx = event.getRawX() - downRawX;
                float dy = event.getRawY() - downRawY;
                long elapsed = Math.max(0L, event.getEventTime() - bubbleTouchDownTime);
                if (FloatingOpenModeLogic.movedTooEarly(elapsed, dx, dy,
                        Math.max(touchSlop, dp(14)))) {
                    bubbleMovedBeforeHold = true;
                    cancelHoldHaptic();
                }
                if (!dragged && FloatingOpenModeLogic.startDrag(elapsed,
                        bubbleMovedBeforeHold, dx, dy, Math.max(touchSlop, dp(14)))) {
                    dragged = true;
                    markHoldHaptic();
                }
                if (dragged && bubble != null && bubbleParams != null) {
                    DisplayMetrics metrics = new DisplayMetrics();
                    windowManager.getDefaultDisplay().getMetrics(metrics);
                    bubbleParams.x = Math.max(0, Math.min(
                            metrics.widthPixels - bubbleParams.width, downX + (int) dx));
                    bubbleParams.y = Math.max(0, Math.min(
                            metrics.heightPixels - bubbleParams.height, downY + (int) dy));
                    try { windowManager.updateViewLayout(bubble, bubbleParams); }
                    catch (RuntimeException ignored) { }
                }
                return true;
            case MotionEvent.ACTION_UP:
                cancelHoldHaptic();
                float upDx = event.getRawX() - downRawX;
                float upDy = event.getRawY() - downRawY;
                long upElapsed = Math.max(0L, event.getEventTime() - bubbleTouchDownTime);
                // A coalesced final MOVE can be the first indication of a drag.
                if (FloatingOpenModeLogic.movedTooEarly(upElapsed, upDx, upDy,
                        Math.max(touchSlop, dp(14)))) {
                    bubbleMovedBeforeHold = true;
                }
                if (!dragged && FloatingOpenModeLogic.startDrag(upElapsed,
                        bubbleMovedBeforeHold, upDx, upDy, Math.max(touchSlop, dp(14)))) {
                    dragged = true;
                    markHoldHaptic();
                }
                floatingTouchActive = false;
                if (dragged && bubbleParams != null) {
                    // Follow the final pointer position before persisting it.
                    DisplayMetrics screen = new DisplayMetrics();
                    windowManager.getDefaultDisplay().getMetrics(screen);
                    bubbleParams.x = Math.max(0, Math.min(screen.widthPixels - bubbleParams.width,
                            downX + (int) upDx));
                    bubbleParams.y = Math.max(0, Math.min(screen.heightPixels - bubbleParams.height,
                            downY + (int) upDy));
                    try { windowManager.updateViewLayout(bubble, bubbleParams); }
                    catch (RuntimeException ignored) { }
                    getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                            .putInt("floating.x", bubbleParams.x)
                            .putInt("floating.y", bubbleParams.y)
                            .putBoolean("floating.edge.left", bubbleParams.x + bubbleParams.width / 2
                                    < screen.widthPixels / 2)
                            .putFloat(EDGE_CENTER_FRACTION, FloatingEdgeGeometry.centerFraction(
                                    bubbleParams.y + bubbleParams.height / 2, screen.heightPixels))
                            .putBoolean(FloatingBoundaryPolicy.PREF_MANUAL_POSITION, true)
                            .putBoolean(GLOBAL_EDGE_MOVED, false)
                            .apply();
                    scheduleAutoHide();
                } else if (FloatingOpenModeLogic.shouldOpen(openOnTap(), openOnSwipe(),
                        quickPanelEnabled(), false, bubbleMovedBeforeHold, upElapsed,
                        upDx, upDy, Math.max(dp(10), touchSlop), dp(18))) {
                    // Retain left/right and vertical swipe detection regression coverage;
                    // mode policy also supports outward slides for accessibility.
                    boolean slide = FloatingBarGestureLogic.bubbleSwipe(true,
                            upDx, upDy, upElapsed, dp(18))
                            || FloatingBarGestureLogic.qualifiesAsSlide(upDx, upDy, dp(18));
                    if (!bubbleMovedBeforeHold || slide) {
                        if (panel != null) dismissPanelFromOutsideTouch();
                        else {
                            if (bubbleMovedBeforeHold) SwipeHaptics.onSwipeMenuOpen(this);
                            openQuickControlsFromGesture();
                        }
                    }
                } else {
                    scheduleAutoHide();
                }
                dragged = false;
                bubbleMovedBeforeHold = false;
                return true;
            case MotionEvent.ACTION_CANCEL:
                cancelHoldHaptic();
                floatingTouchActive = false;
                if (dragged && bubbleParams != null) {
                    getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                            .putInt("floating.x", bubbleParams.x)
                            .putInt("floating.y", bubbleParams.y)
                            .putBoolean("floating.edge.left", bubbleParams.x <
                                    getResources().getDisplayMetrics().widthPixels / 2)
                            .putFloat(EDGE_CENTER_FRACTION, FloatingEdgeGeometry.centerFraction(
                                    bubbleParams.y + bubbleParams.height / 2,
                                    getResources().getDisplayMetrics().heightPixels))
                            .putBoolean(FloatingBoundaryPolicy.PREF_MANUAL_POSITION, true)
                            .putBoolean(GLOBAL_EDGE_MOVED, false)
.apply();
                }
                dragged = false;
                bubbleMovedBeforeHold = false;
                scheduleAutoHide();
                return true;
            default:
                return true;
        }
    }

    private boolean quickPanelEnabled() {
        return getSharedPreferences("tool_state", MODE_PRIVATE)
                .getBoolean("floating.panel.enabled", true);
    }

    private boolean openOnTap() {
        return getSharedPreferences("tool_state", MODE_PRIVATE)
                .getBoolean(FloatingOpenModeLogic.PREF_TAP, true);
    }

    private boolean openOnSwipe() {
        return getSharedPreferences("tool_state", MODE_PRIVATE)
                .getBoolean(FloatingOpenModeLogic.PREF_SWIPE, true);
    }

    private void openQuickControlsFromGesture() {
        cancelAutoHide();
        if (!quickPanelEnabled()) {
            scheduleAutoHide();
            return;
        }
        if (panel != null) {
            cancelPanelAutoClose();
            schedulePanelAutoClose();
        } else if (bubble != null && bubbleParams != null) {
            showPanel();
        }
    }

    private boolean isAutoHideEnabled() {
        return getSharedPreferences("tool_state", MODE_PRIVATE)
                .getBoolean("floating.auto_hide", true);
    }

    // 2-second uninterrupted, stationary hold is acknowledged ONCE with a short vibration.
    // Gestures that move before 2 seconds (swipes) and taps never trigger hold feedback.
    private void beginHoldHaptic(boolean edgeTouch) {
        cancelHoldHaptic();
        holdHapticPlayed = false;
        holdHapticRunnable = () -> {
            holdHapticRunnable = null;
            if (floatingTouchActive && !(edgeTouch ? edgeMovedBeforeHold : bubbleMovedBeforeHold)) {
                markHoldHaptic();
            }
        };
        holdHapticHandler.postDelayed(holdHapticRunnable, FloatingOpenModeLogic.HOLD_TO_MOVE_MS);
    }

    private void cancelHoldHaptic() {
        if (holdHapticRunnable != null) {
            holdHapticHandler.removeCallbacks(holdHapticRunnable);
            holdHapticRunnable = null;
        }
    }

    private void markHoldHaptic() {
        if (holdHapticPlayed) return;
        holdHapticPlayed = true;
        HoldDragHaptics.onHoldReady(this);
    }

    private void cancelAutoHide() {
        if (autoHideRunnable != null) {
            autoHideHandler.removeCallbacks(autoHideRunnable);
            autoHideRunnable = null;
        }
    }

    private void cancelPanelAutoClose() {
        if (panelAutoCloseRunnable != null) {
            autoHideHandler.removeCallbacks(panelAutoCloseRunnable);
            panelAutoCloseRunnable = null;
        }
    }

    private void schedulePanelAutoClose() {
        cancelPanelAutoClose();
        if (panel == null) return;

        panelAutoCloseRunnable = () -> {
            panelAutoCloseRunnable = null;
            if (panel == null) return;
            removePanel();
            // The quick panel has a fixed three-second idle timeout.
            // Edge-collapse separately follows the user-selected icon auto-hide setting.
            scheduleAutoHide();
        };
        autoHideHandler.postDelayed(panelAutoCloseRunnable, PANEL_IDLE_TIMEOUT_MS);
    }

    // An outside tap should dismiss the panel immediately, even during the first 3 seconds.
    // We do not capture or consume touches made in another application.
    private void dismissPanelFromOutsideTouch() {
        if (panel == null) return;
        removePanel();
        scheduleAutoHide();
    }

    private void scheduleAutoHide() {
        cancelAutoHide();
        if (bubble == null || panel != null || floatingTouchActive || !isAutoHideEnabled()) return;
        autoHideRunnable = this::hideBubbleToEdge;
        int delaySeconds = Math.max(1, Math.min(60,
                getSharedPreferences("tool_state", MODE_PRIVATE)
                        .getInt("floating.auto_hide_seconds", 4)));
        autoHideHandler.postDelayed(autoHideRunnable, FloatingIdleLogic.idleTimeoutMs(delaySeconds));
    }

    private void hideBubbleToEdge() {
        autoHideRunnable = null;
        if (bubble == null || bubbleParams == null || panel != null
                || floatingTouchActive || !isAutoHideEnabled()) return;

        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(metrics);
        android.content.SharedPreferences prefs = getSharedPreferences("tool_state", MODE_PRIVATE);
        boolean leftSide = prefs.getBoolean("floating.edge.left",
                bubbleParams.x + bubbleParams.width / 2 < metrics.widthPixels / 2);
        float fraction = prefs.getFloat(EDGE_CENTER_FRACTION,
                FloatingEdgeGeometry.centerFraction(bubbleParams.y + bubbleParams.height / 2,
                        metrics.heightPixels));
        int centerY = FloatingEdgeGeometry.centerForFraction(fraction, metrics.heightPixels);

        prefs.edit().putInt("floating.x", bubbleParams.x)
                .putInt("floating.y", bubbleParams.y)
                .putBoolean("floating.edge.left", leftSide)
                .putFloat(EDGE_CENTER_FRACTION, fraction)
                .putInt("floating.edge.y", centerY)
                .putBoolean("floating.auto_hidden", true).apply();

        try { windowManager.removeView(bubble); } catch (Exception ignored) {}
        bubble = null;
        bubbleParams = null;
        autoHidden = true;
        showEdgeHandle(leftSide, centerY);
    }

    private void showEdgeHandleFromSavedPosition() {
        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(metrics);
        android.content.SharedPreferences prefs = getSharedPreferences("tool_state", MODE_PRIVATE);
        int savedX = prefs.getInt("floating.x", -1);
        int sizePx = dp(Math.max(24, Math.min(76, prefs.getInt("floating.size", 54))));
        boolean leftSide = prefs.getBoolean("floating.edge.left",
                savedX >= 0 && savedX + sizePx / 2 < metrics.widthPixels / 2);
        int legacyY = prefs.getInt("floating.edge.y",
                prefs.getInt("floating.y", metrics.heightPixels / 3));
        float fraction = prefs.getFloat(EDGE_CENTER_FRACTION,
                FloatingEdgeGeometry.centerFraction(legacyY, metrics.heightPixels));
        if (!prefs.contains(EDGE_CENTER_FRACTION)) {
            prefs.edit().putFloat(EDGE_CENTER_FRACTION, fraction).apply();
        }
        showEdgeHandle(leftSide, FloatingEdgeGeometry.centerForFraction(fraction,
                metrics.heightPixels));
    }

    private void showEdgeHandle(boolean leftSide, int centerY) {
        if (edgeHandle != null) return;
        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(metrics);
        android.content.SharedPreferences prefs = getSharedPreferences("tool_state", MODE_PRIVATE);
        if (!prefs.contains(EDGE_CENTER_FRACTION)) {
            prefs.edit().putFloat(EDGE_CENTER_FRACTION,
                    FloatingEdgeGeometry.centerFraction(centerY, metrics.heightPixels)).apply();
        }
        centerY = FloatingEdgeGeometry.centerForFraction(
                prefs.getFloat(EDGE_CENTER_FRACTION, 0.5f), metrics.heightPixels);
        int edgeWidthDp = Math.max(6, Math.min(26, prefs.getInt("floating.edge.width", 12)));
        // The overlay MUST NOT steal taps from content beside the strip.
        // Android touch dispatch cannot pass a consumed tap through an overlay window,
        // so use the physical strip's own narrow width, never an invisible 44dp pad.
        int touchWidthDp = SidebarInputPolicy.edgeTouchWidthDp(edgeWidthDp);
        int height = dp(FloatingIdleLogic.clampEdgeHeight(
                prefs.getInt(FloatingIdleLogic.PREF_EDGE_HEIGHT_DP, 92)));
        int touchWidth = dp(touchWidthDp);

        edgeHandle = new FrameLayout(this);
        edgeHandle.setContentDescription(leftSide
                ? "Left SR Toolbox edge bar. Swipe to open when enabled; hold 2 seconds then drag to move."
                : "Right SR Toolbox edge bar. Swipe to open when enabled; hold 2 seconds then drag to move.");
        edgeHandle.setClickable(true);
        // Enables accessibility click actions in addition to physical swipe/tap.
        edgeHandle.setOnClickListener(v -> {
            // Accessibility click is a TAP and must obey the user's tap setting.
            if (SidebarInputPolicy.mayOpenFromTap(openOnTap(), openOnSwipe(), quickPanelEnabled())) revealQuickPanelFromEdge();
        });

        TextView strip = new TextView(this);
        strip.setText(edgeWidthDp <= 10 ? "" : (leftSide ? "›" : "‹"));
        strip.setTextColor(ThemeManager.isLight(this) ? Color.WHITE : Color.rgb(18, 23, 30));
        strip.setTextSize(Math.max(10f, Math.min(18f, edgeWidthDp)));
        strip.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        strip.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Ui.ACCENT);
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), Ui.TEXT);
        strip.setBackground(bg);
        int opacity = Math.max(30, Math.min(100, prefs.getInt("floating.opacity", 100)));
        strip.setAlpha(Math.max(0.65f, opacity / 100f));
        FrameLayout.LayoutParams stripLayout = new FrameLayout.LayoutParams(
                dp(touchWidthDp), FrameLayout.LayoutParams.MATCH_PARENT,
                leftSide ? Gravity.START : Gravity.END);
        edgeHandle.addView(strip, stripLayout);

        edgeParams = new WindowManager.LayoutParams(
                touchWidth, height,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        edgeParams.gravity = Gravity.TOP | Gravity.START;
        edgeParams.x = FloatingEdgeGeometry.x(leftSide, metrics.widthPixels, touchWidth);
        edgeParams.y = FloatingEdgeGeometry.y(centerY - height / 2,
                metrics.heightPixels, height, dp(8));

        edgeHandle.setOnTouchListener((view, event) -> handleEdgeGesture(event, leftSide));
        try {
            windowManager.addView(edgeHandle, edgeParams);
        } catch (Exception e) {
            edgeHandle = null;
            edgeParams = null;
            stopSelf();
        }
    }

    // Keep the touched overlay alive until release. Both open modes permit
    // moving the tab, but ONLY after a stationary two-second press then drag.
    private boolean handleEdgeGesture(MotionEvent event, boolean leftSide) {
        if (edgeParams == null) return true;
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                edgeTouchStartX = event.getRawX();
                edgeTouchStartY = event.getRawY();
                edgeTouchDownTime = event.getEventTime();
                edgeDownX = edgeParams.x;
                edgeDownY = edgeParams.y;
                edgeDockLeftDuringDrag = getSharedPreferences("tool_state", MODE_PRIVATE)
                        .getBoolean("floating.edge.left", leftSide);
                edgeMovedBeforeHold = false;
                edgeDragging = false;
                floatingTouchActive = true;
                beginHoldHaptic(true);
                cancelAutoHide();
                return true;
            case MotionEvent.ACTION_MOVE:
                float dx = event.getRawX() - edgeTouchStartX;
                float dy = event.getRawY() - edgeTouchStartY;
                long elapsed = Math.max(0L, event.getEventTime() - edgeTouchDownTime);
                if (FloatingOpenModeLogic.movedTooEarly(elapsed, dx, dy,
                        Math.max(touchSlop, dp(14)))) {
                    edgeMovedBeforeHold = true;
                    cancelHoldHaptic();
                }
                if (!edgeDragging && FloatingOpenModeLogic.startDrag(elapsed,
                        edgeMovedBeforeHold, dx, dy, Math.max(touchSlop, dp(14)))) {
                    edgeDragging = true;
                    markHoldHaptic();
                }
                if (edgeDragging) moveTouchedEdgeTab(dx, dy);
                return true;
            case MotionEvent.ACTION_UP:
                cancelHoldHaptic();
                float upDx = event.getRawX() - edgeTouchStartX;
                float upDy = event.getRawY() - edgeTouchStartY;
                long held = Math.max(0L, event.getEventTime() - edgeTouchDownTime);
                if (FloatingOpenModeLogic.movedTooEarly(held, upDx, upDy,
                        Math.max(touchSlop, dp(14)))) {
                    edgeMovedBeforeHold = true;
                }
                if (!edgeDragging && FloatingOpenModeLogic.startDrag(held,
                        edgeMovedBeforeHold, upDx, upDy, Math.max(touchSlop, dp(14)))) {
                    edgeDragging = true;
                    markHoldHaptic();
                }
                floatingTouchActive = false;
                if (edgeDragging) {
                    moveTouchedEdgeTab(upDx, upDy);
                    finishEdgeTabDrag();
                } else if (FloatingOpenModeLogic.shouldOpen(
                        SidebarInputPolicy.mayOpenFromTap(openOnTap(), openOnSwipe(), quickPanelEnabled()),
                        openOnSwipe(), quickPanelEnabled(), false, edgeMovedBeforeHold, held,
                        upDx, upDy, Math.max(dp(10), touchSlop), dp(18))) {
                    // A swipe is not a tap: the swipe toggle remains independent.
                    if (edgeMovedBeforeHold && (FloatingBarGestureLogic.edgeSwipe(upDx, upDy,
                            dp(18)) || EdgeSwipeLogic.isInwardSwipe(leftSide, upDx, upDy, dp(18)))) {
                        SwipeHaptics.onSwipeMenuOpen(this);
                        revealQuickPanelFromEdge();
                    } else if (!edgeMovedBeforeHold && edgeHandle != null) {
                        edgeHandle.performClick();
                    }
                } else {
                    scheduleAutoHide();
                }
                edgeDragging = false;
                edgeMovedBeforeHold = false;
                return true;
            case MotionEvent.ACTION_CANCEL:
                cancelHoldHaptic();
                floatingTouchActive = false;
                if (edgeDragging) finishEdgeTabDrag();
                edgeDragging = false;
                edgeMovedBeforeHold = false;
                return true;
            default:
                return true;
        }
    }

    private void moveTouchedEdgeTab(float dx, float dy) {
        if (edgeHandle == null || edgeParams == null) return;
        DisplayMetrics screen = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(screen);
        // The collapsed sidebar is border-flush in BOTH portrait and landscape.
        // A 2-second hold may move it vertically or switch sides, not leave it
        // floating in the middle of the display.
        edgeDockLeftDuringDrag = FloatingEdgeGeometry.leftForDrop(
                edgeTouchStartX + dx, screen.widthPixels);
        edgeParams.x = FloatingEdgeGeometry.x(edgeDockLeftDuringDrag,
                screen.widthPixels, edgeParams.width);
        edgeParams.y = FloatingEdgeGeometry.y(edgeDownY + (int) dy,
                screen.heightPixels, edgeParams.height, dp(8));
        try { windowManager.updateViewLayout(edgeHandle, edgeParams); }
        catch (RuntimeException ignored) { }
    }

    private void finishEdgeTabDrag() {
        if (edgeParams == null) return;
        DisplayMetrics screen = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(screen);
        int centerX = edgeParams.x + edgeParams.width / 2;
        int centerY = edgeParams.y + edgeParams.height / 2;
        boolean left = centerX < screen.widthPixels / 2;
        int bubbleSize = dp(Math.max(24, Math.min(76,
                getSharedPreferences("tool_state", MODE_PRIVATE).getInt("floating.size", 54))));
        int savedX = Math.max(0, Math.min(screen.widthPixels - bubbleSize,
                centerX - bubbleSize / 2));
        int savedY = Math.max(0, Math.min(screen.heightPixels - bubbleSize,
                centerY - bubbleSize / 2));
        getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                .putBoolean("floating.edge.left", left)
                .putInt("floating.edge.y", centerY)
                .putFloat(EDGE_CENTER_FRACTION,
                        FloatingEdgeGeometry.centerFraction(centerY, screen.heightPixels))
                .putInt("floating.x", savedX)
                .putInt("floating.y", savedY)
                .putBoolean(FloatingBoundaryPolicy.PREF_MANUAL_POSITION, false)
                .putBoolean(GLOBAL_EDGE_MOVED, false)
                .putBoolean("floating.auto_hidden", true).apply();
        // Rebuild only after ACTION_UP to avoid losing the touch sequence.
        // Keep the collapsed VERTICAL tab at the selected border in every
        // display orientation, including after later rotations and app changes.
        removeEdgeHandle();
        autoHidden = true;
        showEdgeHandle(left, centerY);
    }

    private void revealQuickPanelFromEdge() {
        if (!quickPanelEnabled()) return;
        restoreBubbleFromEdge(true);
        // Some OEMs cancel the 270ms reveal animation while updating an overlay.
        // Retry once without capturing touches from any underlying application.
        if (pendingGestureOpenFallback != null) {
            gestureFallbackHandler.removeCallbacks(pendingGestureOpenFallback);
        }
        pendingGestureOpenFallback = () -> {
            pendingGestureOpenFallback = null;
            android.content.SharedPreferences prefs = getSharedPreferences("tool_state", MODE_PRIVATE);
            if (quickPanelEnabled() && hasOverlayPermission(this)
                    && prefs.getBoolean("floating.enabled", true)
                    && !prefs.getBoolean("floating.hidden", false)
                    && panel == null && bubble != null && bubbleParams != null) {
                cancelBubbleRevealAnimation();
                showPanel();
            }
        };
        gestureFallbackHandler.postDelayed(pendingGestureOpenFallback, 500L);
    }

    private void restoreBubbleFromEdge(boolean openPanel) {
        cancelAutoHide();
        android.content.SharedPreferences prefs = getSharedPreferences("tool_state", MODE_PRIVATE);
        boolean leftSide = prefs.getBoolean("floating.edge.left", false);
        DisplayMetrics restored = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(restored);
        int edgeCenterY = FloatingEdgeGeometry.centerForFraction(
                prefs.getFloat(EDGE_CENTER_FRACTION,
                        FloatingEdgeGeometry.centerFraction(prefs.getInt("floating.edge.y",
                                restored.heightPixels / 3), restored.heightPixels)),
                restored.heightPixels);
        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(metrics);
        int sizePx = dp(Math.max(24, Math.min(76, prefs.getInt("floating.size", 54))));
        int bubbleX = EdgeSwipeLogic.bubbleXForSide(
                leftSide, metrics.widthPixels, sizePx, dp(5));
        int bubbleY = Math.max(0, Math.min(metrics.heightPixels - sizePx, edgeCenterY - sizePx / 2));
        // Manual move retains its last explicitly chosen coordinates. Idle mode
        // only collapses the icon into a slim vertical edge bar temporarily.
        if (manuallyPositioned()) {
            bubbleX = Math.max(0, Math.min(metrics.widthPixels - sizePx,
                    prefs.getInt("floating.x", bubbleX)));
            bubbleY = Math.max(0, Math.min(metrics.heightPixels - sizePx,
                    prefs.getInt("floating.y", bubbleY)));
        }
        prefs.edit().putBoolean("floating.auto_hidden", false)
                .putInt("floating.x", bubbleX).putInt("floating.y", bubbleY).apply();
        removeEdgeHandle();
        autoHidden = false;
        ensureBubble();
        animateBubbleFromEdge(leftSide, bubbleX, openPanel);
    }

    // The icon itself slides in from the edge; then the Quick Panel fades/slides in.
    // This animation is visual only and does not alter stored icon coordinates.
    private void animateBubbleFromEdge(boolean leftSide, int targetX, boolean openPanel) {
        cancelBubbleRevealAnimation();
        if (bubble == null || bubbleParams == null) return;
        cancelAutoHide();
        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(metrics);
        final int initialX = BubbleSlideLogic.revealStartX(
                leftSide, metrics.widthPixels, bubbleParams.width);
        final int endX = targetX;
        final float finalAlpha = Math.max(0.3f, Math.min(1f,
                getSharedPreferences("tool_state", MODE_PRIVATE)
                        .getInt("floating.opacity", 100) / 100f));
        bubbleParams.x = initialX;
        bubble.setAlpha(finalAlpha * 0.45f);
        bubble.setScaleX(0.78f);
        bubble.setScaleY(0.78f);
        try { windowManager.updateViewLayout(bubble, bubbleParams); }
        catch (RuntimeException ignored) { /* The icon may already have been removed. */ }

        ValueAnimator animator = ValueAnimator.ofFloat(0f, 1f);
        bubbleRevealAnimator = animator;
        animator.setDuration(270L);
        animator.setInterpolator(new DecelerateInterpolator());
        animator.addUpdateListener(animation -> {
            if (bubbleRevealAnimator != animator || bubble == null || bubbleParams == null) return;
            float fraction = (Float) animation.getAnimatedValue();
            bubbleParams.x = BubbleSlideLogic.interpolate(initialX, endX, fraction);
            bubble.setAlpha(BubbleSlideLogic.alpha(finalAlpha * 0.45f, finalAlpha, fraction));
            float scale = 0.78f + 0.22f * fraction;
            bubble.setScaleX(scale);
            bubble.setScaleY(scale);
            try { windowManager.updateViewLayout(bubble, bubbleParams); }
            catch (RuntimeException ignored) { /* Overlay was closed while animating. */ }
        });
        animator.addListener(new AnimatorListenerAdapter() {
            private boolean cancelled;
            @Override public void onAnimationCancel(Animator animation) { cancelled = true; }
            @Override public void onAnimationEnd(Animator animation) {
                if (bubbleRevealAnimator == animator) bubbleRevealAnimator = null;
                if (cancelled || bubble == null || bubbleParams == null) return;
                bubbleParams.x = endX;
                bubble.setScaleX(1f);
                bubble.setScaleY(1f);
                bubble.setAlpha(finalAlpha);
                try { windowManager.updateViewLayout(bubble, bubbleParams); }
                catch (RuntimeException ignored) { return; }
                if (openPanel && getSharedPreferences("tool_state", MODE_PRIVATE)
                        .getBoolean("floating.panel.enabled", true)) {
                    showPanel();
                } else {
                    scheduleAutoHide();
                }
            }
        });
        animator.start();
    }

    private void cancelBubbleRevealAnimation() {
        ValueAnimator running = bubbleRevealAnimator;
        bubbleRevealAnimator = null;
        if (running != null) running.cancel();
        if (bubble != null && bubbleParams != null) {
            bubble.setScaleX(1f);
            bubble.setScaleY(1f);
            int opacity = Math.max(30, Math.min(100,
                    getSharedPreferences("tool_state", MODE_PRIVATE)
                            .getInt("floating.opacity", 100)));
            bubble.setAlpha(opacity / 100f);
        }
    }

    private void removeEdgeHandle() {
        if (edgeHandle != null) {
            try { windowManager.removeView(edgeHandle); } catch (Exception ignored) {}
            edgeHandle = null;
            edgeParams = null;
        }
    }

    private void showPanel() {
        // A successful menu opening cancels the one-shot animation fallback,
        // preventing a recently closed panel from being reopened unexpectedly.
        if (pendingGestureOpenFallback != null) {
            gestureFallbackHandler.removeCallbacks(pendingGestureOpenFallback);
            pendingGestureOpenFallback = null;
        }
        cancelAutoHide();
        removePanel();
        if (bubble == null || bubbleParams == null) return;

        GradientDrawable background = new GradientDrawable();
        if (Ui.isPremium()) {
            background.setOrientation(GradientDrawable.Orientation.TL_BR);
            background.setColors(new int[]{Ui.shade(Ui.CARD, Ui.ACCENT, .11f), Ui.CARD,
                    Ui.shade(Ui.CARD, Ui.CARD_2, .50f)});
        } else background.setColor(Ui.CARD);
        background.setCornerRadius(dp(Ui.isPremium() ? 23 : 18));
        background.setStroke(dp(1), Ui.isPremium() ? Ui.shade(Ui.ACCENT, Ui.CARD_2, .43f) : Ui.MUTED);
        UiSound.play(this, UiSound.NAVIGATE);
        UiHaptics.click(this);

        android.content.SharedPreferences panelSizePrefs =
                getSharedPreferences("tool_state", MODE_PRIVATE);
        int requestedToolboxWidthDp = ToolboxPanelSize.clampWidthDp(
                panelSizePrefs.getInt("floating.toolbox.width_dp", ToolboxPanelSize.DEFAULT_WIDTH_DP));
        int requestedToolboxHeightDp = ToolboxPanelSize.clampHeightDp(
                panelSizePrefs.getInt("floating.toolbox.height_dp", ToolboxPanelSize.DEFAULT_HEIGHT_DP));

        panel = new ScrollView(this) {
            @Override public boolean dispatchTouchEvent(MotionEvent event) {
                if (event.getActionMasked() == MotionEvent.ACTION_OUTSIDE) {
                    dismissPanelFromOutsideTouch();
                    return true;
                }
                return super.dispatchTouchEvent(event);
            }

            @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
                int screenHeight = getResources().getDisplayMetrics().heightPixels;
                int maxHeight = ToolboxPanelSize.fitToScreenPx(
                        dp(requestedToolboxHeightDp), screenHeight, dp(16));
                int limitedHeightSpec = View.MeasureSpec.makeMeasureSpec(
                        maxHeight, View.MeasureSpec.AT_MOST);
                super.onMeasure(widthMeasureSpec, limitedHeightSpec);
                setMeasuredDimension(getMeasuredWidth(), CompactControlMath.panelHeight(
                        getMeasuredHeight(), maxHeight, screenHeight, dp(8)));
            }
        };
        panel.setFillViewport(false);
        panel.setVerticalScrollBarEnabled(true);
        panel.setClipToPadding(true);
        panel.setClipChildren(true);
        panel.setOverScrollMode(View.OVER_SCROLL_NEVER);
        panel.setBackground(background);
        // Clip everything (including partially visible last rows) to rounded bounds.
        panel.setClipToOutline(true);
        panel.setElevation(dp(12));
        panel.setOnTouchListener((view, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                cancelPanelAutoClose();
            } else if (event.getAction() == MotionEvent.ACTION_UP
                    || event.getAction() == MotionEvent.ACTION_CANCEL) {
                schedulePanelAutoClose();
            }
            return false;
        });
        panelContent = new LinearLayout(this);
        panelContent.setOrientation(LinearLayout.VERTICAL);
        panelContent.setPadding(dp(7), dp(7), dp(7), dp(7));
        panelContent.setClipChildren(true);
        panelContent.setClipToPadding(true);
        panel.addView(panelContent, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));

        // Fallback close control remains in the header; normally quick controls dismiss automatically.
        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("SR SMART TOOLBOX");
        title.setTextColor(Ui.ACCENT);
        title.setTextSize(13);
        title.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        titleRow.addView(title, new LinearLayout.LayoutParams(0, -2, 1));

        TextView close = new TextView(this);
        close.setText("×");
        close.setTextColor(Ui.TEXT);
        close.setTextSize(24);
        close.setGravity(Gravity.CENTER);
        close.setContentDescription("Close quick controls");
        close.setBackground(makePanelActionBackground());
        LinearLayout.LayoutParams closeParams = new LinearLayout.LayoutParams(dp(31), dp(30));
        titleRow.addView(close, closeParams);
        close.setOnClickListener(v -> {
            removePanel();
            scheduleAutoHide();
        });
        panelContent.addView(titleRow);

        // No instructional subtitle: every pixel is reserved for compact controls.
        final boolean compact = requestedToolboxHeightDp <= 350 || requestedToolboxWidthDp <= 260;

        android.content.SharedPreferences toolPrefs =
                getSharedPreferences("tool_state", MODE_PRIVATE);
        boolean night = getSharedPreferences("night", MODE_PRIVATE).getBoolean("active", false);
        boolean thermal = toolPrefs.getBoolean("thermal.active", false);
        boolean masterOn = toolPrefs.getBoolean("audio.master.enabled",
                toolPrefs.getBoolean("audio.active", false));
        boolean scanner = toolPrefs.getBoolean("scanner.active", false);

        // Entire colored bar: tap toggles feature; horizontal swipe changes its level.
        int nightLevel = Math.max(0, Math.min(95,
                getSharedPreferences("night", MODE_PRIVATE).getInt("level", 60)));
        addCompactLevelControl("Night Screen", night, nightLevel, 95,
                value -> value + "%", this::toggleNight,
                this::scheduleNightLevelUpdate, this::flushNightLevelUpdate, compact);

        thermalReadout = addCompactToggleControl("Thermal", thermal, this::toggleThermal, compact);
        updateThermalReadout();

        int audioGain = Math.max(0, Math.min(1000, toolPrefs.getInt("audio.gain", 400)));
        addCompactLevelControl("Volume Boost", masterOn, audioGain, 1000,
                value -> String.format(java.util.Locale.getDefault(), "+%.1f dB", value / 100f),
                this::toggleAudio, this::scheduleAudioGainUpdate,
                this::flushAudioGainUpdate, compact);
        // Phone's native volume +/- is independent of the extra boost gain.
        addNativeMediaVolumeControls(panelContent, compact);

        addCompactActionToPanel("▦  QR / Barcode Scanner", this::toggleScanner, compact);

        // No separate bottom settings / hide / cancel actions are rendered.
        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(metrics);
        int panelWidth = ToolboxPanelSize.fitToScreenPx(
                dp(requestedToolboxWidthDp), metrics.widthPixels, dp(6));
        int maxPanelHeight = ToolboxPanelSize.fitToScreenPx(
                dp(requestedToolboxHeightDp), metrics.heightPixels, dp(16));
        panelParams = new WindowManager.LayoutParams(
                panelWidth, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.START;
        int maxX = Math.max(0, metrics.widthPixels - panelWidth);
        panelParams.x = Math.max(0, Math.min(maxX,
                bubbleParams.x - panelWidth + bubbleParams.width));
        panelParams.y = ToolboxPanelSize.clampTopY(
                bubbleParams.y, metrics.heightPixels, maxPanelHeight, dp(8));
        try {
            windowManager.addView(panel, panelParams);
            boolean opensFromLeft = bubbleParams.x + bubbleParams.width / 2
                    < metrics.widthPixels / 2;
            panel.setAlpha(0f);
            panel.setTranslationX(opensFromLeft ? -dp(26) : dp(26));
            panel.animate().alpha(1f).translationX(0f).setDuration(200L)
                    .setInterpolator(new DecelerateInterpolator()).start();
            scheduleThermalReadout();
            schedulePanelAutoClose();
        } catch (Exception e) {
            panel = null;
            panelContent = null;
            panelParams = null;
            thermalReadout = null;
        }
    }

    private GradientDrawable makePanelActionBackground() {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Ui.CARD_2);
        bg.setCornerRadius(dp(9));
        return bg;
    }

    private interface LevelCallback { void apply(int level); }

    private void addCompactRow(View row) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(5);
        panelContent.addView(row, params);
    }

    private void addCompactLevelControl(String title, boolean enabled, int level, int maxLevel,
            CompactFeatureBar.ValueFormatter formatter, Runnable toggle,
            LevelCallback changed, LevelCallback released, boolean compact) {
        CompactFeatureBar bar = new CompactFeatureBar(this, title, enabled,
                level, maxLevel, true, compact ? 39 : 45, formatter);
        bar.setListener(new CompactFeatureBar.Listener() {
            @Override public void onToggle() { toggle.run(); }
            @Override public void onLevelChanged(int value) { changed.apply(value); }
            @Override public void onLevelReleased(int value) { released.apply(value); }
            @Override public void onInteractionStart() { cancelPanelAutoClose(); }
            @Override public void onInteractionEnd() { schedulePanelAutoClose(); }
        });
        addCompactRow(bar);
    }

    private CompactFeatureBar addCompactToggleControl(String title, boolean enabled,
                                                       Runnable toggle, boolean compact) {
        CompactFeatureBar bar = new CompactFeatureBar(this, title, enabled,
                0, 1, false, compact ? 39 : 45, value -> "");
        bar.setListener(new CompactFeatureBar.Listener() {
            @Override public void onToggle() { toggle.run(); }
            @Override public void onLevelChanged(int value) { }
            @Override public void onLevelReleased(int value) { }
            @Override public void onInteractionStart() { cancelPanelAutoClose(); }
            @Override public void onInteractionEnd() { schedulePanelAutoClose(); }
        });
        addCompactRow(bar);
        return bar;
    }

    private void addCompactActionToPanel(String label, Runnable action, boolean compact) {
        TextView row = new TextView(this);
        row.setText(label + "    ›");
        row.setTextColor(Ui.TEXT);
        row.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        row.setTextSize(compact ? 12 : 13);
        row.setPadding(dp(12), 0, dp(10), 0);
        row.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Ui.CARD_2);
        bg.setCornerRadius(dp(Ui.isPremium() ? 15 : 11));
        bg.setStroke(dp(1), Ui.isPremium() ? Ui.shade(Ui.ACCENT, Ui.CARD_2, .55f) : Ui.MUTED);
        row.setBackground(bg);
        row.setContentDescription(label + ", open");
        row.setOnTouchListener((view, event) -> {
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) cancelPanelAutoClose();
            return false;
        });
        row.setOnClickListener(v -> {
            UiSound.play(this, UiSound.TAP);
            UiHaptics.click(this);
            action.run();
            schedulePanelAutoClose();
        });
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                -1, dp(compact ? 34 : 39));
        params.topMargin = dp(5);
        panelContent.addView(row, params);
    }

    private void addNativeMediaVolumeControls(LinearLayout card, boolean compact) {
        AudioManager audio = (AudioManager) getSystemService(AUDIO_SERVICE);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(-1, -2);
        rowParams.topMargin = dp(3);

        TextView level = new TextView(this);
        level.setTextColor(Ui.MUTED);
        level.setTextSize(compact ? 10 : 11);
        level.setText(getNativeVolumeText(audio));
        row.addView(level, new LinearLayout.LayoutParams(0, dp(compact ? 30 : 32), 1));
        level.setGravity(Gravity.CENTER_VERTICAL);

        TextView minus = makeNativeVolumeButton("−", "Decrease phone media volume");
        TextView plus = makeNativeVolumeButton("+", "Increase phone media volume");
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(
                dp(compact ? 34 : 38), dp(compact ? 30 : 32));
        buttonParams.rightMargin = dp(6);
        row.addView(minus, buttonParams);
        row.addView(plus, new LinearLayout.LayoutParams(
                dp(compact ? 34 : 38), dp(compact ? 30 : 32)));
        minus.setOnClickListener(v -> adjustNativeMediaVolume(audio, AudioManager.ADJUST_LOWER, level));
        plus.setOnClickListener(v -> adjustNativeMediaVolume(audio, AudioManager.ADJUST_RAISE, level));
        card.addView(row, rowParams);
    }

    private TextView makeNativeVolumeButton(String symbol, String description) {
        TextView button = new TextView(this);
        button.setText(symbol);
        button.setTextSize(17);
        button.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        button.setTextColor(Ui.TEXT);
        button.setGravity(Gravity.CENTER);
        button.setBackground(makePanelActionBackground());
        button.setContentDescription(description);
        button.setOnTouchListener((view, event) -> {
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) cancelPanelAutoClose();
            return false;
        });
        return button;
    }

    private String getNativeVolumeText(AudioManager audio) {
        if (audio == null) return "Phone media volume unavailable";
        return "Phone media " + audio.getStreamVolume(AudioManager.STREAM_MUSIC)
                + "/" + audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
    }

    private void adjustNativeMediaVolume(AudioManager audio, int direction, TextView level) {
        if (audio == null) {
            level.setText("Phone media volume unavailable");
        } else if (audio.isVolumeFixed()) {
            level.setText("This phone has fixed media volume");
        } else {
            try {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, 0);
                level.setText(getNativeVolumeText(audio));
            } catch (SecurityException | IllegalArgumentException error) {
                level.setText("Media volume cannot be changed here");
            }
        }
        schedulePanelAutoClose();
    }

    private void scheduleNightLevelUpdate(int level) {
        getSharedPreferences("night", MODE_PRIVATE).edit().putInt("level", level).apply();
        if (!getSharedPreferences("night", MODE_PRIVATE).getBoolean("active", false)) return;
        if (pendingNightUpdate != null) sliderHandler.removeCallbacks(pendingNightUpdate);
        pendingNightUpdate = () -> {
            pendingNightUpdate = null;
            applyNightLevel(level);
        };
        sliderHandler.postDelayed(pendingNightUpdate, 120);
    }

    private void flushNightLevelUpdate(int level) {
        getSharedPreferences("night", MODE_PRIVATE).edit().putInt("level", level).apply();
        if (pendingNightUpdate != null) sliderHandler.removeCallbacks(pendingNightUpdate);
        pendingNightUpdate = null;
        if (getSharedPreferences("night", MODE_PRIVATE).getBoolean("active", false)) {
            applyNightLevel(level);
        }
    }

    private void applyNightLevel(int level) {
        android.content.SharedPreferences prefs = getSharedPreferences("night", MODE_PRIVATE);
        Intent update = new Intent(this, DimOverlayService.class);
        update.putExtra("level", Math.max(0, Math.min(95, level)));
        update.putExtra("warm", prefs.getBoolean("warm", false));
        ContextCompat.startForegroundService(this, update);
    }

    private void scheduleAudioGainUpdate(int gain) {
        getSharedPreferences("tool_state", MODE_PRIVATE).edit().putInt("audio.gain", gain).apply();
        if (!getSharedPreferences("tool_state", MODE_PRIVATE)
                .getBoolean("audio.master.enabled", false)) return;
        if (pendingAudioUpdate != null) sliderHandler.removeCallbacks(pendingAudioUpdate);
        pendingAudioUpdate = () -> {
            pendingAudioUpdate = null;
            applyAudioGain(gain);
        };
        sliderHandler.postDelayed(pendingAudioUpdate, 120);
    }

    private void flushAudioGainUpdate(int gain) {
        getSharedPreferences("tool_state", MODE_PRIVATE).edit().putInt("audio.gain", gain).apply();
        if (pendingAudioUpdate != null) sliderHandler.removeCallbacks(pendingAudioUpdate);
        pendingAudioUpdate = null;
        if (getSharedPreferences("tool_state", MODE_PRIVATE)
                .getBoolean("audio.master.enabled", false)) {
            applyAudioGain(gain);
        }
    }

    private void applyAudioGain(int gain) {
        Intent update = new Intent(this, SystemAudioBoostService.class);
        update.setAction(SystemAudioBoostService.ACTION_UPDATE);
        update.putExtra(SystemAudioBoostService.EXTRA_GAIN_MB, Math.max(0, Math.min(1000, gain)));
        ContextCompat.startForegroundService(this, update);
    }

    private void updateThermalReadout() {
        if (thermalReadout == null) return;
        android.content.SharedPreferences prefs = getSharedPreferences("tool_state", MODE_PRIVATE);
        if (!prefs.getBoolean("thermal.active", false)) {
            thermalReadout.setInfo("");
        } else {
            String battery = prefs.getString("thermal.battery", "-- °C");
            thermalReadout.setInfo(battery == null ? "-- °C"
                    : battery.replace("Battery temperature", "").replace("Battery", "").trim());
        }
    }

    private void scheduleThermalReadout() {
        if (thermalReadoutRunnable != null) {
            sliderHandler.removeCallbacks(thermalReadoutRunnable);
        }
        thermalReadoutRunnable = () -> {
            if (thermalReadout == null || panel == null) return;
            updateThermalReadout();
            sliderHandler.postDelayed(thermalReadoutRunnable, 1500L);
        };
        sliderHandler.postDelayed(thermalReadoutRunnable, 1500L);
    }

    private void toggleNight() {
        android.content.SharedPreferences prefs = getSharedPreferences("night", MODE_PRIVATE);
        boolean active = prefs.getBoolean("active", false);
        Intent intent = new Intent(this, DimOverlayService.class);
        if (active) {
            intent.setAction(DimOverlayService.ACTION_STOP);
            startService(intent);
            prefs.edit().putBoolean("active", false).apply();
        } else {
            int level = prefs.getInt("level", 60);
            boolean warm = prefs.getBoolean("warm", false);
            intent.putExtra("level", level);
            intent.putExtra("warm", warm);
            prefs.edit().putBoolean("active", true).apply();
            ContextCompat.startForegroundService(this, intent);
            FloatingControlService.start(this);
        }
        showPanel();
    }

    private void toggleThermal() {
        boolean active = getSharedPreferences("tool_state", MODE_PRIVATE)
                .getBoolean("thermal.active", false);
        Intent intent = new Intent(this, ThermalMonitorService.class);
        if (active) {
            intent.setAction(ThermalMonitorService.ACTION_STOP);
            getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                    .putBoolean("thermal.active", false).apply();
            startService(intent);
        } else {
            getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                    .putBoolean("thermal.active", true).apply();
            ContextCompat.startForegroundService(this, intent);
        }
        showPanel();
    }

    private void toggleAudio() {
        android.content.SharedPreferences prefs =
                getSharedPreferences("tool_state", MODE_PRIVATE);
        boolean masterOn = prefs.getBoolean("audio.master.enabled",
                prefs.getBoolean("audio.active", false));
        Intent control = new Intent(this, SystemAudioBoostService.class);
        if (masterOn) {
            prefs.edit().putBoolean("audio.master.enabled", false).apply();
            control.setAction(SystemAudioBoostService.ACTION_MASTER_OFF);
            startService(control);
        } else {
            prefs.edit().putBoolean("audio.master.enabled", true).apply();
            control.setAction(SystemAudioBoostService.ACTION_MASTER_ON);
            control.putExtra(SystemAudioBoostService.EXTRA_GAIN_MB,
                    prefs.getInt("audio.gain", 400));
            ContextCompat.startForegroundService(this, control);
        }
        showPanel();
    }

    private void toggleScanner() {
        boolean active = getSharedPreferences("tool_state", MODE_PRIVATE)
                .getBoolean("scanner.active", false);
        if (active) {
            Intent close = new Intent(this, MainActivity.class);
            close.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP
                    | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(close);
        } else {
            Intent open = new Intent(this, BarcodeScannerActivity.class);
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            startActivity(open);
        }
        removePanel();
        scheduleAutoHide();
    }

    private void openFloatingSettings() {
        removePanel();
        scheduleAutoHide();
        Intent open = new Intent(this, FloatingIconSettingsActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(open);
    }

    private void hideBubble() {
        cancelAutoHide();
        getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                .putBoolean("floating.hidden", true)
                .putBoolean("floating.enabled", false)
                .putBoolean("floating.auto_hidden", false).apply();
        removePanelAndBubble();
        getSharedPreferences("tool_state", MODE_PRIVATE).edit()
                .putBoolean(GLOBAL_EDGE_MOVED, false).apply();
        stopForeground(true);
        stopSelf();
    }

    private void removePanel() {
        cancelPanelAutoClose();
        if (thermalReadoutRunnable != null) {
            sliderHandler.removeCallbacks(thermalReadoutRunnable);
            thermalReadoutRunnable = null;
        }
        thermalReadout = null;
        if (panel != null) {
            panel.animate().cancel();
            try { windowManager.removeView(panel); } catch (Exception ignored) {}
            panel = null;
            panelContent = null;
            panelParams = null;
        }
    }

    private void removePanelAndBubble() {
        cancelBubbleRevealAnimation();
        cancelAutoHide();
        removePanel();
        removeEdgeHandle();
        autoHidden = false;
        if (bubble != null) {
            try { windowManager.removeView(bubble); } catch (Exception ignored) {}
            bubble = null;
            bubbleParams = null;
        }
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "Floating controls", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Keeps the user-enabled SR Smart Toolbox floating sidebar available, even when no tool is active.");
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        return builder.setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("SR Smart Toolbox floating control")
                .setContentText("Tap the edge tab or ST bubble for quick controls.")
                .setOngoing(true)
                .build();
    }

    @Override public void onDestroy() {
        gestureFallbackHandler.removeCallbacksAndMessages(null);
        pendingGestureOpenFallback = null;
        portraitMonitorHandler.removeCallbacksAndMessages(null);
        if (portraitDisplayManager != null) {
            try { portraitDisplayManager.unregisterDisplayListener(portraitDisplayListener); }
            catch (Exception ignored) { }
        }
        if (pendingNightUpdate != null) sliderHandler.removeCallbacks(pendingNightUpdate);
        if (pendingAudioUpdate != null) sliderHandler.removeCallbacks(pendingAudioUpdate);
        if (thermalReadoutRunnable != null) sliderHandler.removeCallbacks(thermalReadoutRunnable);
        cancelAutoHide();
        cancelPanelAutoClose();
        cancelHoldHaptic();
        removePanelAndBubble();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
