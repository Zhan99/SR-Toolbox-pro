package com.smarttoolbox.pro;

/** Screen-safe sizing for the floating quick toolbox panel, independent of icon size. */
final class ToolboxPanelSize {
    static final int MIN_WIDTH_DP = 176;
    static final int MAX_WIDTH_DP = 440;
    static final int DEFAULT_WIDTH_DP = 292;
    static final int MIN_HEIGHT_DP = 185;
    static final int MAX_HEIGHT_DP = 760;
    static final int DEFAULT_HEIGHT_DP = 580;

    private ToolboxPanelSize() {}

    static int clampWidthDp(int widthDp) {
        return Math.max(MIN_WIDTH_DP, Math.min(MAX_WIDTH_DP, widthDp));
    }

    static int clampHeightDp(int heightDp) {
        return Math.max(MIN_HEIGHT_DP, Math.min(MAX_HEIGHT_DP, heightDp));
    }

    static int fitToScreenPx(int requestedPx, int screenPx, int marginPx) {
        int available = Math.max(1, screenPx - 2 * Math.max(0, marginPx));
        return Math.max(1, Math.min(Math.max(1, requestedPx), available));
    }

    static int clampTopY(int requestedTopPx, int screenHeightPx, int panelMaxHeightPx, int marginPx) {
        int margin = Math.max(0, marginPx);
        int lastTop = Math.max(margin, screenHeightPx - panelMaxHeightPx - margin);
        return Math.max(margin, Math.min(lastTop, requestedTopPx));
    }
}
