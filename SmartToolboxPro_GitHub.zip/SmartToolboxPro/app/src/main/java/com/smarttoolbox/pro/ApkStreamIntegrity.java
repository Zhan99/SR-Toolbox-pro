package com.smarttoolbox.pro;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.MessageDigest;

/** Tested byte-for-byte stream copy and SHA-256 helpers; no re-signing or APK edits. */
final class ApkStreamIntegrity {
    static final class Result {
        final long bytes;
        final String sha256;
        Result(long bytes, String sha256) { this.bytes=bytes;this.sha256=sha256; }
    }
    private ApkStreamIntegrity() { }
    static Result copy(InputStream source,OutputStream dest) throws IOException {
        if(source==null || dest==null)throw new IOException("Stream unavailable");
        MessageDigest digest=digest();long written=0;int n;byte[] block=new byte[65536];
        while((n=source.read(block))!=-1){
            dest.write(block,0,n);digest.update(block,0,n);written+=n;
        }
        return new Result(written,hex(digest.digest()));
    }
    static String sha256(InputStream source) throws IOException {
        if(source==null)throw new IOException("APK stream unavailable");
        MessageDigest digest=digest();int n;byte[] block=new byte[65536];
        while((n=source.read(block))!=-1)digest.update(block,0,n);
        return hex(digest.digest());
    }
    private static MessageDigest digest() {
        try{return MessageDigest.getInstance("SHA-256");}
        catch(Exception error){throw new IllegalStateException(error);}
    }
    private static String hex(byte[] data){
        StringBuilder result=new StringBuilder(data.length*2);
        for(byte b:data)result.append(String.format(java.util.Locale.ROOT,"%02x",b&255));
        return result.toString();
    }
}
