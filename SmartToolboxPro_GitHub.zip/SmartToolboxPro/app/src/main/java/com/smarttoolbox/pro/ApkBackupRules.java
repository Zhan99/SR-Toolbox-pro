package com.smarttoolbox.pro;

import java.util.Comparator;
import java.util.Locale;

/** Pure JVM rules for archive names, duplicate identity, and list ordering. */
final class ApkBackupRules {
    static final String[] SORT_LABELS = {
            "Name A → Z", "Name Z → A", "Date: Oldest", "Date: Newest",
            "Size: Smallest", "Size: Largest", "Not Installed First", "Not Archived First"
    };
    private ApkBackupRules() {}

    static String safePart(String s) {
        if (s == null) return "unknown";
        String safe = s.replaceAll("[^a-zA-Z0-9._-]", "_")
                .replaceAll("\\.\\.+", "_");
        while (safe.startsWith(".")) safe = safe.substring(1);
        if (safe.isEmpty()) safe = "unknown";
        return safe.length() > 100 ? safe.substring(0, 100) : safe;
    }

    static String archiveFolder(String packageName, long versionCode, long stamp) {
        return safePart(packageName) + "__" + versionCode + "__" + stamp;
    }

    static boolean validArchivePart(String relative) {
        return "base.apk".equals(relative) || (relative != null
                && !relative.contains("..")
                && relative.matches("splits/[a-zA-Z0-9._-]+\\.apk"));
    }

    static boolean duplicate(String pkg1, long ver1, String digest1,
                             String pkg2, long ver2, String digest2) {
        return pkg1 != null && pkg1.equals(pkg2) && ver1 == ver2
                && digest1 != null && !digest1.isEmpty()
                && digest1.equalsIgnoreCase(digest2);
    }

    static int compare(int sort, String nameA, String nameB,
                       long dateA, long dateB, long sizeA, long sizeB,
                       boolean installedA, boolean installedB,
                       boolean archivedA, boolean archivedB) {
        int value;
        switch (sort) {
            case 0: value = nameA.compareToIgnoreCase(nameB); break;
            case 1: value = nameB.compareToIgnoreCase(nameA); break;
            case 2: value = Long.compare(dateA, dateB); break;
            case 3: value = Long.compare(dateB, dateA); break;
            case 4: value = Long.compare(sizeA, sizeB); break;
            case 5: value = Long.compare(sizeB, sizeA); break;
            case 6: value = Boolean.compare(installedA, installedB); break;
            case 7: value = Boolean.compare(archivedA, archivedB); break;
            default: value = nameA.compareToIgnoreCase(nameB); break;
        }
        return value == 0 ? nameA.compareToIgnoreCase(nameB) : value;
    }
}
