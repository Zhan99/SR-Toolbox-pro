package com.smarttoolbox.pro;

/** Stateless input/size math for compact floating controls, testable without Android. */
final class CompactControlMath {
    private CompactControlMath() { }

    static int levelFromTouch(float x, int width, int inset, int maxLevel) {
        int usable = Math.max(1, width - Math.max(0, inset) * 2);
        float fraction = (x - Math.max(0, inset)) / usable;
        return Math.max(0, Math.min(Math.max(0, maxLevel),
                Math.round(fraction * Math.max(0, maxLevel))));
    }

    static boolean isHorizontalDrag(float dx, float dy, int slop) {
        return Math.abs(dx) > Math.max(0, slop) && Math.abs(dx) > Math.abs(dy) * 1.15f;
    }

    static int panelHeight(int measuredHeight, int requestedHeight, int screenHeight, int margin) {
        int safeMax = ToolboxPanelSize.fitToScreenPx(requestedHeight, screenHeight, margin);
        return Math.max(1, Math.min(Math.max(1, measuredHeight), safeMax));
    }
}
