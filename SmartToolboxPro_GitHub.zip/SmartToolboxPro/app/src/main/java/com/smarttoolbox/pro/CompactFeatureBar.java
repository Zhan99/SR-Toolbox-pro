package com.smarttoolbox.pro;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

/**
 * Single compact bar: tap anywhere to toggle ON/OFF; drag horizontally across
 * that same bar to adjust a feature level. The whole bar changes color on toggle.
 * A non-adjustable bar supports simple state toggle and a live status readout.
 */
final class CompactFeatureBar extends View {
    interface Listener {
        void onToggle();
        void onLevelChanged(int value);
        void onLevelReleased(int value);
        void onInteractionStart();
        void onInteractionEnd();
    }

    interface ValueFormatter { String format(int value); }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF shape = new RectF();
    private final String title;
    private final ValueFormatter formatter;
    private final boolean adjustable;
    private final int maxLevel;
    private final int desiredHeightPx;
    private final int touchSlop;
    private Listener listener;
    private boolean enabled;
    private boolean dragging;
    private float downX;
    private float downY;
    private int level;
    private String info = "";

    CompactFeatureBar(Context context, String title, boolean enabled,
                      int level, int maxLevel, boolean adjustable, int heightDp,
                      ValueFormatter formatter) {
        super(context);
        this.title = title;
        this.enabled = enabled;
        this.adjustable = adjustable;
        this.maxLevel = Math.max(1, maxLevel);
        this.level = Math.max(0, Math.min(this.maxLevel, level));
        this.formatter = formatter;
        this.desiredHeightPx = dp(heightDp);
        this.touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        setClickable(true);
        setFocusable(true);
        setContentDescription(getDescription());
    }

    void setListener(Listener listener) { this.listener = listener; }

    void setInfo(String detail) {
        info = detail == null ? "" : detail;
        setContentDescription(getDescription());
        invalidate();
    }

    private String getDescription() {
        return title + ", " + (enabled ? "ON" : "OFF")
                + (adjustable ? ", " + formatter.format(level) : ", " + info)
                + (adjustable ? ". Tap to toggle, slide horizontally to adjust." : ". Tap to toggle.");
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), desiredHeightPx);
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        if (w <= 0 || h <= 0) return;
        float radius = dp(11);
        shape.set(0, 0, w, h);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(enabled ? Ui.GREEN : Ui.CARD_2);
        canvas.drawRoundRect(shape, radius, radius, paint);
        if (adjustable) {
            // The colored fill lives inside the ON/OFF bar, not in a second slider row.
            float fraction = level / (float) maxLevel;
            if (fraction > 0f) {
                canvas.save();
                android.graphics.Path clip = new android.graphics.Path();
                clip.addRoundRect(shape, radius, radius, android.graphics.Path.Direction.CW);
                canvas.clipPath(clip);
                paint.setColor(enabled ? Ui.ACCENT : Ui.MUTED);
                canvas.drawRect(0, 0, w * fraction, h, paint);
                canvas.restore();
            }
            paint.setColor(Ui.ACCENT);
            canvas.drawRoundRect(dp(9), h - dp(4), dp(9) + (w - dp(18)) * fraction,
                    h - dp(2), dp(2), dp(2), paint);
        }
        paint.setColor(enabled ? Ui.ACCENT : Ui.MUTED);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(1));
        canvas.drawRoundRect(shape, radius, radius, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setTextSize(sp(13.5f));
        paint.setColor(Color.WHITE);
        String detail = (enabled ? "ON" : "OFF") + (adjustable ? " · " + formatter.format(level)
                : (info.isEmpty() ? "" : " · " + info));
        float rightWidth;
        paint.setTextSize(sp(11));
        rightWidth = paint.measureText(detail);
        float rightX = w - dp(10) - rightWidth;
        // Never allow status text to draw outside the rounded panel at narrow widths.
        if (rightX < dp(85)) {
            detail = enabled ? "ON" : "OFF";
            if (adjustable) detail += " " + formatter.format(level);
            rightWidth = paint.measureText(detail);
            rightX = w - dp(9) - rightWidth;
        }
        float baseline = h / 2f - (paint.ascent() + paint.descent()) / 2f - dp(1);
        paint.setColor(enabled ? Color.rgb(13, 34, 24) : Ui.TEXT);
        canvas.drawText(detail, Math.max(dp(8), rightX), baseline, paint);

        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setTextSize(sp(13));
        paint.setColor(enabled ? Color.rgb(13, 34, 24) : Ui.TEXT);
        float available = Math.max(dp(20), rightX - dp(19));
        String left = title;
        while (left.length() > 2 && paint.measureText(left) > available) {
            left = left.substring(0, left.length() - 2) + "…";
        }
        canvas.drawText(left, dp(11), baseline, paint);
    }

    private float sp(float size) {
        return size * getResources().getDisplayMetrics().scaledDensity;
    }

    private void updateFromX(float x) {
        int updated = CompactControlMath.levelFromTouch(x, getWidth(), dp(12), maxLevel);
        if (updated != level) {
            level = updated;
            setContentDescription(getDescription());
            invalidate();
            if (listener != null) listener.onLevelChanged(level);
        }
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = event.getX();
                downY = event.getY();
                dragging = false;
                if (listener != null) listener.onInteractionStart();
                return true;
            case MotionEvent.ACTION_MOVE:
                if (adjustable && !dragging && CompactControlMath.isHorizontalDrag(
                        event.getX() - downX, event.getY() - downY, touchSlop)) {
                    dragging = true;
                    if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                }
                if (dragging) updateFromX(event.getX());
                return true;
            case MotionEvent.ACTION_UP:
                if (dragging) {
                    updateFromX(event.getX());
                    if (listener != null) listener.onLevelReleased(level);
                } else if (Math.abs(event.getX() - downX) < touchSlop
                        && Math.abs(event.getY() - downY) < touchSlop) {
                    performClick();
                }
                if (listener != null) listener.onInteractionEnd();
                dragging = false;
                return true;
            case MotionEvent.ACTION_CANCEL:
                if (dragging && listener != null) listener.onLevelReleased(level);
                if (listener != null) listener.onInteractionEnd();
                dragging = false;
                return true;
            default:
                return super.onTouchEvent(event);
        }
    }

    @Override public boolean performClick() {
        super.performClick();
        if (listener != null) listener.onToggle();
        return true;
    }
}
