package com.smarttoolbox.pro;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

/** User taps a notification when installer consent is required in background. */
public final class ApkInstallApprovalActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Intent action=(Intent)getIntent().getParcelableExtra("user_action");
        if(action!=null)try {
            startActivity(action.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch(Exception ignored) { }
        finish();
    }
}
