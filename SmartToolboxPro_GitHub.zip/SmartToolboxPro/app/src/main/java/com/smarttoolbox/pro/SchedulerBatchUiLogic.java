package com.smarttoolbox.pro;

import java.util.List;

/** Pure Java rules for showing ONE card for an entire broadcast batch. */
final class SchedulerBatchUiLogic {
    private SchedulerBatchUiLogic() {}

    /** Individual items remain in storage and have their own AlarmManager intents. */
    static String cardKey(String id, String batchId) {
        return batchId == null || batchId.isEmpty() ? "single:" + id : "group:" + batchId;
    }

    /** Prefer the earliest pending recipient; otherwise a paused one, then latest history. */
    static int representativeIndex(List<String> statuses, List<Long> dueTimes) {
        if (statuses == null || dueTimes == null || statuses.isEmpty()
                || statuses.size() != dueTimes.size()) return -1;
        int chosen = -1;
        for (int i = 0; i < statuses.size(); i++) {
            if ("pending".equals(statuses.get(i))
                    && (chosen < 0 || !"pending".equals(statuses.get(chosen))
                    || dueTimes.get(i) < dueTimes.get(chosen))) chosen = i;
        }
        if (chosen >= 0) return chosen;
        for (int i = 0; i < statuses.size(); i++) {
            if ("paused".equals(statuses.get(i))) return i;
        }
        // History prefers the most recently due member as the representative.
        chosen = 0;
        for (int i = 1; i < dueTimes.size(); i++) {
            if (dueTimes.get(i) > dueTimes.get(chosen)) chosen = i;
        }
        return chosen;
    }

    static String statusShort(String status) {
        if ("pending".equals(status)) return "Pending";
        if ("paused".equals(status)) return "Paused";
        if ("due".equals(status)) return "Due · manual check";
        if ("attempted".equals(status)) return "Send attempted · not confirmed";
        if ("done".equals(status)) return "Marked sent";
        return "Unknown";
    }
    static int countStatus(List<String> statuses, String target) {
        if (statuses == null) return 0;
        int count = 0;
        for (String status : statuses) if (target.equals(status)) count++;
        return count;
    }
}
