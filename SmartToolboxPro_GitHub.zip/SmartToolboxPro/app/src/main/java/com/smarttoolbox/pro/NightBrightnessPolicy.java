package com.smarttoolbox.pro;

/** Pure Java safety policy for the optional global Night Screen brightness change. */
final class NightBrightnessPolicy {
    private NightBrightnessPolicy() { }
    // Android's documented setting range starts at 1; 0 can black out the panel.
    static final int MIN_BRIGHTNESS = 1;
    static final int MAX_BRIGHTNESS = 255;
    static final int MANUAL = 0;
    static final int AUTOMATIC = 1;
    // Android 12+ blocks pass-through touches under heavily obscuring untrusted overlays.
    static final float SAFE_OVERLAY_WINDOW_ALPHA = 0.78f;
    static int safeBrightness(int current) {
        return Math.max(MIN_BRIGHTNESS, Math.min(MAX_BRIGHTNESS, current));
    }
    static int safeMode(int mode) { return mode == AUTOMATIC ? AUTOMATIC : MANUAL; }
    static boolean canLower(boolean permission, boolean optedIn) {
        return permission && optedIn;
    }
    static boolean shouldRestore(boolean snapshotPresent, boolean permission,
                                 int currentBrightness, int currentMode) {
        // The user may have changed brightness or enabled adaptive brightness
        // while Night Screen was active. Never overwrite that newer decision.
        return snapshotPresent && permission && currentBrightness <= MIN_BRIGHTNESS
                && currentMode == MANUAL;
    }
    static int safeDimLevel(int requested) { return Math.max(0, Math.min(95, requested)); }
    static float overlayViewAlpha(int requested) { return safeDimLevel(requested) / 100f; }
}
