package com.smarttoolbox.pro;

/** Policy for screen-orientation based icon docking, independent of the video app. */
final class GlobalPortraitEdgeLogic {
    private GlobalPortraitEdgeLogic() { }
    static boolean isPortrait(int displayWidth, int displayHeight, boolean resourcePortrait) {
        if (displayWidth > 0 && displayHeight > 0 && displayWidth != displayHeight) {
            return displayHeight > displayWidth;
        }
        return resourcePortrait;
    }
    static boolean shouldDock(boolean allAppsEnabled, boolean portrait,
                              boolean overlayEnabled, boolean iconEnabled,
                              boolean iconHidden, boolean panelOpen) {
        return allAppsEnabled && portrait && overlayEnabled && iconEnabled
                && !iconHidden && !panelOpen;
    }
    static boolean shouldUndock(boolean wasDockedBySystem, boolean portrait,
                                boolean allAppsEnabled) {
        return wasDockedBySystem && (!portrait || !allAppsEnabled);
    }
    static int edgeX(boolean left, int displayWidth, int handleWidth) {
        return left ? 0 : Math.max(0, displayWidth - Math.max(1, handleWidth));
    }
    static int edgeY(int desiredY, int displayHeight, int handleHeight, int margin) {
        int bottom = Math.max(0, displayHeight - Math.max(1, handleHeight) - Math.max(0,margin));
        return Math.max(Math.min(Math.max(0, margin), bottom), Math.min(desiredY, bottom));
    }
}
