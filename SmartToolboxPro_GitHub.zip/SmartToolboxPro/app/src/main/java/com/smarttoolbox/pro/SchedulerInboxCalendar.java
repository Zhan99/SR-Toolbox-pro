package com.smarttoolbox.pro;

import android.app.Activity;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.time.DayOfWeek;
import java.time.Instant;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.function.Consumer;

/** Always-visible scheduler inbox calendar; older/future records appear only when tapped. */
final class SchedulerInboxCalendar {
    private SchedulerInboxCalendar() {}

    static void render(Activity activity, LinearLayout container, YearMonth month,
                       LocalDate selected, List<MessageScheduleStore.Item> items,
                       Consumer<YearMonth> onMonth, Consumer<LocalDate> onDay) {
        Set<LocalDate> datesWithRecords = new HashSet<>();
        ZoneId zone = ZoneId.systemDefault();
        for (MessageScheduleStore.Item item : items) {
            if (item.scheduledAtMillis > 0) datesWithRecords.add(
                    SchedulerCalendarLogic.toLocalDate(item.scheduledAtMillis, zone));
            if (item.lastTriggeredAtMillis > 0) datesWithRecords.add(
                    SchedulerCalendarLogic.toLocalDate(item.lastTriggeredAtMillis, zone));
        }
        LinearLayout card = Ui.card(activity);
        LinearLayout heading = new LinearLayout(activity);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        TextView previous = Ui.text(activity, "‹", 28, Ui.ACCENT, true);
        previous.setGravity(Gravity.CENTER);
        heading.addView(previous, new LinearLayout.LayoutParams(Ui.dp(activity, 42), Ui.dp(activity, 48)));
        TextView title = Ui.text(activity, month.format(DateTimeFormatter.ofPattern(
                "MMMM yyyy", Locale.getDefault())), 17, Ui.TEXT, true);
        title.setGravity(Gravity.CENTER);
        heading.addView(title, new LinearLayout.LayoutParams(0, Ui.dp(activity, 48), 1f));
        TextView next = Ui.text(activity, "›", 28, Ui.ACCENT, true);
        next.setGravity(Gravity.CENTER);
        heading.addView(next, new LinearLayout.LayoutParams(Ui.dp(activity, 42), Ui.dp(activity, 48)));
        previous.setOnClickListener(v -> onMonth.accept(month.minusMonths(1)));
        next.setOnClickListener(v -> onMonth.accept(month.plusMonths(1)));
        card.addView(heading);
        String[] weekdays = {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"};
        LinearLayout labels = new LinearLayout(activity);
        for (String day : weekdays) {
            TextView label = Ui.text(activity, day, 12, Ui.MUTED, true);
            label.setGravity(Gravity.CENTER);
            labels.addView(label, new LinearLayout.LayoutParams(0, Ui.dp(activity, 28), 1f));
        }
        card.addView(labels);
        LocalDate first = month.atDay(1);
        LocalDate start = first.minusDays(first.getDayOfWeek().getValue() - DayOfWeek.MONDAY.getValue());
        LocalDate today = LocalDate.now(zone);
        for (int row = 0; row < 6; row++) {
            LinearLayout line = new LinearLayout(activity);
            for (int col = 0; col < 7; col++) {
                LocalDate date = start.plusDays(row * 7L + col);
                boolean hasMessages = datesWithRecords.contains(date);
                boolean isInMonth = YearMonth.from(date).equals(month);
                TextView cell = Ui.text(activity,
                        date.getDayOfMonth() + (hasMessages ? "\n●" : "\n "),
                        13, hasMessages ? Ui.ACCENT : isInMonth ? Ui.TEXT : Ui.MUTED,
                        date.equals(today));
                cell.setGravity(Gravity.CENTER);
                cell.setContentDescription(date + (hasMessages ? ", saved messages" : ", no saved messages"));
                cell.setClickable(true);
                if (date.equals(selected) || date.equals(today)) {
                    GradientDrawable highlight = new GradientDrawable();
                    highlight.setCornerRadius(Ui.dp(activity, 10));
                    highlight.setColor(Ui.CARD_2);
                    highlight.setStroke(Ui.dp(activity, 1),
                            date.equals(selected) ? Ui.ACCENT : Ui.MUTED);
                    cell.setBackground(highlight);
                }
                cell.setOnClickListener(v -> onDay.accept(date));
                LinearLayout.LayoutParams cellLp = new LinearLayout.LayoutParams(0,
                        Ui.dp(activity, 49), 1f);
                cellLp.setMargins(Ui.dp(activity, 1), Ui.dp(activity, 1),
                        Ui.dp(activity, 1), Ui.dp(activity, 1));
                line.addView(cell, cellLp);
            }
            card.addView(line);
        }
        Ui.addText(activity, card,
                "● = ওই তারিখে সংরক্ষিত শিডিউল বা History আছে (ডেলিভারি নিশ্চিত নয়)। "
                        + "পুরোনো/ভবিষ্যতের মেসেজ দেখতে তারিখে চাপুন।",
                12, Ui.MUTED, false, 10);
        Ui.addCard(activity, container, card, 8);
    }
}
