package com.smarttoolbox.pro;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.res.ColorStateList;
import android.graphics.drawable.RippleDrawable;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

final class Ui {
    static int BG = Color.rgb(9, 13, 18);
    static int CARD = Color.rgb(23, 29, 37);
    static int CARD_2 = Color.rgb(31, 38, 48);
    static int TEXT = Color.rgb(245, 247, 250);
    static int MUTED = Color.rgb(157, 168, 181);
    static int ACCENT = Color.rgb(255, 194, 71);
    static int GREEN = Color.rgb(90, 210, 145);
    private static boolean premiumLook;
    private static boolean lightLook;

    private Ui() {}
    static boolean isPremium() { return premiumLook; }
    static void applyPremiumLook(boolean premium, boolean light) {
        premiumLook = premium;
        lightLook = light;
        if (premium) {
            if (light) {
                BG = shade(BG, Color.WHITE, .25f);
                CARD_2 = shade(CARD_2, Color.WHITE, .12f);
            } else {
                BG = shade(BG, Color.BLACK, .23f);
                CARD = shade(CARD, 0xFF17253B, .23f);
                CARD_2 = shade(CARD_2, 0xFF26344B, .28f);
            }
        }
    }
    static int shade(int from, int to, float fraction) {
        float t = Math.max(0f, Math.min(1f, fraction));
        return Color.rgb((int) (Color.red(from) * (1 - t) + Color.red(to) * t),
                (int) (Color.green(from) * (1 - t) + Color.green(to) * t),
                (int) (Color.blue(from) * (1 - t) + Color.blue(to) * t));
    }

    static void applyColors(int[] colors) {
        BG = colors[0]; CARD = colors[1]; CARD_2 = colors[2];
        TEXT = colors[3]; MUTED = colors[4]; ACCENT = colors[5]; GREEN = colors[6];
    }


    static int dp(Activity a, float value) {
        return (int) (value * a.getResources().getDisplayMetrics().density + 0.5f);
    }

    static LinearLayout page(Activity a, String title) {
        LinearLayout outer = new LinearLayout(a);
        outer.setOrientation(LinearLayout.VERTICAL);
        if (premiumLook) {
            GradientDrawable canvas = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    new int[]{BG, shade(BG, CARD_2, .34f), BG});
            outer.setBackground(canvas);
        } else outer.setBackgroundColor(BG);
        outer.setPadding(dp(a, 18), dp(a, 14), dp(a, 18), dp(a, 22));

        LinearLayout header = new LinearLayout(a);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = text(a, "‹", 34, TEXT, false);
        back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v -> {
            UiSound.play(a, UiSound.NAVIGATE);
            a.finish();
        });
        header.addView(back, new LinearLayout.LayoutParams(dp(a, 44), dp(a, 52)));
        TextView heading = text(a, title, 22, TEXT, true);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(0, -2, 1);
        hp.leftMargin = dp(a, 8);
        header.addView(heading, hp);
        if (premiumLook) {
            header.setPadding(dp(a, 5), dp(a, 4), dp(a, 10), dp(a, 4));
            GradientDrawable headerBg = new GradientDrawable(
                    GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{shade(CARD, ACCENT, .09f), CARD});
            headerBg.setCornerRadius(dp(a, 22));
            headerBg.setStroke(dp(a, 1), shade(CARD_2, ACCENT, .48f));
            header.setBackground(headerBg);
            header.setElevation(dp(a, 3));
        }
        outer.addView(header);

        ScrollView scroll = new ScrollView(a);
        scroll.setFillViewport(true);
        LinearLayout content = new LinearLayout(a);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(a, 12), 0, dp(a, 12));
        scroll.addView(content);
        outer.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        outer.setTag(content);
        return outer;
    }

    static LinearLayout content(LinearLayout page) {
        return (LinearLayout) page.getTag();
    }

    static TextView text(Activity a, String value, int size, int color, boolean bold) {
        TextView t = new TextView(a);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setTypeface(Typeface.create(premiumLook && bold ? "sans-serif-medium" : "sans-serif",
                bold ? Typeface.BOLD : Typeface.NORMAL));
        if (premiumLook && bold && size >= 16) t.setLetterSpacing(.012f);
        t.setIncludeFontPadding(true);
        return t;
    }

    static TextView addText(Activity a, LinearLayout parent, String value, int size, int color, boolean bold, int top) {
        TextView t = text(a, value, size, color, bold);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(a, top);
        parent.addView(t, p);
        return t;
    }

    static Button button(Activity a, String label, Runnable action) {
        Button b = new Button(a);
        b.setText(label);
        b.setTextSize(15);
        b.setTextColor(premiumLook
                ? (lightLook ? Color.WHITE : Color.rgb(12, 18, 28))
                : (ThemeManager.isLight(a) ? Color.WHITE : Color.rgb(18, 23, 30)));
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        GradientDrawable bg = premiumLook
                ? new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                        new int[]{shade(ACCENT, Color.WHITE, .23f), ACCENT, shade(ACCENT, Color.BLACK, .17f)})
                : new GradientDrawable();
        if (!premiumLook) bg.setColor(ACCENT);
        bg.setCornerRadius(dp(a, premiumLook ? 18 : 16));
        if (premiumLook) {
            bg.setStroke(dp(a, 1), shade(ACCENT, Color.WHITE, .28f));
            b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), bg, null));
            b.setElevation(dp(a, 3));
        } else b.setBackground(bg);
        b.setPadding(dp(a, 14), dp(a, 10), dp(a, 14), dp(a, 10));
        b.setOnClickListener(v -> {
            UiSound.play(a, UiSound.TAP);
            action.run();
        });
        return b;
    }

    static LinearLayout card(Activity a) {
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(a, premiumLook ? 18 : 16), dp(a, premiumLook ? 18 : 16),
                dp(a, premiumLook ? 18 : 16), dp(a, premiumLook ? 18 : 16));
        GradientDrawable bg = premiumLook
                ? new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                        new int[]{shade(CARD, ACCENT, lightLook ? .045f : .11f), CARD,
                                shade(CARD, CARD_2, .36f)})
                : new GradientDrawable();
        if (!premiumLook) bg.setColor(CARD);
        bg.setCornerRadius(dp(a, premiumLook ? 25 : 20));
        bg.setStroke(dp(a, 1), premiumLook ? shade(CARD_2, ACCENT, .40f) : CARD_2);
        box.setBackground(bg);
        if (premiumLook) box.setElevation(dp(a, 3));
        return box;
    }

    static void addCard(Activity a, LinearLayout parent, View child, int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(a, top);
        parent.addView(child, p);
        if (premiumLook && PremiumExperience.motion(a) && parent.getChildCount() < 10) {
            child.setAlpha(0f);
            child.setTranslationY(dp(a, 11));
            child.animate().alpha(1f).translationY(0f).setDuration(280L).start();
        }
    }
}
