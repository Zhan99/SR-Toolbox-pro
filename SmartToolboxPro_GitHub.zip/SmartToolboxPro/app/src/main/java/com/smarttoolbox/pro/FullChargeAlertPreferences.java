package com.smarttoolbox.pro;

import android.content.Context;
import android.content.SharedPreferences;

/** User opt-in and last announced charging session survive process restarts. */
final class FullChargeAlertPreferences {
    private static final String STORE = "sr_full_charge_voice_v1";
    private static final String ENABLED = "enabled";
    private static final String ANNOUNCED = "announced_this_charge";
    private static final String LANGUAGE = "voice_language";
    private static final String DEVICE_TTS = "prefer_device_tts";
    private FullChargeAlertPreferences() { }

    private static SharedPreferences preferences(Context context) {
        return context.getApplicationContext().getSharedPreferences(STORE, Context.MODE_PRIVATE);
    }
    static boolean enabled(Context context) { return preferences(context).getBoolean(ENABLED, false); }
    static boolean announced(Context context) { return preferences(context).getBoolean(ANNOUNCED, false); }

    static String language(Context c) {
        return FullChargeLanguageLogic.normalize(preferences(c).getString(LANGUAGE, "bn"));
    }
    static boolean setLanguage(Context c, String language) {
        return preferences(c).edit().putString(LANGUAGE,
                FullChargeLanguageLogic.normalize(language)).commit();
    }
    static boolean preferDeviceVoice(Context c) {
        return preferences(c).getBoolean(DEVICE_TTS, true);
    }
    static void setPreferDeviceVoice(Context c, boolean prefer) {
        preferences(c).edit().putBoolean(DEVICE_TTS, prefer).apply();
    }

    /** Enabling a NEW monitoring session permits the first genuine full-charge alert. */
    static boolean setEnabled(Context context, boolean enabled) {
        return preferences(context).edit().putBoolean(ENABLED, enabled)
                .putBoolean(ANNOUNCED, false).commit();
    }
    static boolean setAnnounced(Context context, boolean announced) {
        return preferences(context).edit().putBoolean(ANNOUNCED, announced).commit();
    }
}
