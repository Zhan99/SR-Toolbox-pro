package com.smarttoolbox.pro;
import android.app.Application;
public final class SrToolboxApp extends Application {
    @Override public void onCreate() {
        super.onCreate();
        ThemeManager.initialize(this);
        UiSound.preload(this);
    }
}
