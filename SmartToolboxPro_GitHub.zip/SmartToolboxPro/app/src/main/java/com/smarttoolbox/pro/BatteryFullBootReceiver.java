package com.smarttoolbox.pro;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Best effort restart after reboot/update; OEM battery policies can disallow it. */
public final class BatteryFullBootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String action = intent == null ? "" : intent.getAction();
        if ((Intent.ACTION_BOOT_COMPLETED.equals(action)
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action))
                && BatteryFullAlertPrefs.enabled(context)) {
            BatteryFullVoiceService.startMonitoring(context);
        }
    }
}
