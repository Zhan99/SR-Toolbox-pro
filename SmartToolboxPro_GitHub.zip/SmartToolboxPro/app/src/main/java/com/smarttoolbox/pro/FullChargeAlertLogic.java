package com.smarttoolbox.pro;

/** No Android dependencies: one spoken warning per physical charging session. */
final class FullChargeAlertLogic {
    // BatteryManager.BATTERY_STATUS_FULL is 5 (Android constants are not needed here).
    static final int STATUS_FULL = 5;
    static final int IGNORE = 0;
    static final int RESET_SESSION = 1;
    static final int ANNOUNCE_ONCE = 2;
    private FullChargeAlertLogic() { }

    static boolean isPowered(int plugged) { return plugged > 0; }
    static boolean isFull(int batteryStatus, int level, int scale) {
        return batteryStatus == STATUS_FULL
                || (scale > 0 && level >= 0 && level >= scale);
    }
    static int decision(boolean enabled, int plugged, int status,
                        int level, int scale, boolean announced) {
        if (!enabled) return IGNORE;
        if (!isPowered(plugged)) return RESET_SESSION;
        return isFull(status, level, scale) && !announced ? ANNOUNCE_ONCE : IGNORE;
    }
    static int percent(int level, int scale) {
        if (level < 0 || scale <= 0) return -1;
        return Math.min(100, Math.max(0, Math.round(level * 100f / scale)));
    }
}
