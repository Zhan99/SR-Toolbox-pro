package com.smarttoolbox.pro;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/** Home ⋮ > Full Charge Voice Alert; opt-in control and built-in Bengali voice preview. */
public final class FullChargeAlertActivity extends Activity {
    private Switch enableSwitch;
    private boolean changingSwitchProgrammatically;
    private TextView currentBattery;
    private TextView monitorStatus;
    private FullChargeVoicePlayer.Playback testVoice;
    private static final int ASK_NOTIFICATIONS = 2509;

    @Override public void onCreate(Bundle state) {
        ThemeManager.applyToActivity(this);
        super.onCreate(state);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);

        LinearLayout page = Ui.page(this, "🔋 Full Charge Voice Alert");
        LinearLayout body = Ui.content(page);
        LinearLayout card = Ui.card(this);
        Ui.addText(this, card, "ব্যাটারি পূর্ণ হলে বাংলা / English / উভয় ভাষার ভয়েস", 21, Ui.TEXT, true, 4);
        Ui.addText(this, card,
                "চার্জে থাকা অবস্থায় ১০০% হলে নির্বাচিত ভাষায় একবার বলবে:\n"
                        + "বাংলা: ব্যাটারি ফুল চার্জ হয়েছে, চার্জ থেকে খুলুন।\n"
                        + "English: The battery is fully charged. Please unplug your charger.",
                15, Ui.ACCENT, true, 12);
        Ui.addText(this, card, "🔊 Alert voice language / অ্যালার্টের ভাষা",
                16, Ui.TEXT, true, 10);
        Spinner languages = new Spinner(this);
        ArrayAdapter<String> languageAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"বাংলা (Bengali)", "English", "বাংলা + English (both)"});
        languages.setAdapter(languageAdapter);
        String savedLanguage = FullChargeAlertPreferences.language(this);
        languages.setSelection("both".equals(savedLanguage) ? 2
                : ("en".equals(savedLanguage) ? 1 : 0));
        card.addView(languages, new LinearLayout.LayoutParams(-1, -2));
        languages.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, android.view.View view,
                                                 int position, long id) {
                FullChargeAlertPreferences.setLanguage(FullChargeAlertActivity.this,
                        position == 2 ? "both" : (position == 1 ? "en" : "bn"));
                if (testVoice != null) { testVoice.stop(); testVoice = null; }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
        Switch naturalVoice = new Switch(this);
        naturalVoice.setText("✨ Prefer best available phone voice (TTS)");
        naturalVoice.setTextColor(Ui.TEXT);
        naturalVoice.setChecked(FullChargeAlertPreferences.preferDeviceVoice(this));
        card.addView(naturalVoice, new LinearLayout.LayoutParams(-1, -2));
        naturalVoice.setOnCheckedChangeListener((button, enabled) ->
                FullChargeAlertPreferences.setPreferDeviceVoice(this, enabled));
        Ui.addText(this, card,
                "A natural device voice is used when its language pack is available. "
                        + "Otherwise the app plays its built-in offline voice in your chosen language.",
                12, Ui.MUTED, false, 8);
        enableSwitch = new Switch(this);
        enableSwitch.setText("🔊 Full Charge Voice Alert চালু রাখুন / Enable");
        enableSwitch.setTextColor(Ui.TEXT);
        enableSwitch.setTextSize(15);
        enableSwitch.setChecked(FullChargeAlertPreferences.enabled(this));
        card.addView(enableSwitch);
        monitorStatus = Ui.addText(this, card, "", 13, Ui.MUTED, false, 9);
        currentBattery = Ui.addText(this, card, "", 14, Ui.TEXT, false, 10);
        enableSwitch.setOnCheckedChangeListener((button, enabled) -> {
            if (!changingSwitchProgrammatically) setMonitoring(enabled);
        });
        Ui.addCard(this, body, card, 12);

        LinearLayout testCard = Ui.card(this);
        Ui.addText(this, testCard, "🔈 বাংলা / English / উভয় ভাষার ভয়েস প্রিভিউ", 17, Ui.ACCENT, true, 2);
        Ui.addText(this, testCard,
                "বাংলা ও English অফলাইন ভয়েস অ্যাপের ভেতরে আছে। উন্নত TTS Voice থাকলে "
                        + "সেটি ব্যবহার হবে, না থাকলে অফলাইন ভয়েস বাজবে। "
                        + "Alarm Volume ও Do Not Disturb প্রভাব ফেলতে পারে।",
                13, Ui.MUTED, false, 6);
        Button preview = Ui.button(this, "▶ নির্বাচিত ভাষার ভয়েস শুনে দেখুন", this::testVoice);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.topMargin = Ui.dp(this, 10);
        testCard.addView(preview, bp);
        Ui.addCard(this, body, testCard, 10);

        LinearLayout guide = Ui.card(this);
        Ui.addText(this, guide, "কীভাবে কাজ করে", 17, Ui.TEXT, true, 2);
        Ui.addText(this, guide,
                "১. একবার Full Charge Voice Alert চালু করুন।\n"
                        + "২. চার্জার সংযুক্ত হলে Monitoring চালু থাকবে।\n"
                        + "৩. ফোন ১০০% হলে নির্বাচিত ভাষায় একবার Voice ও Notification আসবে।\n"
                        + "৪. চার্জার খুললে সতর্কবার্তা Reset হবে। পরের চার্জে আবার বলবে।\n\n"
                        + "ব্যাকগ্রাউন্ডে কাজ করার জন্য একটি চলমান Notification থাকবে। "
                        + "সেখানকার ‘বন্ধ করুন’ বাটন দিয়ে বন্ধ করা যাবে। "
                        + "Android Battery Saver, Force Stop বা নির্মাতার Background Restriction থাকলে "
                        + "সতর্কবার্তা দেরি হতে পারে বা বন্ধ হয়ে যেতে পারে।",
                13, Ui.MUTED, false, 10);
        Ui.addCard(this, body, guide, 10);
        setContentView(page);
        refreshState();
    }

    private void setMonitoring(boolean enabled) {
        boolean saved = FullChargeAlertPreferences.setEnabled(this, enabled);
        if (!saved) {
            Toast.makeText(this, "সেটিং সংরক্ষণ করা যায়নি।", Toast.LENGTH_LONG).show();
            changingSwitchProgrammatically = true;
            enableSwitch.setChecked(!enabled);
            changingSwitchProgrammatically = false;
            return;
        }
        Intent service = new Intent(this, FullChargeVoiceService.class);
        if (enabled) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service);
                else startService(service);
            } catch (RuntimeException e) {
                FullChargeAlertPreferences.setEnabled(this, false);
                changingSwitchProgrammatically = true;
                enableSwitch.setChecked(false);
                changingSwitchProgrammatically = false;
                Toast.makeText(this, "Android Background Service চালু করতে দেয়নি: "
                        + e.getClass().getSimpleName(), Toast.LENGTH_LONG).show();
                return;
            }
            if (Build.VERSION.SDK_INT >= 33
                    && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                            != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, ASK_NOTIFICATIONS);
            }
        } else {
            service.setAction(FullChargeVoiceService.ACTION_STOP);
            try { startService(service); } catch (RuntimeException e) {
                stopService(new Intent(this, FullChargeVoiceService.class));
            }
        }
        refreshState();
    }

    private void testVoice() {
        if (testVoice != null) testVoice.stop();
        testVoice = FullChargeVoicePlayer.speak(this, FullChargeAlertPreferences.language(this),
                FullChargeAlertPreferences.preferDeviceVoice(this));
    }

    private void refreshState() {
        boolean enabled = FullChargeAlertPreferences.enabled(this);
        changingSwitchProgrammatically = true;
        enableSwitch.setChecked(enabled);
        changingSwitchProgrammatically = false;
        monitorStatus.setText(enabled
                ? "● Monitoring ON · 100% হলে Voice Alert" : "○ Monitoring OFF · Voice Alert বন্ধ");
        Intent state = registerReceiver(null, new android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (state == null) {
            currentBattery.setText("Battery Level: পাওয়া যাচ্ছে না");
            return;
        }
        int percentage = FullChargeAlertLogic.percent(
                state.getIntExtra(BatteryManager.EXTRA_LEVEL, -1),
                state.getIntExtra(BatteryManager.EXTRA_SCALE, 100));
        boolean charging = state.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) > 0;
        currentBattery.setText("🔋 Current Battery: " + (percentage >= 0 ? percentage + "%" : "Unknown")
                + "  ·  " + (charging ? "চার্জার সংযুক্ত" : "চার্জার খোলা"));
    }

    @Override protected void onResume() {
        super.onResume();
        if (enableSwitch != null) refreshState();
    }
    @Override protected void onDestroy() {
        if (testVoice != null) {
            testVoice.stop();
            testVoice = null;
        }
        super.onDestroy();
    }
}
