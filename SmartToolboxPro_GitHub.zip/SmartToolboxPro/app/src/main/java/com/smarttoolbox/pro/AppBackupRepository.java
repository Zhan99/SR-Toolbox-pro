package com.smarttoolbox.pro;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import androidx.documentfile.provider.DocumentFile;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Offline APK-only archive management. Never reads other apps' private data. */
final class AppBackupRepository {
    static final String ROOT = "SR_Apps_Backup";
    static final String META = "backup.json";
    static final String APK_MIME = "application/vnd.android.package-archive";
    private final Context context;
    private final PackageManager pm;

    interface Progress { void update(String message, int percent); }

    static final class Installed {
        String pkg, name, version;
        long code, updated, bytes;
        boolean system, archived;
        Drawable icon;
        File base;
        final List<File> splits = new ArrayList<>();
    }
    static final class Part {
        String path, sha256;
        long bytes;
        Part(String path, long bytes, String sha256) {
            this.path=path; this.bytes=bytes; this.sha256=sha256;
        }
        JSONObject toJson() throws Exception {
            JSONObject o = new JSONObject();
            o.put("path",path); o.put("bytes",bytes); o.put("sha256",sha256);
            return o;
        }
    }
    static final class Archived {
        String pkg, name, version, digest;
        long code, backedUpAt, bytes;
        DocumentFile folder;
        boolean installed;
        final List<Part> parts = new ArrayList<>();
        String key() { return folder.getUri().toString(); }
        boolean split() { return parts.size()>1; }
    }

    AppBackupRepository(Context context) {
        this.context=context.getApplicationContext(); pm=context.getPackageManager();
    }

    private static long versionCode(PackageInfo info) {
        return Build.VERSION.SDK_INT>=28 ? info.getLongVersionCode() : info.versionCode;
    }
    private static boolean system(ApplicationInfo a) {
        return (a.flags & (ApplicationInfo.FLAG_SYSTEM | ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0;
    }
    List<Installed> installed() {
        List<Installed> result=new ArrayList<>();
        List<PackageInfo> packages;
        if (Build.VERSION.SDK_INT >= 33) {
            packages=pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(0));
        } else packages=pm.getInstalledPackages(0);
        for(PackageInfo pi:packages) {
            ApplicationInfo ai=pi.applicationInfo;
            if(ai==null || ai.sourceDir==null) continue;
            Installed a=new Installed(); a.pkg=pi.packageName;
            try { a.name=String.valueOf(pm.getApplicationLabel(ai)); }
            catch(Exception ignored) { a.name=a.pkg; }
            a.version=pi.versionName==null ? "" : pi.versionName;
            a.code=versionCode(pi); a.updated=pi.lastUpdateTime; a.system=system(ai);
            a.base=new File(ai.sourceDir);
            a.bytes=a.base.length();
            if(ai.splitSourceDirs!=null) for(String path:ai.splitSourceDirs) {
                if(path!=null) { File f=new File(path);a.splits.add(f);a.bytes+=f.length(); }
            }
            // Preserve the original drawable resource, without creating synthetic icons.
            try { a.icon=pm.getApplicationIcon(ai); } catch(Exception ignored) { }
            result.add(a);
        }
        return result;
    }

    DocumentFile selectedTree(boolean create) throws IOException {
        Uri uri=AppBackupPreferences.treeUri(context);
        if(uri==null) return null;
        try {
            DocumentFile root=DocumentFile.fromTreeUri(context,uri);
            if(root==null || !root.isDirectory()) throw new IOException("Selected backup storage is inaccessible. Re-select it in Settings.");
            if(create && !root.canWrite()) throw new IOException("Storage is read-only. Select a writable folder.");
            DocumentFile child=root.findFile(ROOT);
            if(child==null && create) child=root.createDirectory(ROOT);
            if(child!=null && !child.isDirectory()) throw new IOException("Backup folder name conflicts with an existing file.");
            if(create && child==null) throw new IOException("Cannot create Apps Backup directory.");
            return child;
        } catch(SecurityException ex) { throw new IOException("Storage grant revoked. Select the backup folder again.",ex); }
    }

    List<Archived> archives() throws IOException {
        DocumentFile root=selectedTree(false);
        List<Archived> out=new ArrayList<>();
        if(root==null) return out;
        for(DocumentFile folder:root.listFiles()) {
            if(!folder.isDirectory() || folder.getName()==null || folder.getName().startsWith("__partial_"))continue;
            DocumentFile json=folder.findFile(META);
            if(json==null || !json.isFile()) continue;
            try {
                String data=readText(json.getUri(),64*1024);
                JSONObject obj=new JSONObject(data);
                Archived a=new Archived(); a.folder=folder;
                a.pkg=obj.getString("package"); a.name=obj.optString("name",a.pkg);
                a.version=obj.optString("version",""); a.code=obj.optLong("versionCode",0);
                a.backedUpAt=obj.optLong("backedUpAt",0);
                a.digest=obj.optString("digest","");
                JSONArray parts=obj.getJSONArray("apks");
                if(parts.length()==0 || !"base.apk".equals(parts.getJSONObject(0).getString("path")))continue;
                boolean complete=true;
                for(int i=0;i<parts.length();i++) {
                    JSONObject p=parts.getJSONObject(i);
                    String path=p.getString("path");
                    if(!ApkBackupRules.validArchivePart(path)) {complete=false;break;}
                    Part part=new Part(path,p.getLong("bytes"),p.getString("sha256"));
                    if(findRelative(folder,path)==null){complete=false;break;}
                    a.parts.add(part);a.bytes+=part.bytes;
                }
                if(!complete)continue;
                a.installed=isInstalled(a.pkg);
                out.add(a);
            } catch(Exception ignored) { // Ignore interrupted/incomplete/corrupt backups, not other archives.
            }
        }
        return out;
    }

    boolean isInstalled(String pkg) {
        try { pm.getPackageInfo(pkg,0);return true; }
        catch(PackageManager.NameNotFoundException ignored){return false;}
    }
    static DocumentFile findRelative(DocumentFile folder,String relative) {
        if(folder==null || relative==null || relative.contains(".."))return null;
        DocumentFile cursor=folder;
        for(String s:relative.split("/")) {
            if(s.isEmpty())return null;
            cursor=cursor.findFile(s);
            if(cursor==null)return null;
        }
        return cursor != null && cursor.isFile() ? cursor : null;
    }

    private String readText(Uri uri,int max) throws IOException {
        try(InputStream in=context.getContentResolver().openInputStream(uri)) {
            if(in==null) throw new IOException("Cannot open archive metadata");
            ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] buf=new byte[4096];int n;
            while((n=in.read(buf))!=-1) {
                if(out.size()+n>max)throw new IOException("Metadata size exceeds limit");
                out.write(buf,0,n);
            }
            return out.toString("UTF-8");
        }
    }
    private static String hex(byte[] bytes) {
        StringBuilder s=new StringBuilder(bytes.length*2);
        for(byte b:bytes)s.append(String.format(java.util.Locale.ROOT,"%02x",b&255));
        return s.toString();
    }
    private static MessageDigest hasher() {
        try { return MessageDigest.getInstance("SHA-256"); }
        catch(Exception e){throw new IllegalStateException(e);}
    }
    private static String shaFile(File f) throws IOException {
        try(InputStream in=new FileInputStream(f)) {
            return ApkStreamIntegrity.sha256(in);
        }
    }
    String shaUri(Uri uri) throws IOException {
        try(InputStream in=context.getContentResolver().openInputStream(uri)) {
            return ApkStreamIntegrity.sha256(in);
        }
    }
    private static String combinedDigest(List<Part> parts) {
        MessageDigest d=hasher();
        for(Part p:parts) {
            byte[] b=(p.path+":"+p.bytes+":"+p.sha256+"\n")
                    .getBytes(java.nio.charset.StandardCharsets.UTF_8);
            d.update(b);
        }
        return hex(d.digest());
    }
    private static final class SourcePart {
        final String relative;final File file;
        SourcePart(String relative,File file){this.relative=relative;this.file=file;}
    }
    private static List<SourcePart> sources(Installed app) {
        List<SourcePart> src=new ArrayList<>();src.add(new SourcePart("base.apk",app.base));
        Set<String> used=new HashSet<>();
        for(int i=0;i<app.splits.size();i++) {
            File split=app.splits.get(i);
            String name=ApkBackupRules.safePart(split.getName());
            if(!name.endsWith(".apk"))name+=".apk";
            while(!used.add(name)) name="split_"+i+"_"+name;
            src.add(new SourcePart("splits/"+name,split));
        }
        return src;
    }
    private static List<Part> identities(List<SourcePart> files) throws IOException {
        List<Part> parts=new ArrayList<>();
        for(SourcePart src:files) {
            if(!src.file.isFile() || !src.file.canRead())throw new IOException("APK file is inaccessible: "+src.relative);
            parts.add(new Part(src.relative,src.file.length(),shaFile(src.file)));
        }
        return parts;
    }
    void backup(Installed app,Progress progress) throws Exception {
        DocumentFile root=selectedTree(true);
        if(root==null)throw new IOException("Choose an Internal Storage or SD Card folder in Backup Settings first.");
        List<SourcePart> src=sources(app);
        List<Part> checks=identities(src);String digest=combinedDigest(checks);
        List<Archived> prior=archives();
        if(AppBackupPreferences.preventDuplicates(context))for(Archived a:prior) {
            if(ApkBackupRules.duplicate(app.pkg,app.code,digest,a.pkg,a.code,a.digest)) {
                // A manifest digest alone is insufficient: a stored APK may have been
                // deleted or corrupted after the original backup. Verify every part.
                try {
                    verifyArchive(a,(message,percent)->{});
                    progress.update("Skipped existing intact APK backup: "+app.name,100);
                    return;
                } catch(IOException damagedBackup) {
                    // Make a fresh verified backup; do not count corrupt files as success.
                }
            }
        }
        long stamp=System.currentTimeMillis();
        String target=ApkBackupRules.archiveFolder(app.pkg,app.code,stamp);
        while(root.findFile(target)!=null){stamp++;target=ApkBackupRules.archiveFolder(app.pkg,app.code,stamp);}
        DocumentFile staged=root.createDirectory("__partial_"+target);
        if(staged==null)throw new IOException("Could not create temporary archive folder");
        boolean complete=false;
        try {
            DocumentFile splits=null;
            long total=0;for(Part p:checks)total+=p.bytes;
            long processed=0;
            int lastProgress=-1;
            for(int i=0;i<src.size();i++) {
                SourcePart input=src.get(i);Part verify=checks.get(i);
                DocumentFile dir=staged;
                if(i>0){
                    if(splits==null)splits=staged.createDirectory("splits");
                    if(splits==null)throw new IOException("Cannot create split APK folder");
                    dir=splits;
                }
                String fileName=i==0?"base.apk":input.relative.substring("splits/".length());
                DocumentFile dest=dir.createFile(APK_MIME,fileName);
                if(dest==null)throw new IOException("Failed creating "+fileName);
                // Copy exactly the bytes installed on disk; never modify nor re-sign the APK.
                MessageDigest sum=hasher();long written=0;byte[] buf=new byte[64*1024];int n;
                try(InputStream from=new FileInputStream(input.file);
                    OutputStream to=context.getContentResolver().openOutputStream(dest.getUri(),"w")) {
                    if(to==null)throw new IOException("Cannot open destination");
                    while((n=from.read(buf))!=-1) {
                        to.write(buf,0,n);sum.update(buf,0,n);written+=n;
                        final int percent=total==0?0:(int)Math.min(95,(processed+written)*95/total);
                        if(percent!=lastProgress) {
                            progress.update("Backing up "+app.name+" · "+(i+1)+"/"+src.size(),percent);
                            lastProgress=percent;
                        }
                    }
                    to.flush();
                }
                if(written!=verify.bytes || !hex(sum.digest()).equals(verify.sha256)
                        || !shaUri(dest.getUri()).equals(verify.sha256))
                    throw new IOException("Backup integrity failed: "+fileName);
                processed+=written;
            }
            // Icon stored separately: never injected into / re-signed APK.
            try { saveIcon(app,staged); } catch(Exception ignored) { }
            JSONObject metadata=new JSONObject();
            metadata.put("schema",1);metadata.put("package",app.pkg);
            metadata.put("name",app.name); metadata.put("version",app.version);
            metadata.put("versionCode",app.code);metadata.put("backedUpAt",System.currentTimeMillis());
            metadata.put("digest",digest);
            JSONArray parts=new JSONArray();for(Part p:checks)parts.put(p.toJson());
            metadata.put("apks",parts);
            DocumentFile document=staged.createFile("application/json",META);
            if(document==null)throw new IOException("Cannot create archive manifest");
            try(OutputStream os=context.getContentResolver().openOutputStream(document.getUri(),"w")) {
                if(os==null)throw new IOException("Cannot write metadata");
                os.write(metadata.toString(2).getBytes(java.nio.charset.StandardCharsets.UTF_8));
            }
            if(!staged.renameTo(target))throw new IOException("Storage provider could not finalize the backup directory");
            complete=true;
            if(!AppBackupPreferences.keepVersions(context)) {
                for(Archived previous:prior) if(previous.pkg.equals(app.pkg)) previous.folder.delete();
            }
            progress.update("Backup successful: "+app.name,100);
        } finally {
            if(!complete)staged.delete();
        }
    }

    private void saveIcon(Installed app,DocumentFile folder)throws Exception {
        Drawable drawable=app.icon;
        if(drawable==null)return;
        Bitmap bitmap=Bitmap.createBitmap(96,96,Bitmap.Config.ARGB_8888);
        Canvas canvas=new Canvas(bitmap); drawable.setBounds(0,0,96,96);drawable.draw(canvas);
        DocumentFile icon=folder.createFile("image/png","icon.png");
        if(icon!=null)try(OutputStream os=context.getContentResolver().openOutputStream(icon.getUri(),"w")){
            if(os!=null)bitmap.compress(Bitmap.CompressFormat.PNG,100,os);
        }
        bitmap.recycle();
    }
    Drawable archiveIcon(Archived a) {
        if(a.installed) try{return pm.getApplicationIcon(a.pkg);}catch(Exception ignored){}
        DocumentFile icon=a.folder.findFile("icon.png");
        if(icon!=null)try(InputStream stream=context.getContentResolver().openInputStream(icon.getUri())){
            if(stream!=null) {
                android.graphics.Bitmap b=android.graphics.BitmapFactory.decodeStream(stream);
                if(b!=null)return new android.graphics.drawable.BitmapDrawable(context.getResources(),b);
            }
        } catch(Exception ignored) { }
        return context.getDrawable(android.R.drawable.sym_def_app_icon);
    }
    List<Uri> shareUris(Archived a) {
        List<Uri> out=new ArrayList<>();
        for(Part p:a.parts){DocumentFile f=findRelative(a.folder,p.path);if(f!=null)out.add(f.getUri());}
        return out;
    }
    List<Uri> shareInstalled(List<Installed> apps) throws IOException {
        File folder=new File(context.getCacheDir(),"shared_apks");
        if(!folder.isDirectory() && !folder.mkdirs())throw new IOException("Cannot create share cache");
        List<Uri> uris=new ArrayList<>();
        for(Installed app:apps) {
            List<SourcePart> parts=sources(app);
            for(int i=0;i<parts.size();i++) {
                SourcePart src=parts.get(i);
                File dest=new File(folder,ApkBackupRules.safePart(app.pkg)+"_"+app.code+"_"+i+".apk");
                try(InputStream in=new FileInputStream(src.file);
                    OutputStream out=new java.io.FileOutputStream(dest)){
                    byte[] buf=new byte[64*1024];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);
                }
                if(dest.length()!=src.file.length() || !shaFile(dest).equals(shaFile(src.file)))
                    throw new IOException("Share APK integrity mismatch");
                uris.add(androidx.core.content.FileProvider.getUriForFile(context,
                        context.getPackageName()+".fileprovider",dest));
            }
        }
        return uris;
    }
    boolean deleteArchive(Archived a) {
        return a.folder!=null && a.folder.delete();
    }
    void verifyArchive(Archived a,Progress progress) throws IOException {
        for(int i=0;i<a.parts.size();i++) {
            Part p=a.parts.get(i);DocumentFile f=findRelative(a.folder,p.path);
            if(f==null || !f.exists())throw new IOException("Missing APK: "+p.path);
            if(f.length()!=p.bytes || !shaUri(f.getUri()).equalsIgnoreCase(p.sha256))
                throw new IOException("Integrity verification failed: "+p.path);
            progress.update("Verifying "+a.name+" · "+(i+1)+"/"+a.parts.size(),
                    (int)((i+1)*100.0/a.parts.size()));
        }
    }
}
