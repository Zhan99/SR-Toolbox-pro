package com.smarttoolbox.pro;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Pure Java rules shared by the WhatsApp scheduler and its CI tests. */
final class MessageScheduleLogic {
    private MessageScheduleLogic() {}

    static String digitsOnly(String value) {
        if (value == null) return "";
        return value.replaceAll("[^0-9]", "");
    }

    static String normalizePhone(String countryCode, String rawPhone) {
        String raw = rawPhone == null ? "" : rawPhone.trim();
        if (raw.isEmpty()) return "";

        boolean explicitInternational = raw.startsWith("+") || raw.startsWith("00");
        String digits = digitsOnly(raw);
        if (digits.startsWith("00")) digits = digits.substring(2);
        if (digits.isEmpty()) return "";

        String cc = digitsOnly(countryCode);
        if (cc.isEmpty()) cc = "880";

        if (explicitInternational) return digits;
        if (digits.startsWith(cc) && digits.length() > cc.length() + 6) return digits;
        if (digits.startsWith("0")) digits = digits.substring(1);
        return cc + digits;
    }

    static List<String> normalizePhones(String countryCode, String rawPhones) {
        Set<String> unique = new LinkedHashSet<>();
        if (rawPhones == null) return new ArrayList<>();
        String[] parts = rawPhones.split("[,;\\n\\r]+");
        for (String part : parts) {
            String normalized = normalizePhone(countryCode, part);
            if (isValidPhone(normalized)) unique.add(normalized);
        }
        return new ArrayList<>(unique);
    }

    static boolean isValidPhone(String phone) {
        String digits = digitsOnly(phone);
        return digits.length() >= 8 && digits.length() <= 15;
    }

    static boolean isValidMessage(String message) {
        return message != null && !message.trim().isEmpty();
    }

    static boolean isValidFutureTime(long scheduledAtMillis, long nowMillis) {
        return scheduledAtMillis > nowMillis + 1000L;
    }

    /** Returns the next local-calendar occurrence for daily/weekly repeats, or -1 for once. */
    static long nextOccurrence(long previousMillis, String repeatMode, long nowMillis) {
        if (!"daily".equals(repeatMode) && !"weekly".equals(repeatMode)) return -1L;
        Calendar next = Calendar.getInstance();
        next.setTimeInMillis(previousMillis);
        int field = "daily".equals(repeatMode) ? Calendar.DAY_OF_YEAR : Calendar.WEEK_OF_YEAR;
        int amount = 1;
        int guard = 0;
        do {
            next.add(field, amount);
            guard++;
        } while (next.getTimeInMillis() <= nowMillis && guard < 520);
        return guard >= 520 ? -1L : next.getTimeInMillis();
    }

    static String buildWhatsAppUrl(String normalizedPhone, String message) {
        String phone = digitsOnly(normalizedPhone);
        if (!isValidPhone(phone)) throw new IllegalArgumentException("Invalid WhatsApp phone number");
        if (!isValidMessage(message)) throw new IllegalArgumentException("Message is empty");
        try {
            String encoded = URLEncoder.encode(message.trim(), StandardCharsets.UTF_8.name())
                    .replace("+", "%20");
            return "https://wa.me/" + phone + "?text=" + encoded;
        } catch (Exception error) {
            throw new IllegalArgumentException("Unable to encode WhatsApp message", error);
        }
    }

    static int stableAlarmId(String id) {
        int hash = id == null ? 0 : id.hashCode();
        return 10000 + (hash & 0x3fffffff);
    }

    static String repeatLabel(String repeatMode) {
        if ("daily".equals(repeatMode)) return "প্রতিদিন";
        if ("weekly".equals(repeatMode)) return "প্রতি সপ্তাহে";
        return "একবার";
    }

    static String messagePreview(String message, int maxChars) {
        if (message == null) return "";
        String compact = message.trim().replaceAll("\\s+", " ");
        if (compact.length() <= maxChars) return compact;
        return compact.substring(0, Math.max(0, maxChars - 1)) + "…";
    }
}
