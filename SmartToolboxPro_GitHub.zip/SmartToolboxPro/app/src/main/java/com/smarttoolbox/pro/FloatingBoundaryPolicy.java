package com.smarttoolbox.pro;

/** Preserve user's explicit hold-to-move choice over automatic border docking. */
final class FloatingBoundaryPolicy {
    static final String PREF_MANUAL_POSITION = "floating.manual_position_override";
    private FloatingBoundaryPolicy() {}

    static boolean shouldAutoDock(boolean edgeModeEnabled, boolean manuallyMoved,
                                  boolean panelOpen, boolean touching) {
        return edgeModeEnabled && !manuallyMoved && !panelOpen && !touching;
    }

    static int clamp(int coord, int size, int displaySize) {
        return Math.max(0, Math.min(coord, Math.max(0, displaySize - Math.max(0, size))));
    }

    static int edgeX(int currentX, int iconSize, int displayWidth) {
        int maxX = Math.max(0, displayWidth - Math.max(0, iconSize));
        return currentX + Math.max(0, iconSize) / 2 < displayWidth / 2 ? 0 : maxX;
    }
}
