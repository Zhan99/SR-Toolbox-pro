package com.smarttoolbox.pro;
/** Language, text and notification labels shared by UI, service and voice player. */
final class FullChargeLanguageLogic {
    static final String BANGLA = "bn";
    static final String ENGLISH = "en";
    static final String BOTH = "both";
    private FullChargeLanguageLogic() { }
    static String normalize(String s) {
        return BOTH.equalsIgnoreCase(s) ? BOTH
                : (ENGLISH.equalsIgnoreCase(s) ? ENGLISH : BANGLA);
    }
    static String speech(String s) {
        String language = normalize(s);
        if (BOTH.equals(language)) return speech(BANGLA) + " " + speech(ENGLISH);
        return ENGLISH.equals(language)
                ? "The battery is fully charged. Please unplug your charger."
                : "ব্যাটারি ফুল চার্জ হয়েছে, চার্জ থেকে খুলুন।";
    }
    static String fullTitle(String s) {
        if (BOTH.equals(normalize(s))) return "ব্যাটারি পূর্ণ · Battery fully charged";
        return ENGLISH.equals(normalize(s)) ? "Battery fully charged — unplug charger"
                : "ব্যাটারি ১০০% — চার্জ থেকে খুলুন";
    }
    static String monitorTitle(String s) {
        if (BOTH.equals(normalize(s))) return "SR Full Charge · ফুল চার্জ ভয়েস";
        return ENGLISH.equals(normalize(s)) ? "SR Full Charge Voice Alert"
                : "SR ফুল চার্জ ভয়েস অ্যালার্ট";
    }
    static String monitoring(String s) {
        if (BOTH.equals(normalize(s))) return "Monitoring · চার্জ ১০০% হলে ভয়েস";
        return ENGLISH.equals(normalize(s)) ? "Monitoring charge · voice at 100%"
                : "চার্জ মনিটরিং চালু · ১০০% হলে ভয়েস";
    }
    static String progress(String s, boolean plugged, boolean full) {
        if (BOTH.equals(normalize(s))) return progress(BANGLA, plugged, full)
                + " / " + progress(ENGLISH, plugged, full);
        if (ENGLISH.equals(normalize(s))) {
            return !plugged ? "Charger disconnected" : full
                    ? "Battery full · unplug charger" : "Charging · voice alert at 100%";
        }
        return !plugged ? "চার্জার সংযুক্ত নেই" : full
                ? "ব্যাটারি পূর্ণ · চার্জ থেকে খুলুন" : "চার্জ হচ্ছে · পূর্ণ হলে সতর্ক করবে";
    }
    static String stop(String s) {
        if (BOTH.equals(normalize(s))) return "Stop / বন্ধ";
        return ENGLISH.equals(normalize(s)) ? "Stop monitoring" : "বন্ধ করুন";
    }
}
