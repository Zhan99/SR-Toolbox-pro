package com.smarttoolbox.pro;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** Backup-specific preferences + SAF local storage selection. */
public final class AppBackupSettingsActivity extends Activity {
    private static final int PICK_DIRECTORY = 5701;
    private LinearLayout content;
    @Override public void onCreate(Bundle state) {
        ThemeManager.applyToActivity(this); super.onCreate(state);
        LinearLayout root=Ui.page(this,"⚙ Backup Settings");
        content=Ui.content(root);setContentView(root);render();
    }
    private void render() {
        content.removeAllViews();
        Ui.addText(this,content,"Backup Storage Location",19,Ui.TEXT,true,8);
        Uri uri=AppBackupPreferences.treeUri(this);
        Ui.addText(this,content,uri==null?"No folder selected":
                "Selected folder: "+Uri.decode(uri.getLastPathSegment()),12,Ui.MUTED,false,8);
        Ui.addText(this,content,"Choose local Internal Storage or SD Card in Android's folder picker. "
                +"Backup files are stored inside SR_Apps_Backup. Offline use requires a local provider.",
                12,Ui.MUTED,false,8);
        content.addView(Ui.button(this,"📂 Choose / Change Storage Folder",this::chooseFolder));

        Ui.addText(this,content,"Backup Behaviour",19,Ui.TEXT,true,21);
        toggle("Keep Old Version APK",AppBackupPreferences.keepVersions(this),v->{
            AppBackupPreferences.setKeepVersions(this,v);render();});
        toggle("Show System Apps",AppBackupPreferences.showSystem(this),v->{
            AppBackupPreferences.setShowSystem(this,v);render();});
        toggle("Duplicate Backup Prevention",AppBackupPreferences.preventDuplicates(this),v->{
            AppBackupPreferences.setPreventDuplicates(this,v);render();});
        Ui.addText(this,content,"Turning off Keep Old Version will remove earlier archives for the same "
                +"package only after a new backup completes successfully.",12,Ui.MUTED,false,9);

        Ui.addText(this,content,"Appearance",19,Ui.TEXT,true,22);
        Ui.addText(this,content,"Uses your existing app-wide Theme Studio. Changing it here "
                +"also updates other screens, with Premium/Classic retained.",12,Ui.MUTED,false,5);
        int current=ThemeManager.appearanceMode(this);
        appearance("◐ System Default",ThemeManager.MODE_SYSTEM,current);
        appearance("☀ Light Mode",ThemeManager.MODE_LIGHT,current);
        appearance("☾ Dark Mode",ThemeManager.MODE_DARK,current);
        Ui.addText(this,content,"APK-only backup: no app private data, logins, chats or hidden "
                +"app storage are copied. Installation always needs Android's approval.",12,Ui.MUTED,false,20);
    }
    private interface Setter { void set(boolean value); }
    private void toggle(String text,boolean value,Setter onSet) {
        LinearLayout card=Ui.card(this);
        card.addView(Ui.button(this,(value?"☑ ":"☐ ")+text,()->onSet.set(!value)));
        Ui.addCard(this,content,card,8);
    }
    private void appearance(String text,int mode,int current) {
        LinearLayout card=Ui.card(this);
        card.addView(Ui.button(this,(current==mode?"✓  ":"")+text,()->{
            ThemeManager.saveAppearance(this,mode);
            recreate();
        }));
        Ui.addCard(this,content,card,7);
    }
    private void chooseFolder() {
        try {
            Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    |Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    |Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                    |Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
            startActivityForResult(intent,PICK_DIRECTORY);
        } catch(Exception error){Toast.makeText(this,"No folder picker available",Toast.LENGTH_LONG).show();}
    }
    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if(request==PICK_DIRECTORY && result==RESULT_OK && data!=null && data.getData()!=null) {
            Uri uri=data.getData();
            int grant=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            try {
                if((grant&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION))
                        !=(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION))
                    throw new SecurityException("Folder must allow both read and write");
                getContentResolver().takePersistableUriPermission(uri,grant);
                AppBackupPreferences.saveTree(this,uri);
                new AppBackupRepository(this).selectedTree(true);
                Toast.makeText(this,"Backup folder saved",Toast.LENGTH_SHORT).show();
            } catch(Exception ex){
                AppBackupPreferences.saveTree(this,null);
                Toast.makeText(this,"Folder access failed: "+ex.getMessage(),Toast.LENGTH_LONG).show();
            }
            render();
        }
    }
}
