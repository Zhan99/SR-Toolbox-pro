package com.smarttoolbox.pro;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.HashSet;
import java.util.Set;

/** Calendar record dots and editing yesterday's schedule without changing its clock time. */
final class SchedulerCalendarLogic {
    private SchedulerCalendarLogic() {}

    static Set<LocalDate> markedDates(long[] scheduledMillis, long[] lastTriggeredMillis, ZoneId zone) {
        Set<LocalDate> dates = new HashSet<>();
        if (scheduledMillis != null) for (long millis : scheduledMillis) {
            if (millis > 0) dates.add(toLocalDate(millis, zone));
        }
        if (lastTriggeredMillis != null) for (long millis : lastTriggeredMillis) {
            if (millis > 0) dates.add(toLocalDate(millis, zone));
        }
        return dates;
    }

    static LocalDate toLocalDate(long millis, ZoneId zone) {
        return Instant.ofEpochMilli(millis).atZone(zone).toLocalDate();
    }

    /** Keep a future schedule untouched; rebase an expired one to today or tomorrow,
     * retaining the original local hour/minute. The lead avoids saving a time that
     * becomes past while the user edits the form. */
    static long futureWithOriginalTime(long originalMillis, long nowMillis,
                                       long minimumLeadMillis, ZoneId zone) {
        if (originalMillis > nowMillis + Math.max(0L, minimumLeadMillis)) return originalMillis;
        ZonedDateTime original = Instant.ofEpochMilli(originalMillis).atZone(zone);
        LocalDate today = Instant.ofEpochMilli(nowMillis).atZone(zone).toLocalDate();
        LocalDateTime local = today.atTime(original.getHour(), original.getMinute(), 0);
        long candidate = local.atZone(zone).toInstant().toEpochMilli();
        if (candidate <= nowMillis + Math.max(0L, minimumLeadMillis)) {
            candidate = local.plusDays(1).atZone(zone).toInstant().toEpochMilli();
        }
        return candidate;
    }
}
