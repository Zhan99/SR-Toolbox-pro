package com.smarttoolbox.pro;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

/** Local, private schedule storage and AlarmManager integration. */
final class MessageScheduleStore {
    static final String STATUS_PENDING = "pending";
    static final String STATUS_DUE = "due";
    static final String STATUS_DONE = "done";
    static final String STATUS_ATTEMPTED = "attempted";
    static final String STATUS_PAUSED = "paused";

    private static final String PREFS = "sr_whatsapp_scheduler_v1";
    private static final String KEY_ITEMS = "items_json";

    static final class Item {
        String id;
        int alarmId;
        String contactName;
        String phone;
        String message;
        long scheduledAtMillis;
        String repeatMode;
        String status;
        long lastTriggeredAtMillis;
        String batchId;
        String groupName;
        int batchIndex;
        int batchSize;

        Item(String id, int alarmId, String contactName, String phone, String message,
             long scheduledAtMillis, String repeatMode, String status, long lastTriggeredAtMillis) {
            this(id, alarmId, contactName, phone, message, scheduledAtMillis, repeatMode,
                    status, lastTriggeredAtMillis, "", 1, 1);
        }

        Item(String id, int alarmId, String contactName, String phone, String message,
             long scheduledAtMillis, String repeatMode, String status, long lastTriggeredAtMillis,
             String batchId, int batchIndex, int batchSize) {
            this.id = id;
            this.alarmId = alarmId;
            this.contactName = contactName == null ? "" : contactName;
            this.phone = phone == null ? "" : phone;
            this.message = message == null ? "" : message;
            this.scheduledAtMillis = scheduledAtMillis;
            this.repeatMode = repeatMode == null ? "once" : repeatMode;
            this.status = status == null ? STATUS_PENDING : status;
            this.lastTriggeredAtMillis = lastTriggeredAtMillis;
            this.batchId = batchId == null ? "" : batchId;
            this.groupName = "";
            this.batchIndex = Math.max(1, batchIndex);
            this.batchSize = Math.max(1, batchSize);
        }

        static Item create(String name, String phone, String message, long when, String repeatMode) {
            return createBatch(name, phone, message, when, repeatMode, "", 1, 1);
        }

        static Item createBatch(String name, String phone, String message, long when,
                                String repeatMode, String batchId, int batchIndex, int batchSize) {
            String id = UUID.randomUUID().toString();
            return new Item(id, MessageScheduleLogic.stableAlarmId(id), name, phone, message,
                    when, repeatMode, STATUS_PENDING, 0L, batchId, batchIndex, batchSize);
        }
    }

    private MessageScheduleStore() {}

    static synchronized List<Item> getAll(Context context) {
        List<Item> result = new ArrayList<>();
        try {
            String raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .getString(KEY_ITEMS, "[]");
            JSONArray array = new JSONArray(raw == null ? "[]" : raw);
            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.optJSONObject(i);
                if (obj == null) continue;
                String id = obj.optString("id", "");
                if (id.isEmpty()) continue;
                result.add(new Item(
                        id,
                        obj.optInt("alarmId", MessageScheduleLogic.stableAlarmId(id)),
                        obj.optString("contactName", ""),
                        obj.optString("phone", ""),
                        obj.optString("message", ""),
                        obj.optLong("scheduledAtMillis", 0L),
                        obj.optString("repeatMode", "once"),
                        obj.optString("status", STATUS_PENDING),
                        obj.optLong("lastTriggeredAtMillis", 0L),
                        obj.optString("batchId", ""),
                        obj.optInt("batchIndex", 1),
                        obj.optInt("batchSize", 1)
                ));
                String legacyGroupName = obj.optString("batchId", "").isEmpty()
                        ? "" : obj.optString("contactName", "");
                result.get(result.size() - 1).groupName = GroupScheduleLogic.cleanGroupName(
                        obj.optString("groupName", legacyGroupName));
            }
        } catch (Exception ignored) {}
        return result;
    }

    static synchronized Item get(Context context, String id) {
        for (Item item : getAll(context)) {
            if (item.id.equals(id)) return item;
        }
        return null;
    }

    static synchronized void save(Context context, Item item) {
        List<Item> items = getAll(context);
        boolean replaced = false;
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).id.equals(item.id)) {
                items.set(i, item);
                replaced = true;
                break;
            }
        }
        if (!replaced) items.add(0, item);
        saveAll(context, items);
    }

    static synchronized void saveAll(Context context, List<Item> items) {
        JSONArray array = new JSONArray();
        try {
            for (Item item : items) {
                JSONObject obj = new JSONObject();
                obj.put("id", item.id);
                obj.put("alarmId", item.alarmId);
                obj.put("contactName", item.contactName);
                obj.put("phone", item.phone);
                obj.put("message", item.message);
                obj.put("scheduledAtMillis", item.scheduledAtMillis);
                obj.put("repeatMode", item.repeatMode);
                obj.put("status", item.status);
                obj.put("lastTriggeredAtMillis", item.lastTriggeredAtMillis);
                obj.put("batchId", item.batchId);
                obj.put("groupName", GroupScheduleLogic.cleanGroupName(item.groupName));
                obj.put("batchIndex", item.batchIndex);
                obj.put("batchSize", item.batchSize);
                array.put(obj);
            }
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .edit().putString(KEY_ITEMS, array.toString()).apply();
        } catch (Exception ignored) {}
    }

    static synchronized void delete(Context context, Item item) {
        if (item == null) return;
        cancel(context, item);
        List<Item> items = getAll(context);
        items.removeIf(existing -> existing.id.equals(item.id));
        saveAll(context, items);
    }

    /** Remove a broadcast as a single UI action while canceling every member alarm. */
    static synchronized void deleteBatch(Context context, String batchId) {
        if (batchId == null || batchId.isEmpty()) return;
        List<Item> items = getAll(context);
        List<Item> keep = new ArrayList<>();
        for (Item item : items) {
            if (batchId.equals(item.batchId)) cancel(context, item);
            else keep.add(item);
        }
        saveAll(context, keep);
    }

    static boolean schedule(Context context, Item item) {
        if (item == null || item.scheduledAtMillis <= System.currentTimeMillis()) return false;
        try {
            AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (manager == null) return false;
            PendingIntent pending = alarmPendingIntent(context, item);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && manager.canScheduleExactAlarms()) {
                manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,
                        item.scheduledAtMillis, pending);
            } else {
                // Android 12+ may deny exact-alarm access. Keep a working, system-throttled reminder.
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,
                        item.scheduledAtMillis, pending);
            }
            manager.cancel(preAlertPendingIntent(context, item));
            // A separate, user-visible three-second pre-send warning, where
            // Android grants sufficiently precise alarm scheduling.
            long previewAt = AutomationRules.preAlertAt(item.scheduledAtMillis);
            if (AutoSendPreferences.enabled(context) && previewAt > System.currentTimeMillis()
                    && (item.batchId == null || item.batchId.isEmpty() || item.batchIndex == 1)) {
                PendingIntent pre = preAlertPendingIntent(context, item);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                        && manager.canScheduleExactAlarms()) {
                    manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, previewAt, pre);
                } else {
                    manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, previewAt, pre);
                }
            }
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }

    static void cancel(Context context, Item item) {
        if (item == null) return;
        try {
            AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (manager != null) {
                manager.cancel(alarmPendingIntent(context, item));
                manager.cancel(preAlertPendingIntent(context, item));
            }
        } catch (Exception ignored) {}
    }

    private static PendingIntent alarmPendingIntent(Context context, Item item) {
        Intent intent = new Intent(context, MessageScheduleReceiver.class)
                .setAction("com.smarttoolbox.pro.MESSAGE_SCHEDULE_" + item.id)
                .putExtra(MessageScheduleReceiver.EXTRA_SCHEDULE_ID, item.id);
        return PendingIntent.getBroadcast(context, item.alarmId, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static PendingIntent preAlertPendingIntent(Context context, Item item) {
        Intent intent = new Intent(context, MessageScheduleReceiver.class)
                .setAction("com.smarttoolbox.pro.MESSAGE_PRE_ALERT_" + item.id)
                .putExtra(MessageScheduleReceiver.EXTRA_SCHEDULE_ID, item.id)
                .putExtra(MessageScheduleReceiver.EXTRA_PRE_ALERT, true)
                .putExtra(MessageScheduleReceiver.EXTRA_EXPECTED_DUE, item.scheduledAtMillis);
        return PendingIntent.getBroadcast(context, item.alarmId, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static synchronized Item onAlarmTriggered(Context context, String id) {
        Item item = get(context, id);
        if (item == null || !STATUS_PENDING.equals(item.status)) return null;

        long now = System.currentTimeMillis();
        item.lastTriggeredAtMillis = now;
        if ("daily".equals(item.repeatMode) || "weekly".equals(item.repeatMode)) {
            long next = MessageScheduleLogic.nextOccurrence(item.scheduledAtMillis,
                    item.repeatMode, now);
            if (next > now) {
                item.scheduledAtMillis = next;
                item.status = STATUS_PENDING;
                save(context, item);
                schedule(context, item);
            } else {
                item.status = STATUS_DUE;
                save(context, item);
            }
        } else {
            item.status = STATUS_DUE;
            save(context, item);
        }
        return item;
    }

    static synchronized void rescheduleAll(Context context) {
        List<Item> items = getAll(context);
        long now = System.currentTimeMillis();
        boolean changed = false;
        for (Item item : items) {
            if (!STATUS_PENDING.equals(item.status)) continue;
            if (item.scheduledAtMillis <= now) {
                if ("daily".equals(item.repeatMode) || "weekly".equals(item.repeatMode)) {
                    long next = MessageScheduleLogic.nextOccurrence(item.scheduledAtMillis,
                            item.repeatMode, now);
                    if (next > now) item.scheduledAtMillis = next;
                    else item.status = STATUS_DUE;
                } else {
                    item.status = STATUS_DUE;
                }
                changed = true;
            }
            if (STATUS_PENDING.equals(item.status)) schedule(context, item);
        }
        if (changed) saveAll(context, items);
    }

    static boolean hasExactAlarmAccess(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true;
        try {
            AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            return manager != null && manager.canScheduleExactAlarms();
        } catch (Exception ignored) {
            return false;
        }
    }
}
