package com.smarttoolbox.pro;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Writes original APK bytes without recompiling/repackaging the APK contents. */
final class ApkArchiveWriter {
    private ApkArchiveWriter() {}

    static void write(String basePath, String[] splitPaths, String metadataJson,
                      OutputStream target) throws IOException {
        verifyReadable(basePath);
        boolean split = ApkBackupLogic.isSplit(splitPaths);
        if (!split) {
            copyFile(basePath, target);
            return;
        }
        if (splitPaths.length > 128) throw new IOException("Too many APK splits");
        for (String path : splitPaths) verifyReadable(path);
        try (ZipOutputStream zip = new ZipOutputStream(target)) {
            zip.putNextEntry(new ZipEntry("info.json"));
            zip.write((metadataJson == null ? "{}" : metadataJson)
                    .getBytes(StandardCharsets.UTF_8));
            zip.closeEntry();
            zip.putNextEntry(new ZipEntry("base.apk"));
            copyFile(basePath, zip);
            zip.closeEntry();
            for (int i = 0; i < splitPaths.length; i++) {
                zip.putNextEntry(new ZipEntry(String.format(Locale.ROOT, "split_%03d.apk", i)));
                copyFile(splitPaths[i], zip);
                zip.closeEntry();
            }
            zip.finish();
        }
    }

    private static void verifyReadable(String source) throws IOException {
        if (source == null || !new File(source).isFile()) {
            throw new IOException("Original installed APK is missing: " + source);
        }
    }
    private static void copyFile(String source, OutputStream target) throws IOException {
        try (InputStream input = new FileInputStream(source)) {
            byte[] bytes = new byte[64 * 1024];
            int n;
            while ((n = input.read(bytes)) != -1) target.write(bytes, 0, n);
        }
    }
}
