package com.smarttoolbox.pro;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Restores pending message reminders after reboot or app replacement. */
public final class MessageScheduleBootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(action)
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)) {
            MessageScheduleStore.rescheduleAll(context.getApplicationContext());
            // User opted in to this foreground monitor earlier. After reboot or app
            // update attempt to restore it; background start restrictions may veto it.
            if (FullChargeAlertPreferences.enabled(context)) {
                try {
                    Intent monitor = new Intent(context, FullChargeVoiceService.class);
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                        context.startForegroundService(monitor);
                    } else {
                        context.startService(monitor);
                    }
                } catch (RuntimeException ignored) {
                    // Android/OEM background-start restrictions: user can re-enable
                    // from the visible Full Charge Alert page, no crash on boot.
                }
            }
        }
    }
}
