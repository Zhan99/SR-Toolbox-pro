package com.smarttoolbox.pro;

import java.io.*;
import java.util.zip.*;

/** Copies original signed APK bytes without modification or re-signing. */
final class AppsBackupPayload {
    private AppsBackupPayload() {}
    static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[65536];
        int n;
        while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
    }
    static void writeBase(String[] paths, OutputStream out) throws IOException {
        if (paths == null || paths.length == 0 || paths[0] == null
                || paths[0].isEmpty()) throw new IOException("No base APK available");
        try (InputStream in = new FileInputStream(paths[0])) { copy(in, out); }
    }
    static void writeFull(String[] paths, OutputStream out) throws IOException {
        if (paths == null || paths.length == 0) throw new IOException("No APK available");
        if (paths.length == 1) { writeBase(paths, out); return; }
        try (ZipOutputStream zip = new ZipOutputStream(out)) {
            for (int i = 0; i < paths.length; i++) {
                zip.putNextEntry(new ZipEntry(i == 0 ? "base.apk" : "split_" + i + ".apk"));
                try (InputStream in = new FileInputStream(paths[i])) { copy(in, zip); }
                zip.closeEntry();
            }
        }
    }
}
