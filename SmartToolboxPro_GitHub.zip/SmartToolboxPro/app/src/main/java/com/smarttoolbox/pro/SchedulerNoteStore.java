package com.smarttoolbox.pro;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/** Device-local note store. Does not request contacts, SMS, files or network access. */
final class SchedulerNoteStore {
    private static final String FILE = "sr_scheduler_notepad_v1";
    private static final String KEY = "notes";

    static final class Note {
        final String id;
        final String title;
        final String body;
        final long createdAt;
        final long updatedAt;

        Note(String id, String title, String body, long createdAt, long updatedAt) {
            this.id = id;
            this.title = title;
            this.body = body;
            this.createdAt = createdAt;
            this.updatedAt = updatedAt;
        }
    }

    private SchedulerNoteStore() { }

    private static SharedPreferences preferences(Context context) {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    static synchronized List<Note> all(Context context) {
        List<Note> notes = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(preferences(context).getString(KEY, "[]"));
            for (int i = 0; i < array.length(); i++) {
                JSONObject o = array.optJSONObject(i);
                if (o == null) continue;
                String id = o.optString("id", "");
                String body = o.optString("body", "");
                if (id.isEmpty() || !SchedulerNoteLogic.valid(body)) continue;
                notes.add(new Note(id, o.optString("title", ""), body,
                        o.optLong("createdAt", 0L), o.optLong("updatedAt", 0L)));
            }
        } catch (Exception ignored) {
            // A corrupt or older value must never crash the scheduler.
        }
        Collections.sort(notes, (left, right) -> Long.compare(right.updatedAt, left.updatedAt));
        return notes;
    }

    static synchronized boolean save(Context context, String id, String rawTitle, String rawBody) {
        if (!SchedulerNoteLogic.valid(rawBody)) return false;
        List<Note> notes = all(context);
        long now = System.currentTimeMillis();
        String noteId = id == null || id.isEmpty() ? UUID.randomUUID().toString() : id;
        long created = now;
        for (int i = 0; i < notes.size(); i++) {
            Note old = notes.get(i);
            if (old.id.equals(noteId)) {
                created = old.createdAt;
                notes.remove(i);
                break;
            }
        }
        if (notes.size() >= SchedulerNoteLogic.MAX_NOTES) return false;
        String body = SchedulerNoteLogic.body(rawBody);
        String title = SchedulerNoteLogic.title(rawTitle);
        if (title.isEmpty()) title = SchedulerNoteLogic.title(SchedulerNoteLogic.preview(body));
        notes.add(0, new Note(noteId, title, body, created, now));
        return write(context, notes);
    }

    static synchronized boolean delete(Context context, String id) {
        List<Note> notes = all(context);
        boolean removed = notes.removeIf(note -> note.id.equals(id));
        return removed && write(context, notes);
    }

    private static boolean write(Context context, List<Note> notes) {
        try {
            JSONArray arr = new JSONArray();
            for (Note note : notes) {
                JSONObject obj = new JSONObject();
                obj.put("id", note.id);
                obj.put("title", note.title);
                obj.put("body", note.body);
                obj.put("createdAt", note.createdAt);
                obj.put("updatedAt", note.updatedAt);
                arr.put(obj);
            }
            return preferences(context).edit().putString(KEY, arr.toString()).commit();
        } catch (Exception ignored) {
            return false;
        }
    }
}
