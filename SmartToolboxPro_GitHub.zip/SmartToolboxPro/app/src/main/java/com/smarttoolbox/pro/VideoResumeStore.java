package com.smarttoolbox.pro;

import android.content.Context;
import android.content.SharedPreferences;

/** Private on-device playback bookmarks, kept independently for each video URI. */
final class VideoResumeStore {
    private static final String PREFERENCES = "sr_video_per_file_positions";

    private VideoResumeStore() {}

    static long get(Context context, String uri) {
        if (uri == null || uri.isEmpty()) return 0L;
        SharedPreferences prefs = context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE);
        return Math.max(0L, prefs.getLong(VideoResumeLogic.keyForUri(uri), 0L));
    }

    static void put(Context context, String uri, long positionMs, long durationMs, boolean ended) {
        if (uri == null || uri.isEmpty()) return;
        long saved = VideoResumeLogic.positionToSave(positionMs, durationMs, ended);
        context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE).edit()
                .putLong(VideoResumeLogic.keyForUri(uri), saved).apply();
    }
}
