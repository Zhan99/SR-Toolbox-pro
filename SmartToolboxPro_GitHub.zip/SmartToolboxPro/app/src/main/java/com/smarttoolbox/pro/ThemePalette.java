package com.smarttoolbox.pro;

/** SR palettes. The first five indexes are preserved for existing saved theme preferences. */
final class ThemePalette {
    static final String[] NAMES = {
            "Midnight Gold", "Ocean Blue", "Emerald Green", "Royal Purple", "Light Day",
            "Sunset Coral", "Graphite Cyan", "Rose Quartz", "Arctic Mint"
    };
    private static final int[][] DARK = {
        {0xFF090D12, 0xFF171D25, 0xFF1F2630, 0xFFF5F7FA, 0xFF9DA8B5, 0xFFFFC247, 0xFF5AD291},
        {0xFF071827, 0xFF13283C, 0xFF1B354D, 0xFFF3FAFF, 0xFFA6BDCF, 0xFF48B8FF, 0xFF51D5BF},
        {0xFF071811, 0xFF11271E, 0xFF1B352A, 0xFFF2FFF8, 0xFFA0BFAE, 0xFF65E2A2, 0xFF65E2A2},
        {0xFF140C26, 0xFF241A37, 0xFF34284C, 0xFFF9F5FF, 0xFFB7A7D1, 0xFFC19BFF, 0xFF84E0D0},
        {0xFF101820, 0xFF1B2732, 0xFF263542, 0xFFF5F8FC, 0xFFAAB8C6, 0xFF4A91E8, 0xFF4DC5A5},
        {0xFF21110F, 0xFF34201D, 0xFF49302B, 0xFFFFF5F1, 0xFFD5B8AE, 0xFFFF806B, 0xFF74D7A1},
        {0xFF11171B, 0xFF202A30, 0xFF2C3940, 0xFFF2F8FA, 0xFFA5B7BF, 0xFF52D5E5, 0xFF73D6A8},
        {0xFF21131C, 0xFF34212D, 0xFF493040, 0xFFFFF5FA, 0xFFD6B9C8, 0xFFFF8DB8, 0xFF8EDDB8},
        {0xFF081C1B, 0xFF14302D, 0xFF1F4440, 0xFFF1FFFC, 0xFFA6C9C2, 0xFF67DCC6, 0xFF8DE0A8}
    };
    private static final int[][] LIGHT_SURFACES = {
        {0xFFF6F8FC, 0xFFFFFFFF, 0xFFEAF0F7, 0xFF202B3A, 0xFF657489},
        {0xFFF2F8FD, 0xFFFFFFFF, 0xFFE5F1FA, 0xFF1B2C3B, 0xFF60788D},
        {0xFFF2FAF5, 0xFFFFFFFF, 0xFFE5F3EA, 0xFF1D3328, 0xFF617A6C},
        {0xFFF8F5FC, 0xFFFFFFFF, 0xFFEDE7F7, 0xFF302642, 0xFF766A89},
        {0xFFF7FAFE, 0xFFFFFFFF, 0xFFEAF1FA, 0xFF202B3A, 0xFF657489},
        {0xFFFFF6F3, 0xFFFFFFFF, 0xFFFCE8E2, 0xFF3C2925, 0xFF8B6B63},
        {0xFFF4F8FA, 0xFFFFFFFF, 0xFFE7EFF2, 0xFF24333A, 0xFF657B83},
        {0xFFFFF5F9, 0xFFFFFFFF, 0xFFF8E7EF, 0xFF3D2A35, 0xFF8A6C7B},
        {0xFFF1FAF8, 0xFFFFFFFF, 0xFFE2F2EE, 0xFF1F3733, 0xFF617D76}
    };
    private ThemePalette() {}
    static int count() { return NAMES.length; }
    static int safeIndex(int id) { return id >= 0 && id < NAMES.length ? id : 0; }
    static String name(int id) { return NAMES[safeIndex(id)]; }
    static int[] colors(int id) { return colors(id, id == 4); }
    static int[] colors(int id, boolean light) {
        int index = safeIndex(id);
        int[] result = new int[7];
        int[] surfaces = light ? LIGHT_SURFACES[index] : DARK[index];
        System.arraycopy(surfaces, 0, result, 0, 5);
        result[5] = DARK[index][5];
        result[6] = DARK[index][6];
        return result;
    }
    /** Legacy semantic: index 4 is the original Light Day preset. */
    static boolean isLight(int id) { return safeIndex(id) == 4; }
}
