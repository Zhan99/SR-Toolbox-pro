package com.smarttoolbox.pro;

import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings;

/**
 * Optional, user-authorized system brightness adjustment.
 * The previous setting is persisted so a service stop cannot forget it.
 * No device settings are changed until the user grants WRITE_SETTINGS.
 */
final class NightBrightnessController {
    static final String PREFS = "night_brightness_backup_v1";
    private static final String KEY_SAVED = "backup_saved";
    private static final String KEY_BRIGHTNESS = "previous_brightness";
    private static final String KEY_MODE = "previous_mode";
    private NightBrightnessController() { }

    static boolean hasPermission(Context context) {
        try { return Settings.System.canWrite(context); }
        catch (Exception denied) { return false; }
    }

    static synchronized boolean applyMinimum(Context context) {
        if (!hasPermission(context)) return false;
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        try {
            // Critical: multiple level updates or startService calls must never
            // overwrite the ORIGINAL brightness with our own minimum setting.
            if (prefs.getBoolean(KEY_SAVED, false)) return true;
            int oldBrightness = Settings.System.getInt(context.getContentResolver(),
                    Settings.System.SCREEN_BRIGHTNESS);
            int oldMode = Settings.System.getInt(context.getContentResolver(),
                    Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
            if (!prefs.edit().putInt(KEY_BRIGHTNESS, oldBrightness)
                    .putInt(KEY_MODE, oldMode).putBoolean(KEY_SAVED, true).commit()) return false;
            boolean modeOk = Settings.System.putInt(context.getContentResolver(),
                    Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
            boolean brightOk = modeOk && Settings.System.putInt(context.getContentResolver(),
                    Settings.System.SCREEN_BRIGHTNESS, NightBrightnessPolicy.MIN_BRIGHTNESS);
            if (!brightOk) {
                rollbackFailedApply(context, prefs, oldBrightness, oldMode);
                return false;
            }
            return true;
        } catch (Exception failure) {
            restore(context);
            return false;
        }
    }

    private static void rollbackFailedApply(Context context, SharedPreferences prefs,
                                            int originalBrightness, int originalMode) {
        try {
            int currently = Settings.System.getInt(context.getContentResolver(),
                    Settings.System.SCREEN_BRIGHTNESS, originalBrightness);
            boolean first = currently == originalBrightness || Settings.System.putInt(
                    context.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS,
                    NightBrightnessPolicy.safeBrightness(originalBrightness));
            boolean second = Settings.System.putInt(context.getContentResolver(),
                    Settings.System.SCREEN_BRIGHTNESS_MODE,
                    NightBrightnessPolicy.safeMode(originalMode));
            if (first && second) {
                prefs.edit().remove(KEY_SAVED).remove(KEY_BRIGHTNESS).remove(KEY_MODE).commit();
            }
        } catch (Exception ignored) { /* Snapshot retained for later restore. */ }
    }

    static synchronized boolean hasSnapshot(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean(KEY_SAVED, false);
    }

    static synchronized void restore(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (!prefs.getBoolean(KEY_SAVED, false)) return;
        // Keep snapshot if settings permission was revoked, for recovery after
        // permission is re-granted. Do not pretend restoration succeeded.
        if (!hasPermission(context)) return;
        try {
            int currentBrightness = Settings.System.getInt(context.getContentResolver(),
                    Settings.System.SCREEN_BRIGHTNESS, NightBrightnessPolicy.MIN_BRIGHTNESS);
            int currentMode = Settings.System.getInt(context.getContentResolver(),
                    Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
            if (NightBrightnessPolicy.shouldRestore(true, true, currentBrightness, currentMode)) {
                int originalBrightness = prefs.getInt(KEY_BRIGHTNESS, 128);
                int originalMode = prefs.getInt(KEY_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
                boolean brightnessRestored = Settings.System.putInt(context.getContentResolver(),
                        Settings.System.SCREEN_BRIGHTNESS,
                        NightBrightnessPolicy.safeBrightness(originalBrightness));
                boolean modeRestored = brightnessRestored && Settings.System.putInt(
                        context.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE,
                        NightBrightnessPolicy.safeMode(originalMode));
                if (!modeRestored) return; // Retry if the user grants access again.
            }
            // A user-edited brightness takes priority over our old snapshot.
            prefs.edit().remove(KEY_SAVED).remove(KEY_BRIGHTNESS).remove(KEY_MODE).commit();
        } catch (Exception ignored) { /* Preserve snapshot for the next recovery attempt. */ }
    }
}
