package com.smarttoolbox.pro;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.List;

/** Local, permission-free per-URI NEW flags for the phone video library. */
final class VideoFreshnessStore {
    private static final String PREFERENCES = "sr_video_library_new_v1";
    private static final String INITIALIZED = "initial_scan_done";
    private VideoFreshnessStore() {}
    private static String key(String uri) { return VideoResumeLogic.keyForUri(uri); }

    /** Only call after a successful MediaStore scan; first scan is the baseline. */
    static void recordSuccessfulScan(Context context, List<String> videoUris) {
        SharedPreferences prefs = context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE);
        boolean initialized = prefs.getBoolean(INITIALIZED, false);
        SharedPreferences.Editor edits = prefs.edit();
        for (String uri : videoUris) {
            if (uri == null || uri.isEmpty()) continue;
            String id = key(uri);
            boolean known = prefs.getBoolean("known." + id, false);
            boolean watched = prefs.getBoolean("watched." + id, false);
            if (!known) {
                edits.putBoolean("known." + id, true);
                if (VideoFreshnessLogic.markNew(initialized, known, watched)) {
                    edits.putBoolean("new." + id, true);
                }
            }
        }
        edits.putBoolean(INITIALIZED, true).apply();
    }

    static boolean isNew(Context context, String uri) {
        if (uri == null || uri.isEmpty()) return false;
        SharedPreferences prefs = context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE);
        String id = key(uri);
        return prefs.getBoolean("new." + id, false)
                && !prefs.getBoolean("watched." + id, false);
    }

    /** Invoked only when playback actually begins, not when a file is tapped. */
    static void markViewed(Context context, String uri) {
        if (uri == null || uri.isEmpty() || !uri.startsWith("content://")) return;
        String id = key(uri);
        context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE).edit()
                .putBoolean("watched." + id, true).putBoolean("known." + id, true)
                .remove("new." + id).apply();
    }
}
