package com.smarttoolbox.pro;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Local encrypted experimental PIN storage. Never logs, backs up or exports PIN bytes.
 * Keystore encryption protects the stored blob, but an enabled app/service may still
 * access the decrypted PIN. This is a serious security trade-off and opt-in only.
 */
final class SecurePinVault {
    private static final String KEY_ALIAS = "sr_automation_pin_aes_v1";
    private static final String PREFS = "sr_private_pin_v1";
    private static final String VALUE = "pin_blob";
    private SecurePinVault() { }

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
    private static SecretKey key() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        java.security.Key existing = store.getKey(KEY_ALIAS, null);
        if (existing instanceof SecretKey) return (SecretKey) existing;
        KeyGenerator generator = KeyGenerator.getInstance(
                KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build());
        return generator.generateKey();
    }
    static synchronized boolean store(Context context, char[] pin) {
        if (!AutomationRules.validPin(pin)) return false;
        byte[] plain = new String(pin).getBytes(StandardCharsets.UTF_8);
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, key());
            byte[] nonce = cipher.getIV();
            byte[] encrypted = cipher.doFinal(plain);
            prefs(context).edit().putString(VALUE,
                    Base64.encodeToString(nonce, Base64.NO_WRAP) + "."
                            + Base64.encodeToString(encrypted, Base64.NO_WRAP)).apply();
            return true;
        } catch (Exception error) {
            return false;
        } finally {
            Arrays.fill(plain, (byte) 0);
        }
    }
    static synchronized char[] read(Context context) {
        String stored = prefs(context).getString(VALUE, "");
        if (stored == null || stored.isEmpty()) return null;
        byte[] clear = null;
        try {
            String[] pieces = stored.split("\\.", -1);
            if (pieces.length != 2) return null;
            byte[] nonce = Base64.decode(pieces[0], Base64.NO_WRAP);
            byte[] ciphertext = Base64.decode(pieces[1], Base64.NO_WRAP);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, nonce));
            clear = cipher.doFinal(ciphertext);
            char[] pin = new String(clear, StandardCharsets.UTF_8).toCharArray();
            if (!AutomationRules.validPin(pin)) {
                Arrays.fill(pin, '\0');
                return null;
            }
            return pin;
        } catch (Exception error) {
            return null;
        } finally {
            if (clear != null) Arrays.fill(clear, (byte) 0);
        }
    }
    static boolean exists(Context context) {
        return prefs(context).contains(VALUE);
    }
    static void clear(Context context) {
        prefs(context).edit().remove(VALUE).apply();
        try {
            KeyStore store = KeyStore.getInstance("AndroidKeyStore");
            store.load(null);
            if (store.containsAlias(KEY_ALIAS)) store.deleteEntry(KEY_ALIAS);
        } catch (Exception ignored) { }
        AutoSendPreferences.setExperimentalUnlock(context, false);
    }
}
