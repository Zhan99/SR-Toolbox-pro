package com.smarttoolbox.pro;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.time.DayOfWeek;
import java.time.Instant;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** A custom date picker because Android's stock DatePicker does not support day dots. */
final class SchedulerRecordCalendar {
    interface OnPick { void picked(LocalDate date); }
    private SchedulerRecordCalendar() {}

    static void show(Activity activity, long selectedMillis,
                     List<MessageScheduleStore.Item> items, OnPick onPick) {
        ZoneId zone = ZoneId.systemDefault();
        long[] scheduled = new long[items.size()];
        long[] triggered = new long[items.size()];
        for (int i = 0; i < items.size(); i++) {
            scheduled[i] = items.get(i).scheduledAtMillis;
            triggered[i] = items.get(i).lastTriggeredAtMillis;
        }
        Set<LocalDate> marked = SchedulerCalendarLogic.markedDates(scheduled, triggered, zone);
        LocalDate selected = Instant.ofEpochMilli(selectedMillis).atZone(zone).toLocalDate();
        YearMonth[] visible = {YearMonth.from(selected)};

        LinearLayout root = new LinearLayout(activity);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(Ui.dp(activity, 12), Ui.dp(activity, 10), Ui.dp(activity, 12),
                Ui.dp(activity, 8));
        LinearLayout controls = new LinearLayout(activity);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        TextView previous = navigation(activity, "‹");
        TextView next = navigation(activity, "›");
        TextView title = Ui.text(activity, "", 17, Ui.TEXT, true);
        title.setGravity(Gravity.CENTER);
        controls.addView(previous, new LinearLayout.LayoutParams(Ui.dp(activity, 44), Ui.dp(activity, 44)));
        controls.addView(title, new LinearLayout.LayoutParams(0, Ui.dp(activity, 44), 1f));
        controls.addView(next, new LinearLayout.LayoutParams(Ui.dp(activity, 44), Ui.dp(activity, 44)));
        root.addView(controls);

        LinearLayout weekdayRow = new LinearLayout(activity);
        String[] dayNames = {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"};
        for (String name : dayNames) {
            TextView text = Ui.text(activity, name, 12, Ui.MUTED, true);
            text.setGravity(Gravity.CENTER);
            weekdayRow.addView(text, new LinearLayout.LayoutParams(0, Ui.dp(activity, 31), 1));
        }
        root.addView(weekdayRow);
        LinearLayout dates = new LinearLayout(activity);
        dates.setOrientation(LinearLayout.VERTICAL);
        root.addView(dates);
        TextView legend = Ui.text(activity,
                "● = এই তারিখে সেভ করা মেসেজ/History আছে (ডেলিভারি নিশ্চিত নয়)",
                12, Ui.ACCENT, false);
        legend.setPadding(0, Ui.dp(activity, 8), 0, 0);
        root.addView(legend);
        AlertDialog dialog = new AlertDialog.Builder(activity)
                .setTitle("📅 Schedule Calendar")
                .setView(root)
                .setNegativeButton("Cancel", null)
                .create();
        Runnable draw = new Runnable() {
            @Override public void run() {
                YearMonth month = visible[0];
                title.setText(month.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.getDefault())));
                dates.removeAllViews();
                LocalDate first = month.atDay(1);
                int offset = first.getDayOfWeek().getValue() - DayOfWeek.MONDAY.getValue();
                LocalDate start = first.minusDays(offset);
                for (int row = 0; row < 6; row++) {
                    LinearLayout line = new LinearLayout(activity);
                    for (int col = 0; col < 7; col++) {
                        LocalDate day = start.plusDays(row * 7L + col);
                        boolean sameMonth = YearMonth.from(day).equals(month);
                        boolean hasRecord = marked.contains(day);
                        TextView cell = Ui.text(activity,
                                day.getDayOfMonth() + (hasRecord ? "\n●" : "\n "),
                                14, sameMonth ? Ui.TEXT : Ui.MUTED, day.equals(selected));
                        cell.setGravity(Gravity.CENTER);
                        cell.setTextColor(hasRecord ? Ui.ACCENT : sameMonth ? Ui.TEXT : Ui.MUTED);
                        cell.setContentDescription(day + (hasRecord ? ", recorded messages" : ""));
                        if (day.equals(selected)) {
                            GradientDrawable bg = new GradientDrawable();
                            bg.setColor(Ui.CARD_2);
                            bg.setCornerRadius(Ui.dp(activity, 13));
                            bg.setStroke(Ui.dp(activity, 1), Ui.ACCENT);
                            cell.setBackground(bg);
                        }
                        cell.setClickable(true);
                        cell.setOnClickListener(v -> {
                            onPick.picked(day);
                            dialog.dismiss();
                        });
                        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                                0, Ui.dp(activity, 48), 1f);
                        lp.setMargins(Ui.dp(activity, 1), Ui.dp(activity, 1),
                                Ui.dp(activity, 1), Ui.dp(activity, 1));
                        line.addView(cell, lp);
                    }
                    dates.addView(line);
                }
            }
        };
        previous.setOnClickListener(v -> { visible[0] = visible[0].minusMonths(1); draw.run(); });
        next.setOnClickListener(v -> { visible[0] = visible[0].plusMonths(1); draw.run(); });
        draw.run();
        dialog.show();
    }

    private static TextView navigation(Activity activity, String label) {
        TextView view = Ui.text(activity, label, 27, Ui.ACCENT, true);
        view.setGravity(Gravity.CENTER);
        view.setClickable(true);
        return view;
    }
}
