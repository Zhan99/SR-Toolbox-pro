package com.smarttoolbox.pro;

import android.Manifest;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.AppOpsManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.view.View;
import java.util.List;

/** Single, feature-labelled permission overview; only requests an actual permission on tap. */
public final class AppPermissionsActivity extends Activity {
    private LinearLayout body;
    private int themeKey;
    private static final int REQ_CONTACTS=1401,REQ_NOTIFICATIONS=1402,REQ_VIDEOS=1403;

    @Override public void onCreate(Bundle saved) {
        ThemeManager.applyToActivity(this);
        super.onCreate(saved);
        themeKey=ThemeManager.styleKey(this);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        LinearLayout page=Ui.page(this,"🔐 App Permissions");
        body=Ui.content(page);
        setContentView(page);
        showPermissions();
    }

    @Override protected void onResume() {
        super.onResume();
        if(themeKey!=ThemeManager.styleKey(this)){recreate();return;}
        if(body!=null)showPermissions();
    }

    private boolean granted(String permission) {
        return Build.VERSION.SDK_INT<23 || checkSelfPermission(permission)==PackageManager.PERMISSION_GRANTED;
    }

    private void showPermissions() {
        body.removeAllViews();
        Ui.addText(this,body,"অনুমতি ও কাজের বিবরণ",22,Ui.TEXT,true,5);
        Ui.addText(this,body,"প্রতিটি অনুমতির ওপর লেখা আছে কোন ফিচারের জন্য এটি প্রয়োজন। "
                +"শুধু যে ফিচার ব্যবহার করতে চান, তার অনুমতিই দিন। কিছু System অনুমতি "
                +"Android নিজে নিয়ন্ত্রণ করে—এখান থেকে বদলানো যায় না।",12,Ui.MUTED,false,10);

        boolean overlay=Settings.canDrawOverlays(this);
        item("Floating Toolbox / Night Screen / Scheduler Preview",
                "Display over other apps (SYSTEM_ALERT_WINDOW)",
                "অন্য অ্যাপের ওপর Floating Icon, Screen Dim এবং ঐচ্ছিক Countdown দেখানোর জন্য।",
                overlay?"✓ অনুমতি দেওয়া":"অনুমতি প্রয়োজন",
                true,()->open(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,true));

        item("Night Screen · Minimum Brightness",
                "Modify system settings (WRITE_SETTINGS)",
                "Night Screen চালু থাকলে Brightness সর্বনিম্নে নামানো এবং পরে আগের মান ফেরানোর জন্য।",
                Settings.System.canWrite(this)?"✓ অনুমতি দেওয়া":"অনুমতি প্রয়োজন",
                true,()->open(Settings.ACTION_MANAGE_WRITE_SETTINGS,true));

        boolean contacts=granted(Manifest.permission.READ_CONTACTS);
        item("WhatsApp Scheduler · Phone Contacts",
                "Read contacts (READ_CONTACTS)",
                "শুধুমাত্র আপনার নির্বাচিত Contact-এর নম্বর থেকে শিডিউল তৈরির জন্য।",
                contacts?"✓ অনুমতি দেওয়া":"অনুমতি প্রয়োজন",true,
                ()->ask(new String[]{Manifest.permission.READ_CONTACTS},REQ_CONTACTS));

        boolean exact=Build.VERSION.SDK_INT<31 || ((AlarmManager)getSystemService(ALARM_SERVICE)).canScheduleExactAlarms();
        item("WhatsApp Scheduler · Scheduled reminders",
                "Alarms & reminders (SCHEDULE_EXACT_ALARM)",
                "নির্ধারিত সময়ে মেসেজের Reminder/Countdown ট্রিগার করার জন্য। Android-এ দেরি হতে পারে।",
                exact?"✓ অনুমোদিত":"অনুমতি প্রয়োজন",Build.VERSION.SDK_INT>=31,
                ()->open(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,true));

        item("WhatsApp Scheduler · Experimental Auto Send (optional)",
                "Accessibility Service access",
                "আপনি আলাদাভাবে চালু করলে WhatsApp UI-তে নির্দিষ্ট মেসেজ পাঠানোর চেষ্টা করে। "
                        +"সাধারণ Reminder-এর জন্য এটি বাধ্যতামূলক নয়।",
                schedulerAccessibilityOn()?"✓ Service চালু":"Service বন্ধ",true,
                ()->open(Settings.ACTION_ACCESSIBILITY_SETTINGS,false));

        boolean notification=Build.VERSION.SDK_INT<33 || granted(Manifest.permission.POST_NOTIFICATIONS);
        item("Full Charge Bengali Voice / WhatsApp Reminder / Active tools",
                "Notifications (POST_NOTIFICATIONS)",
                "চার্জ পূর্ণ হওয়ার বার্তা, শিডিউলার Reminder এবং চলমান Service-এর বিজ্ঞপ্তির জন্য।",
                notification?"✓ অনুমতি দেওয়া":"অনুমতি প্রয়োজন",Build.VERSION.SDK_INT>=33,
                ()->ask(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIFICATIONS));

        boolean video=Build.VERSION.SDK_INT>=33?granted(Manifest.permission.READ_MEDIA_VIDEO)
                :granted(Manifest.permission.READ_EXTERNAL_STORAGE);
        boolean partial=Build.VERSION.SDK_INT>=34
                &&granted(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED);
        if(Build.VERSION.SDK_INT>=33){
            item("SR Video Player · All local video files",
                    "READ_MEDIA_VIDEO",
                    "ফোনের সব ভিডিও খুঁজে দেখা ও চালানোর জন্য।",
                    video?"✓ অনুমতি দেওয়া":(partial?"◐ শুধু নির্বাচিত ভিডিও":"অনুমতি প্রয়োজন"),true,
                    this::askVideo);
        }
        if(Build.VERSION.SDK_INT>=34){
            item("SR Video Player · Selected video access",
                    "READ_MEDIA_VISUAL_USER_SELECTED",
                    "Android 14+ এ নির্দিষ্ট ভিডিও নির্বাচনের সীমিত অনুমতি।",
                    partial?"✓ নির্বাচিত ভিডিওতে অনুমতি":"নির্বাচন করা হয়নি",true,this::askVideo);
        }
        if(Build.VERSION.SDK_INT<=32){
            item("SR Video Player · Local videos on older Android",
                    "READ_EXTERNAL_STORAGE (legacy, Android 12 or below)",
                    "পুরোনো Android-এ ভিডিও লাইব্রেরি পড়ার অনুমতি।",
                    video?"✓ অনুমতি দেওয়া":"অনুমতি প্রয়োজন",true,this::askVideo);
        }

        boolean install=Build.VERSION.SDK_INT<26 || getPackageManager().canRequestPackageInstalls();
        item("Apps Backup & Restore · Restore APK",
                "Install unknown apps (REQUEST_INSTALL_PACKAGES)",
                "Backup থেকে APK/APKS ইনস্টল করতে Android-এর আলাদা অনুমতি ও প্রতিবার Confirmation লাগে।",
                install?"✓ ইনস্টল অনুমোদিত":"ইনস্টল অনুমতি প্রয়োজন",Build.VERSION.SDK_INT>=26,
                ()->open(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,true));

        item("Apps Backup & Restore · Installed apps list",
                "Installed app visibility (QUERY_ALL_PACKAGES)",
                "ব্যাকআপের জন্য ফোনের ইনস্টল থাকা অ্যাপগুলোর তালিকা ও APK ফাইল খুঁজে পেতে। "
                        +"এটি Manifest-ঘোষিত System permission; আলাদা Runtime Popup নেই।",
                "Android দ্বারা নিয়ন্ত্রিত",false,null);

        item("Apps Backup & Restore · Backup folder",
                "Public Downloads / user-selected folder access",
                "Android 10+ এ Download/App Backup স্বয়ংক্রিয়ভাবে তৈরি হয়। পুরোনো Android-এ বা "
                        +"অন্য ফোল্ডার চাইলে System File Picker থেকে অনুমতি দিতে হবে। "
                        +"সকল ফাইলের (All Files) অনুমতি লাগে না।",
                "ফাইল সংরক্ষণকালে নির্ধারিত",true,
                ()->startActivity(new Intent(this,AppsBackupActivity.class)));

        item("Apps Backup & Restore · Uninstall selected apps",
                "Delete app request (REQUEST_DELETE_PACKAGES)",
                "ব্যাকআপ স্ক্রিন থেকে Uninstall চাইলে Android প্রতিটি অ্যাপের জন্য Confirmation দেখায়।",
                "প্রতিবার Android নিশ্চিত করে",false,null);

        item("Floating Icon · Swipe-to-Open Feedback",
                "Vibration (VIBRATE)",
                "শুধু Swipe দিয়ে Floating Menu খুললে হালকা ভাইব্রেশন দেওয়ার জন্য। "
                        + "Floating Icon Settings থেকে ON/OFF করা যায়।",
                "Android দ্বারা নিয়ন্ত্রিত · সেটিংস থেকে বন্ধ করা যাবে",false,null);

        item("Volume Booster · Equalizer / Bass Boost",
                "Modify audio settings (MODIFY_AUDIO_SETTINGS)",
                "সমর্থিত ফোনে Equalizer, Sound Gain ও অন্যান্য অডিও কন্ট্রোল ব্যবহার করতে।",
                "Android দ্বারা নিয়ন্ত্রিত",false,null);

        item("Video Player · Playback / Background audio",
                "FOREGROUND_SERVICE_MEDIA_PLAYBACK",
                "ভিডিও/অডিও চালু থাকলে Media Session ও Notification বজায় রাখতে।",
                "Android দ্বারা নিয়ন্ত্রিত",false,null);

        item("Floating Toolbox / Night Screen / Full Charge Alert",
                "FOREGROUND_SERVICE",
                "নিয়ম অনুযায়ী চলমান ও ব্যবহারকারীকে জানানো Background Monitoring Service চালাতে।",
                "Android দ্বারা নিয়ন্ত্রিত",false,null);

        item("Floating Bar / Night Screen / Thermal / Full Charge Voice",
                "FOREGROUND_SERVICE_SPECIAL_USE",
                "User-enabled বিশেষ উদ্দেশ্যের দীর্ঘস্থায়ী Foreground Service ঘোষণা।",
                "Android দ্বারা নিয়ন্ত্রিত",false,null);

        item("WhatsApp Scheduler / Full Charge monitor",
                "WAKE_LOCK",
                "প্রয়োজনীয় মুহূর্তে CPU Sleep বিলম্বিত করে নির্ধারিত কাজ সম্পন্ন করার চেষ্টা।",
                "Android দ্বারা নিয়ন্ত্রিত",false,null);

        item("WhatsApp Scheduler / Full Charge alert",
                "RECEIVE_BOOT_COMPLETED",
                "ফোন রিস্টার্টের পরে আগে চালু করা Scheduler ও Charging Monitor প্রস্তুত করার জন্য।",
                "Android দ্বারা নিয়ন্ত্রিত",false,null);

        item("Online video / Branding links / Media download",
                "INTERNET",
                "অনলাইন ভিডিও, YouTube/Facebook লিংক ও নেটওয়ার্ক-সমর্থিত ফিচার চালাতে।",
                "Android দ্বারা নিয়ন্ত্রিত",false,null);

        item("QR / Barcode Scanner",
                "Camera access via Google Code Scanner",
                "QR Scan-এর সময় Google Code Scanner নিজস্ব Camera UI পরিচালনা করে; "
                        +"এই অ্যাপ আলাদা CAMERA Permission ঘোষণা করে না।",
                "আলাদা App Camera Permission নেই",false,null);

        Button details=Ui.button(this,"⚙ Android App Information / All Permission Details",()->openAppDetails());
        LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(-1,-2);
        dp.topMargin=Ui.dp(this,15);body.addView(details,dp);
    }

    private void item(String feature,String permission,String purpose,String status,boolean canOpen,Runnable action){
        LinearLayout card=Ui.card(this);
        Ui.addText(this,card,"কোন ফিচারের জন্য:  "+feature,12,Ui.ACCENT,true,3);
        Ui.addText(this,card,permission,16,Ui.TEXT,true,6);
        Ui.addText(this,card,purpose,12,Ui.MUTED,false,6);
        Ui.addText(this,card,status,12,status.startsWith("✓")?Ui.GREEN:Ui.MUTED,true,6);
        if(canOpen&&action!=null){
            Button button=Ui.button(this,"অনুমতি দেখুন / পরিবর্তন করুন",action);
            card.addView(button,new LinearLayout.LayoutParams(-1,-2));
        }
        Ui.addCard(this,body,card,8);
    }

    private void ask(String[] permissions,int request){
        if(Build.VERSION.SDK_INT>=23)requestPermissions(permissions,request);
    }

    private void askVideo(){
        if(Build.VERSION.SDK_INT>=34)ask(new String[]{Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED},REQ_VIDEOS);
        else if(Build.VERSION.SDK_INT>=33)ask(new String[]{Manifest.permission.READ_MEDIA_VIDEO},REQ_VIDEOS);
        else ask(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},REQ_VIDEOS);
    }

    private void open(String action,boolean packageUri){
        try{Intent intent=packageUri?new Intent(action,Uri.parse("package:"+getPackageName()))
                :new Intent(action);startActivity(intent);
        }catch(Exception ex){openAppDetails();}
    }
    private void openAppDetails(){
        try{startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:"+getPackageName())));}
        catch(Exception e){Toast.makeText(this,"এই ফোনে Permission Settings খোলা যায়নি",Toast.LENGTH_LONG).show();}
    }

    private boolean schedulerAccessibilityOn(){
        try{
            AccessibilityManager manager=(AccessibilityManager)getSystemService(ACCESSIBILITY_SERVICE);
            List<AccessibilityServiceInfo> enabled=manager.getEnabledAccessibilityServiceList(
                    AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
            for(AccessibilityServiceInfo service:enabled)
                if(service.getId()!=null && service.getId().contains(getPackageName())
                        && service.getId().contains("ScheduledWhatsAppAccessibilityService"))return true;
        }catch(Exception ignored){}
        return false;
    }

    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){
        super.onRequestPermissionsResult(request,permissions,results);
        showPermissions();
    }
}
