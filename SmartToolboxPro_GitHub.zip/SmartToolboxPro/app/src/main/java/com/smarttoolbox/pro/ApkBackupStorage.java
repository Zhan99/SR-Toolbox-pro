package com.smarttoolbox.pro;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.text.format.DateFormat;

import androidx.documentfile.provider.DocumentFile;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Saves the ORIGINAL installed base APK, plus every installed split APK if present. */
final class ApkBackupStorage {
    static final class InstalledApp {
        final String name;
        final String packageName;
        final String versionName;
        final long versionCode;
        final long lastUpdated;
        final long apkBytes;
        final boolean isSystem;
        final String basePath;
        final String[] splitPaths;
        InstalledApp(String name, String pkg, String version, long code, long date,
                long bytes, boolean system, String base, String[] splits) {
            this.name = name; packageName = pkg; versionName = version; versionCode = code;
            lastUpdated = date; apkBytes = bytes; isSystem = system; basePath = base;
            splitPaths = splits == null ? new String[0] : splits;
        }
        boolean isSplit() { return ApkBackupLogic.isSplit(splitPaths); }
    }

    private ApkBackupStorage() {}

    static List<InstalledApp> installed(Context context) {
        PackageManager pm = context.getPackageManager();
        List<InstalledApp> result = new ArrayList<>();
        for (PackageInfo pkg : pm.getInstalledPackages(0)) {
            ApplicationInfo app = pkg.applicationInfo;
            if (app == null || pkg.packageName == null) continue;
            String base = app.sourceDir;
            String[] splits = app.splitSourceDirs;
            long bytes = length(base);
            if (splits != null) for (String path : splits) bytes += length(path);
            CharSequence label = pm.getApplicationLabel(app);
            String version = pkg.versionName == null ? "Unknown" : pkg.versionName;
            long code = Build.VERSION.SDK_INT >= 28 ? pkg.getLongVersionCode() : pkg.versionCode;
            boolean system = (app.flags & (ApplicationInfo.FLAG_SYSTEM
                    | ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0;
            result.add(new InstalledApp(label == null ? pkg.packageName : label.toString(),
                    pkg.packageName, version, code, pkg.lastUpdateTime, bytes, system,
                    base, splits));
        }
        result.sort(Comparator.comparing(a -> a.name.toLowerCase(Locale.ROOT)));
        return result;
    }

    private static long length(String path) {
        if (path == null) return 0;
        File file = new File(path);
        return file.isFile() ? Math.max(0, file.length()) : 0;
    }

    static String backupName(InstalledApp app) {
        return ApkBackupLogic.fileName(app.packageName, app.versionCode, app.isSplit(),
                System.currentTimeMillis());
    }

    static DocumentFile saveToFolder(Context context, Uri tree, InstalledApp app)
            throws IOException {
        DocumentFile dir = DocumentFile.fromTreeUri(context, tree);
        if (dir == null || !dir.canWrite()) throw new IOException("Backup folder access denied");
        String filename = backupName(app);
        // Keep the exact .apks extension instead of letting providers append ".zip".
        String mime = app.isSplit() ? "application/octet-stream"
                : "application/vnd.android.package-archive";
        DocumentFile created = dir.createFile(mime, filename);
        if (created == null) throw new IOException("Cannot create file in the selected folder");
        try {
            String expectedExtension = app.isSplit() ? ".apks" : ".apk";
            String actual = created.getName();
            if (actual == null || !actual.toLowerCase(Locale.ROOT).endsWith(expectedExtension)) {
                if (!created.renameTo(filename)) {
                    throw new IOException("Storage provider did not preserve " + expectedExtension + " filename");
                }
            }
            try (OutputStream out = context.getContentResolver().openOutputStream(created.getUri(), "w")) {
                if (out == null) throw new IOException("Selected storage does not support writing");
                writeArchive(app, out);
                out.flush();
            }
            return created;
        } catch (Exception error) {
            created.delete(); // Never leave a partially backed-up file advertised as valid.
            if (error instanceof IOException) throw (IOException) error;
            throw new IOException("Backup failed for " + app.packageName, error);
        }
    }

    static File saveToShareCache(Context context, InstalledApp app) throws IOException {
        File dir = new File(context.getCacheDir(), "apk_shares");
        if (!dir.isDirectory() && !dir.mkdirs()) throw new IOException("Unable to prepare share cache");
        File output = new File(dir, backupName(app));
        try {
            try (OutputStream stream = new FileOutputStream(output)) {
                writeArchive(app, stream);
            }
            return output;
        } catch (IOException e) {
            output.delete();
            throw e;
        }
    }

    /** Single file is an unchanged APK; split file is a ZIP container of ORIGINAL APK parts. */
    private static void writeArchive(InstalledApp app, OutputStream destination) throws IOException {
        JSONObject metadata = new JSONObject();
        try {
            metadata.put("format", "sr-original-apk-splits-v1");
            metadata.put("packageName", app.packageName);
            metadata.put("versionCode", app.versionCode);
            metadata.put("versionName", app.versionName);
            metadata.put("apkCount", app.splitPaths.length + 1);
        } catch (Exception e) { throw new IOException("Could not prepare archive metadata", e); }
        ApkArchiveWriter.write(app.basePath, app.splitPaths, metadata.toString(), destination);
    }
}
