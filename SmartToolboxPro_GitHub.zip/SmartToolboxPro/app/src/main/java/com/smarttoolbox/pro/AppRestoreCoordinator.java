package com.smarttoolbox.pro;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInstaller;
import android.os.Build;
import android.provider.Settings;
import android.net.Uri;
import androidx.documentfile.provider.DocumentFile;
import org.json.JSONArray;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Install APK and every split together in a user-approved PackageInstaller session. */
final class AppRestoreCoordinator {
    private static final String P = "sr_apk_restore_queue_v1";
    private static final String CHANNEL = "sr_apk_restore_permission";
    private static final ExecutorService EXEC = Executors.newSingleThreadExecutor();
    private static final AtomicBoolean PREPARING = new AtomicBoolean(false);
    private static volatile Intent pendingUserApproval;
    private AppRestoreCoordinator() { }
    private static SharedPreferences prefs(Context c) { return c.getSharedPreferences(P,Context.MODE_PRIVATE); }
    static String status(Context c) { return prefs(c).getString("status","No restore running"); }
    static boolean active(Context c) {
        SharedPreferences p=prefs(c);
        return p.getBoolean("working",false) || p.getBoolean("active_session",false);
    }
    static boolean hasQueued(Context c) {
        SharedPreferences p=prefs(c);
        try { return p.getInt("index",0)<new JSONArray(p.getString("queue","[]")).length(); }
        catch(Exception ignored) { return false; }
    }
    static boolean hasPermission(Context c) {
        return Build.VERSION.SDK_INT<26 || c.getPackageManager().canRequestPackageInstalls();
    }
    static void begin(Context context, List<AppBackupRepository.Archived> selected) {
        if(selected.isEmpty() || hasQueued(context) || active(context)) return;
        JSONArray j=new JSONArray();for(AppBackupRepository.Archived a:selected)j.put(a.key());
        prefs(context).edit().putString("queue",j.toString()).putInt("index",0)
                .putBoolean("active_session",false).putBoolean("working",false)
                .putString("status","Restore queued: "+selected.size()+" app(s)")
                .putInt("success",0).putInt("failed",0).commit();
        resume(context);
    }
    static void resume(Context context) {
        Context c=context.getApplicationContext();
        if(!hasPermission(c)) {
            prefs(c).edit().putString("status","Allow installation from this app, then return to Restore").apply();
            return;
        }
        if(!hasQueued(c) || prefs(c).getBoolean("active_session",false)) return;
        if(!PREPARING.compareAndSet(false,true))return;
        EXEC.execute(() -> {
            try { prepareNext(c); }
            finally {
                PREPARING.set(false);
                // A failed archive must not strand later apps in a multiple-restore queue.
                if (hasPermission(c) && hasQueued(c)
                        && !prefs(c).getBoolean("active_session",false)) resume(c);
            }
        });
    }
    private static void prepareNext(Context c) {
        SharedPreferences p=prefs(c);
        if(p.getBoolean("active_session",false))return;
        try {
            JSONArray array=new JSONArray(p.getString("queue","[]"));
            int at=p.getInt("index",0);
            if(at>=array.length()) { p.edit().putString("status",finishMessage(c)).apply();return; }
            String uri=array.getString(at);
            AppBackupRepository repo=new AppBackupRepository(c);
            AppBackupRepository.Archived chosen=null;
            for(AppBackupRepository.Archived a:repo.archives()) if(a.key().equals(uri)){chosen=a;break;}
            if(chosen==null) throw new IOException("Backup not found in selected storage");
            final AppBackupRepository.Archived item=chosen;
            p.edit().putString("status","Verifying APK: "+item.name+" ("+(at+1)+"/"+array.length()+")").apply();
            repo.verifyArchive(item,(message,percentage)-> p.edit().putString("status",message+" "+percentage+"%").apply());
            PackageInstaller installer=c.getPackageManager().getPackageInstaller();
            PackageInstaller.SessionParams params=new PackageInstaller.SessionParams(
                    PackageInstaller.SessionParams.MODE_FULL_INSTALL);
            params.setAppPackageName(item.pkg);
            if(Build.VERSION.SDK_INT>=31)
                params.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_REQUIRED);
            params.setSize(item.bytes);
            int sessionId=installer.createSession(params);
            PackageInstaller.Session session=null;
            try {
                session=installer.openSession(sessionId);
                byte[] buf=new byte[64*1024];
                for(int i=0;i<item.parts.size();i++) {
                    AppBackupRepository.Part part=item.parts.get(i);
                    DocumentFile f=AppBackupRepository.findRelative(item.folder,part.path);
                    if(f==null) throw new IOException("Missing split APK: "+part.path);
                    String sessionName=(i==0?"base.apk":"split_"+i+".apk");
                    try(InputStream input=c.getContentResolver().openInputStream(f.getUri());
                        OutputStream output=session.openWrite(sessionName,0,part.bytes)) {
                        if(input==null)throw new IOException("Cannot read archived APK");
                        int n;while((n=input.read(buf))!=-1)output.write(buf,0,n);
                        session.fsync(output);
                    }
                }
                Intent callback=new Intent(c,ApkRestoreResultReceiver.class);
                callback.setAction("com.smarttoolbox.pro.RESTORE_STATUS");
                callback.putExtra("restoreIndex",at);
                int flags=PendingIntent.FLAG_UPDATE_CURRENT
                        |(Build.VERSION.SDK_INT>=31?PendingIntent.FLAG_MUTABLE:0);
                PendingIntent pending=PendingIntent.getBroadcast(c,sessionId,callback,flags);
                // Session sends user-consent and final result to the explicit receiver.
                p.edit().putBoolean("active_session",true).putInt("sessionId",sessionId)
                        .putString("status","Awaiting Android install confirmation: "+item.name).commit();
                session.commit(pending.getIntentSender());
            } catch(Exception ex) {
                p.edit().putBoolean("active_session",false).apply();
                if(session!=null)try{session.abandon();}catch(Exception ignored){}
                throw ex;
            } finally { if(session!=null)session.close(); }
        } catch(Exception error) {
            p.edit().putString("status","Restore failed: "+error.getMessage()).apply();
            completed(c,false,"Restore failed: "+error.getMessage());
        }
    }
    private static String finishMessage(Context c) {
        SharedPreferences p=prefs(c);
        return "Restore finished · "+p.getInt("success",0)+" success · "+p.getInt("failed",0)+" failed";
    }
    static void completed(Context c,boolean success,String description) {
        SharedPreferences p=prefs(c);
        int i=p.getInt("index",0);
        SharedPreferences.Editor e=p.edit().putInt("index",i+1).putBoolean("active_session",false)
                .putBoolean("working",false).putString("status",description);
        if(success)e.putInt("success",p.getInt("success",0)+1);
        else e.putInt("failed",p.getInt("failed",0)+1);
        e.commit();
        if(hasQueued(c)) resume(c);
        else p.edit().putString("status",finishMessage(c)).apply();
    }
    static void onInstallerStatus(Context context,Intent result) {
        int code=result.getIntExtra(PackageInstaller.EXTRA_STATUS,PackageInstaller.STATUS_FAILURE);
        if(code==PackageInstaller.STATUS_PENDING_USER_ACTION) {
            Intent userAction=(Intent) result.getParcelableExtra(Intent.EXTRA_INTENT);
            if(userAction==null) {
                completed(context,false,"Android installer did not return confirmation UI");return;
            }
            prefs(context).edit().putString("status","Tap to approve app installation").apply();
            pendingUserApproval = userAction;
            AppBackupActivity visible=AppBackupActivity.current();
            if(visible!=null) visible.requestInstallApproval(userAction);
            else notifyApproval(context,userAction);
            return;
        }
        pendingUserApproval = null;
        String msg=result.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);
        boolean success=code==PackageInstaller.STATUS_SUCCESS;
        completed(context,success,success?"Installed successfully":
                "Install denied/failed"+(msg==null?"":": "+msg));
    }
    static void resumeApprovalWhenVisible(AppBackupActivity activity) {
        Intent waiting=pendingUserApproval;
        if(waiting!=null) {
            pendingUserApproval=null;
            activity.requestInstallApproval(waiting);
        }
    }
    private static void notifyApproval(Context c,Intent userAction) {
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(nm==null)return;
        nm.createNotificationChannel(new NotificationChannel(CHANNEL,"APK restore approval",
                NotificationManager.IMPORTANCE_HIGH));
        Intent approval=new Intent(c,ApkInstallApprovalActivity.class);
        approval.putExtra("user_action",userAction);
        approval.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent tap=PendingIntent.getActivity(c,9501,approval,
                PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification n=new Notification.Builder(c,CHANNEL)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("Approve APK Restore")
                .setContentText("Android requires your confirmation to install an archived app.")
                .setContentIntent(tap).setAutoCancel(true).build();
        nm.notify(9501,n);
    }
}
