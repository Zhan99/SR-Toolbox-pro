package com.smarttoolbox.pro;

/** Pure-Java policy: global vibration, feature vibration and Android system haptics. */
public final class FeedbackPolicy {
    private FeedbackPolicy() { }
    public static boolean vibrate(boolean globallyEnabled, boolean featureEnabled,
                                  boolean systemHapticsEnabled) {
        return globallyEnabled && featureEnabled && systemHapticsEnabled;
    }
}
