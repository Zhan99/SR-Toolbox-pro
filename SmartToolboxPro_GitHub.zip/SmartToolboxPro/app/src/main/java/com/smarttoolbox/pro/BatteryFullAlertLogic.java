package com.smarttoolbox.pro;

/** Pure Java decisions: one alarm per plugged-in fully charged cycle. */
final class BatteryFullAlertLogic {
    private BatteryFullAlertLogic() {}

    static boolean isFull(int level, int scale, int batteryStatus, int fullStatus) {
        return batteryStatus == fullStatus || (level >= 0 && scale > 0 && level >= scale);
    }

    static boolean shouldAnnounce(boolean enabled, boolean plugged, boolean full,
                                  boolean alreadyAnnounced) {
        return enabled && plugged && full && !alreadyAnnounced;
    }

    /** Re-arm after physically unplugging or after charge has dropped below 100%. */
    static boolean nextAnnouncedState(boolean plugged, boolean full, boolean alreadyAnnounced) {
        return plugged && full && alreadyAnnounced;
    }
}
