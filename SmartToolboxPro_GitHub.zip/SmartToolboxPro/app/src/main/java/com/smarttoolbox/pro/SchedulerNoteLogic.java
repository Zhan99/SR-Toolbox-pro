package com.smarttoolbox.pro;

/** Shared validation rules for local, reusable scheduler notes; no Android dependency. */
final class SchedulerNoteLogic {
    static final int MAX_NOTES = 200;
    static final int MAX_TITLE_CHARS = 80;
    static final int MAX_MESSAGE_CHARS = 12000;

    private SchedulerNoteLogic() { }

    static String title(String raw) {
        if (raw == null) return "";
        String normalized = raw.trim().replaceAll("\\s+", " ");
        return normalized.length() > MAX_TITLE_CHARS
                ? normalized.substring(0, MAX_TITLE_CHARS).trim() : normalized;
    }

    static String body(String raw) {
        if (raw == null) return "";
        String content = raw.trim();
        return content.length() > MAX_MESSAGE_CHARS
                ? content.substring(0, MAX_MESSAGE_CHARS) : content;
    }

    static boolean valid(String raw) { return !body(raw).isEmpty(); }

    static String preview(String raw) {
        String text = body(raw).replaceAll("\\s+", " ");
        return text.length() > 90 ? text.substring(0, 89) + "…" : text;
    }

    static boolean matches(String title, String body, String query) {
        if (query == null || query.trim().isEmpty()) return true;
        String search = query.trim().toLowerCase(java.util.Locale.ROOT);
        return (title != null && title.toLowerCase(java.util.Locale.ROOT).contains(search))
                || (body != null && body.toLowerCase(java.util.Locale.ROOT).contains(search));
    }
}
