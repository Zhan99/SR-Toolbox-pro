package com.smarttoolbox.pro;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;

import java.util.Locale;

/**
 * Selectable Bengali/English voice. Prefer the best embedded installed Android TTS voice;
 * fall back to bundled recordings in either language, with no internet dependency.
 * Use the RINGTONE audio usage for both paths so the user controls alert loudness
 * with the phone ringtone slider, respecting Silent / Vibrate and DND policy.
 */
final class FullChargeVoicePlayer {
    private FullChargeVoicePlayer() { }

    /** Owns the TTS engine or the fallback MediaPlayer until completion/cancellation. */
    static final class Playback {
        private final Context context;
        private final String language;
        private final Handler handler = new Handler(Looper.getMainLooper());
        private TextToSpeech tts;
        private MediaPlayer player;
        private boolean stopped;
        private boolean resolved;
        private int fallbackPart;
        private final Runnable fallbackTimeout = this::fallback;

        Playback(Context c, String language, boolean preferDeviceTts) {
            context = c.getApplicationContext();
            this.language = FullChargeLanguageLogic.normalize(language);
            // A bilingual alert uses two separate offline recordings so each
            // language is pronounced correctly, instead of forcing one TTS voice.
            if (!preferDeviceTts || FullChargeLanguageLogic.BOTH.equals(this.language)) {
                fallback();
                return;
            }
            try {
                tts = new TextToSpeech(context, status ->
                        handler.post(() -> initializeTts(status)));
                // Some OEM engines never call back; preserve a reliable offline fallback.
                handler.postDelayed(fallbackTimeout, 2800L);
            } catch (RuntimeException e) {
                fallback();
            }
        }

        private void initializeTts(int status) {
            if (stopped || resolved) return;
            if (status != TextToSpeech.SUCCESS || tts == null) { fallback(); return; }
            Locale locale = FullChargeLanguageLogic.ENGLISH.equals(language)
                    ? Locale.US : Locale.forLanguageTag("bn-BD");
            try {
                int supported = tts.setLanguage(locale);
                if (supported == TextToSpeech.LANG_MISSING_DATA
                        || supported == TextToSpeech.LANG_NOT_SUPPORTED) {
                    fallback(); return;
                }
                // Prefer the highest-quality installed OFFLINE voice. Network-only TTS is
                // not reliable for an urgent background battery notification.
                Voice best = null;
                if (tts.getVoices() != null) {
                    for (Voice v : tts.getVoices()) {
                        if (!v.isNetworkConnectionRequired()
                                && v.getLocale() != null
                                && language.equals(v.getLocale().getLanguage())
                                && (best == null || v.getQuality() > best.getQuality())) {
                            best = v;
                        }
                    }
                }
                if (best != null) tts.setVoice(best);
                else if (tts.getVoice() == null || tts.getVoice().isNetworkConnectionRequired()) {
                    fallback(); return;
                }
                tts.setSpeechRate(0.93f);
                tts.setPitch(1.03f);
                tts.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) { }
                    @Override public void onDone(String id) {
                        handler.post(() -> { if (!stopped) stop(); });
                    }
                    @Override public void onError(String id) {
                        handler.post(() -> { if (!stopped) fallback(); });
                    }
                });
                int result = tts.speak(FullChargeLanguageLogic.speech(language),
                        TextToSpeech.QUEUE_FLUSH, null, "sr-full-charge-voice");
                if (result == TextToSpeech.ERROR) fallback();
                else {
                    resolved = true;
                    handler.removeCallbacks(fallbackTimeout);
                }
            } catch (RuntimeException ex) { fallback(); }
        }

        private void fallback() {
            if (stopped || player != null) return;
            resolved = true;
            handler.removeCallbacks(fallbackTimeout);
            if (tts != null) {
                try { tts.stop(); tts.shutdown(); } catch (RuntimeException ignored) { }
                tts = null;
            }
            MediaPlayer fallbackPlayer = new MediaPlayer();
            try {
                fallbackPlayer.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
                int rawId = FullChargeLanguageLogic.ENGLISH.equals(language)
                        || (FullChargeLanguageLogic.BOTH.equals(language) && fallbackPart == 1)
                        ? R.raw.battery_full_english : R.raw.battery_full_bengali;
                Uri uri = Uri.parse("android.resource://" + context.getPackageName() + "/" + rawId);
                fallbackPlayer.setDataSource(context, uri);
                fallbackPlayer.setOnCompletionListener(mp -> {
                    if (FullChargeLanguageLogic.BOTH.equals(language) && fallbackPart == 0) {
                        fallbackPart = 1;
                        player = null;
                        try { mp.release(); } catch (RuntimeException ignored) { }
                        fallback();
                    } else stop();
                });
                fallbackPlayer.setOnErrorListener((mp, what, extra) -> { stop(); return true; });
                fallbackPlayer.prepare();
                player = fallbackPlayer;
                fallbackPlayer.start();
            } catch (Exception ex) {
                try { fallbackPlayer.release(); } catch (RuntimeException ignored) { }
            }
        }

        void stop() {
            if (stopped) return;
            stopped = true;
            handler.removeCallbacks(fallbackTimeout);
            if (tts != null) {
                try { tts.stop(); tts.shutdown(); } catch (RuntimeException ignored) { }
                tts = null;
            }
            if (player != null) {
                try { if (player.isPlaying()) player.stop(); } catch (RuntimeException ignored) { }
                try { player.release(); } catch (RuntimeException ignored) { }
                player = null;
            }
        }
    }

    static Playback speak(Context context, String language, boolean preferDeviceTts) {
        return new Playback(context, language, preferDeviceTts);
    }
}
