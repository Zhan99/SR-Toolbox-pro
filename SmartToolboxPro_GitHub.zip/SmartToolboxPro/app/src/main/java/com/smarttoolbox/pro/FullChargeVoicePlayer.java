package com.smarttoolbox.pro;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;

/** Offline Bengali voice: does not require internet access or a Bengali TTS engine. */
final class FullChargeVoicePlayer {
    private FullChargeVoicePlayer() { }

    static MediaPlayer play(Context context) {
        MediaPlayer player = new MediaPlayer();
        try {
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
            Uri file = Uri.parse("android.resource://" + context.getPackageName()
                    + "/" + R.raw.battery_full_bengali);
            player.setDataSource(context.getApplicationContext(), file);
            player.setOnCompletionListener(MediaPlayer::release);
            player.setOnErrorListener((mp, what, extra) -> {
                mp.release();
                return true;
            });
            player.prepare();
            player.start();
            return player;
        } catch (Exception ex) {
            try { player.release(); } catch (RuntimeException ignored) { }
            return null;
        }
    }
}
