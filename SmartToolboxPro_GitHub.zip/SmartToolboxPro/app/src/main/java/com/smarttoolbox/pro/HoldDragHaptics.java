package com.smarttoolbox.pro;

import android.content.Context;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.provider.Settings;

/** Short confirmation only after a stationary 2000-ms hold, before dragging. */
final class HoldDragHaptics {
    static final String PREF = "floating.hold.vibration";
    private HoldDragHaptics() {}
    static boolean allowed(boolean enabled, boolean systemHaptics, boolean alreadyPlayed) {
        return enabled && systemHaptics && !alreadyPlayed;
    }
    static void onHoldReady(Context context) {
        if (!context.getSharedPreferences("tool_state", Context.MODE_PRIVATE)
                .getBoolean(PREF, true)) return;
        if (Settings.System.getInt(context.getContentResolver(),
                Settings.System.HAPTIC_FEEDBACK_ENABLED, 1) == 0) return;
        try {
            Vibrator vibrator;
            if (Build.VERSION.SDK_INT >= 31) {
                VibratorManager manager = (VibratorManager) context.getSystemService(
                        Context.VIBRATOR_MANAGER_SERVICE);
                vibrator = manager == null ? null : manager.getDefaultVibrator();
            } else {
                vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
            }
            if (vibrator != null && vibrator.hasVibrator()) {
                vibrator.vibrate(VibrationEffect.createOneShot(38L, 95));
            }
        } catch (RuntimeException ignored) { /* no haptic hardware or OEM restriction */ }
    }
}
