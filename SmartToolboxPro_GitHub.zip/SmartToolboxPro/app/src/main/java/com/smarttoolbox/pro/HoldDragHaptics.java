package com.smarttoolbox.pro;

import android.content.Context;
import android.provider.Settings;

/** Hold-to-move vibration respects both the local and global preference. */
final class HoldDragHaptics {
    static final String PREF = "floating.hold.vibration";
    private HoldDragHaptics() { }
    static boolean allowed(boolean enabled, boolean systemHaptics, boolean alreadyPlayed) {
        return enabled && systemHaptics && !alreadyPlayed;
    }
    static void onHoldReady(Context context) {
        if (!context.getSharedPreferences("tool_state", Context.MODE_PRIVATE)
                .getBoolean(PREF, true)) return;
        if (Settings.System.getInt(context.getContentResolver(),
                Settings.System.HAPTIC_FEEDBACK_ENABLED, 1) == 0) return;
        UiHaptics.pulse(context, 38L, 95);
    }
}
