package com.smarttoolbox.pro;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public final class BatteryFullAlertActivity extends Activity {
    private TextView status;
    private Switch enabled;

    @Override public void onCreate(Bundle savedInstanceState) {
        ThemeManager.applyToActivity(this);
        super.onCreate(savedInstanceState);
        LinearLayout page = Ui.page(this, "🔋 Full Charge Voice Alert");
        LinearLayout body = Ui.content(page);
        Ui.addText(this, body,
                "চার্জে থাকা অবস্থায় ব্যাটারি ১০০% হলে বাংলায় বলবে: ‘ব্যাটারি ফুল চার্জ হয়েছে, চার্জ থেকে খুলুন।’",
                16, Ui.TEXT, true, 5);

        LinearLayout card = Ui.card(this);
        enabled = new Switch(this);
        enabled.setText("বাংলা ফুল চার্জ ভয়েস — চালু / বন্ধ");
        enabled.setTextColor(Ui.TEXT);
        enabled.setTextSize(16);
        enabled.setChecked(BatteryFullAlertPrefs.enabled(this));
        card.addView(enabled);
        status = Ui.addText(this, card, "", 13, Ui.MUTED, false, 10);
        enabled.setOnCheckedChangeListener((view, isOn) -> {
            if (isOn) {
                BatteryFullAlertPrefs.setEnabled(this, true);
                if (!BatteryFullVoiceService.startMonitoring(this)) {
                    BatteryFullAlertPrefs.setEnabled(this, false);
                    enabled.setChecked(false);
                    Toast.makeText(this, "মনিটর চালু হয়নি। Android Battery/Background অনুমতি দেখুন।",
                            Toast.LENGTH_LONG).show();
                } else requestNotificationAccess();
            } else {
                BatteryFullAlertPrefs.setEnabled(this, false);
                BatteryFullVoiceService.stopMonitoring(this);
            }
            refreshStatus();
        });
        Ui.addCard(this, body, card, 12);

        LinearLayout actions = Ui.card(this);
        Ui.addText(this, actions, "বাংলা ভয়েস পরীক্ষা", 17, Ui.TEXT, true, 0);
        Ui.addText(this, actions,
                "Test Voice চাপলে পূর্ণ চার্জ হওয়ার অপেক্ষা না করে বাক্যটি একবার শোনাবে।",
                13, Ui.MUTED, false, 6);
        actions.addView(Ui.button(this, "🔊 Test Bangla Voice", () -> {
            if (!BatteryFullAlertPrefs.enabled(this)) {
                Toast.makeText(this, "আগে ভয়েস সতর্কতা চালু করুন", Toast.LENGTH_SHORT).show();
            } else if (!BatteryFullVoiceService.testVoice(this)) {
                Toast.makeText(this, "ভয়েস সেবা চালু করা যায়নি", Toast.LENGTH_LONG).show();
            }
        }));
        actions.addView(Ui.button(this, "🗣 Android TTS Voice Settings", () -> {
            try { startActivity(new Intent("com.android.settings.TTS_SETTINGS")); }
            catch (Exception problem) {
                Toast.makeText(this, "ফোনের Settings → Text-to-Speech থেকে বাংলা ভয়েস চালু করুন।",
                        Toast.LENGTH_LONG).show();
            }
        }));
        Ui.addCard(this, body, actions, 12);

        Ui.addText(this, body,
                "নোট: এই সুবিধা চালু থাকলে একটি চলমান Foreground Notification দেখা যাবে। "
                + "প্রতি চার্জিং সাইকেলে একবার কথা বলবে; চার্জ খুলে আবার লাগালে নতুন সাইকেল। "
                + "ফোনে বাংলা Text-to-Speech না থাকলে Voice বাজবে না। Android/OEM Battery Saver, "
                + "Do Not Disturb এবং Background Restriction সতর্কতা দেরি করাতে পারে।",
                12, Ui.MUTED, false, 16);
        setContentView(page);
        refreshStatus();
    }

    private void requestNotificationAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 801);
        }
    }

    private void refreshStatus() {
        if (status == null) return;
        status.setText(BatteryFullAlertPrefs.enabled(this)
                ? "✅ মনিটরিং চালু আছে • ফোন চার্জে ১০০% হলে বাংলায় জানাবে"
                : "⏸ ভয়েস সতর্কতা বন্ধ আছে");
    }

    @Override protected void onResume() {
        super.onResume();
        if (enabled != null) enabled.setChecked(BatteryFullAlertPrefs.enabled(this));
        refreshStatus();
    }
}
