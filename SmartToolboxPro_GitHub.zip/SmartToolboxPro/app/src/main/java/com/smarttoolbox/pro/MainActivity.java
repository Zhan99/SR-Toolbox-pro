package com.smarttoolbox.pro;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.view.Menu;
import android.view.View;
import android.widget.PopupMenu;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int MENU_FLOATING_SETTINGS = 201;
    private static final int MENU_NOTIFICATION_CONTROLS = 202;
    private static final int MENU_ANDROID_APP_SETTINGS = 203;
    private static final int MENU_ABOUT_DEVELOPER = 204;
    private static final int MENU_THEME_SETTINGS = 205;
    private static final int MENU_MESSAGE_SCHEDULER = 206;
    private static final int MENU_APPS_BACKUP = 207;
    private static final int MENU_FULL_CHARGE_VOICE = 208;
    private static final int MENU_APP_PERMISSIONS = 209;
    private int themeWhenCreated;

    @Override public void onCreate(Bundle savedInstanceState) {
        ThemeManager.applyToActivity(this);
        super.onCreate(savedInstanceState);
        themeWhenCreated = ThemeManager.styleKey(this);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);

        FloatingControlService.refresh(this);
        LinearLayout page = Ui.page(this, "SR Smart Toolbox Pro");
        // The home screen has an overflow button instead of the redundant back arrow.
        // Secondary activities continue to use Ui.page() and its normal back navigation.
        LinearLayout header = (LinearLayout) page.getChildAt(0);
        header.removeViewAt(0);
        TextView homeTitle = (TextView) header.getChildAt(0);
        homeTitle.setTextSize(20);
        // Preserve the premium SR logo as a compact toolbar icon, not a creator card.
        if (Ui.isPremium()) {
            ImageView brandIcon=new ImageView(this);
            brandIcon.setImageResource(R.drawable.sr_premium_logo);
            brandIcon.setContentDescription("SR Smart Toolbox Pro");
            brandIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);
            header.addView(brandIcon,0,new LinearLayout.LayoutParams(Ui.dp(this,38),Ui.dp(this,38)));
        }

        TextView overflow = Ui.text(this, "⋮", 30, Ui.ACCENT, true);
        overflow.setGravity(Gravity.CENTER);
        overflow.setClickable(true);
        overflow.setFocusable(true);
        overflow.setContentDescription("More options: App Permissions, Settings, Scheduler, Notifications and About");
        header.addView(overflow, new LinearLayout.LayoutParams(Ui.dp(this, 48), Ui.dp(this, 52)));
        overflow.setOnClickListener(v -> {
            UiSound.play(this, UiSound.NAVIGATE);
            showOverflowMenu(overflow);
        });

        LinearLayout body = Ui.content(page);
        // Home is now tools-first. Creator/about details remain in the existing
        // About Developer screen and opening brand animation, not a large home card.
        Ui.addText(this, body, "আপনার প্রয়োজনীয় Smart Tools", 18, Ui.ACCENT, true, 8);

        addTool(body, "🌙", "Night Screen", "Dim the display and enable a warm screen filter.", NightScreenActivity.class);
        addTool(body, "🔊", "System-Wide Extra Volume", "Control master output gain, five-band equalizer, Bass Boost and spatial sound where the phone supports global effects.", VolumeBoosterActivity.class);
        addTool(body, "🌡️", "Thermal Monitor", "Check battery temperature and Android thermal status.", ThermalMonitorActivity.class);
        addTool(body, "▦", "QR / Barcode Scanner", "Scan QR codes and common barcode formats, then copy, share or open web links.", BarcodeScannerActivity.class);
        addTool(body, "📦", "Apps Backup & Restore", "Back up installed APKs, keep split APK archives, share files and restore with Android installation confirmation.", AppsBackupActivity.class);
        addTool(body, "🗓️", "WhatsApp Smart Scheduler", "Schedule single or broadcast-style messages to up to 20 selected contacts, edit quick templates, and choose app-wide themes; experimental Accessibility auto-send remains opt-in.", MessageSchedulerActivity.class);

        Ui.addText(this, body,
                "⋮  Settings: Premium/Classic, App Permissions, Floating Icon, Notifications and Smart Scheduler.",
                13, Ui.MUTED, false, 22);
        setContentView(page);
    }

    private void showOverflowMenu(View anchor) {
        PopupMenu popup = new PopupMenu(this, anchor);
        Menu menu = popup.getMenu();

        // Compact groups keep the home screen focused while exposing settings and the scheduler shortcut.
        menu.add(Menu.NONE, 0, 0, "SETTINGS").setEnabled(false);
        menu.add(Menu.NONE, MENU_THEME_SETTINGS, 1, "✨  Premium / Classic & Sounds");
        menu.add(Menu.NONE, MENU_FLOATING_SETTINGS, 2, "◉  Floating Icon Settings");
        menu.add(Menu.NONE, MENU_NOTIFICATION_CONTROLS, 3, "🔔  Notification Controls");
        menu.add(Menu.NONE, MENU_APP_PERMISSIONS, 3, "🔐  App Permissions (সব অনুমতি)");
        menu.add(Menu.NONE, MENU_FULL_CHARGE_VOICE, 3, "🔋  Full Charge বাংলা Voice Alert" +
                (FullChargeAlertPreferences.enabled(this) ? "  ✓ ON" : "  ○ OFF"));
        menu.add(Menu.NONE, MENU_ANDROID_APP_SETTINGS, 4, "⚙  Android App Settings");
        menu.add(Menu.NONE, 0, 5, "SMART TOOLS").setEnabled(false);
        menu.add(Menu.NONE, MENU_MESSAGE_SCHEDULER, 6, "🗓️  WhatsApp Smart Scheduler");
        menu.add(Menu.NONE, MENU_APPS_BACKUP, 7, "📦  Apps Backup & Restore");
        menu.add(Menu.NONE, 0, 7, "ABOUT").setEnabled(false);
        menu.add(Menu.NONE, MENU_ABOUT_DEVELOPER, 8, "👤  About Shahriar Rahman");

        popup.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case MENU_THEME_SETTINGS:
                    startActivity(new Intent(this, ThemeSettingsActivity.class));
                    return true;
                case MENU_FLOATING_SETTINGS:
                    startActivity(new Intent(this, FloatingIconSettingsActivity.class));
                    return true;
                case MENU_NOTIFICATION_CONTROLS:
                    startActivity(new Intent(this, NotificationControlsActivity.class));
                    return true;
                case MENU_APP_PERMISSIONS:
                    startActivity(new Intent(this, AppPermissionsActivity.class));
                    return true;
                case MENU_FULL_CHARGE_VOICE:
                    startActivity(new Intent(this, FullChargeAlertActivity.class));
                    return true;
                case MENU_ANDROID_APP_SETTINGS:
                    openAndroidAppSettings();
                    return true;
                case MENU_MESSAGE_SCHEDULER:
                    startActivity(new Intent(this, MessageSchedulerActivity.class));
                    return true;
                case MENU_APPS_BACKUP:
                    startActivity(new Intent(this, AppsBackupActivity.class));
                    return true;
                case MENU_ABOUT_DEVELOPER:
                    startActivity(new Intent(this, AboutDeveloperActivity.class));
                    return true;
                default:
                    return false;
            }
        });
        popup.show();
    }

    @Override protected void onResume() {
        super.onResume();
        if (themeWhenCreated != ThemeManager.styleKey(this)) {
            ThemeManager.initialize(this);
            recreate();
        }
    }

    private void openAndroidAppSettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Exception ignored) {
            // Android/OEM variations: the app itself still works if this screen is unavailable.
            android.widget.Toast.makeText(this,
                    "Android App Settings are unavailable on this device.",
                    android.widget.Toast.LENGTH_SHORT).show();
        }
    }

    private void addTool(LinearLayout body, String icon, String name, String description, Class<?> target) {
        LinearLayout card = Ui.card(this);
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView emoji = Ui.text(this, icon, 30, Ui.TEXT, false);
        row.addView(emoji, new LinearLayout.LayoutParams(Ui.dp(this, 48), -2));
        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        TextView heading = Ui.text(this, name, 18, Ui.TEXT, true);
        labels.addView(heading);
        TextView detail = Ui.text(this, description, 13, Ui.MUTED, false);
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1, -2);
        dp.topMargin = Ui.dp(this, 4);
        labels.addView(detail, dp);
        row.addView(labels, new LinearLayout.LayoutParams(0, -2, 1));
        TextView arrow = Ui.text(this, "›", 30, Ui.ACCENT, false);
        row.addView(arrow);
        card.addView(row);
        card.setOnClickListener(v -> {
            UiSound.play(this, UiSound.NAVIGATE);
            UiHaptics.click(this);
            startActivity(new Intent(this, target));
        });
        Ui.addCard(this, body, card, 12);
    }
}
