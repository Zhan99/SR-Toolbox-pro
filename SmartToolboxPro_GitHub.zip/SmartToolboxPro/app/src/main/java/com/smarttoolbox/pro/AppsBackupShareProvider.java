package com.smarttoolbox.pro;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileNotFoundException;

public class AppsBackupShareProvider extends ContentProvider {
    public boolean onCreate(){ return true; }
    private File resolve(Uri uri) throws FileNotFoundException {
        if(uri.getPathSegments().size()!=1) throw new FileNotFoundException();
        String name=uri.getLastPathSegment();
        if(name==null || name.contains("/") || name.contains("\\") || name.equals(".") || name.equals("..")) throw new FileNotFoundException();
        File f=new File(new File(getContext().getCacheDir(),"share"),name);
        if(!f.isFile()) throw new FileNotFoundException();
        return f;
    }
    public ParcelFileDescriptor openFile(Uri uri,String mode) throws FileNotFoundException {
        if(!"r".equals(mode)) throw new FileNotFoundException();
        return ParcelFileDescriptor.open(resolve(uri),ParcelFileDescriptor.MODE_READ_ONLY);
    }
    public String getType(Uri uri){ return uri.toString().endsWith(".apk")?"application/vnd.android.package-archive":"application/zip"; }
    public Cursor query(Uri uri,String[] projection,String selection,String[] args,String sort){
        try { File f=resolve(uri); String[] cols=projection==null?new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE}:projection;
            MatrixCursor c=new MatrixCursor(cols); Object[] row=new Object[cols.length];
            for(int i=0;i<cols.length;i++){ if(OpenableColumns.DISPLAY_NAME.equals(cols[i]))row[i]=f.getName().length()>37?f.getName().substring(37):f.getName(); else if(OpenableColumns.SIZE.equals(cols[i]))row[i]=f.length(); }
            c.addRow(row);return c;
        } catch(FileNotFoundException e){return null;}
    }
    public Uri insert(Uri u,ContentValues v){throw new UnsupportedOperationException();}
    public int delete(Uri u,String s,String[] a){throw new UnsupportedOperationException();}
    public int update(Uri u,ContentValues v,String s,String[] a){throw new UnsupportedOperationException();}
}
