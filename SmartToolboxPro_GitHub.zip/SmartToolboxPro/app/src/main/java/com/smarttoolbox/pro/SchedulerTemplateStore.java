package com.smarttoolbox.pro;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Local editable template library. Existing default shortcuts are seeded on first use. */
final class SchedulerTemplateStore {
    private static final String PREFS = "sr_scheduler_templates_v1";
    private static final String KEY = "templates_json";
    static final class Entry {
        final String id;
        final String title;
        final String message;
        Entry(String id, String title, String message) {
            this.id = id == null ? "" : id;
            this.title = title == null ? "" : title;
            this.message = message == null ? "" : message;
        }
    }
    private SchedulerTemplateStore() {}

    static synchronized List<Entry> getAll(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (!prefs.contains(KEY)) seedDefaults(context);
        List<Entry> result = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(prefs.getString(KEY, "[]"));
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.optJSONObject(i);
                if (item == null) continue;
                String id = item.optString("id", "");
                String title = item.optString("title", "");
                String message = item.optString("message", "");
                if (!id.isEmpty() && SchedulerTemplateLogic.isValid(title, message)) {
                    result.add(new Entry(id, title, message));
                }
            }
        } catch (Exception ignored) { }
        return result;
    }

    private static void seedDefaults(Context context) {
        List<Entry> defaults = new ArrayList<>();
        for (int i = 0; i < SchedulerDisplayLogic.templateCount(); i++) {
            defaults.add(new Entry("builtin_" + i, SchedulerDisplayLogic.templateTitle(i),
                    SchedulerDisplayLogic.templateMessage(i)));
        }
        saveAll(context, defaults);
    }

    static synchronized boolean add(Context context, String title, String message) {
        if (!SchedulerTemplateLogic.isValid(title, message)) return false;
        List<Entry> entries = getAll(context);
        if (entries.size() >= 50) return false;
        entries.add(new Entry(UUID.randomUUID().toString(), SchedulerTemplateLogic.cleanTitle(title),
                SchedulerTemplateLogic.cleanMessage(message)));
        saveAll(context, entries);
        return true;
    }

    static synchronized boolean update(Context context, String id, String title, String message) {
        if (id == null || !SchedulerTemplateLogic.isValid(title, message)) return false;
        List<Entry> entries = getAll(context);
        boolean found = false;
        for (int i = 0; i < entries.size(); i++) {
            Entry old = entries.get(i);
            if (old.id.equals(id)) {
                entries.set(i, new Entry(id, SchedulerTemplateLogic.cleanTitle(title),
                        SchedulerTemplateLogic.cleanMessage(message)));
                found = true;
                break;
            }
        }
        if (found) saveAll(context, entries);
        return found;
    }

    static synchronized boolean delete(Context context, String id) {
        if (id == null) return false;
        List<Entry> entries = getAll(context);
        boolean removed = false;
        for (int i = entries.size() - 1; i >= 0; i--) {
            if (entries.get(i).id.equals(id)) { entries.remove(i); removed = true; }
        }
        if (removed) saveAll(context, entries);
        return removed;
    }

    private static void saveAll(Context context, List<Entry> entries) {
        JSONArray array = new JSONArray();
        try {
            for (Entry entry : entries) {
                JSONObject item = new JSONObject();
                item.put("id", entry.id);
                item.put("title", entry.title);
                item.put("message", entry.message);
                array.put(item);
            }
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                    .putString(KEY, array.toString()).apply();
        } catch (Exception ignored) { }
    }
}
