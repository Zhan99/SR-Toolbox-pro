package com.smarttoolbox.pro;

import java.util.ArrayList;
import java.util.List;

/** Pure Java selection logic for the + button in the recent-number history. */
final class RecipientSelectionLogic {
    private RecipientSelectionLogic() {}

    static List<String> appendUnique(String existing, String newPhone) {
        List<String> result = new ArrayList<>(MessageScheduleLogic.normalizePhones("880", existing));
        String phone = MessageScheduleLogic.normalizePhone("880", "+" + (newPhone == null ? "" : newPhone));
        if (MessageScheduleLogic.isValidPhone(phone) && !result.contains(phone)) result.add(phone);
        return result;
    }

    static String asCommaSeparatedNumbers(List<String> numbers) {
        StringBuilder out = new StringBuilder();
        for (String phone : numbers) {
            if (!MessageScheduleLogic.isValidPhone(phone)) continue;
            if (out.length() > 0) out.append(", ");
            out.append("+").append(phone);
        }
        return out.toString();
    }
}
