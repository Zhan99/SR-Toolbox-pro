package com.smarttoolbox.pro;

import java.time.LocalDate;
import java.time.YearMonth;
import java.time.ZoneId;

/** Calendar navigation for saved schedule events; never equates 'attempted' with delivered. */
final class SchedulerInboxLogic {
    private SchedulerInboxLogic() {}
    static boolean onDate(long scheduledAtMillis, long lastTriggeredMillis,
                          LocalDate date, ZoneId zone) {
        return date != null && ((scheduledAtMillis > 0
                && SchedulerCalendarLogic.toLocalDate(scheduledAtMillis, zone).equals(date))
                || (lastTriggeredMillis > 0
                && SchedulerCalendarLogic.toLocalDate(lastTriggeredMillis, zone).equals(date)));
    }
    static boolean showSelectedDay(LocalDate selected, LocalDate today) {
        return selected != null && !selected.equals(today);
    }
    static YearMonth monthFor(LocalDate selected, YearMonth current) {
        return selected == null ? current : YearMonth.from(selected);
    }
}
