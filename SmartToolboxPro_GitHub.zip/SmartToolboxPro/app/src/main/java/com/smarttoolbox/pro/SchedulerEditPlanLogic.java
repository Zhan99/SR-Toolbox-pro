package com.smarttoolbox.pro;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Deterministic identity plan for editing a broadcast IN PLACE, without cloning it. */
final class SchedulerEditPlanLogic {
    static final class Plan {
        final Map<String, String> preservedIds;
        final List<String> removedPhones;
        final List<String> addedPhones;
        final List<String> requestedPhones;
        Plan(Map<String, String> preserved, List<String> removed, List<String> added,
             List<String> requested) {
            preservedIds = Collections.unmodifiableMap(preserved);
            removedPhones = Collections.unmodifiableList(removed);
            addedPhones = Collections.unmodifiableList(added);
            requestedPhones = Collections.unmodifiableList(requested);
        }
        String existingIdFor(String phone) { return preservedIds.get(phone); }
    }

    private SchedulerEditPlanLogic() {}

    static Plan create(Map<String, String> currentPhoneToId, List<String> desiredPhones) {
        if (currentPhoneToId == null || currentPhoneToId.isEmpty() || desiredPhones == null
                || desiredPhones.size() < 2 || desiredPhones.size() > 20) return null;
        Set<String> desired = new HashSet<>(desiredPhones);
        if (desired.size() != desiredPhones.size()) return null;
        Map<String, String> preserved = new HashMap<>();
        List<String> removed = new ArrayList<>(), added = new ArrayList<>();
        for (String phone : desiredPhones) {
            if (phone == null || phone.isEmpty()) return null;
            String id = currentPhoneToId.get(phone);
            if (id != null && !id.isEmpty()) preserved.put(phone, id);
            else added.add(phone);
        }
        for (String phone : currentPhoneToId.keySet()) {
            if (!desired.contains(phone)) removed.add(phone);
        }
        return new Plan(preserved, removed, added, new ArrayList<>(desiredPhones));
    }
}
