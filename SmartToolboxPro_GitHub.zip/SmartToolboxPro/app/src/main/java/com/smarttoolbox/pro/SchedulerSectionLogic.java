package com.smarttoolbox.pro;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.List;

/** Pure-Java, device-local-date grouping for saved WhatsApp schedules. */
final class SchedulerSectionLogic {
    static final String TODAY = "today";
    static final String TOMORROW = "tomorrow";
    static final String UPCOMING = "upcoming";
    static final String HISTORY = "history";
    static final String PAUSED = "paused";
    static final List<String> ORDER = Arrays.asList(TODAY, TOMORROW, UPCOMING, HISTORY, PAUSED);

    private SchedulerSectionLogic() {}

    /** Status always takes precedence. A past-due pending item is not called "sent". */
    static String sectionFor(String status, long dueMillis, long nowMillis, ZoneId zone) {
        if ("paused".equals(status)) return PAUSED;
        if ("due".equals(status) || "done".equals(status) || "attempted".equals(status)
                || dueMillis <= nowMillis) return HISTORY;
        if (!"pending".equals(status)) return HISTORY;
        LocalDate nowDate = Instant.ofEpochMilli(nowMillis).atZone(zone).toLocalDate();
        LocalDate dueDate = Instant.ofEpochMilli(dueMillis).atZone(zone).toLocalDate();
        if (dueDate.equals(nowDate)) return TODAY;
        if (dueDate.equals(nowDate.plusDays(1))) return TOMORROW;
        return dueDate.isAfter(nowDate) ? UPCOMING : HISTORY;
    }

    static String title(String key) {
        switch (key) {
            case TODAY: return "আজকের শিডিউল";
            case TOMORROW: return "আগামীকালের শিডিউল";
            case UPCOMING: return "পরবর্তী দিনের শিডিউল";
            case HISTORY: return "সময় পেরিয়েছে / History";
            case PAUSED: return "বিরতিতে থাকা শিডিউল";
            default: return "অন্যান্য শিডিউল";
        }
    }

    static String icon(String key) {
        switch (key) {
            case TODAY: return "📅";
            case TOMORROW: return "🌅";
            case UPCOMING: return "🗂";
            case HISTORY: return "🕓";
            case PAUSED: return "⏸";
            default: return "📁";
        }
    }

    static boolean defaultExpanded(String key) { return TODAY.equals(key); }
    static boolean mostRecentFirst(String key) { return HISTORY.equals(key); }
}
