package com.smarttoolbox.pro;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInstaller;
import android.widget.Toast;
public class AppsBackupInstallReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context,Intent intent){
        int status=intent.getIntExtra(PackageInstaller.EXTRA_STATUS,PackageInstaller.STATUS_FAILURE);
        int session=intent.getIntExtra(PackageInstaller.EXTRA_SESSION_ID,-1);
        AppsBackupActivity a=AppsBackupActivity.active;
        if(status==PackageInstaller.STATUS_PENDING_USER_ACTION){
            Intent confirm=intent.getParcelableExtra(Intent.EXTRA_INTENT);
            if(confirm!=null){
                try{if(a!=null) a.startActivity(confirm); else {confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); context.startActivity(confirm);} }
                catch(Exception e){Toast.makeText(context,"Open Apps Backup Restore and retry installation",Toast.LENGTH_LONG).show();if(a!=null)a.installResult(session,false,"Could not open installer");}
            } else if(a!=null)a.installResult(session,false,"Missing installation confirmation");
        }else{
            String message=intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);
            if(a!=null)a.installResult(session,status==PackageInstaller.STATUS_SUCCESS,message);
            else Toast.makeText(context,status==PackageInstaller.STATUS_SUCCESS?"App installed":"Install failed: "+message,Toast.LENGTH_LONG).show();
        }
    }
}
