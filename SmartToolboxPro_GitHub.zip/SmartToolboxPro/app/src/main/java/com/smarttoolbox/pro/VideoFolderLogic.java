package com.smarttoolbox.pro;

import java.util.Locale;

/** Stable, case-insensitive folder grouping using MediaStore's organization-only path. */
public final class VideoFolderLogic {
    private VideoFolderLogic() {}
    public static String folderKey(String raw) {
        if (raw == null) return "Other videos";
        String cleaned = raw.trim().replace('\\', '/');
        while (cleaned.endsWith("/") && cleaned.length() > 1)
            cleaned = cleaned.substring(0, cleaned.length()-1);
        return cleaned.isEmpty() ? "Other videos" : cleaned;
    }
    public static String displayName(String path) {
        String value = folderKey(path);
        int slash = value.lastIndexOf('/');
        String name = slash < 0 ? value : value.substring(slash + 1);
        return name.trim().isEmpty() ? "Other videos" : name;
    }
    public static boolean sameFolder(String one, String two) {
        return folderKey(one).equalsIgnoreCase(folderKey(two));
    }
}
