package com.smarttoolbox.pro;

/** Pure Java safeguards for the WhatsApp UI (only one chat can be active at once). */
final class GroupQueueLogic {
    private GroupQueueLogic() {}
    static boolean mayQueue(String runningBatch, String incomingBatch, boolean duplicate,
                            int queuedCount) {
        return runningBatch != null && !runningBatch.isEmpty()
                && runningBatch.equals(incomingBatch) && !duplicate
                && queuedCount >= 0 && queuedCount < GroupScheduleLogic.MAX_RECIPIENTS - 1;
    }
}
