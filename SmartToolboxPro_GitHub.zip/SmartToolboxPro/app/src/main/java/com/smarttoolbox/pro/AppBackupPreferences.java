package com.smarttoolbox.pro;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;

/** SAF backup selection and preferences: no all-files permission needed. */
final class AppBackupPreferences {
    private static final String PREFS = "sr_app_backup_v1";
    private static final String TREE = "tree_uri";
    private AppBackupPreferences() {}
    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
    static Uri treeUri(Context c) {
        String value = p(c).getString(TREE, "");
        if (value == null || value.isEmpty()) return null;
        try { return Uri.parse(value); } catch (RuntimeException ignored) { return null; }
    }
    static void saveTree(Context c, Uri uri) {
        p(c).edit().putString(TREE, uri == null ? "" : uri.toString()).apply();
    }
    static boolean showSystem(Context c) { return p(c).getBoolean("system", false); }
    static void setShowSystem(Context c, boolean value) { p(c).edit().putBoolean("system",value).apply(); }
    static boolean keepVersions(Context c) { return p(c).getBoolean("keep_old", true); }
    static void setKeepVersions(Context c, boolean value) { p(c).edit().putBoolean("keep_old",value).apply(); }
    static boolean preventDuplicates(Context c) { return p(c).getBoolean("no_duplicate", true); }
    static void setPreventDuplicates(Context c, boolean value) { p(c).edit().putBoolean("no_duplicate",value).apply(); }
}
