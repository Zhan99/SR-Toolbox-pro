package com.smarttoolbox.pro;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.text.Editable;
import android.text.TextWatcher;
import java.lang.ref.WeakReference;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** APK Backup & Restore UI: installed/archived tabs, search, sort, batch operations. */
public final class AppBackupActivity extends Activity {
    private static final int REQ_UNINSTALL = 4011;
    private static final int REQ_INSTALL_PERMISSION = 4012;
    private static WeakReference<AppBackupActivity> foreground = new WeakReference<>(null);
    static AppBackupActivity current() { return foreground.get(); }
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final AppBackupRepository.Progress reporter=(s,p)->handler.post(()->progress(s,p));
    private AppBackupRepository repo;
    private final List<AppBackupRepository.Installed> installed=new ArrayList<>();
    private final List<AppBackupRepository.Archived> archived=new ArrayList<>();
    private final Set<String> pickedInstalled=new HashSet<>();
    private final Set<String> pickedArchived=new HashSet<>();
    private List<String> uninstallQueue=new ArrayList<>();
    private int uninstallIndex=0;
    private boolean archivedTab=false,busy=false;
    private int sort=0,category=0,loadGeneration=0,visibleLimit=60;
    private String lastBackupSummary="";
    private String search="";
    private LinearLayout rows;
    private TextView heading,selectionStatus,progressText,restoreStatus;
    private ProgressBar progressBar;
    private Button tabInstalled,tabArchived;
    private Spinner sortSpinner,categorySpinner;
    private final Runnable statusTicker=new Runnable(){
        @Override public void run(){
            if(isFinishing() || isDestroyed())return;
            if(restoreStatus!=null) {
                restoreStatus.setText("Restore: "+AppRestoreCoordinator.status(AppBackupActivity.this));
            }
            handler.postDelayed(this,1500L);
        }
    };

    @Override public void onCreate(Bundle saved) {
        ThemeManager.applyToActivity(this);super.onCreate(saved);
        repo=new AppBackupRepository(this);
        LinearLayout page=Ui.page(this,"📦 Apps Backup & Restore");
        LinearLayout content=Ui.content(page);
        Ui.addText(this,content,"Installed Apps  ·  Archived APKs",19,Ui.TEXT,true,5);
        Ui.addText(this,content,"Offline APK-only backups. Android approval is required to install or uninstall apps.",
                12,Ui.MUTED,false,6);
        LinearLayout tabs=new LinearLayout(this);tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabInstalled=Ui.button(this,"📱 Installed",()->switchTab(false));
        tabArchived=Ui.button(this,"🗃 Archived",()->switchTab(true));
        tabs.addView(tabInstalled,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.leftMargin=Ui.dp(this,7);
        tabs.addView(tabArchived,p);Ui.addCard(this,content,tabs,12);
        LinearLayout toolbar=new LinearLayout(this);toolbar.setOrientation(LinearLayout.VERTICAL);
        EditText query=new EditText(this);query.setHint("🔎 Search name, package or version");
        query.setSingleLine(true);query.setTextColor(Ui.TEXT);query.setHintTextColor(Ui.MUTED);
        query.setTextSize(14);query.setBackgroundColor(Ui.CARD_2);
        query.setPadding(Ui.dp(this,13),Ui.dp(this,11),Ui.dp(this,13),Ui.dp(this,11));
        toolbar.addView(query,new LinearLayout.LayoutParams(-1,-2));
        query.addTextChangedListener(new TextWatcher(){
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count){
                search=s.toString().trim().toLowerCase(java.util.Locale.ROOT);
                visibleLimit=60;renderRows();
            }
            @Override public void afterTextChanged(Editable e){}
        });
        LinearLayout controls=new LinearLayout(this);controls.setOrientation(LinearLayout.HORIZONTAL);
        sortSpinner=spinner(ApkBackupRules.SORT_LABELS);
        controls.addView(sortSpinner,new LinearLayout.LayoutParams(0,Ui.dp(this,50),2));
        categorySpinner=spinner(new String[]{"User Apps","System Apps","All Apps"});
        LinearLayout.LayoutParams cat=new LinearLayout.LayoutParams(0,Ui.dp(this,50),1);cat.leftMargin=Ui.dp(this,5);
        controls.addView(categorySpinner,cat);
        toolbar.addView(controls);
        LinearLayout upper=new LinearLayout(this);upper.setOrientation(LinearLayout.HORIZONTAL);
        upper.addView(Ui.button(this,"⚙ Settings",()->
                startActivity(new Intent(this,AppBackupSettingsActivity.class))),
                new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams refresh=new LinearLayout.LayoutParams(0,-2,1);
        refresh.leftMargin=Ui.dp(this,7);
        upper.addView(Ui.button(this,"↻ Refresh",this::refresh),refresh);
        toolbar.addView(upper);
        Ui.addCard(this,content,toolbar,11);
        sortSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){
                sort=pos;visibleLimit=60;renderRows();
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> p){}
        });
        categorySpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){
                category=pos;visibleLimit=60;renderRows();
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> p){}
        });
        heading=Ui.addText(this,content,"Installed Apps",17,Ui.TEXT,true,17);
        selectionStatus=Ui.addText(this,content,"No apps selected",12,Ui.MUTED,false,5);
        rows=new LinearLayout(this);rows.setOrientation(LinearLayout.VERTICAL);
        content.addView(rows,new LinearLayout.LayoutParams(-1,-2));
        // Fixed bottom action bar (outside the scrolling list).
        LinearLayout footer=new LinearLayout(this);footer.setOrientation(LinearLayout.VERTICAL);
        footer.setPadding(0,Ui.dp(this,7),0,0);
        footer.setBackgroundColor(Ui.CARD);
        progressBar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);footer.addView(progressBar,new LinearLayout.LayoutParams(-1,Ui.dp(this,4)));
        progressText=Ui.text(this,"Choose an app to back up or restore",12,Ui.MUTED,false);
        footer.addView(progressText);
        restoreStatus=Ui.text(this,"Restore: No restore running",12,Ui.MUTED,false);
        footer.addView(restoreStatus);
        LinearLayout row1=new LinearLayout(this);row1.setOrientation(LinearLayout.HORIZONTAL);
        addFooterAction(row1,"↻ Refresh",this::refresh);
        addFooterAction(row1,"☑ All",()->selectAll(true));
        addFooterAction(row1,"☐ None",()->selectAll(false));
        footer.addView(row1);
        LinearLayout row2=new LinearLayout(this);row2.setOrientation(LinearLayout.HORIZONTAL);
        addFooterAction(row2,"💾 Backup / Restore",this::backupOrRestore);
        addFooterAction(row2,"↗ Share",this::share);
        addFooterAction(row2,"🗑 Delete / Uninstall",this::deleteOrUninstall);
        footer.addView(row2);
        page.addView(footer,new LinearLayout.LayoutParams(-1,-2));
        setContentView(page);
    }
    private Spinner spinner(String[] values) {
        Spinner s=new Spinner(this);
        ArrayAdapter<String> a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,values);
        s.setAdapter(a);return s;
    }
    private void addFooterAction(LinearLayout row,String label,Runnable action) {
        Button b=Ui.button(this,label,action);b.setTextSize(11);b.setPadding(2,2,2,2);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,Ui.dp(this,47),1);
        p.leftMargin=Ui.dp(this,3);p.topMargin=Ui.dp(this,4);row.addView(b,p);
    }
    private void progress(String text,int percent) {
        if(progressText!=null) progressText.setText(text);
        if(progressBar!=null)progressBar.setProgress(Math.max(0,Math.min(100,percent)));
    }
    private void switchTab(boolean archivedMode) {
        archivedTab=archivedMode;visibleLimit=60;renderRows();
    }
    private void refresh() {
        if(busy)return;
        int gen=++loadGeneration;
        progress("Refreshing installed and archived apps…",0);
        io.execute(()->{
            try {
                List<AppBackupRepository.Installed> fresh=repo.installed();
                List<AppBackupRepository.Archived> backups=repo.archives();
                Set<String> hasBackup=new HashSet<>();
                for(AppBackupRepository.Archived a:backups){
                    hasBackup.add(a.pkg);
                    a.installed=repo.isInstalled(a.pkg);
                    a.icon=repo.archiveIcon(a);
                }
                for(AppBackupRepository.Installed a:fresh)a.archived=hasBackup.contains(a.pkg);
                runOnUiThread(()->{
                    if(gen!=loadGeneration || isFinishing())return;
                    installed.clear();installed.addAll(fresh);
                    archived.clear();archived.addAll(backups);
                    pickedInstalled.retainAll(packageKeys(fresh));
                    pickedArchived.retainAll(archiveKeys(backups));
                    progress(lastBackupSummary.isEmpty()?
                            "Ready: "+installed.size()+" installed / "+archived.size()+" archives":
                            lastBackupSummary,100);
                    renderRows();
                });
            } catch(Exception ex){runOnUiThread(()->progress("Refresh failed: "+ex.getMessage(),0));}
        });
    }
    private Set<String> packageKeys(List<AppBackupRepository.Installed> apps) {
        Set<String> s=new HashSet<>();for(AppBackupRepository.Installed a:apps)s.add(a.pkg);return s;
    }
    private Set<String> archiveKeys(List<AppBackupRepository.Archived> apps) {
        Set<String> s=new HashSet<>();for(AppBackupRepository.Archived a:apps)s.add(a.key());return s;
    }
    private boolean matches(String name,String pkg,String version) {
        return search.isEmpty() || name.toLowerCase(java.util.Locale.ROOT).contains(search)
                || pkg.toLowerCase(java.util.Locale.ROOT).contains(search)
                || version.toLowerCase(java.util.Locale.ROOT).contains(search);
    }
    private List<AppBackupRepository.Installed> filteredInstalled() {
        List<AppBackupRepository.Installed> results=new ArrayList<>();
        for(AppBackupRepository.Installed a:installed) {
            if(a.system && !AppBackupPreferences.showSystem(this))continue;
            if(category==0 && a.system)continue;
            if(category==1 && !a.system)continue;
            if(matches(a.name,a.pkg,a.version))results.add(a);
        }
        results.sort((a,b)->ApkBackupRules.compare(sort,a.name,b.name,a.updated,b.updated,
                a.bytes,b.bytes,true,true,a.archived,b.archived));
        return results;
    }
    private List<AppBackupRepository.Archived> filteredArchived() {
        List<AppBackupRepository.Archived> results=new ArrayList<>();
        for(AppBackupRepository.Archived a:archived) if(matches(a.name,a.pkg,a.version))results.add(a);
        results.sort((a,b)->ApkBackupRules.compare(sort,a.name,b.name,a.backedUpAt,b.backedUpAt,
                a.bytes,b.bytes,a.installed,b.installed,true,true));
        return results;
    }
    private void renderRows() {
        if(rows==null)return;
        rows.removeAllViews();
        if(heading!=null) heading.setText(archivedTab?"🗃 Archived APKs ("+archived.size()+")":
                "📱 Installed Apps ("+installed.size()+")");
        if(tabInstalled!=null)tabInstalled.setAlpha(archivedTab?.55f:1f);
        if(tabArchived!=null)tabArchived.setAlpha(archivedTab?1f:.55f);
        if(categorySpinner!=null) categorySpinner.setVisibility(archivedTab?View.GONE:View.VISIBLE);
        if(archivedTab) {
            List<AppBackupRepository.Archived> visible=filteredArchived();
            for(int i=0;i<Math.min(visibleLimit,visible.size());i++)archiveCard(visible.get(i));
            if(visible.size()>visibleLimit)loadMore(visible.size());
            if(visible.isEmpty())Ui.addText(this,rows,"No archived apps found. Choose a storage folder and back up your apps.",
                    14,Ui.MUTED,false,15);
        } else {
            List<AppBackupRepository.Installed> visible=filteredInstalled();
            for(int i=0;i<Math.min(visibleLimit,visible.size());i++)installedCard(visible.get(i));
            if(visible.size()>visibleLimit)loadMore(visible.size());
            if(visible.isEmpty())Ui.addText(this,rows,
                    category==1 && !AppBackupPreferences.showSystem(this)?
                    "System apps are hidden. Enable Show System Apps in Backup Settings.":"No installed apps match this search.",
                    14,Ui.MUTED,false,15);
        }
        updateSelection();
    }
    private void loadMore(int total) {
        Ui.addCard(this,rows,Ui.button(this,
                "Show more apps ("+Math.min(visibleLimit,total)+" / "+total+")",
                ()->{visibleLimit+=60;renderRows();}),12);
    }
    private static String size(long b) {
        if(b<1024)return b+" B";
        if(b<1024L*1024)return String.format(java.util.Locale.ROOT,"%.1f KB",b/1024.0);
        return String.format(java.util.Locale.ROOT,"%.1f MB",b/(1024.0*1024));
    }
    private static String date(long time) {
        return time<=0?"Unknown":DateFormat.getDateTimeInstance(DateFormat.MEDIUM,DateFormat.SHORT).format(new Date(time));
    }
    private void installedCard(AppBackupRepository.Installed a) {
        LinearLayout card=Ui.card(this);LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        ImageView icon=new ImageView(this); if(a.icon!=null)icon.setImageDrawable(a.icon);
        row.addView(icon,new LinearLayout.LayoutParams(Ui.dp(this,49),Ui.dp(this,49)));
        LinearLayout details=new LinearLayout(this);details.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(0,-2,1);dp.leftMargin=Ui.dp(this,9);
        row.addView(details,dp);
        details.addView(Ui.text(this,a.name,16,Ui.TEXT,true));
        details.addView(Ui.text(this,a.pkg,11,Ui.MUTED,false));
        details.addView(Ui.text(this,"v"+a.version+" ("+a.code+")  ·  "+size(a.bytes),12,Ui.MUTED,false));
        details.addView(Ui.text(this,"Updated: "+date(a.updated),11,Ui.MUTED,false));
        details.addView(Ui.text(this,(a.system?"SYSTEM APP":"USER APP")+(a.archived?"   ·   ✓ ARCHIVED":"   ·   NOT ARCHIVED"),
                11,a.archived?Ui.GREEN:Ui.ACCENT,false));
        CheckBox checkbox=new CheckBox(this);
        checkbox.setButtonTintList(android.content.res.ColorStateList.valueOf(Ui.ACCENT));
        checkbox.setChecked(pickedInstalled.contains(a.pkg));
        checkbox.setContentDescription("Select "+a.name);
        checkbox.setOnCheckedChangeListener((button,checked)->{
            if(checked)pickedInstalled.add(a.pkg);else pickedInstalled.remove(a.pkg);
            updateSelection();
        });
        row.addView(checkbox);card.addView(row);
        Ui.addCard(this,rows,card,9);
    }
    private void archiveCard(AppBackupRepository.Archived a) {
        LinearLayout card=Ui.card(this);LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        ImageView icon=new ImageView(this);if(a.icon!=null)icon.setImageDrawable(a.icon);
        row.addView(icon,new LinearLayout.LayoutParams(Ui.dp(this,49),Ui.dp(this,49)));
        LinearLayout details=new LinearLayout(this);details.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(0,-2,1);dp.leftMargin=Ui.dp(this,9);
        row.addView(details,dp);
        details.addView(Ui.text(this,a.name,16,Ui.TEXT,true));
        details.addView(Ui.text(this,a.pkg,11,Ui.MUTED,false));
        details.addView(Ui.text(this,"v"+a.version+" ("+a.code+") · "+size(a.bytes),12,Ui.MUTED,false));
        details.addView(Ui.text(this,"Backup: "+date(a.backedUpAt),11,Ui.MUTED,false));
        details.addView(Ui.text(this,(a.installed?"✓ INSTALLED":"NOT INSTALLED")+"  ·  "+
                (a.split()?"BASE + "+(a.parts.size()-1)+" SPLITS":"SINGLE APK"),11,
                a.installed?Ui.GREEN:Ui.ACCENT,false));
        CheckBox checkbox=new CheckBox(this);
        checkbox.setButtonTintList(android.content.res.ColorStateList.valueOf(Ui.ACCENT));
        checkbox.setChecked(pickedArchived.contains(a.key()));
        checkbox.setContentDescription("Select backup "+a.name);
        checkbox.setOnCheckedChangeListener((button,checked)->{
            if(checked)pickedArchived.add(a.key());else pickedArchived.remove(a.key());
            updateSelection();
        });
        row.addView(checkbox);card.addView(row);
        Ui.addCard(this,rows,card,9);
    }
    private void updateSelection() {
        if(selectionStatus!=null)selectionStatus.setText((archivedTab?pickedArchived.size():pickedInstalled.size())+
                " selected  ·  "+(archivedTab?"Restore / Share / Delete Backup":"Backup / Share / Uninstall"));
    }
    private void selectAll(boolean checked) {
        if(archivedTab){for(AppBackupRepository.Archived a:filteredArchived()){
            if(checked)pickedArchived.add(a.key());else pickedArchived.remove(a.key());
        }} else {for(AppBackupRepository.Installed a:filteredInstalled()) {
            if(checked)pickedInstalled.add(a.pkg);else pickedInstalled.remove(a.pkg);
        }}
        renderRows();
    }
    private List<AppBackupRepository.Installed> selectedInstalled() {
        List<AppBackupRepository.Installed> out=new ArrayList<>();
        for(AppBackupRepository.Installed a:installed)if(pickedInstalled.contains(a.pkg))out.add(a);
        return out;
    }
    private List<AppBackupRepository.Archived> selectedArchived() {
        List<AppBackupRepository.Archived> out=new ArrayList<>();
        for(AppBackupRepository.Archived a:archived)if(pickedArchived.contains(a.key()))out.add(a);
        return out;
    }
    private void backupOrRestore() {
        if(busy)return;
        if(archivedTab) {
            List<AppBackupRepository.Archived> targets=selectedArchived();
            if(targets.isEmpty()){toast("Select archived apps to restore");return;}
            if(AppRestoreCoordinator.hasQueued(this) || AppRestoreCoordinator.active(this)){
                toast("Another restore is already running; finish the Android confirmations first.");return;
            }
            new AlertDialog.Builder(this).setTitle("Restore "+targets.size()+" app(s)?")
                    .setMessage("Android will request approval for each installation. Split APKs will be submitted together. "
                            +"Existing app signatures must match to update installed apps.")
                    .setNegativeButton("Cancel",null).setPositiveButton("Restore",(d,w)->{
                        AppRestoreCoordinator.begin(this,targets);
                        if(!AppRestoreCoordinator.hasPermission(this))requestUnknownInstallPermission();
                        else progress(AppRestoreCoordinator.status(this),0);
                    }).show();
            return;
        }
        List<AppBackupRepository.Installed> selected=selectedInstalled();
        if(selected.isEmpty()){toast("Select installed apps for backup");return;}
        if(AppBackupPreferences.treeUri(this)==null){
            new AlertDialog.Builder(this).setTitle("Choose Storage Folder")
                    .setMessage("Select Internal Storage or SD Card in Backup Settings first.")
                    .setPositiveButton("Settings",(d,w)->startActivity(new Intent(this,AppBackupSettingsActivity.class)))
                    .setNegativeButton("Cancel",null).show();
            return;
        }
        new AlertDialog.Builder(this).setTitle("Backup "+selected.size()+" app(s)?")
                .setMessage("Copies installed base APKs and all split APKs without modifying signatures. "
                        +"This does not back up private app data or logins.")
                .setNegativeButton("Cancel",null).setPositiveButton("Start Backup",(d,w)->{
                    busy=true;lastBackupSummary="";progress("Starting backup…",0);
                    io.execute(()->{
                        int ok=0,fail=0;String lastFailure="";
                        for(int i=0;i<selected.size();i++){
                            AppBackupRepository.Installed app=selected.get(i);
                            final int position=i;
                            try {repo.backup(app,(text,value)->reporter.update(
                                    (position+1)+"/"+selected.size()+" · "+text,value));ok++;}
                            catch(Exception error){fail++;lastFailure=app.name+": "+error.getMessage();
                                reporter.update("Backup failed: "+lastFailure,0);}
                        }
                        final int done=ok,errors=fail;final String failure=lastFailure;
                        runOnUiThread(()->{
                            busy=false;
                            lastBackupSummary="Backup finished: "+done+" successful/skipped, "+errors+
                                    " failed"+(failure.isEmpty()?"":" · "+failure);
                            progress(lastBackupSummary,100);
                            pickedInstalled.clear();refresh();
                            toast(errors==0?"Backup finished":"Backup finished with failures; check storage");
                        });
                    });
                }).show();
    }
    private void requestUnknownInstallPermission() {
        try {
            Intent intent=new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:"+getPackageName()));
            startActivityForResult(intent,REQ_INSTALL_PERMISSION);
        } catch(Exception error){toast("Allow install unknown apps in Android Settings");}
    }
    private void share() {
        if(busy)return;
        List<Uri> uriList=new ArrayList<>();
        if(archivedTab) {
            for(AppBackupRepository.Archived a:selectedArchived())uriList.addAll(repo.shareUris(a));
            if(uriList.isEmpty()){toast("Select APK backups to share");return;}
            sendShare(uriList);return;
        }
        List<AppBackupRepository.Installed> selected=selectedInstalled();
        if(selected.isEmpty()){toast("Select installed apps to share their APK");return;}
        busy=true;progress("Preparing original APKs for sharing…",0);
        io.execute(()->{
            try { List<Uri> files=repo.shareInstalled(selected);
                runOnUiThread(()->{busy=false;progress("APKs ready to share",100);sendShare(files);});
            } catch(Exception error){runOnUiThread(()->{busy=false;progress("Share failed: "+error.getMessage(),0);});}
        });
    }
    private void sendShare(List<Uri> links) {
        if(links.isEmpty())return;
        try {
            Intent intent=new Intent(links.size()>1?Intent.ACTION_SEND_MULTIPLE:Intent.ACTION_SEND);
            intent.setType(links.size()>1?"application/octet-stream":AppBackupRepository.APK_MIME);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            ClipData clip=ClipData.newUri(getContentResolver(),"APK",links.get(0));
            for(int i=1;i<links.size();i++)clip.addItem(new ClipData.Item(links.get(i)));
            intent.setClipData(clip);
            if(links.size()==1)intent.putExtra(Intent.EXTRA_STREAM,links.get(0));
            else intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM,new ArrayList<>(links));
            startActivity(Intent.createChooser(intent,"Share APK file(s)"));
        } catch(Exception error){toast("Sharing failed: "+error.getMessage());}
    }
    private void deleteOrUninstall() {
        if(busy)return;
        if(archivedTab) {
            List<AppBackupRepository.Archived> targets=selectedArchived();
            if(targets.isEmpty()){toast("Select backups to delete");return;}
            new AlertDialog.Builder(this).setTitle("Delete "+targets.size()+" APK backup(s)?")
                    .setMessage("This permanently removes the selected archives from your chosen storage folder. "
                            +"It does not uninstall any installed apps.")
                    .setNegativeButton("Cancel",null).setPositiveButton("Delete Backup",(d,w)->{
                        busy=true;
                        io.execute(()->{
                            int ok=0;for(AppBackupRepository.Archived a:targets)if(repo.deleteArchive(a))ok++;
                            final int count=ok;
                            runOnUiThread(()->{busy=false;pickedArchived.clear();refresh();
                                toast("Deleted "+count+" of "+targets.size()+" archives");});
                        });
                    }).show();
            return;
        }
        List<AppBackupRepository.Installed> targets=selectedInstalled();
        if(targets.isEmpty()){toast("Select apps to uninstall");return;}
        new AlertDialog.Builder(this).setTitle("Uninstall "+targets.size()+" app(s)?")
                .setMessage("Android asks for your confirmation for each app. "
                        +"System apps usually cannot be fully uninstalled without special privileges.")
                .setNegativeButton("Cancel",null).setPositiveButton("Continue",(d,w)->{
                    uninstallQueue=new ArrayList<>();for(AppBackupRepository.Installed a:targets)uninstallQueue.add(a.pkg);
                    uninstallIndex=0;uninstallNext();
                }).show();
    }
    private void uninstallNext() {
        if(uninstallIndex>=uninstallQueue.size()){toast("Uninstall flow finished");refresh();return;}
        String pkg=uninstallQueue.get(uninstallIndex);
        try {
            Intent intent=new Intent(Intent.ACTION_UNINSTALL_PACKAGE);
            intent.setData(Uri.parse("package:"+pkg));
            intent.putExtra(Intent.EXTRA_RETURN_RESULT,true);
            startActivityForResult(intent,REQ_UNINSTALL);
        } catch(Exception error) {toast("Cannot uninstall "+pkg);uninstallIndex++;uninstallNext();}
    }
    @Override protected void onActivityResult(int req,int result,Intent data) {
        super.onActivityResult(req,result,data);
        if(req==REQ_UNINSTALL){
            if(result==RESULT_OK){uninstallIndex++;uninstallNext();}
            else {uninstallQueue.clear();refresh();toast("Uninstall canceled or denied");}
        } else if(req==REQ_INSTALL_PERMISSION){
            if(AppRestoreCoordinator.hasPermission(this))AppRestoreCoordinator.resume(this);
            else toast("Installation permission not granted");
        }
    }
    void requestInstallApproval(Intent intent) {
        runOnUiThread(()->{
            try { startActivity(intent); }
            catch(Exception error){
                progress("Android install confirmation could not open: "+error.getMessage(),0);
            }
        });
    }
    private void toast(String message) {Toast.makeText(this,message,Toast.LENGTH_LONG).show();}
    @Override protected void onResume() {
        super.onResume();foreground=new WeakReference<>(this);
        handler.removeCallbacks(statusTicker);handler.post(statusTicker);
        AppRestoreCoordinator.resumeApprovalWhenVisible(this);
        if(AppRestoreCoordinator.hasPermission(this))AppRestoreCoordinator.resume(this);
        if(repo!=null && rows!=null && !busy)refresh();
    }
    @Override protected void onPause() {
        if(foreground.get()==this)foreground.clear();handler.removeCallbacks(statusTicker);super.onPause();
    }
    @Override protected void onDestroy(){handler.removeCallbacks(statusTicker);io.shutdown();super.onDestroy();}
}
