package com.smarttoolbox.pro;

import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.text.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public class AppsBackupActivity extends Activity {
    static AppsBackupActivity active;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private SharedPreferences prefs; private AppsBackupStore store; private LinearLayout root,toolbar,tabbar,bottom; private FrameLayout frame,listFrame; private ListView list; private TextView empty,primary,selectAll,installedTab,archiveTab; private EditText search;
    private List<AppsBackupStore.Entry> installed=new ArrayList<>(),archives=new ArrayList<>(),visible=new ArrayList<>();
    private final Set<String> selected=new LinkedHashSet<>(); private final ArrayDeque<AppsBackupStore.Entry> restoreQueue=new ArrayDeque<>(),deleteQueue=new ArrayDeque<>();
    private boolean archived=false,settings=false,searching=false,dark=false,busy=false,resumed=false; private String filter=""; private int sort=0,bg,fg,muted,accent,border,bar,surface,sessionId=-1; private boolean priority=false,preparing=false; private Runnable afterFolder; private FrameLayout drawer; private ProgressDialog progress;
    private static final int FOLDER=20,INSTALL_PERMISSION=21,UNINSTALL=22;
    private int themeWhenCreated;
    @Override public void onCreate(Bundle state){
        // Keep the backup module visually consistent with the rest of SR Smart Toolbox Pro.
        ThemeManager.applyToActivity(this);
        super.onCreate(state);
        prefs=getSharedPreferences("sr_apps_backup_settings_v1",MODE_PRIVATE);
        dark=!ThemeManager.isLight(this);
        store=new AppsBackupStore(this);active=this;store.pruneShare();
        sort=prefs.getInt("sort",0);priority=prefs.getBoolean("priority",false);
        themeWhenCreated=ThemeManager.styleKey(this);
        palette();home();refresh();
    }
    @Override protected void onResume(){
        super.onResume();resumed=true;active=this;
        if(themeWhenCreated!=ThemeManager.styleKey(this) && !busy){recreate();return;}
        if(!preparing&&sessionId==-1&&!restoreQueue.isEmpty())advanceRestore();
    }
    @Override protected void onPause(){resumed=false;super.onPause();}
    @Override protected void onDestroy(){if(active==this)active=null;worker.shutdown();super.onDestroy();}
    private void palette(){
        bg=Ui.BG;surface=Ui.CARD;fg=Ui.TEXT;muted=Ui.MUTED;
        accent=Ui.ACCENT;border=Ui.CARD_2;bar=Ui.isPremium()?Ui.shade(Ui.CARD,Ui.ACCENT,.14f):Ui.CARD;
        getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);
        int flags=getWindow().getDecorView().getSystemUiVisibility();
        flags=ThemeManager.isLight(this)?flags|View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR:
                flags&~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        getWindow().getDecorView().setSystemUiVisibility(flags);
    }
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    private LinearLayout col(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);return x;}
    private LinearLayout row(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.HORIZONTAL);x.setGravity(Gravity.CENTER_VERTICAL);return x;}
    private TextView text(String s,float size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);t.setFontFeatureSettings("kern");return t;}
    private GradientDrawable shape(int color,int radius,int stroke){
        GradientDrawable d=(Ui.isPremium()&&color==surface)
                ?new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{
                    Ui.shade(surface,accent,.10f),surface,Ui.shade(surface,border,.25f)})
                :new GradientDrawable();
        if(!(Ui.isPremium()&&color==surface))d.setColor(color);
        d.setCornerRadius(dp(Ui.isPremium()?Math.max(radius,18):radius));
        if(stroke!=0)d.setStroke(dp(1),Ui.isPremium()?Ui.shade(stroke,accent,.30f):stroke);
        return d;
    }
    private TextView icon(String symbol,String desc,Runnable action){TextView t=new ToolIcon(desc);t.setText(symbol);t.setGravity(Gravity.CENTER);t.setContentDescription(desc);t.setOnClickListener(v->action.run());return t;}
    private class ToolIcon extends TextView {
        final String kind; final Paint pen=new Paint(Paint.ANTI_ALIAS_FLAG);
        ToolIcon(String kind){super(AppsBackupActivity.this);this.kind=kind;}
        private void l(Canvas c,float x,float y,float a,float b){c.drawLine(x,y,a,b,pen);}
        @Override protected void onDraw(Canvas canvas){
            canvas.save();canvas.translate(getWidth()/2f-dp(12),getHeight()/2f-dp(12));canvas.scale(dp(24)/24f,dp(24)/24f);
            pen.setColor(accent);pen.setStyle(Paint.Style.STROKE);pen.setStrokeWidth(2);pen.setStrokeCap(Paint.Cap.ROUND);pen.setStrokeJoin(Paint.Join.ROUND);
            switch(kind){
                case "Navigation menu":l(canvas,3,5,21,5);l(canvas,3,12,21,12);l(canvas,3,19,21,19);break;
                case "Search":canvas.drawCircle(10,10,6,pen);l(canvas,14.5f,14.5f,21,21);break;
                case "Sort":l(canvas,3,6,21,6);l(canvas,3,12,15,12);l(canvas,3,18,9,18);break;
                case "More options":pen.setStyle(Paint.Style.FILL);canvas.drawCircle(12,5,1.8f,pen);canvas.drawCircle(12,12,1.8f,pen);canvas.drawCircle(12,19,1.8f,pen);break;
                case "Close search":case "Back":l(canvas,5,12,21,12);l(canvas,5,12,12,5);l(canvas,5,12,12,19);break;
                case "Refresh":canvas.drawArc(4,4,20,20,45,285,false,pen);l(canvas,19,3,19,9);l(canvas,19,9,13,9);break;
                case "Delete / Uninstall":l(canvas,4,5,20,5);l(canvas,9,3,15,3);canvas.drawRoundRect(6,8,18,21,1,1,pen);l(canvas,10,11,10,18);l(canvas,14,11,14,18);break;
                case "Share":l(canvas,6,12,18,5);l(canvas,6,12,18,19);pen.setStyle(Paint.Style.FILL);canvas.drawCircle(5,12,3,pen);canvas.drawCircle(19,4,3,pen);canvas.drawCircle(19,20,3,pen);break;
                case "Select all":canvas.drawRoundRect(4,4,20,20,1,1,pen);if("☑".contentEquals(getText())){l(canvas,7,12,10,15);l(canvas,10,15,17,8);}break;
            }canvas.restore();
        }
    }
    private void line(LinearLayout parent){View v=new View(this);v.setBackgroundColor(border);parent.addView(v,new LinearLayout.LayoutParams(-1,dp(1)));}
    private void home(){
        UiSound.play(this,UiSound.NAVIGATE);
        settings=false;drawer=null;frame=new FrameLayout(this);root=col();root.setBackgroundColor(bg);frame.addView(root,new FrameLayout.LayoutParams(-1,-1));setContentView(frame);
        toolbar=row();toolbar.setPadding(dp(5),0,dp(3),0);root.addView(toolbar,new LinearLayout.LayoutParams(-1,dp(64)));buildToolbar();
        tabbar=row();installedTab=tab("Installed",false);archiveTab=tab("Archived",true);line(root);
        // Tab bar goes immediately above the divider.
        root.addView(tabbar,1,new LinearLayout.LayoutParams(-1,dp(49)));
        listFrame=new FrameLayout(this);root.addView(listFrame,new LinearLayout.LayoutParams(-1,0,1));
        list=new ListView(this);list.setDivider(null);list.setDividerHeight(0);list.setPadding(dp(6),dp(3),dp(6),dp(4));list.setClipToPadding(false);list.setVerticalScrollBarEnabled(true);listFrame.addView(list,new FrameLayout.LayoutParams(-1,-1));
        empty=text("",15,muted);empty.setGravity(Gravity.CENTER);empty.setPadding(dp(24),0,dp(24),0);listFrame.addView(empty,new FrameLayout.LayoutParams(-1,-1));
        bottom=row();bottom.setBackgroundColor(bar);bottom.setPadding(dp(4),dp(4),dp(4),dp(4));root.addView(bottom,new LinearLayout.LayoutParams(-1,dp(54)));
        addControl("↻","Refresh",()->refresh());addControl("▣","Delete / Uninstall",()->deleteSelected());primary=text("Backup",15,Color.luminance(accent)>.45f?Color.BLACK:Color.WHITE);primary.setGravity(Gravity.CENTER);primary.setBackground(shape(accent,40,0));bottom.addView(primary,new LinearLayout.LayoutParams(0,dp(44),1.5f));primary.setOnClickListener(v->{if(archived)restoreSelected();else backupSelected();});addControl("•—•","Share",()->shareSelected());selectAll=icon("□","Select all",()->toggleAll());bottom.addView(selectAll,new LinearLayout.LayoutParams(0,-1,1));
        updateList();
    }
    private void addControl(String s,String desc,Runnable action){TextView t=icon(s,desc,action);bottom.addView(t,new LinearLayout.LayoutParams(0,-1,1));}
    private TextView tab(String name,boolean a){TextView t=text(name,14,fg);t.setGravity(Gravity.CENTER);LinearLayout wrapper=col();wrapper.addView(t,new LinearLayout.LayoutParams(-1,0,1));View marker=new View(this);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(45),dp(3));lp.gravity=Gravity.CENTER_HORIZONTAL;wrapper.addView(marker,lp);wrapper.setOnClickListener(v->{if(busy)return;archived=a;selected.clear();updateList();});t.setOnClickListener(v->wrapper.performClick());tabbar.addView(wrapper,new LinearLayout.LayoutParams(0,-1,1));return t;}
    private void buildToolbar(){toolbar.removeAllViews();if(searching){toolbar.addView(icon("‹","Close search",()->closeSearch()),new LinearLayout.LayoutParams(dp(48),-1));search=new EditText(this);search.setSingleLine(true);search.setTextSize(17);search.setTextColor(fg);search.setHintTextColor(muted);search.setHint("Search apps");search.setText(filter);toolbar.addView(search,new LinearLayout.LayoutParams(0,-1,1));search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int c){filter=s.toString();selected.clear();updateList();}public void afterTextChanged(Editable e){}});search.requestFocus();search.post(()->((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(search,InputMethodManager.SHOW_IMPLICIT));return;}
        toolbar.addView(icon("☰","Navigation menu",()->showDrawer()),new LinearLayout.LayoutParams(dp(48),-1));TextView title=text("📦 Apps Backup",19,fg);title.setSingleLine(true);toolbar.addView(title,new LinearLayout.LayoutParams(0,-1,1));toolbar.addView(icon("⌕","Search",()->{searching=true;buildToolbar();}),new LinearLayout.LayoutParams(dp(43),-1));TextView sortButton=icon("≡","Sort",()->{});sortButton.setOnClickListener(v->showSort(v));toolbar.addView(sortButton,new LinearLayout.LayoutParams(dp(43),-1));TextView more=icon("⋮","More options",()->{});more.setOnClickListener(v->showMore(v));toolbar.addView(more,new LinearLayout.LayoutParams(dp(36),-1));
    }
    private void closeSearch(){if(search!=null)((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(search.getWindowToken(),0);searching=false;filter="";selected.clear();buildToolbar();updateList();}
    private void showSort(View anchor){PopupMenu menu=new PopupMenu(this,anchor);String[] labels={"Name ascending","Name descending","Date ascending","Date descending","Size ascending","Size descending"};for(int i=0;i<labels.length;i++)menu.getMenu().add(1,i,0,labels[i]).setCheckable(true).setChecked(sort==i);menu.getMenu().setGroupCheckable(1,true,true);menu.getMenu().add(2,6,0,"Not installed/archived at Top").setCheckable(true).setChecked(priority);menu.setOnMenuItemClickListener(item->{if(item.getItemId()==6)priority=!priority;else sort=item.getItemId();prefs.edit().putInt("sort",sort).putBoolean("priority",priority).apply();updateList();return true;});menu.show();}
    private void showMore(View anchor){PopupMenu m=new PopupMenu(this,anchor);String[] a={"Share this App","Backup Settings","Give Facebook Like","Privacy policy","About Developer"};for(int i=0;i<a.length;i++)m.getMenu().add(0,i,i,a[i]);m.setOnMenuItemClickListener(item->{switch(item.getItemId()){case 0:shareThis();break;case 1:showSettings();break;case 2:open("https://fb.com/srcreation.farm");break;case 3:privacy();break;case 4:about();break;}return true;});m.show();}
    private void showDrawer(){if(drawer!=null)return;drawer=new FrameLayout(this);drawer.setBackgroundColor(0x88000000);frame.addView(drawer,new FrameLayout.LayoutParams(-1,-1));drawer.setOnClickListener(v->closeDrawer());LinearLayout panel=col();panel.setBackgroundColor(bg);panel.setOnClickListener(v->{});FrameLayout.LayoutParams params=new FrameLayout.LayoutParams((int)(getResources().getDisplayMetrics().widthPixels*.84),-1,Gravity.LEFT);drawer.addView(panel,params);LinearLayout head=col();head.setGravity(Gravity.CENTER);head.setBackgroundColor(Ui.shade(accent,Color.BLACK,.52f));ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.ic_launcher);head.addView(logo,new LinearLayout.LayoutParams(dp(76),dp(76)));TextView brand=text("SR Creation Farm  •  App Backup",16,Color.WHITE);brand.setGravity(Gravity.CENTER);head.addView(brand,new LinearLayout.LayoutParams(-1,dp(40)));panel.addView(head,new LinearLayout.LayoutParams(-1,dp(154)));drawerItem(panel,"⚙    Settings",()->showSettings());drawerItem(panel,"↗    Share app",()->shareThis());drawerItem(panel,"★    Rate app",()->new AlertDialog.Builder(this).setMessage("No store listing yet. Thank you for using SR Creation Farm apps.").setPositiveButton("OK",null).show());drawerItem(panel,"▶    YouTube",()->open("https://www.youtube.com/@SRCreation-farm"));drawerItem(panel,"f     Facebook",()->open("https://fb.com/srcreation.farm"));drawerItem(panel,"ⓘ    About Developer",()->about());}
    private void drawerItem(LinearLayout panel,String s,Runnable r){TextView t=text(s,17,fg);t.setPadding(dp(24),0,0,0);panel.addView(t,new LinearLayout.LayoutParams(-1,dp(55)));t.setOnClickListener(v->{closeDrawer();r.run();});}
    private void closeDrawer(){if(drawer!=null){frame.removeView(drawer);drawer=null;}}
    private Uri tree(){String s=prefs.getString("folder",null);return s==null?null:Uri.parse(s);}
    private String pathLabel(){Uri u=tree();if(u==null)return AppsBackupStore.supportsAutomaticPublicFolder()
            ? "Download / App Backup (automatic on first backup)"
            : "Choose a parent folder (Android 8–9)";
        try{return DocumentsContractId(u)+" / App Backup (created automatically if needed)";}
        catch(Exception ex){return u.toString();}}
    private String DocumentsContractId(Uri u){String id=android.provider.DocumentsContract.getTreeDocumentId(u);return id.startsWith("primary:")?"/storage/emulated/0/"+id.substring(8):id;}
    private void chooseFolder(Runnable then){if(busy)return;afterFolder=then;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION|Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);try{startActivityForResult(i,FOLDER);}catch(Exception e){afterFolder=null;toast("No folder picker available");}}
    private void showSettings(){if(busy)return;closeDrawer();settings=true;LinearLayout screen=col();screen.setBackgroundColor(bg);setContentView(screen);LinearLayout top=row();top.addView(icon("‹","Back",()->{home();refresh();}),new LinearLayout.LayoutParams(dp(60),dp(60)));top.addView(text("Settings",22,fg));screen.addView(top);ScrollView sc=new ScrollView(this);screen.addView(sc,new LinearLayout.LayoutParams(-1,0,1));LinearLayout items=col();sc.addView(items);section(items,"GENERAL");setting(items,"Backup path",pathLabel(),()->chooseFolder(null));
        if(AppsBackupStore.supportsAutomaticPublicFolder() && tree()!=null)
            setting(items,"↺ Use automatic Download/App Backup", "New backups go to Download/App Backup. Your existing custom-folder files stay untouched.", () -> {
                prefs.edit().remove("folder").apply();showSettings();if(!busy)refresh();
            });
        setting(items,"App Permissions", "See permissions and their associated features in one place", () -> startActivity(new Intent(this, AppPermissionsActivity.class)));
        setting(items,"Premium / Classic & Sounds","Uses the global SR Smart Toolbox appearance",()->startActivity(new Intent(this,ThemeSettingsActivity.class)));setting(items,"Backup format","Download/App Backup/*.apk and Download/App Backup/Split backups/*.apks",()->new AlertDialog.Builder(this).setTitle("APK backup format").setMessage("Android 10+: the first backup automatically creates Download/App Backup. Normal APKs are saved inside; split apps also get a complete .apks file in the Split backups subfolder. Select a custom folder only if you want a different location. Android 8–9 needs a one-time parent-folder selection. Use Archived > Restore for split apps; their base APK may not install alone.").setPositiveButton("OK",null).show());checkSetting(items,"Keep old version apk","Keep the old version apk by version number in app name on backup","keep");checkSetting(items,"Show System Apps","Show system apps in Installed apps list","system");line(items);section(items,"OTHER");setting(items,"Privacy policy",null,()->privacy());setting(items,"About Developer",null,()->about());}
    private void section(LinearLayout p,String title){TextView t=text(title,14,muted);t.setPadding(dp(76),dp(24),0,dp(8));p.addView(t,new LinearLayout.LayoutParams(-1,dp(60)));}
    private LinearLayout settingText(String title,String sub){LinearLayout x=col();x.setGravity(Gravity.CENTER_VERTICAL);TextView t=text(title,17,fg);x.addView(t);if(sub!=null){TextView s=text(sub,14,muted);s.setPadding(0,dp(4),0,0);x.addView(s);}return x;}
    private void setting(LinearLayout parent,String title,String sub,Runnable r){LinearLayout x=settingText(title,sub);x.setPadding(dp(76),dp(10),dp(20),dp(10));x.setMinimumHeight(dp(73));parent.addView(x,new LinearLayout.LayoutParams(-1,-2));x.setOnClickListener(v->r.run());}
    private CheckBox check(boolean checked){CheckBox x=new CheckBox(this);x.setButtonTintList(ColorStateList.valueOf(accent));x.setChecked(checked);return x;}
    private void checkSetting(LinearLayout parent,String title,String sub,String key){LinearLayout x=row();x.setPadding(dp(76),dp(12),dp(20),dp(12));x.setMinimumHeight(dp(85));x.addView(settingText(title,sub),new LinearLayout.LayoutParams(0,-2,1));CheckBox cb=check(prefs.getBoolean(key,false));x.addView(cb,new LinearLayout.LayoutParams(dp(44),dp(48)));cb.setOnCheckedChangeListener((b,c)->prefs.edit().putBoolean(key,c).apply());x.setOnClickListener(v->cb.toggle());parent.addView(x);}
    private void privacy(){new AlertDialog.Builder(this).setTitle("Privacy policy").setMessage("This feature reads installed app names, versions and APK packages to create local installation backups. By default on Android 10+ the files are written to your shared Download/App Backup folder; you can instead choose a custom SAF folder. Files are only shared when you initiate it. Private app data, accounts and messages are not backed up. Android controls installation permissions. Other SR Toolbox features may use Internet or additional permissions (see App Permissions).").setPositiveButton("OK",null).show();}
    private void about(){new AlertDialog.Builder(this).setTitle("About Developer").setIcon(R.drawable.ic_launcher).setMessage("SR Smart Toolbox Pro · Apps Backup\n\nDeveloper: Shahriar Rahman\nBrand: SR Creation Farm\n© SR Creation Farm").setPositiveButton("YouTube",(d,w)->open("https://www.youtube.com/@SRCreation-farm")).setNeutralButton("Facebook",(d,w)->open("https://fb.com/srcreation.farm")).setNegativeButton("Close",null).show();}
    private void open(String s){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(s)));}catch(Exception e){toast("No browser available");}}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    private void error(String s){new AlertDialog.Builder(this).setTitle("Notice").setMessage(s).setPositiveButton("OK",null).show();}
    private interface Task<T>{T run()throws Exception;}
    private interface Done<T>{void accept(T result);}
    private <T> void work(String title,Task<T> task,Done<T> done,Done<Exception> failed){if(busy)return;busy=true;progress=new ProgressDialog(this);progress.setMessage(title);progress.setCancelable(false);progress.show();worker.execute(()->{try{T result=task.run();runOnUiThread(()->{finishWork();if(!isFinishing()&&!isDestroyed())done.accept(result);});}catch(Exception ex){runOnUiThread(()->{finishWork();if(!isFinishing()&&!isDestroyed())failed.accept(ex);});}});}
    private void finishWork(){busy=false;if(progress!=null){progress.dismiss();progress=null;}}
    private void refresh(){if(busy||isFinishing())return;boolean sys=prefs.getBoolean("system",false);Uri folder=tree();work("Loading apps…",()->{List<AppsBackupStore.Entry> i=store.installed(sys);List<AppsBackupStore.Entry> a;String err=null;try{
            a=folder==null && AppsBackupStore.supportsAutomaticPublicFolder()
                    ?store.archivesPublic():store.archives(folder);
        }catch(Exception ex){a=new ArrayList<>();err="Backup folder unavailable. Check Apps Backup Settings.";}return new Object[]{i,a,err};},r->{installed=(List<AppsBackupStore.Entry>)r[0];archives=(List<AppsBackupStore.Entry>)r[1];if(!settings)updateList();if(r[2]!=null)toast((String)r[2]);},e->error("Cannot load apps: "+e.getMessage()));}
    private void updateList(){if(list==null||settings)return;visible=new ArrayList<>();String f=filter.toLowerCase(Locale.ROOT);Set<String> backed=new HashSet<>();for(AppsBackupStore.Entry e:archives)backed.add(e.pkg);Set<String> live=new HashSet<>();for(AppsBackupStore.Entry e:installed)live.add(e.pkg);
        for(AppsBackupStore.Entry e:archived?archives:installed)if(e.name.toLowerCase(Locale.ROOT).contains(f)||e.pkg.toLowerCase(Locale.ROOT).contains(f))visible.add(e);
        Comparator<AppsBackupStore.Entry> comp;switch(sort){case 1:comp=Comparator.comparing((AppsBackupStore.Entry e)->e.name,String.CASE_INSENSITIVE_ORDER).reversed();break;case 2:comp=Comparator.comparingLong(e->e.date);break;case 3:comp=Comparator.comparingLong((AppsBackupStore.Entry e)->e.date).reversed();break;case 4:comp=Comparator.comparingLong(e->e.size);break;case 5:comp=Comparator.comparingLong((AppsBackupStore.Entry e)->e.size).reversed();break;default:comp=Comparator.comparing(e->e.name,String.CASE_INSENSITIVE_ORDER);}
        if(priority){Comparator<AppsBackupStore.Entry> first=Comparator.comparingInt(e->(archived?live:backed).contains(e.pkg)?1:0);comp=first.thenComparing(comp);}visible.sort(comp);Set<String> keys=new HashSet<>();for(AppsBackupStore.Entry e:visible)keys.add(e.key);selected.retainAll(keys);
        installedTab.setTextColor(archived?fg:accent);archiveTab.setTextColor(archived?accent:fg);((LinearLayout)installedTab.getParent()).getChildAt(1).setBackgroundColor(archived?Color.TRANSPARENT:accent);((LinearLayout)archiveTab.getParent()).getChildAt(1).setBackgroundColor(archived?accent:Color.TRANSPARENT);
        int pos=list.getFirstVisiblePosition();View child=list.getChildAt(0);int offset=child==null?0:child.getTop();list.setAdapter(new AppAdapter());if(pos<visible.size())list.setSelectionFromTop(pos,offset);empty.setText(!filter.isEmpty()?"No matching apps":archived?(tree()==null && !AppsBackupStore.supportsAutomaticPublicFolder()?"No backups yet\nChoose a backup folder in Settings":"No archived apps"):"No installed apps");empty.setVisibility(visible.isEmpty()?View.VISIBLE:View.GONE);updateSelection();
    }
    private void updateSelection(){if(primary==null)return;primary.setText((archived?"Restore":"Backup")+(selected.isEmpty()?"":" ("+selected.size()+")"));selectAll.setText(!visible.isEmpty()&&selected.size()==visible.size()?"☑":"□");}
    private void toggleAll(){if(busy)return;if(!visible.isEmpty()&&selected.size()==visible.size())selected.clear();else for(AppsBackupStore.Entry e:visible)selected.add(e.key);((BaseAdapter)list.getAdapter()).notifyDataSetChanged();updateSelection();}
    private void toggle(AppsBackupStore.Entry e){if(busy)return;if(!selected.add(e.key))selected.remove(e.key);((BaseAdapter)list.getAdapter()).notifyDataSetChanged();updateSelection();}
    private String size(long n){return android.text.format.Formatter.formatFileSize(this,n);}
    private String date(long n){return n<=0?"Unknown date":new SimpleDateFormat("d MMM yyyy",Locale.ENGLISH).format(new Date(n));}
    private class AppAdapter extends BaseAdapter{
        public int getCount(){return visible.size();}public Object getItem(int p){return visible.get(p);}public long getItemId(int p){return p;}
        public View getView(int p,View recycled,android.view.ViewGroup parent){AppsBackupStore.Entry e=visible.get(p);LinearLayout outer=col();outer.setPadding(0,0,0,dp(5));LinearLayout card=row();card.setPadding(dp(15),dp(9),dp(13),dp(9));card.setBackground(shape(surface,13,border));if(Ui.isPremium())card.setElevation(dp(2));outer.addView(card,new LinearLayout.LayoutParams(-1,dp(76)));ImageView image=new ImageView(AppsBackupActivity.this);image.setImageDrawable(e.icon);image.setScaleType(ImageView.ScaleType.FIT_CENTER);card.addView(image,new LinearLayout.LayoutParams(dp(48),dp(48)));LinearLayout info=col();info.setGravity(Gravity.CENTER_VERTICAL);info.setPadding(dp(12),0,0,0);card.addView(info,new LinearLayout.LayoutParams(0,-1,1));TextView name=text(e.name,17,fg);name.setSingleLine(true);name.setEllipsize(TextUtils.TruncateAt.END);info.addView(name);TextView version=text("v"+e.version+(e.split?(e.baseUri!=null?"  ·  APK + Split":"  ·  Split APK"):"  ·  APK"),13,muted);version.setSingleLine(true);version.setEllipsize(TextUtils.TruncateAt.END);info.addView(version);TextView meta=text(size(e.size)+" | "+date(e.date),13,muted);meta.setSingleLine(true);info.addView(meta);CheckBox cb=check(selected.contains(e.key));cb.setContentDescription("Select "+e.name);card.addView(cb,new LinearLayout.LayoutParams(dp(42),dp(48)));cb.setOnClickListener(v->toggle(e));card.setOnClickListener(v->toggle(e));card.setOnLongClickListener(v->{details(e);return true;});return outer;}
    }
    private void details(AppsBackupStore.Entry e){AlertDialog.Builder d=new AlertDialog.Builder(this).setTitle(e.name).setIcon(e.icon).setMessage("Package: "+(e.pkg.isEmpty()?"Unknown":e.pkg)+"\nVersion: "+e.version+"\nSize: "+size(e.size)+"\nDate: "+date(e.date)+"\nFormat: "+(e.split?(e.baseUri!=null?"Base APK + complete split backup. Use Restore for all parts.":"Split APK (.apks). Use Restore."):"APK"));if(!e.archived)d.setNeutralButton("App info",(x,w)->{try{startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+e.pkg)));}catch(Exception ex){toast("App info unavailable");}});d.setPositiveButton("Close",null).show();}
    private List<AppsBackupStore.Entry> selection(){List<AppsBackupStore.Entry> x=new ArrayList<>();for(AppsBackupStore.Entry e:visible)if(selected.contains(e.key))x.add(e);if(x.isEmpty())toast("Select at least one app");return x;}
    private void backupSelected(){if(busy)return;List<AppsBackupStore.Entry> entries=selection();if(entries.isEmpty())return;
        if(tree()==null && !AppsBackupStore.supportsAutomaticPublicFolder()){
            chooseFolder(()->backupEntries(entries));return;
        }
        backupEntries(entries);
    }
    private void backupEntries(List<AppsBackupStore.Entry> entries){Uri u=tree();if(u==null && !AppsBackupStore.supportsAutomaticPublicFolder())return;
        boolean keep=prefs.getBoolean("keep",false);
        work("Backing up APK files…",()->{
            int success=0;StringBuilder errors=new StringBuilder();
            for(AppsBackupStore.Entry e:entries){try{
                if(u==null)store.backupPublic(e,keep);
                else store.backup(e,u,keep);
                success++;
            }catch(Exception ex){errors.append(e.name).append(": ").append(ex.getMessage()).append('\n');}}
            return new String[]{"Backed up "+success+" of "+entries.size()+" apps",errors.toString()};
        },r->{selected.clear();if(r[1].isEmpty())toast(r[0]+". Saved in App Backup; use Restore for split apps.");else error(r[0]+"\n"+r[1]);refresh();},e->error(e.getMessage()));
    }
    private void shareSelected(){if(busy)return;List<AppsBackupStore.Entry> entries=selection();if(entries.isEmpty())return;shareEntries(entries);}
    private void shareThis(){if(busy)return;work("Preparing app…",()->{for(AppsBackupStore.Entry e:store.installed(true))if(e.pkg.equals(getPackageName()))return e;throw new Exception("App not found");},e->shareEntries(Collections.singletonList(e)),e->error(e.getMessage()));}
    private void shareEntries(List<AppsBackupStore.Entry> entries){work("Preparing files to share…",()->{ArrayList<Uri> uris=new ArrayList<>();for(AppsBackupStore.Entry e:entries)uris.add(store.shareCopy(e));return uris;},uris->{Intent i=new Intent(uris.size()==1?Intent.ACTION_SEND:Intent.ACTION_SEND_MULTIPLE);i.setType(uris.size()==1?(uris.get(0).toString().endsWith(".apk")?"application/vnd.android.package-archive":"application/zip"):"application/octet-stream");if(uris.size()==1)i.putExtra(Intent.EXTRA_STREAM,uris.get(0));else i.putParcelableArrayListExtra(Intent.EXTRA_STREAM,uris);ClipData clip=ClipData.newRawUri("APK backup",uris.get(0));for(int j=1;j<uris.size();j++)clip.addItem(new ClipData.Item(uris.get(j)));i.setClipData(clip);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);try{startActivity(Intent.createChooser(i,"Share app files"));}catch(Exception ex){error("No sharing app available");}},e->error(e.getMessage()));}
    private void deleteSelected(){if(busy||preparing||sessionId!=-1||!restoreQueue.isEmpty())return;List<AppsBackupStore.Entry> entries=selection();if(entries.isEmpty())return;new AlertDialog.Builder(this).setTitle(archived?"Delete backups?":"Uninstall apps?").setMessage(archived?"Permanently delete "+entries.size()+" selected backups and their associated APK files?":"Android will request confirmation for each selected app. System apps may not be removable.").setNegativeButton("Cancel",null).setPositiveButton(archived?"Delete":"Uninstall",(d,w)->{if(archived){work("Deleting backups…",()->{int n=0;for(AppsBackupStore.Entry e:entries)try{if(store.deleteBackup(e))n++;}catch(Exception ignored){}return n;},n->{selected.clear();toast("Deleted "+n+" of "+entries.size());refresh();},e->error(e.getMessage()));}else{deleteQueue.clear();for(AppsBackupStore.Entry e:entries)if(!e.pkg.equals(getPackageName()))deleteQueue.add(e);nextUninstall();}}).show();}
    private void nextUninstall(){if(deleteQueue.isEmpty()){selected.clear();refresh();return;}AppsBackupStore.Entry e=deleteQueue.removeFirst();Intent i=new Intent(Intent.ACTION_DELETE,Uri.parse("package:"+e.pkg));i.putExtra(Intent.EXTRA_RETURN_RESULT,true);try{startActivityForResult(i,UNINSTALL);}catch(Exception ex){toast("Cannot uninstall "+e.name);nextUninstall();}}
    private void restoreSelected(){if(busy||preparing||sessionId!=-1||!restoreQueue.isEmpty())return;List<AppsBackupStore.Entry> entries=selection();if(entries.isEmpty())return;restoreQueue.addAll(entries);if(Build.VERSION.SDK_INT>=26&&!getPackageManager().canRequestPackageInstalls()){new AlertDialog.Builder(this).setTitle("Allow app installation").setMessage("Enable Allow from this source for SR Smart Toolbox Pro, then return.").setNegativeButton("Cancel",(d,w)->restoreQueue.clear()).setOnCancelListener(d->restoreQueue.clear()).setPositiveButton("Settings",(d,w)->{try{startActivityForResult(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:"+getPackageName())),INSTALL_PERMISSION);}catch(Exception ex){restoreQueue.clear();error("Cannot open install permission settings");}}).show();return;}advanceRestore();}
    private void advanceRestore(){if(!resumed||busy||preparing||sessionId!=-1||restoreQueue.isEmpty())return;if(Build.VERSION.SDK_INT>=26&&!getPackageManager().canRequestPackageInstalls())return;AppsBackupStore.Entry e=restoreQueue.removeFirst();preparing=true;work("Preparing "+e.name+"…",()->store.prepareInstall(e),id->{preparing=false;sessionId=id;try{store.commit(id);}catch(Exception ex){installResult(id,false,ex.getMessage());}},ex->{preparing=false;restoreQueue.clear();error(ex.getMessage());});}
    void installResult(int id,boolean success,String message){if(sessionId!=id)return;sessionId=-1;if(!success){restoreQueue.clear();error("Installation not completed. "+(message==null?"":message));selected.clear();return;}toast("App restored");if(restoreQueue.isEmpty()){selected.clear();refresh();}else if(resumed)advanceRestore();}
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == FOLDER) {
            Runnable then = afterFolder;
            afterFolder = null;
            if (result != RESULT_OK || data == null || data.getData() == null) return;
            try {
                Uri folder = data.getData();
                int granted = data.getFlags();
                // Both grants are necessary: listing/restoring and creating/deleting backups.
                if ((granted & Intent.FLAG_GRANT_READ_URI_PERMISSION) == 0 ||
                    (granted & Intent.FLAG_GRANT_WRITE_URI_PERMISSION) == 0) {
                    throw new SecurityException("Choose a folder with read and write access");
                }
                // Pass only the two permitted constants, not arbitrary Intent flags.
                getContentResolver().takePersistableUriPermission(folder,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                prefs.edit().putString("folder", folder.toString()).apply();
                if (settings) showSettings();
                if (then != null) then.run();
                else if (!settings) refresh();
            } catch (Exception ex) {
                error("Cannot use folder: " + ex.getMessage());
            }
        } else if (request == INSTALL_PERMISSION) {
            if (Build.VERSION.SDK_INT < 26 || getPackageManager().canRequestPackageInstalls()) {
                if (resumed) advanceRestore();
            } else {
                restoreQueue.clear();
                toast("Installation permission not granted");
            }
        } else if (request == UNINSTALL) {
            if (result != RESULT_OK) deleteQueue.clear();
            nextUninstall();
        }
    }
    @Override public void onBackPressed(){if(busy)return;if(drawer!=null){closeDrawer();return;}if(settings){home();refresh();return;}if(searching){closeSearch();return;}if(!selected.isEmpty()){selected.clear();updateList();return;}super.onBackPressed();}
}
