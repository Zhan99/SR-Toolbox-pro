package com.smarttoolbox.pro;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.documentfile.provider.DocumentFile;

import java.io.File;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Installed APK inventory, user-selected backup folder, sharing and user-confirmed restore. */
public final class AppsBackupActivity extends Activity {
    private static final int REQUEST_FOLDER = 4011;
    private static final int REQUEST_RESTORE_FILE = 4012;
    private static final int REQUEST_UNINSTALL = 4013;
    private static final String PREFS = "sr_apps_backup_prefs";
    private static final String BACKUP_TREE = "folder_uri";
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final List<ApkBackupStorage.InstalledApp> allApps = new ArrayList<>();
    private final List<ApkBackupStorage.InstalledApp> visibleApps = new ArrayList<>();
    private final Set<String> selected = new HashSet<>();
    private final Map<String, Drawable> icons = new HashMap<>();
    private final ArrayDeque<String> uninstallQueue = new ArrayDeque<>();
    private String currentlyUninstalling;
    private String query = "";
    private int filter = 0; // All installed apps initially; user/system filters available.
    private boolean busy;
    private Uri treeUri;
    private Uri pendingRestoreUri;
    private boolean backupAfterFolderChosen;
    private TextView status;
    private TextView countLabel;
    private TextView folderLabel;
    private LinearLayout backupList;
    private final AppAdapter adapter = new AppAdapter();

    @Override public void onCreate(Bundle savedInstanceState) {
        ThemeManager.applyToActivity(this);
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        String savedFolder = getSharedPreferences(PREFS, MODE_PRIVATE).getString(BACKUP_TREE, "");
        if (!savedFolder.isEmpty()) treeUri = Uri.parse(savedFolder);
        LinearLayout page = Ui.page(this, "📦 Apps Backup & Restore");
        LinearLayout body = Ui.content(page);
        Ui.addText(this, body, "SR Creation Farm · Original installed APK backups", 13,
                Ui.ACCENT, true, 3);
        Ui.addText(this, body, "অ্যাপের APK সংরক্ষণ হবে; অ্যাপের ব্যক্তিগত ডেটা/লগইন নয়। "
                + "Split Apps স্বয়ংক্রিয়ভাবে .apks ফরম্যাটে সংরক্ষিত হবে।",
                12, Ui.MUTED, false, 6);

        LinearLayout backupCard = Ui.card(this);
        Ui.addText(this, backupCard, "💾 Backup location", 18, Ui.TEXT, true, 0);
        folderLabel = Ui.addText(this, backupCard, "", 12, Ui.MUTED, false, 6);
        addButton(backupCard, "📁 Choose memory / SD-card folder", this::chooseBackupFolder);
        addButton(backupCard, "↩ Restore a saved .apk / .apks", this::openRestorePicker);
        Ui.addCard(this, body, backupCard, 12);

        Ui.addText(this, body, "📱 Installed applications", 19, Ui.TEXT, true, 22);
        EditText search = new EditText(this);
        search.setSingleLine(true);
        search.setHint("Search app name or package…");
        search.setTextColor(Ui.TEXT);
        search.setHintTextColor(Ui.MUTED);
        search.setTextSize(15);
        search.setPadding(Ui.dp(this, 14), Ui.dp(this, 11), Ui.dp(this, 14), Ui.dp(this, 11));
        search.setBackground(Ui.card(this).getBackground().getConstantState().newDrawable().mutate());
        LinearLayout.LayoutParams searchParams = new LinearLayout.LayoutParams(-1, -2);
        searchParams.topMargin = Ui.dp(this, 10);
        body.addView(search, searchParams);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                query = s.toString(); applyFilter();
            }
            @Override public void afterTextChanged(Editable e) {}
        });
        LinearLayout filters = new LinearLayout(this);
        filters.setOrientation(LinearLayout.HORIZONTAL);
        addFitButton(filters, "All", () -> setFilter(0));
        addFitButton(filters, "User Apps", () -> setFilter(1));
        addFitButton(filters, "System Apps", () -> setFilter(2));
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
        fp.topMargin = Ui.dp(this, 9);
        body.addView(filters, fp);
        countLabel = Ui.addText(this, body, "Loading…", 12, Ui.MUTED, false, 10);
        status = Ui.addText(this, body, "Reading installed apps…", 12, Ui.ACCENT, false, 3);

        LinearLayout row = new LinearLayout(this);
        addFitButton(row, "✓ Select All", this::selectVisible);
        addFitButton(row, "✕ Deselect All", () -> {
            selected.clear(); adapter.notifyDataSetChanged(); updateCount();
        });
        addFitButton(row, "↻ Refresh", this::loadInstalledApps);
        Ui.addCard(this, body, row, 8);

        ListView list = new ListView(this);
        list.setAdapter(adapter);
        list.setDividerHeight(Ui.dp(this, 5));
        list.setCacheColorHint(android.graphics.Color.TRANSPARENT);
        list.setOnItemClickListener((parent, view, position, id) -> toggleItem(visibleApps.get(position)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, Ui.dp(this, 475));
        lp.topMargin = Ui.dp(this, 7);
        body.addView(list, lp);

        LinearLayout actions = Ui.card(this);
        Ui.addText(this, actions, "Actions for selected apps", 17, Ui.TEXT, true, 0);
        addButton(actions, "💾 Backup selected APKs", this::backupSelected);
        addButton(actions, "↗ Share original APKs", this::shareSelected);
        addButton(actions, "🗑 Uninstall selected apps", this::uninstallSelected);
        Ui.addText(this, actions,
                "Uninstall-এর প্রতিটি অ্যাপ Android-এর অনুমতি/Confirmation দিয়ে হবে। "
                + "System Apps এবং এই অ্যাপ নিজে Uninstall হবে না।",
                12, Ui.MUTED, false, 9);
        Ui.addCard(this, body, actions, 11);

        Ui.addText(this, body, "🗂 Saved backups", 19, Ui.TEXT, true, 22);
        Ui.addText(this, body, "নির্বাচিত ফোল্ডারে থাকা .apk / .apks ফাইল এখানে দেখা যাবে।",
                12, Ui.MUTED, false, 3);
        backupList = new LinearLayout(this);
        backupList.setOrientation(LinearLayout.VERTICAL);
        body.addView(backupList);
        Ui.addText(this, body, "Backup সীমাবদ্ধতা: Some protected apps may not expose a readable APK. "
                + "Restoring does not restore personal app data. A split .apks bundle needs this "
                + "Restore option; renaming it to .apk will not work.",
                12, Ui.MUTED, false, 17);
        setContentView(page);
        updateFolderLabel();
        loadInstalledApps();
        refreshBackups();
    }

    private void addButton(LinearLayout parent, String title, Runnable action) {
        Button button = Ui.button(this, title, action);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = Ui.dp(this, 9);
        parent.addView(button, params);
    }
    private void addFitButton(LinearLayout parent, String title, Runnable action) {
        Button button = Ui.button(this, title, action);
        button.setTextSize(12);
        button.setPadding(Ui.dp(this, 3), Ui.dp(this, 9), Ui.dp(this, 3), Ui.dp(this, 9));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, -2, 1f);
        params.rightMargin = Ui.dp(this, 3);
        parent.addView(button, params);
    }
    private void setBusy(boolean value, String message) {
        busy = value;
        if (status != null) status.setText(message);
    }
    private void updateFolderLabel() {
        folderLabel.setText(treeUri == null ? "No backup folder chosen. Choose one first."
                : "Selected folder: " + treeUri.getLastPathSegment());
    }
    private void setFilter(int which) { filter = which; applyFilter(); }

    private void loadInstalledApps() {
        if (busy) { toast("Finish the current operation first"); return; }
        setBusy(true, "Scanning installed apps…");
        worker.execute(() -> {
            List<ApkBackupStorage.InstalledApp> found = null;
            Exception error = null;
            try { found = ApkBackupStorage.installed(getApplicationContext()); }
            catch (Exception e) { error = e; }
            final List<ApkBackupStorage.InstalledApp> data = found;
            final Exception failed = error;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                if (failed == null) {
                    allApps.clear(); allApps.addAll(data); icons.clear();
                    Set<String> installed = new HashSet<>();
                    for (ApkBackupStorage.InstalledApp item : allApps) installed.add(item.packageName);
                    selected.retainAll(installed);
                    applyFilter();
                    setBusy(false, "Ready · " + allApps.size() + " installed apps");
                } else setBusy(false, "Scan failed: " + failed.getMessage());
            });
        });
    }

    private void applyFilter() {
        visibleApps.clear();
        for (ApkBackupStorage.InstalledApp item : allApps) {
            if (ApkBackupLogic.inCategory(item.isSystem, filter)
                    && ApkBackupLogic.matches(item.name, item.packageName, query)) {
                visibleApps.add(item);
            }
        }
        adapter.notifyDataSetChanged();
        updateCount();
    }
    private void updateCount() {
        if (countLabel != null) countLabel.setText(visibleApps.size() + " shown · "
                + selected.size() + " selected · " + (filter == 0 ? "All" : filter == 1 ? "User" : "System"));
    }
    private void toggleItem(ApkBackupStorage.InstalledApp item) {
        if (!selected.add(item.packageName)) selected.remove(item.packageName);
        adapter.notifyDataSetChanged();
        updateCount();
    }
    private void selectVisible() {
        for (ApkBackupStorage.InstalledApp app : visibleApps) selected.add(app.packageName);
        adapter.notifyDataSetChanged(); updateCount();
    }
    private List<ApkBackupStorage.InstalledApp> selectedSnapshot() {
        List<ApkBackupStorage.InstalledApp> items = new ArrayList<>();
        for (ApkBackupStorage.InstalledApp app : allApps) {
            if (selected.contains(app.packageName)) items.add(app);
        }
        if (items.isEmpty()) toast("Select one or more apps first");
        return items;
    }

    private void chooseBackupFolder() {
        Intent chooser = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(chooser, REQUEST_FOLDER); }
        catch (Exception e) { toast("Folder picker unavailable: " + e.getMessage()); }
    }
    private void backupSelected() {
        if (busy) return;
        List<ApkBackupStorage.InstalledApp> apps = selectedSnapshot();
        if (apps.isEmpty()) return;
        if (treeUri == null) {
            backupAfterFolderChosen = true;
            toast("Choose a folder, then confirm the APK backup");
            chooseBackupFolder();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Backup " + apps.size() + " APK(s)?")
                .setMessage("Single apps = original .apk; split apps = .apks containing all installed APK parts. "
                        + "Only install files are backed up, not app data.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save to folder", (dialog, which) -> {
                    Uri destination = treeUri;
                    setBusy(true, "Saving backups…");
                    worker.execute(() -> {
                        int saved = 0;
                        List<String> failures = new ArrayList<>();
                        for (ApkBackupStorage.InstalledApp app : apps) {
                            try { ApkBackupStorage.saveToFolder(getApplicationContext(), destination, app); saved++; }
                            catch (Exception e) { failures.add(app.name + ": " + e.getMessage()); }
                            final int done = saved + failures.size();
                            runOnUiThread(() -> { if (status != null) status.setText("Backed up " + done + "/" + apps.size()); });
                        }
                        int finished = saved;
                        runOnUiThread(() -> {
                            if (isFinishing() || isDestroyed()) return;
                            setBusy(false, "Saved " + finished + "/" + apps.size() + " backup(s)");
                            if (!failures.isEmpty()) showFailures("Backup issues", failures);
                            refreshBackups();
                        });
                    });
                }).show();
    }

    private void shareSelected() {
        if (busy) return;
        List<ApkBackupStorage.InstalledApp> apps = selectedSnapshot();
        if (apps.isEmpty()) return;
        setBusy(true, "Preparing original APK files to share…");
        worker.execute(() -> {
            List<Uri> uris = new ArrayList<>();
            List<String> failures = new ArrayList<>();
            for (ApkBackupStorage.InstalledApp app : apps) {
                try {
                    File file = ApkBackupStorage.saveToShareCache(getApplicationContext(), app);
                    uris.add(FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file));
                } catch (Exception e) { failures.add(app.name + ": " + e.getMessage()); }
            }
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                setBusy(false, "Prepared " + uris.size() + " share file(s)");
                if (!failures.isEmpty()) showFailures("Share issues", failures);
                if (uris.isEmpty()) return;
                Intent intent = new Intent(uris.size() == 1 ? Intent.ACTION_SEND : Intent.ACTION_SEND_MULTIPLE);
                intent.setType(uris.size() == 1 && apps.size() == 1 && !apps.get(0).isSplit()
                        ? "application/vnd.android.package-archive" : "application/octet-stream");
                if (uris.size() == 1) intent.putExtra(Intent.EXTRA_STREAM, uris.get(0));
                else intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, new ArrayList<>(uris));
                ClipData clip = ClipData.newUri(getContentResolver(), "SR original APKs", uris.get(0));
                for (int i = 1; i < uris.size(); i++) clip.addItem(new ClipData.Item(uris.get(i)));
                intent.setClipData(clip);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try { startActivity(Intent.createChooser(intent, "Share APK backup")); }
                catch (Exception e) { toast("No compatible sharing app available"); }
            });
        });
    }

    private void uninstallSelected() {
        if (busy) return;
        List<ApkBackupStorage.InstalledApp> apps = selectedSnapshot();
        if (apps.isEmpty()) return;
        List<String> allowed = new ArrayList<>();
        for (ApkBackupStorage.InstalledApp app : apps) {
            if (ApkBackupLogic.canUninstall(app.isSystem, app.packageName, getPackageName())) {
                allowed.add(app.packageName);
            }
        }
        if (allowed.isEmpty()) { toast("Only user apps (not SR Toolbox itself) can be uninstalled here"); return; }
        new AlertDialog.Builder(this)
                .setTitle("Uninstall " + allowed.size() + " user apps?")
                .setMessage("Android will ask confirmation for EVERY app, one at a time. "
                        + "Uninstall may delete that app's data. System apps are excluded.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Continue", (dialog, which) -> {
                    uninstallQueue.clear(); uninstallQueue.addAll(allowed);
                    uninstallNext();
                }).show();
    }
    private void uninstallNext() {
        if (uninstallQueue.isEmpty()) { currentlyUninstalling = null; loadInstalledApps(); return; }
        currentlyUninstalling = uninstallQueue.removeFirst();
        try {
            Intent uninstall = new Intent(Intent.ACTION_UNINSTALL_PACKAGE,
                    Uri.parse("package:" + currentlyUninstalling));
            uninstall.putExtra(Intent.EXTRA_RETURN_RESULT, true);
            startActivityForResult(uninstall, REQUEST_UNINSTALL);
        } catch (Exception e) {
            uninstallQueue.clear(); toast("Android could not open uninstall confirmation");
        }
    }

    private void openRestorePicker() {
        Intent open = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        open.addCategory(Intent.CATEGORY_OPENABLE);
        open.setType("*/*");
        open.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/vnd.android.package-archive", "application/zip",
                "application/octet-stream"});
        open.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivityForResult(open, REQUEST_RESTORE_FILE); }
        catch (Exception e) { toast("Cannot open Android file picker"); }
    }
    private void restoreFromUri(Uri uri, String displayName) {
        if (busy || uri == null) return;
        if (!ApkBackupLogic.isRestorableFile(displayName)) {
            toast("Select a .apk or .apks backup file"); return;
        }
        if (android.os.Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
            pendingRestoreUri = uri;
            new AlertDialog.Builder(this)
                    .setTitle("Allow APK installation")
                    .setMessage("Android requires you to allow SR Smart Toolbox to install apps. "
                            + "After permission is granted, return here to continue.")
                    .setPositiveButton("Open Settings", (dialog, which) -> {
                        Intent allow = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                                Uri.parse("package:" + getPackageName()));
                        startActivity(allow);
                    }).setNegativeButton("Cancel", (dialog, which) -> pendingRestoreUri = null).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Restore " + displayName + "?")
                .setMessage("Android will verify APK signatures and ask for installation approval. "
                        + "Personal app data is NOT part of this backup.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Continue", (dialog, which) -> {
                    if (displayName.toLowerCase(java.util.Locale.ROOT).endsWith(".apk")) {
                        try {
                            Intent install = new Intent(Intent.ACTION_VIEW);
                            install.setDataAndType(uri, "application/vnd.android.package-archive");
                            install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            startActivity(install);
                        } catch (Exception e) { toast("Android installer unavailable"); }
                    } else {
                        setBusy(true, "Preparing split APK restore…");
                        worker.execute(() -> {
                            Exception error = null;
                            try { ApkRestoreInstaller.installSplitArchive(getApplicationContext(), uri); }
                            catch (Exception e) { error = e; }
                            Exception failure = error;
                            runOnUiThread(() -> {
                                if (isFinishing() || isDestroyed()) return;
                                setBusy(false, failure == null
                                        ? "Split APK sent to Android installer · approve prompt/notification"
                                        : "Restore failed: " + failure.getMessage());
                                if (failure != null) toast("Split APK restore failed");
                            });
                        });
                    }
                }).show();
    }
    private String fileDisplayName(Uri uri) {
        try (Cursor cursor = getContentResolver().query(uri,
                new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                String name = cursor.getString(0);
                if (name != null) return name;
            }
        } catch (Exception ignored) {}
        return uri.getLastPathSegment() == null ? "" : uri.getLastPathSegment();
    }

    private void refreshBackups() {
        if (backupList == null) return;
        backupList.removeAllViews();
        if (treeUri == null) {
            Ui.addText(this, backupList, "Choose a backup folder to display saved files.",
                    13, Ui.MUTED, false, 8);
            return;
        }
        Uri folder = treeUri;
        worker.execute(() -> {
            List<DocumentFile> items = new ArrayList<>();
            Exception problem = null;
            try {
                DocumentFile dir = DocumentFile.fromTreeUri(getApplicationContext(), folder);
                if (dir == null) throw new IllegalStateException("Folder unavailable");
                for (DocumentFile file : dir.listFiles()) {
                    if (file.isFile() && ApkBackupLogic.isRestorableFile(file.getName())) items.add(file);
                }
                items.sort((a,b) -> Long.compare(b.lastModified(), a.lastModified()));
            } catch (Exception e) { problem = e; }
            Exception error = problem;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                backupList.removeAllViews();
                if (error != null) {
                    Ui.addText(this, backupList, "Cannot read saved folder: " + error.getMessage(),
                            12, Ui.MUTED, false, 8);
                    return;
                }
                Ui.addText(this, backupList, items.size() + " saved backup(s)",
                        12, Ui.MUTED, false, 8);
                for (int i=0; i<Math.min(items.size(),50);i++) {
                    DocumentFile file = items.get(i);
                    LinearLayout card = Ui.card(this);
                    Ui.addText(this, card, "📦 " + file.getName(), 13, Ui.TEXT, true, 0);
                    Ui.addText(this, card, ApkBackupLogic.fileSize(file.length()),
                            11, Ui.MUTED, false, 4);
                    addButton(card, "↩ Restore", () -> restoreFromUri(file.getUri(), file.getName()));
                    Ui.addCard(this, backupList, card, 6);
                }
                if (items.size() > 50) Ui.addText(this, backupList,
                        "Showing 50 newest backups. Use Restore file picker for older ones.",
                        12, Ui.MUTED, false, 6);
            });
        });
    }
    private void showFailures(String title, List<String> details) {
        new AlertDialog.Builder(this).setTitle(title)
                .setMessage(android.text.TextUtils.join("\n", details))
                .setPositiveButton("OK", null).show();
    }
    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }

    @Override protected void onResume() {
        super.onResume();
        if (pendingRestoreUri != null && (android.os.Build.VERSION.SDK_INT < 26
                || getPackageManager().canRequestPackageInstalls())) {
            Uri restore = pendingRestoreUri;
            pendingRestoreUri = null;
            restoreFromUri(restore, fileDisplayName(restore));
        }
    }
    @Override protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code == REQUEST_FOLDER && result == RESULT_OK && data != null && data.getData() != null) {
            Uri chosen = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(chosen,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                treeUri = chosen;
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(BACKUP_TREE,
                        chosen.toString()).apply();
                updateFolderLabel(); refreshBackups();
                if (backupAfterFolderChosen) { backupAfterFolderChosen = false; backupSelected(); }
            } catch (SecurityException e) { toast("Folder permission could not be saved"); }
        } else if (code == REQUEST_FOLDER) {
            backupAfterFolderChosen = false;
        } else if (code == REQUEST_RESTORE_FILE && result == RESULT_OK && data != null
                && data.getData() != null) {
            restoreFromUri(data.getData(), fileDisplayName(data.getData()));
        } else if (code == REQUEST_UNINSTALL) {
            if (result == RESULT_OK) {
                selected.remove(currentlyUninstalling);
                uninstallNext();
            } else {
                uninstallQueue.clear();
                currentlyUninstalling = null;
                toast("Uninstall cancelled or not completed. Remaining apps were not changed.");
                loadInstalledApps();
            }
        }
    }
    @Override protected void onDestroy() {
        worker.shutdownNow();
        super.onDestroy();
    }

    private final class AppAdapter extends BaseAdapter {
        @Override public int getCount() { return visibleApps.size(); }
        @Override public Object getItem(int position) { return visibleApps.get(position); }
        @Override public long getItemId(int position) { return position; }
        @Override public View getView(int position, View existing, ViewGroup parent) {
            ApkBackupStorage.InstalledApp app = visibleApps.get(position);
            LinearLayout wrapper = Ui.card(AppsBackupActivity.this);
            wrapper.setPadding(Ui.dp(AppsBackupActivity.this, 10), Ui.dp(AppsBackupActivity.this, 8),
                    Ui.dp(AppsBackupActivity.this, 10), Ui.dp(AppsBackupActivity.this, 8));
            LinearLayout row = new LinearLayout(AppsBackupActivity.this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            CheckBox checked = new CheckBox(AppsBackupActivity.this);
            checked.setButtonTintList(android.content.res.ColorStateList.valueOf(Ui.ACCENT));
            checked.setChecked(selected.contains(app.packageName));
            checked.setContentDescription("Select " + app.name);
            checked.setOnCheckedChangeListener((button, value) -> {
                if (value) selected.add(app.packageName); else selected.remove(app.packageName);
                updateCount();
            });
            row.addView(checked, new LinearLayout.LayoutParams(Ui.dp(AppsBackupActivity.this, 44), -2));
            ImageView image = new ImageView(AppsBackupActivity.this);
            Drawable icon = icons.get(app.packageName);
            if (icon == null) {
                try { icon = getPackageManager().getApplicationIcon(app.packageName); }
                catch (PackageManager.NameNotFoundException ignored) {
                    icon = getDrawable(android.R.drawable.sym_def_app_icon);
                }
                if (icons.size() < 200) icons.put(app.packageName, icon);
            }
            image.setImageDrawable(icon);
            row.addView(image, new LinearLayout.LayoutParams(Ui.dp(AppsBackupActivity.this, 49),
                    Ui.dp(AppsBackupActivity.this, 49)));
            LinearLayout texts = new LinearLayout(AppsBackupActivity.this);
            texts.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1f);
            p.leftMargin = Ui.dp(AppsBackupActivity.this, 10);
            row.addView(texts, p);
            texts.addView(Ui.text(AppsBackupActivity.this, app.name, 15, Ui.TEXT, true));
            texts.addView(Ui.text(AppsBackupActivity.this, app.packageName, 11, Ui.MUTED, false));
            texts.addView(Ui.text(AppsBackupActivity.this,
                    "Version " + app.versionName + " · APK " + ApkBackupLogic.fileSize(app.apkBytes)
                            + (app.isSplit() ? " · Split APK" : "")
                            + (app.isSystem ? " · System" : ""),
                    11, Ui.ACCENT, false));
            texts.addView(Ui.text(AppsBackupActivity.this,
                    "Updated " + android.text.format.DateFormat.getMediumDateFormat(AppsBackupActivity.this)
                            .format(new Date(app.lastUpdated)), 11, Ui.MUTED, false));
            wrapper.addView(row);
            wrapper.setOnClickListener(v -> toggleItem(app));
            return wrapper;
        }
    }
}
