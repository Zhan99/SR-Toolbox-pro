package com.smarttoolbox.pro;

import android.content.Intent;
import android.os.Build;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

public class NightTileService extends TileService {
    @Override public void onStartListening() {
        super.onStartListening();
        refreshTile();
    }

    @Override public void onClick() {
        super.onClick();
        boolean active = getSharedPreferences("night", MODE_PRIVATE).getBoolean("active", false);
        Intent i = new Intent(this, DimOverlayService.class);
        if (active) {
            i.setAction(DimOverlayService.ACTION_STOP);
            startService(i);
        } else {
            android.content.SharedPreferences prefs = getSharedPreferences("night", MODE_PRIVATE);
            i.putExtra("level", prefs.getInt("level", 60));
            i.putExtra("warm", prefs.getBoolean("warm", false));
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i); else startService(i);
        }
        getSharedPreferences("night", MODE_PRIVATE).edit().putBoolean("active", !active).apply();
        if (!active && FloatingControlService.hasOverlayPermission(this)) {
            FloatingControlService.start(this);
        } else {
            FloatingControlService.refresh(this);
        }
        refreshTile();
    }

    private void refreshTile() {
        Tile tile = getQsTile();
        if (tile == null) return;
        boolean active = getSharedPreferences("night", MODE_PRIVATE).getBoolean("active", false);
        tile.setState(active ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) tile.setLabel("Night Screen");
        tile.updateTile();
    }
}
