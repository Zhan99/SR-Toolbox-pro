package com.smarttoolbox.pro;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Locale;

/** Small pure-Java helpers used by the SR Video Player and its tests. */
public final class VideoPlayerLogic {
    private VideoPlayerLogic() {}

    public static String subtitleMimeType(String displayName) {
        if (displayName == null) return null;
        String name = displayName.toLowerCase(Locale.ROOT);
        int dot = name.lastIndexOf('.');
        String ext = dot < 0 ? "" : name.substring(dot + 1);
        switch (ext) {
            case "srt": return "application/x-subrip";
            case "vtt": return "text/vtt";
            case "ass":
            case "ssa": return "text/x-ssa";
            case "ttml":
            case "xml": return "application/ttml+xml";
            default: return null;
        }
    }

    public static boolean isNetworkUrl(String value) {
        if (value == null || value.trim().isEmpty()) return false;
        try {
            URI uri = new URI(value.trim());
            String scheme = uri.getScheme();
            return scheme != null
                    && ("https".equalsIgnoreCase(scheme) || "rtsp".equalsIgnoreCase(scheme))
                    && uri.getHost() != null
                    && !uri.getHost().trim().isEmpty();
        } catch (URISyntaxException | IllegalArgumentException error) {
            return false;
        }
    }

    public static String titleFromUrl(String value) {
        if (value == null) return "Network video";
        try {
            URI uri = new URI(value);
            String path = uri.getPath();
            if (path != null && !path.trim().isEmpty()) {
                int slash = path.lastIndexOf('/');
                String name = path.substring(slash + 1);
                if (!name.trim().isEmpty()) return name;
            }
            return uri.getHost() == null ? "Network video" : uri.getHost();
        } catch (Exception ignored) {
            return "Network video";
        }
    }
}
