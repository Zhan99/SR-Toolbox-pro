package com.smarttoolbox.pro;

import java.util.Locale;

/** Platform-independent APK backup policy; used by both the UI and regression tests. */
final class ApkBackupLogic {
    private ApkBackupLogic() {}

    static String safeName(String source) {
        if (source == null) return "unknown";
        String value = source.trim().replaceAll("[^A-Za-z0-9._-]", "_");
        while (value.contains("..")) value = value.replace("..", "_");
        value = value.replaceAll("^\\.+", "").replaceAll("\\.+$", "");
        if (value.isEmpty()) return "unknown";
        return value.length() > 96 ? value.substring(0, 96) : value;
    }

    static boolean isSplit(String[] splitPaths) {
        if (splitPaths == null) return false;
        for (String path : splitPaths) if (path != null && !path.isEmpty()) return true;
        return false;
    }

    static String fileName(String packageName, long version, boolean split, long timestamp) {
        return safeName(packageName) + "_v" + Math.max(0, version) + "_" +
                Math.max(0, timestamp) + (split ? ".apks" : ".apk");
    }

    static boolean isRestorableFile(String name) {
        if (name == null) return false;
        String value = name.toLowerCase(Locale.ROOT);
        return value.endsWith(".apk") || value.endsWith(".apks");
    }

    static boolean matches(String name, String packageName, String query) {
        if (query == null || query.trim().isEmpty()) return true;
        String q = query.trim().toLowerCase(Locale.ROOT);
        return (name != null && name.toLowerCase(Locale.ROOT).contains(q))
                || (packageName != null && packageName.toLowerCase(Locale.ROOT).contains(q));
    }

    static boolean inCategory(boolean isSystem, int filter) {
        return filter == 0 || (filter == 1 && !isSystem) || (filter == 2 && isSystem);
    }

    static boolean canUninstall(boolean isSystem, String pkg, String ownPkg) {
        return !isSystem && pkg != null && !pkg.equals(ownPkg);
    }

    static String fileSize(long bytes) {
        double value = Math.max(0L, bytes);
        String[] units = {"B", "KB", "MB", "GB", "TB"};
        int i = 0;
        while (value >= 1024.0 && i < units.length - 1) { value /= 1024.0; i++; }
        return String.format(Locale.US, i == 0 ? "%.0f %s" : "%.1f %s", value, units[i]);
    }

    static boolean permittedApkZipEntry(String name) {
        if (name == null) return false;
        return "base.apk".equals(name) || name.matches("split_[0-9]{3}\\.apk");
    }
}
