package com.smarttoolbox.pro;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Explicit, non-exported PackageInstaller session callback. */
public final class ApkRestoreResultReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context,Intent intent) {
        if(intent!=null)AppRestoreCoordinator.onInstallerStatus(context,intent);
    }
}
