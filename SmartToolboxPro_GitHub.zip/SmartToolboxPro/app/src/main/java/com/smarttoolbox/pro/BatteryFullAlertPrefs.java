package com.smarttoolbox.pro;

import android.content.Context;
import android.content.SharedPreferences;

final class BatteryFullAlertPrefs {
    private static final String FILE = "sr_full_charge_voice";
    private static final String ENABLED = "enabled";
    private static final String ANNOUNCED = "announced_this_charge";
    private BatteryFullAlertPrefs() {}

    static boolean enabled(Context context) { return prefs(context).getBoolean(ENABLED, false); }
    static void setEnabled(Context context, boolean enabled) {
        prefs(context).edit().putBoolean(ENABLED, enabled).apply();
    }
    static boolean announced(Context context) { return prefs(context).getBoolean(ANNOUNCED, false); }
    static void setAnnounced(Context context, boolean state) {
        // Commit before speaking: process restarts must not repeat the same full-charge alert.
        prefs(context).edit().putBoolean(ANNOUNCED, state).commit();
    }
    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }
}
