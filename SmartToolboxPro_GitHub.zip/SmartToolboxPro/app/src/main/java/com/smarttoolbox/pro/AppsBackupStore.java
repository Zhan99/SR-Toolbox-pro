package com.smarttoolbox.pro;

import android.content.*;
import android.content.pm.*;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.provider.DocumentsContract;
import java.io.*;
import java.util.*;
import java.util.zip.*;

final class AppsBackupStore {
    static class Entry {
        String name,pkg,version,key,fileName; long code,size,date; boolean system,split,archived; Drawable icon; String[] paths; Uri uri,baseUri;
    }
    final Context c; final PackageManager pm; final ContentResolver cr;
    AppsBackupStore(Context c){this.c=c;pm=c.getPackageManager();cr=c.getContentResolver();}
    List<Entry> installed(boolean system){
        List<Entry> out=new ArrayList<>();
        for(PackageInfo p:pm.getInstalledPackages(0)){
            ApplicationInfo a=p.applicationInfo; if(a==null || a.sourceDir==null)continue;
            boolean sys=(a.flags&ApplicationInfo.FLAG_SYSTEM)!=0;
            if(sys && !system)continue;
            Entry e=new Entry();e.name=a.loadLabel(pm).toString();e.pkg=p.packageName;e.key=e.pkg;e.system=sys;e.version=p.versionName==null?"?":p.versionName;e.code=Build.VERSION.SDK_INT>=28?p.getLongVersionCode():p.versionCode;e.date=p.lastUpdateTime;e.icon=a.loadIcon(pm);
            ArrayList<String> paths=new ArrayList<>();paths.add(a.sourceDir);if(a.splitSourceDirs!=null)Collections.addAll(paths,a.splitSourceDirs);e.paths=paths.toArray(new String[0]);e.split=e.paths.length>1;
            for(String path:e.paths)e.size+=new File(path).length();out.add(e);
        }return out;
    }
    Uri root(Uri tree){return DocumentsContract.buildDocumentUriUsingTree(tree,DocumentsContract.getTreeDocumentId(tree));}
    private static final String SPLIT_FOLDER="Split backups";
    private static final String APK_MIME="application/vnd.android.package-archive";
    private static final String[] COLUMNS={DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_SIZE,DocumentsContract.Document.COLUMN_LAST_MODIFIED,DocumentsContract.Document.COLUMN_MIME_TYPE};
    private Uri children(Uri tree,Uri dir){return DocumentsContract.buildChildDocumentsUriUsingTree(tree,DocumentsContract.getDocumentId(dir));}
    private Uri splitFolder(Uri tree,boolean create)throws IOException{
        try(Cursor cur=cr.query(children(tree,root(tree)),COLUMNS,null,null,null)){
            if(cur==null)throw new IOException("Cannot read backup folder");
            while(cur.moveToNext())if(SPLIT_FOLDER.equals(cur.getString(1)) && DocumentsContract.Document.MIME_TYPE_DIR.equals(cur.getString(4)))return DocumentsContract.buildDocumentUriUsingTree(tree,cur.getString(0));
        }
        if(!create)return null;
        Uri u=DocumentsContract.createDocument(cr,root(tree),DocumentsContract.Document.MIME_TYPE_DIR,SPLIT_FOLDER);
        if(u==null)throw new IOException("Cannot create split backup folder");return u;
    }
    List<Entry> archives(Uri tree) throws IOException {
        List<Entry> out=new ArrayList<>();if(tree==null)return out;
        try{
            readArchives(tree,root(tree),out);
            Uri dir=splitFolder(tree,false);if(dir!=null)readArchives(tree,dir,out);
            // A base export and full split archive with the same exact stem form one item.
            // Restoration and sharing use the complete archive, never its incomplete base.
            Map<String,Entry> bases=new HashMap<>();
            for(Entry e:out)if(!e.split)bases.put(stem(e.fileName),e);
            Set<Entry> paired=new HashSet<>();
            for(Entry e:out)if(e.split){Entry base=bases.remove(stem(e.fileName));if(base!=null){e.baseUri=base.uri;paired.add(base);}}
            out.removeAll(paired);
        }catch(RuntimeException ex){throw new IOException("Cannot access backup folder",ex);}return out;
    }
    private static String stem(String f){return AppsBackupArchiveLogic.stem(f);}
    private void readArchives(Uri tree,Uri dir,List<Entry> out)throws IOException{
        try(Cursor cur=cr.query(children(tree,dir),COLUMNS,null,null,null)){
            if(cur==null)throw new IOException("Cannot read backup folder");
            while(cur.moveToNext()){
                String f=cur.getString(1);if(f==null || DocumentsContract.Document.MIME_TYPE_DIR.equals(cur.getString(4)))continue;
                if(!AppsBackupArchiveLogic.supported(f))continue;
                Entry e=new Entry();e.fileName=f;e.uri=DocumentsContract.buildDocumentUriUsingTree(tree,cur.getString(0));e.key=e.uri.toString();e.archived=true;e.split=AppsBackupArchiveLogic.isApks(f);e.size=cur.getLong(2);e.date=cur.getLong(3);
                String stem=stem(f);String[] bits=stem.split("__",4);e.name=stem;e.pkg="";e.version="?";
                if(bits.length==4){try{e.code=Long.parseLong(bits[2]);e.name=bits[0];e.pkg=bits[1];e.version=bits[3];}catch(NumberFormatException ignored){}}
                if(e.pkg.isEmpty()&&!e.split)inspectApk(e);
                if(!e.pkg.isEmpty()&&e.icon==null){try{e.icon=pm.getApplicationIcon(e.pkg);}catch(Exception ignored){}}
                if(e.icon==null)e.icon=pm.getDefaultActivityIcon();out.add(e);
            }
        }
    }
    private void inspectApk(Entry e){
        File temp=null;
        try {temp=File.createTempFile("inspect-",".apk",c.getCacheDir());
            try(InputStream in=cr.openInputStream(e.uri);OutputStream out=new FileOutputStream(temp)){if(in==null)return;copy(in,out);}
            PackageInfo p=pm.getPackageArchiveInfo(temp.getAbsolutePath(),0);
            if(p!=null&&p.applicationInfo!=null){ApplicationInfo a=p.applicationInfo;a.sourceDir=temp.getAbsolutePath();a.publicSourceDir=a.sourceDir;e.pkg=p.packageName;e.name=a.loadLabel(pm).toString();e.version=p.versionName==null?"?":p.versionName;e.code=Build.VERSION.SDK_INT>=28?p.getLongVersionCode():p.versionCode;e.icon=a.loadIcon(pm);}
        }catch(Exception ignored){}finally{if(temp!=null)temp.delete();}
    }
    static String clean(String s){String x=s.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]","_").replaceAll("_+","_").trim();if(x.isEmpty())x="App";return x.length()>48?x.substring(0,48):x;}
    static String baseName(Entry e){return clean(e.name)+"__"+e.pkg+"__"+e.code+"__"+clean(e.version)+".apk";}
    static String fileName(Entry e){String base=baseName(e);return e.split?stem(base)+".apks":base;}
    static void copy(InputStream in,OutputStream out)throws IOException{AppsBackupPayload.copy(in,out);}
    void writeApp(Entry e,OutputStream out)throws IOException{AppsBackupPayload.writeFull(e.paths,out);}
    private void writeBase(Entry e,OutputStream out)throws IOException{AppsBackupPayload.writeBase(e.paths,out);}
    private Uri createBackup(Entry e,Uri dir,String name,boolean full)throws IOException{
        Uri u=DocumentsContract.createDocument(cr,dir,full?"application/octet-stream":APK_MIME,name);
        if(u==null)throw new IOException("Cannot create "+name);
        try(OutputStream out=cr.openOutputStream(u,"w")){
            if(out==null)throw new IOException("Cannot open backup");
            if(full)writeApp(e,out);else writeBase(e,out);
        }catch(Exception ex){removeQuietly(u);throw new IOException("Cannot write "+name,ex);}
        return u;
    }
    private void removeQuietly(Uri u){if(u!=null)try{DocumentsContract.deleteDocument(cr,u);}catch(Exception ignored){}}
    boolean deleteBackup(Entry e)throws IOException{
        // Delete the base first so a failed deletion cannot strand a misleading base-only export.
        if(e.baseUri!=null&&!DocumentsContract.deleteDocument(cr,e.baseUri))return false;
        return DocumentsContract.deleteDocument(cr,e.uri);
    }
    void backup(Entry e,Uri tree,boolean keep)throws IOException{
        List<Entry> existing=archives(tree);String baseName=baseName(e),fullName=fileName(e);ArrayList<Entry> old=new ArrayList<>();
        for(Entry a:existing)if(a.pkg.equals(e.pkg) && (!keep || a.code==e.code))old.add(a);
        Uri base=null,full=null;
        // Both outputs must be written successfully before removing older backups.
        try{
            if(e.split)full=createBackup(e,splitFolder(tree,true),fullName,true);
            base=createBackup(e,root(tree),baseName,false);
        }catch(Exception ex){removeQuietly(base);removeQuietly(full);throw new IOException("Backup failed: "+e.name,ex);}
        for(Entry a:old){try{deleteBackup(a);}catch(Exception ignored){}}
        try{DocumentsContract.renameDocument(cr,base,baseName);}catch(Exception ignored){}
        if(full!=null)try{DocumentsContract.renameDocument(cr,full,fullName);}catch(Exception ignored){}
    }
    Uri shareCopy(Entry e)throws IOException{
        File dir=new File(c.getCacheDir(),"share");if(!dir.exists()&&!dir.mkdirs())throw new IOException("Cannot create share cache");
        File f=new File(dir,UUID.randomUUID()+"_"+(e.archived?e.fileName.replaceAll("[\\\\/]","_"):fileName(e)));
        try(OutputStream out=new FileOutputStream(f)){
            if(e.archived){try(InputStream in=cr.openInputStream(e.uri)){if(in==null)throw new IOException("Missing archive");copy(in,out);}}
            else writeApp(e,out);
        }catch(Exception ex){f.delete();throw new IOException("Share failed",ex);}
        return new Uri.Builder().scheme("content").authority(c.getPackageName()+".share").appendPath(f.getName()).build();
    }
    void pruneShare(){File[] fs=new File(c.getCacheDir(),"share").listFiles();if(fs!=null)for(File f:fs)if(System.currentTimeMillis()-f.lastModified()>86400000L)f.delete();}
    int prepareInstall(Entry e)throws IOException{
        if(e==null || !e.archived || e.uri==null
                || !AppsBackupArchiveLogic.supported(e.fileName)) {
            throw new IOException("Select a saved .apk/.apks file in Archived to restore");
        }
        PackageInstaller pi=pm.getPackageInstaller();PackageInstaller.SessionParams params=new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
        if(Build.VERSION.SDK_INT>=31)params.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_REQUIRED);
        int id=pi.createSession(params);
        try(PackageInstaller.Session session=pi.openSession(id);InputStream in=cr.openInputStream(e.uri)){
            if(in==null)throw new IOException("Cannot open archive");
            if(!e.split){try(OutputStream out=session.openWrite("base.apk",0,-1)){copy(in,out);session.fsync(out);}}
            else{int n=0;try(ZipInputStream zip=new ZipInputStream(in)){ZipEntry ze;while((ze=zip.getNextEntry())!=null){if(!ze.isDirectory()&&ze.getName().toLowerCase(Locale.ROOT).endsWith(".apk")){if(++n>256)throw new IOException("Too many APK parts");try(OutputStream out=session.openWrite("part_"+n+".apk",0,-1)){copy(zip,out);session.fsync(out);}}zip.closeEntry();}}if(n==0)throw new IOException("No APK in archive");}
        }catch(Exception ex){try{pi.abandonSession(id);}catch(Exception ignored){}throw new IOException("Cannot prepare install: "+e.name,ex);}return id;
    }
    void commit(int id)throws IOException{
        Intent callback=new Intent(c,AppsBackupInstallReceiver.class);callback.setAction(c.getPackageName()+".INSTALL_RESULT");
        // PackageInstaller fills in status extras. The callback must be explicit and mutable.
        android.app.PendingIntent pending;
        if (Build.VERSION.SDK_INT >= 31) {
            pending = android.app.PendingIntent.getBroadcast(c, id, callback,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT | android.app.PendingIntent.FLAG_MUTABLE);
        } else {
            pending = android.app.PendingIntent.getBroadcast(c, id, callback,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT);
        }
        try(PackageInstaller.Session s=pm.getPackageInstaller().openSession(id)){s.commit(pending.getIntentSender());}
        catch(Exception e){try{pm.getPackageInstaller().abandonSession(id);}catch(Exception ignored){}throw new IOException("Install could not start",e);}
    }
}
