package com.smarttoolbox.pro;

import android.content.*;
import android.content.pm.*;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.os.Environment;
import android.content.ContentValues;
import java.io.*;
import java.util.*;
import java.util.zip.*;

final class AppsBackupStore {
    static class Entry {
        String name,pkg,version,key,fileName; long code,size,date; boolean system,split,archived; Drawable icon; String[] paths; Uri uri,baseUri;
    }
    final Context c; final PackageManager pm; final ContentResolver cr;
    AppsBackupStore(Context c){this.c=c;pm=c.getPackageManager();cr=c.getContentResolver();}
    List<Entry> installed(boolean system){
        List<Entry> out=new ArrayList<>();
        for(PackageInfo p:pm.getInstalledPackages(0)){
            ApplicationInfo a=p.applicationInfo; if(a==null || a.sourceDir==null)continue;
            boolean sys=(a.flags&ApplicationInfo.FLAG_SYSTEM)!=0;
            if(sys && !system)continue;
            Entry e=new Entry();e.name=a.loadLabel(pm).toString();e.pkg=p.packageName;e.key=e.pkg;e.system=sys;e.version=p.versionName==null?"?":p.versionName;e.code=Build.VERSION.SDK_INT>=28?p.getLongVersionCode():p.versionCode;e.date=p.lastUpdateTime;e.icon=a.loadIcon(pm);
            ArrayList<String> paths=new ArrayList<>();paths.add(a.sourceDir);if(a.splitSourceDirs!=null)Collections.addAll(paths,a.splitSourceDirs);e.paths=paths.toArray(new String[0]);e.split=e.paths.length>1;
            for(String path:e.paths)e.size+=new File(path).length();out.add(e);
        }return out;
    }
    Uri root(Uri tree){return DocumentsContract.buildDocumentUriUsingTree(tree,DocumentsContract.getTreeDocumentId(tree));}
    private static final String SPLIT_FOLDER=AppsBackupFolderLogic.SPLIT;
    static final String APP_BACKUP_FOLDER=AppsBackupFolderLogic.FOLDER;
    private static final String PUBLIC_BACKUP_PATH = Environment.DIRECTORY_DOWNLOADS + "/App Backup/";
    private static final String PUBLIC_SPLIT_PATH = PUBLIC_BACKUP_PATH + SPLIT_FOLDER + "/";
    static boolean supportsAutomaticPublicFolder(){return Build.VERSION.SDK_INT>=29;}
    private static final String APK_MIME="application/vnd.android.package-archive";
    private static final String[] COLUMNS={DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_SIZE,DocumentsContract.Document.COLUMN_LAST_MODIFIED,DocumentsContract.Document.COLUMN_MIME_TYPE};
    private Uri children(Uri tree,Uri dir){return DocumentsContract.buildChildDocumentsUriUsingTree(tree,DocumentsContract.getDocumentId(dir));}
    private Uri findFolder(Uri tree,Uri parent,String folderName,boolean create)throws IOException{
        try(Cursor cur=cr.query(children(tree,parent),COLUMNS,null,null,null)){
            if(cur==null)throw new IOException("Cannot read selected backup location");
            while(cur.moveToNext())if(folderName.equals(cur.getString(1))
                    && DocumentsContract.Document.MIME_TYPE_DIR.equals(cur.getString(4))) {
                return DocumentsContract.buildDocumentUriUsingTree(tree,cur.getString(0));
            }
        }catch(RuntimeException ex){throw new IOException("Cannot read backup location",ex);}
        if(!create)return null;
        Uri created=DocumentsContract.createDocument(cr,parent,DocumentsContract.Document.MIME_TYPE_DIR,folderName);
        if(created==null)throw new IOException("Cannot create " + folderName);
        return created;
    }

    private Uri backupFolder(Uri tree,boolean create)throws IOException{
        Uri selectedRoot=root(tree);
        // Selecting an existing App Backup folder should NOT create App Backup/App Backup.
        try(Cursor cur=cr.query(selectedRoot,new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME},null,null,null)){
            if(cur!=null && cur.moveToFirst()
                    && APP_BACKUP_FOLDER.equalsIgnoreCase(cur.getString(0)))return selectedRoot;
        }catch(RuntimeException ignored){ /* provider may omit the folder label */ }
        Uri child=findFolder(tree,selectedRoot,APP_BACKUP_FOLDER,create);
        return child;
    }

    private Uri splitFolderInside(Uri tree,Uri parent,boolean create)throws IOException{
        return parent==null?null:findFolder(tree,parent,SPLIT_FOLDER,create);
    }

    private Uri splitFolder(Uri tree,boolean create)throws IOException{
        try(Cursor cur=cr.query(children(tree,root(tree)),COLUMNS,null,null,null)){
            if(cur==null)throw new IOException("Cannot read backup folder");
            while(cur.moveToNext())if(SPLIT_FOLDER.equals(cur.getString(1)) && DocumentsContract.Document.MIME_TYPE_DIR.equals(cur.getString(4)))return DocumentsContract.buildDocumentUriUsingTree(tree,cur.getString(0));
        }
        if(!create)return null;
        Uri u=DocumentsContract.createDocument(cr,root(tree),DocumentsContract.Document.MIME_TYPE_DIR,SPLIT_FOLDER);
        if(u==null)throw new IOException("Cannot create split backup folder");return u;
    }
    List<Entry> archives(Uri tree) throws IOException {
        List<Entry> out=new ArrayList<>();if(tree==null)return out;
        try{
            readArchives(tree,root(tree),out);
            Uri dir=splitFolder(tree,false);if(dir!=null)readArchives(tree,dir,out);
            Uri appFolder=backupFolder(tree,false);
            if(appFolder!=null && !appFolder.equals(root(tree))){
                readArchives(tree,appFolder,out);
                Uri appSplit=splitFolderInside(tree,appFolder,false);
                if(appSplit!=null)readArchives(tree,appSplit,out);
            }
            // A base export and full split archive with the same exact stem form one item.
            // Restoration and sharing use the complete archive, never its incomplete base.
            Map<String,Entry> bases=new HashMap<>();
            for(Entry e:out)if(!e.split)bases.put(stem(e.fileName),e);
            Set<Entry> paired=new HashSet<>();
            for(Entry e:out)if(e.split){Entry base=bases.remove(stem(e.fileName));if(base!=null){e.baseUri=base.uri;paired.add(base);}}
            out.removeAll(paired);
        }catch(RuntimeException ex){throw new IOException("Cannot access backup folder",ex);}return out;
    }
    private static String stem(String f){return AppsBackupArchiveLogic.stem(f);}
    private void readArchives(Uri tree,Uri dir,List<Entry> out)throws IOException{
        try(Cursor cur=cr.query(children(tree,dir),COLUMNS,null,null,null)){
            if(cur==null)throw new IOException("Cannot read backup folder");
            while(cur.moveToNext()){
                String f=cur.getString(1);if(f==null || DocumentsContract.Document.MIME_TYPE_DIR.equals(cur.getString(4)))continue;
                if(!AppsBackupArchiveLogic.supported(f))continue;
                Entry e=new Entry();e.fileName=f;e.uri=DocumentsContract.buildDocumentUriUsingTree(tree,cur.getString(0));e.key=e.uri.toString();e.archived=true;e.split=AppsBackupArchiveLogic.isApks(f);e.size=cur.getLong(2);e.date=cur.getLong(3);
                String stem=stem(f);String[] bits=stem.split("__",4);e.name=stem;e.pkg="";e.version="?";
                if(bits.length==4){try{e.code=Long.parseLong(bits[2]);e.name=bits[0];e.pkg=bits[1];e.version=bits[3];}catch(NumberFormatException ignored){}}
                if(e.pkg.isEmpty()&&!e.split)inspectApk(e);
                if(!e.pkg.isEmpty()&&e.icon==null){try{e.icon=pm.getApplicationIcon(e.pkg);}catch(Exception ignored){}}
                if(e.icon==null)e.icon=pm.getDefaultActivityIcon();out.add(e);
            }
        }
    }
    private void inspectApk(Entry e){
        File temp=null;
        try {temp=File.createTempFile("inspect-",".apk",c.getCacheDir());
            try(InputStream in=cr.openInputStream(e.uri);OutputStream out=new FileOutputStream(temp)){if(in==null)return;copy(in,out);}
            PackageInfo p=pm.getPackageArchiveInfo(temp.getAbsolutePath(),0);
            if(p!=null&&p.applicationInfo!=null){ApplicationInfo a=p.applicationInfo;a.sourceDir=temp.getAbsolutePath();a.publicSourceDir=a.sourceDir;e.pkg=p.packageName;e.name=a.loadLabel(pm).toString();e.version=p.versionName==null?"?":p.versionName;e.code=Build.VERSION.SDK_INT>=28?p.getLongVersionCode():p.versionCode;e.icon=a.loadIcon(pm);}
        }catch(Exception ignored){}finally{if(temp!=null)temp.delete();}
    }
    static String clean(String s){String x=s.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]","_").replaceAll("_+","_").trim();if(x.isEmpty())x="App";return x.length()>48?x.substring(0,48):x;}
    static String baseName(Entry e){return clean(e.name)+"__"+e.pkg+"__"+e.code+"__"+clean(e.version)+".apk";}
    static String fileName(Entry e){String base=baseName(e);return e.split?stem(base)+".apks":base;}
    static void copy(InputStream in,OutputStream out)throws IOException{AppsBackupPayload.copy(in,out);}
    void writeApp(Entry e,OutputStream out)throws IOException{AppsBackupPayload.writeFull(e.paths,out);}
    private void writeBase(Entry e,OutputStream out)throws IOException{AppsBackupPayload.writeBase(e.paths,out);}
    private Uri createBackup(Entry e,Uri dir,String name,boolean full)throws IOException{
        Uri u=DocumentsContract.createDocument(cr,dir,full?"application/octet-stream":APK_MIME,name);
        if(u==null)throw new IOException("Cannot create "+name);
        try(OutputStream out=cr.openOutputStream(u,"w")){
            if(out==null)throw new IOException("Cannot open backup");
            if(full)writeApp(e,out);else writeBase(e,out);
        }catch(Exception ex){removeQuietly(u);throw new IOException("Cannot write "+name,ex);}
        return u;
    }
    private void removeQuietly(Uri u){if(u!=null)try{deleteBackupUri(u);}catch(Exception ignored){}}
    boolean deleteBackup(Entry e)throws IOException{
        // Delete the base first so a failed deletion cannot strand a misleading base-only export.
        if(e.baseUri!=null&&!deleteBackupUri(e.baseUri))return false;
        return deleteBackupUri(e.uri);
    }
    private boolean deleteBackupUri(Uri uri) throws IOException {
        try {
            if(DocumentsContract.isDocumentUri(c,uri))return DocumentsContract.deleteDocument(cr,uri);
            return cr.delete(uri,null,null)>0;
        }catch(RuntimeException ex){throw new IOException("Cannot delete backup file",ex);}
    }
    void backup(Entry e,Uri tree,boolean keep)throws IOException{
        List<Entry> existing=archives(tree);String baseName=baseName(e),fullName=fileName(e);ArrayList<Entry> old=new ArrayList<>();
        for(Entry a:existing)if(a.pkg.equals(e.pkg) && (!keep || a.code==e.code))old.add(a);
        Uri base=null,full=null;
        // Both outputs must be written successfully before removing older backups.
        try{
            Uri folder=backupFolder(tree,true);
            if(folder==null)throw new IOException("Cannot create App Backup folder");
            if(e.split)full=createBackup(e,splitFolderInside(tree,folder,true),fullName,true);
            base=createBackup(e,folder,baseName,false);
        }catch(Exception ex){removeQuietly(base);removeQuietly(full);throw new IOException("Backup failed: "+e.name,ex);}
        for(Entry a:old){try{deleteBackup(a);}catch(Exception ignored){}}
        try{DocumentsContract.renameDocument(cr,base,baseName);}catch(Exception ignored){}
        if(full!=null)try{DocumentsContract.renameDocument(cr,full,fullName);}catch(Exception ignored){}
    }
    /** Automatic public Downloads/App Backup folder (Android 10+), without broad storage access. */
    List<Entry> archivesPublic() throws IOException {
        if(!supportsAutomaticPublicFolder())return new ArrayList<>();
        ArrayList<Entry> entries=new ArrayList<>();
        Uri collection=MediaStore.Downloads.EXTERNAL_CONTENT_URI;
        String[] projection={MediaStore.MediaColumns._ID,MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.SIZE,MediaStore.MediaColumns.DATE_MODIFIED,
                MediaStore.MediaColumns.RELATIVE_PATH};
        try(Cursor cursor=cr.query(collection,projection,
                MediaStore.MediaColumns.RELATIVE_PATH+"=? OR "+MediaStore.MediaColumns.RELATIVE_PATH+"=?",
                new String[]{PUBLIC_BACKUP_PATH,PUBLIC_SPLIT_PATH},null)){
            if(cursor==null)throw new IOException("Cannot read Download/App Backup folder");
            while(cursor.moveToNext()){
                String name=cursor.getString(1);
                if(!AppsBackupArchiveLogic.supported(name))continue;
                Entry entry=new Entry();entry.fileName=name;
                entry.uri=ContentUris.withAppendedId(collection,cursor.getLong(0));
                entry.key=entry.uri.toString();entry.archived=true;
                entry.split=AppsBackupArchiveLogic.isApks(name);
                entry.size=cursor.getLong(2);entry.date=cursor.getLong(3)*1000L;
                entry.name=AppsBackupArchiveLogic.stem(name);entry.pkg="";entry.version="?";
                String[] bits=entry.name.split("__",4);
                if(bits.length==4){
                    try {entry.code=Long.parseLong(bits[2]);entry.name=bits[0];
                        entry.pkg=bits[1];entry.version=bits[3];}
                    catch(NumberFormatException ignored){}
                }
                if(entry.pkg.isEmpty() && !entry.split)inspectApk(entry);
                if(!entry.pkg.isEmpty())try{entry.icon=pm.getApplicationIcon(entry.pkg);}catch(Exception ignored){}
                if(entry.icon==null)entry.icon=pm.getDefaultActivityIcon();
                entries.add(entry);
            }
        }catch(RuntimeException ex){throw new IOException("Cannot list public backups",ex);}
        pairArchives(entries);
        return entries;
    }

    private static void pairArchives(List<Entry> all){
        Map<String,Entry> bases=new HashMap<>();
        for(Entry entry:all)if(!entry.split)bases.put(stem(entry.fileName),entry);
        ArrayList<Entry> paired=new ArrayList<>();
        for(Entry entry:all)if(entry.split){
            Entry base=bases.remove(stem(entry.fileName));
            if(base!=null){
                entry.baseUri=base.uri;
                // The visible file name can be bKash.apk / bKash.apks, so carry
                // recovered package details from its base APK into the full archive.
                if(entry.pkg.isEmpty() && !base.pkg.isEmpty()){
                    entry.pkg=base.pkg;entry.code=base.code;entry.version=base.version;
                    entry.name=base.name;entry.icon=base.icon;
                }
                paired.add(base);
            }
        }
        all.removeAll(paired);
    }

    private Uri createPublicBackup(Entry e,String folder,String name,boolean split) throws IOException {
        ContentValues values=new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME,name);
        values.put(MediaStore.MediaColumns.RELATIVE_PATH,folder);
        values.put(MediaStore.MediaColumns.MIME_TYPE,split?"application/octet-stream":APK_MIME);
        values.put(MediaStore.MediaColumns.IS_PENDING,1);
        Uri created=cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);
        if(created==null)throw new IOException("Cannot create file in Download/App Backup");
        try {
            try(OutputStream output=cr.openOutputStream(created,"w")){
                if(output==null)throw new IOException("Cannot open backup file");
                if(split)writeApp(e,output);else writeBase(e,output);
                output.flush();
            }
            // Publish only after close/flush, never expose a partial APK as ready.
            ContentValues ready=new ContentValues();
            ready.put(MediaStore.MediaColumns.IS_PENDING,0);
            if(cr.update(created,ready,null,null)<1)throw new IOException("Could not publish backup file");
            return created;
        }catch(Exception ex){
            removeQuietly(created);
            throw new IOException("Cannot write backup file: "+name,ex);
        }
    }

    void backupPublic(Entry e,boolean keep) throws IOException {
        if(!supportsAutomaticPublicFolder())throw new IOException("Choose a backup folder on this Android version");
        List<Entry> oldEntries=archivesPublic();
        ArrayList<Entry> old=new ArrayList<>();
        for(Entry item:oldEntries)if(item.pkg.equals(e.pkg)&&(!keep||item.code==e.code))old.add(item);
        // Human-readable bKash.apk first; duplicate app names / revisions get a
        // unique paired suffix, preserving old backups until both outputs succeed.
        String base=clean(e.name);
        for(Entry item:oldEntries){
            if(AppsBackupArchiveLogic.stem(item.fileName).equalsIgnoreCase(base)){
                base=AppsBackupFolderLogic.uniqueStem(clean(e.name),e.pkg,e.code,
                        clean(e.version),System.currentTimeMillis());
                break;
            }
        }
        Uri full=null,main=null;
        try {
            if(e.split)full=createPublicBackup(e,PUBLIC_SPLIT_PATH,base+".apks",true);
            main=createPublicBackup(e,PUBLIC_BACKUP_PATH,base+".apk",false);
        }catch(Exception ex){removeQuietly(full);removeQuietly(main);throw new IOException("Backup failed: "+e.name,ex);}
        for(Entry item:old)try{deleteBackup(item);}catch(Exception ignored){}
    }

    Uri shareCopy(Entry e)throws IOException{
        File dir=new File(c.getCacheDir(),"share");if(!dir.exists()&&!dir.mkdirs())throw new IOException("Cannot create share cache");
        File f=new File(dir,UUID.randomUUID()+"_"+(e.archived?e.fileName.replaceAll("[\\\\/]","_"):fileName(e)));
        try(OutputStream out=new FileOutputStream(f)){
            if(e.archived){try(InputStream in=cr.openInputStream(e.uri)){if(in==null)throw new IOException("Missing archive");copy(in,out);}}
            else writeApp(e,out);
        }catch(Exception ex){f.delete();throw new IOException("Share failed",ex);}
        return new Uri.Builder().scheme("content").authority(c.getPackageName()+".share").appendPath(f.getName()).build();
    }
    void pruneShare(){File[] fs=new File(c.getCacheDir(),"share").listFiles();if(fs!=null)for(File f:fs)if(System.currentTimeMillis()-f.lastModified()>86400000L)f.delete();}
    int prepareInstall(Entry e)throws IOException{
        if(e==null || !e.archived || e.uri==null
                || !AppsBackupArchiveLogic.supported(e.fileName)) {
            throw new IOException("Select a saved .apk/.apks file in Archived to restore");
        }
        PackageInstaller pi=pm.getPackageInstaller();PackageInstaller.SessionParams params=new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
        if(Build.VERSION.SDK_INT>=31)params.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_REQUIRED);
        int id=pi.createSession(params);
        try(PackageInstaller.Session session=pi.openSession(id);InputStream in=cr.openInputStream(e.uri)){
            if(in==null)throw new IOException("Cannot open archive");
            if(!e.split){try(OutputStream out=session.openWrite("base.apk",0,-1)){copy(in,out);session.fsync(out);}}
            else{int n=0;try(ZipInputStream zip=new ZipInputStream(in)){ZipEntry ze;while((ze=zip.getNextEntry())!=null){if(!ze.isDirectory()&&ze.getName().toLowerCase(Locale.ROOT).endsWith(".apk")){if(++n>256)throw new IOException("Too many APK parts");try(OutputStream out=session.openWrite("part_"+n+".apk",0,-1)){copy(zip,out);session.fsync(out);}}zip.closeEntry();}}if(n==0)throw new IOException("No APK in archive");}
        }catch(Exception ex){try{pi.abandonSession(id);}catch(Exception ignored){}throw new IOException("Cannot prepare install: "+e.name,ex);}return id;
    }
    void commit(int id)throws IOException{
        Intent callback=new Intent(c,AppsBackupInstallReceiver.class);callback.setAction(c.getPackageName()+".INSTALL_RESULT");
        // PackageInstaller fills in status extras. The callback must be explicit and mutable.
        android.app.PendingIntent pending;
        if (Build.VERSION.SDK_INT >= 31) {
            pending = android.app.PendingIntent.getBroadcast(c, id, callback,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT | android.app.PendingIntent.FLAG_MUTABLE);
        } else {
            pending = android.app.PendingIntent.getBroadcast(c, id, callback,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT);
        }
        try(PackageInstaller.Session s=pm.getPackageInstaller().openSession(id)){s.commit(pending.getIntentSender());}
        catch(Exception e){try{pm.getPackageInstaller().abandonSession(id);}catch(Exception ignored){}throw new IOException("Install could not start",e);}
    }
}
