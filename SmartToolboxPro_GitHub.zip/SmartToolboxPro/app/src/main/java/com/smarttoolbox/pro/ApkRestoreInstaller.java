package com.smarttoolbox.pro;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInstaller;
import android.net.Uri;
import android.os.Build;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashSet;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Restores a .apks bundle with the user's Android Package Installer confirmation. */
final class ApkRestoreInstaller {
    private ApkRestoreInstaller() {}

    static int installSplitArchive(Context context, Uri archive) throws IOException {
        PackageInstaller installer = context.getPackageManager().getPackageInstaller();
        PackageInstaller.SessionParams options = new PackageInstaller.SessionParams(
                PackageInstaller.SessionParams.MODE_FULL_INSTALL);
        int id = installer.createSession(options);
        PackageInstaller.Session session = null;
        boolean committed = false;
        try {
            session = installer.openSession(id);
            int count = 0;
            boolean hasBase = false;
            Set<String> names = new HashSet<>();
            long total = 0;
            try (InputStream in = context.getContentResolver().openInputStream(archive)) {
                if (in == null) throw new IOException("Cannot read selected backup");
                try (ZipInputStream zip = new ZipInputStream(in)) {
                    ZipEntry entry;
                    while ((entry = zip.getNextEntry()) != null) {
                        String name = entry.getName();
                        if (entry.isDirectory()) throw new IOException("Unsupported archive entry");
                        if ("info.json".equals(name)) {
                            // Informational only: the APK signature is validated by Android.
                            byte[] scratch = new byte[4096];
                            long length = 0;
                            int n;
                            while ((n = zip.read(scratch)) != -1) {
                                length += n;
                                if (length > 16 * 1024L) throw new IOException("Metadata too large");
                            }
                            zip.closeEntry();
                            continue;
                        }
                        if (!ApkBackupLogic.permittedApkZipEntry(name) || !names.add(name)) {
                            throw new IOException("Unsupported or duplicate split APK entry: " + name);
                        }
                        if (++count > 128) throw new IOException("Too many APK parts");
                        if ("base.apk".equals(name)) hasBase = true;
                        long entryLength = 0;
                        try (OutputStream out = session.openWrite(name, 0, -1)) {
                            byte[] buf = new byte[64 * 1024];
                            int n;
                            while ((n = zip.read(buf)) != -1) {
                                entryLength += n;
                                total += n;
                                if (total > 2L * 1024 * 1024 * 1024) {
                                    throw new IOException("APK archive exceeds 2 GB safety limit");
                                }
                                out.write(buf, 0, n);
                            }
                            out.flush();
                            session.fsync(out);
                        }
                        if (entryLength == 0) throw new IOException("Empty APK part");
                        zip.closeEntry();
                    }
                }
            }
            if (!hasBase || count < 1) throw new IOException("Backup does not contain base.apk");
            Intent callback = new Intent(context, ApkInstallStatusReceiver.class);
            callback.setAction("com.smarttoolbox.pro.APK_RESTORE_RESULT");
            callback.putExtra("session_id", id);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) flags |= PendingIntent.FLAG_MUTABLE;
            PendingIntent pending = PendingIntent.getBroadcast(context, id, callback, flags);
            session.commit(pending.getIntentSender());
            committed = true;
            return id;
        } finally {
            if (session != null) {
                if (!committed) session.abandon();
                session.close();
            } else if (!committed) installer.abandonSession(id);
        }
    }
}
