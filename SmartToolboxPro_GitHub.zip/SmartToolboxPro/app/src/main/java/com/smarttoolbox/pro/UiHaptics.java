package com.smarttoolbox.pro;

import android.content.Context;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.provider.Settings;

/** Short optional feedback. Does not change phone-wide volume or vibration settings. */
final class UiHaptics {
    private UiHaptics() { }

    static void click(Context c) {
        pulse(c, 16L, 55);
    }

    static void pulse(Context c, long durationMs, int amplitude) {
        if (c == null) return;
        boolean systemEnabled = Settings.System.getInt(c.getContentResolver(),
                Settings.System.HAPTIC_FEEDBACK_ENABLED, 1) != 0;
        if (!FeedbackPolicy.vibrate(PremiumExperience.vibrations(c), true, systemEnabled)) return;
        try {
            Vibrator vibrator;
            if (Build.VERSION.SDK_INT >= 31) {
                VibratorManager manager = (VibratorManager) c.getSystemService(
                        Context.VIBRATOR_MANAGER_SERVICE);
                vibrator = manager == null ? null : manager.getDefaultVibrator();
            } else {
                vibrator = (Vibrator) c.getSystemService(Context.VIBRATOR_SERVICE);
            }
            if (vibrator != null && vibrator.hasVibrator()) {
                vibrator.vibrate(VibrationEffect.createOneShot(durationMs, amplitude));
            }
        } catch (RuntimeException ignored) {
            // The user may disable haptics in Android, or the device may lack hardware.
        }
    }
}
