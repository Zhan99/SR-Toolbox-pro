package com.smarttoolbox.pro;

/** Screen-size-aware, always border-flush coordinates for a collapsed edge tab. */
final class FloatingEdgeGeometry {
    private FloatingEdgeGeometry() {}

    static int x(boolean left, int screenWidth, int tabWidth) {
        return left ? 0 : Math.max(0, screenWidth - Math.max(0, tabWidth));
    }

    static int y(int wantedTop, int screenHeight, int tabHeight, int margin) {
        int safeMargin = Math.max(0, margin);
        int maximumTop = Math.max(0, screenHeight - Math.max(0, tabHeight) - safeMargin);
        return Math.max(Math.min(safeMargin, maximumTop), Math.min(maximumTop, wantedTop));
    }

    static boolean leftForDrop(float touchX, int screenWidth) {
        return touchX < Math.max(1, screenWidth) / 2f;
    }
}
