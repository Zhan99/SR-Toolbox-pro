package com.smarttoolbox.pro;

/** Screen-size-aware, always border-flush coordinates for a collapsed edge tab. */
final class FloatingEdgeGeometry {
    private FloatingEdgeGeometry() {}

    static int x(boolean left, int screenWidth, int tabWidth) {
        return left ? 0 : Math.max(0, screenWidth - Math.max(0, tabWidth));
    }

    static int y(int wantedTop, int screenHeight, int tabHeight, int margin) {
        int safeMargin = Math.max(0, margin);
        int maximumTop = Math.max(0, screenHeight - Math.max(0, tabHeight) - safeMargin);
        return Math.max(Math.min(safeMargin, maximumTop), Math.min(maximumTop, wantedTop));
    }

    /** Save a relative Y position so a screen rotation never changes the chosen height. */
    static float centerFraction(int centerY, int displayHeight) {
        if (displayHeight <= 0) return 0.5f;
        return Math.max(0f, Math.min(1f, centerY / (float) displayHeight));
    }

    static int centerForFraction(float fraction, int displayHeight) {
        if (displayHeight <= 0) return 0;
        if (Float.isNaN(fraction)) fraction = 0.5f;
        return Math.round(Math.max(0f, Math.min(1f, fraction)) * displayHeight);
    }

    static boolean leftForDrop(float touchX, int screenWidth) {
        return touchX < Math.max(1, screenWidth) / 2f;
    }
}
