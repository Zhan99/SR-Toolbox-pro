package com.smarttoolbox.pro;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import java.util.List;

/** Standalone local notepad: create, edit, delete, search and reuse as message. */
public final class SchedulerNotepadActivity extends Activity {
    public static final String EXTRA_PICK_MODE = "sr.note.pick_mode";
    public static final String EXTRA_NOTE_BODY = "sr.note.body";
    public static final String EXTRA_NOTE_TITLE = "sr.note.title";

    private LinearLayout noteList;
    private EditText searchField;

    @Override protected void onCreate(Bundle state) {
        ThemeManager.applyToActivity(this);
        super.onCreate(state);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(Ui.BG);
        page.setPadding(dp(13), dp(12), dp(13), dp(12));

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("📝 My Notepad", 21, Ui.ACCENT);
        titleRow.addView(title, new LinearLayout.LayoutParams(0, dp(54), 1));
        Button add = button("+ New", v -> edit(null));
        titleRow.addView(add);
        page.addView(titleRow);

        TextView help = text("মেসেজের খসড়া লিখুন, সেভ করুন এবং প্রয়োজনে Scheduler-এ নিন। নোট শুধু ফোনে থাকবে।", 13, Ui.MUTED);
        page.addView(help);

        searchField = new EditText(this);
        searchField.setSingleLine(true);
        searchField.setHint("Search notes...");
        searchField.setHintTextColor(Ui.MUTED);
        searchField.setTextColor(Ui.TEXT);
        searchField.setTextSize(14);
        searchField.setPadding(dp(10), dp(6), dp(10), dp(6));
        searchField.setBackground(cardBackground());
        LinearLayout.LayoutParams searchParams = new LinearLayout.LayoutParams(-1, dp(48));
        searchParams.topMargin = dp(12);
        page.addView(searchField, searchParams);
        searchField.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { render(); }
            @Override public void afterTextChanged(Editable s) { }
        });

        ScrollView scroll = new ScrollView(this);
        noteList = new LinearLayout(this);
        noteList.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(noteList);
        LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(-1, 0, 1f);
        scrollParams.topMargin = dp(12);
        page.addView(scroll, scrollParams);
        setContentView(page);
        render();
    }

    private void render() {
        if (noteList == null) return;
        noteList.removeAllViews();
        List<SchedulerNoteStore.Note> notes = SchedulerNoteStore.all(this);
        String query = searchField == null ? "" : searchField.getText().toString();
        int shown = 0;
        for (SchedulerNoteStore.Note note : notes) {
            if (!SchedulerNoteLogic.matches(note.title, note.body, query)) continue;
            shown++;
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(13), dp(11), dp(13), dp(11));
            card.setBackground(cardBackground());
            TextView header = text(note.title, 16, Ui.TEXT);
            card.addView(header);
            TextView preview = text(SchedulerNoteLogic.preview(note.body), 13, Ui.MUTED);
            LinearLayout.LayoutParams previewParams = new LinearLayout.LayoutParams(-1, -2);
            previewParams.topMargin = dp(5);
            card.addView(preview, previewParams);
            LinearLayout controls = new LinearLayout(this);
            controls.setGravity(Gravity.CENTER_VERTICAL);
            Button use = button("Use in message", v -> use(note));
            controls.addView(use, new LinearLayout.LayoutParams(0, dp(48), 1));
            Button edit = button("Edit", v -> edit(note));
            controls.addView(edit, new LinearLayout.LayoutParams(0, dp(48), 0.65f));
            Button delete = button("Delete", v -> confirmDelete(note));
            controls.addView(delete, new LinearLayout.LayoutParams(0, dp(48), 0.75f));
            LinearLayout.LayoutParams controlsParams = new LinearLayout.LayoutParams(-1, -2);
            controlsParams.topMargin = dp(10);
            card.addView(controls, controlsParams);
            LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, -2);
            cardParams.bottomMargin = dp(10);
            noteList.addView(card, cardParams);
        }
        if (shown == 0) noteList.addView(text(notes.isEmpty()
                ? "এখনো কোনো নোট নেই। + New দিয়ে প্রথম নোট তৈরি করুন।"
                : "এই নামের কোনো নোট পাওয়া যায়নি।", 14, Ui.MUTED));
    }

    private void edit(SchedulerNoteStore.Note note) {
        LinearLayout fields = new LinearLayout(this);
        fields.setOrientation(LinearLayout.VERTICAL);
        fields.setPadding(dp(17), dp(6), dp(17), dp(6));
        EditText title = new EditText(this);
        title.setSingleLine(true);
        title.setHint("Title / শিরোনাম");
        if (note != null) title.setText(note.title);
        fields.addView(title, new LinearLayout.LayoutParams(-1, dp(54)));
        EditText body = new EditText(this);
        body.setHint("নোট অথবা মেসেজ লিখুন...");
        body.setMinLines(6);
        body.setMaxLines(12);
        body.setGravity(Gravity.TOP | Gravity.START);
        body.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        if (note != null) body.setText(note.body);
        fields.addView(body);
        new AlertDialog.Builder(this)
                .setTitle(note == null ? "নতুন নোট" : "নোট এডিট করুন")
                .setView(fields)
                .setPositiveButton("Save", (d, which) -> {
                    if (!SchedulerNoteLogic.valid(body.getText().toString())) {
                        toast("খালি নোট সেভ করা যাবে না।");
                        return;
                    }
                    boolean saved = SchedulerNoteStore.save(this,
                            note == null ? null : note.id,
                            title.getText().toString(), body.getText().toString());
                    toast(saved ? "নোট সেভ হয়েছে" : "সেভ করা যায়নি। সর্বোচ্চ ২০০টি নোট রাখা যাবে।");
                    render();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void use(SchedulerNoteStore.Note note) {
        Intent result = new Intent();
        result.putExtra(EXTRA_NOTE_BODY, note.body);
        result.putExtra(EXTRA_NOTE_TITLE, note.title);
        setResult(RESULT_OK, result);
        finish();
    }

    private void confirmDelete(SchedulerNoteStore.Note note) {
        new AlertDialog.Builder(this)
                .setTitle("নোট মুছবেন?")
                .setMessage(note.title + "\nএই কাজটি ফিরিয়ে আনা যাবে না।")
                .setPositiveButton("Delete", (d, which) -> {
                    toast(SchedulerNoteStore.delete(this, note.id)
                            ? "নোট মুছে গেছে" : "নোট মোছা যায়নি");
                    render();
                })
                .setNegativeButton("Cancel", null).show();
    }

    private TextView text(String value, int sizeSp, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sizeSp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(dp(5), dp(5), dp(5), dp(5));
        return t;
    }

    private Button button(String label, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(label);
        b.setTextSize(12);
        b.setOnClickListener(listener);
        return b;
    }

    private GradientDrawable cardBackground() {
        GradientDrawable background = new GradientDrawable();
        background.setColor(Ui.CARD);
        background.setCornerRadius(dp(14));
        background.setStroke(dp(1), Ui.MUTED);
        return background;
    }

    private int dp(float n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }
}
