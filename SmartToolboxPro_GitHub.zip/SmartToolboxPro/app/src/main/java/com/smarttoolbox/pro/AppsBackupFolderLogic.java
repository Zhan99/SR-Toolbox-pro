package com.smarttoolbox.pro;

/** Shared storage folder/naming rules; no Android dependencies (CI regression-tested). */
final class AppsBackupFolderLogic {
    static final String FOLDER = "App Backup";
    static final String SPLIT = "Split backups";
    private AppsBackupFolderLogic() {}

    static String uniqueStem(String app, String pkg, long code, String version, long time) {
        String name=safe(app, "App");
        String packageName=safe(pkg,"package");
        String ver=safe(version,"version");
        return name+"__"+packageName+"__"+code+"__"+ver+"-"+Math.max(time,0);
    }

    static String safe(String raw,String fallback){
        if(raw==null||raw.trim().isEmpty())return fallback;
        String text=raw.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]","_")
                .replaceAll("_+","_").trim();
        if(text.isEmpty())return fallback;
        return text.length()>48?text.substring(0,48):text;
    }

    static boolean isAppFolder(String name){return FOLDER.equalsIgnoreCase(name);}
    static boolean publicStorageAvailable(int androidApi){return androidApi>=29;}
}
