package com.smarttoolbox.pro;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.media.MediaPlayer;
import android.os.BatteryManager;
import android.os.Build;
import android.os.IBinder;

/** User-enabled foreground monitoring. Battery changed is registered dynamically (sticky broadcast). */
public final class FullChargeVoiceService extends Service {
    public static final String ACTION_STOP = "com.smarttoolbox.pro.STOP_FULL_CHARGE_VOICE";
    private static final String CHANNEL_MONITOR = "sr_full_charge_monitor";
    private static final String CHANNEL_ALERT = "sr_full_charge_alert";
    private static final int MONITOR_NOTIFICATION = 2501;
    private static final int ALERT_NOTIFICATION = 2502;
    private boolean registered;
    private int lastPercentage = -2;
    private boolean lastPowered;
    private boolean hasBatteryReading;
    private MediaPlayer voice;

    private final BroadcastReceiver batteryReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (intent == null) return;
            if (Intent.ACTION_BATTERY_CHANGED.equals(intent.getAction())) {
                onBatteryState(intent);
            } else if (Intent.ACTION_POWER_DISCONNECTED.equals(intent.getAction())) {
                resetChargeSession();
                hasBatteryReading = false;
                updateStatus(-1, "চার্জার খোলা হয়েছে · পরবর্তী চার্জের জন্য প্রস্তুত");
            }
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        createChannels();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if ((intent != null && ACTION_STOP.equals(intent.getAction()))
                || !FullChargeAlertPreferences.enabled(this)) {
            FullChargeAlertPreferences.setEnabled(this, false);
            stopListening();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        try {
            startMonitorForeground();
        } catch (RuntimeException ex) {
            // A device/OS may deny this foreground service type. Fail closed;
            // never claim that monitoring is active when the OS rejected it.
            FullChargeAlertPreferences.setEnabled(this, false);
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!registered) {
            IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            filter.addAction(Intent.ACTION_POWER_DISCONNECTED);
            // A dynamic receiver is required; battery-changed cannot be manifest-registered.
            Intent sticky = registerReceiver(batteryReceiver, filter);
            registered = true;
            if (sticky != null) onBatteryState(sticky);
        }
        return START_STICKY;
    }

    private void startMonitorForeground() {
        Notification notification = notification("চার্জ মনিটরিং চালু · ১০০% হলে বাংলা ভয়েস", true);
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(MONITOR_NOTIFICATION, notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(MONITOR_NOTIFICATION, notification);
        }
    }

    private void onBatteryState(Intent battery) {
        if (!FullChargeAlertPreferences.enabled(this)) return;
        int plugged = battery.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
        int status = battery.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        int level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        int percentage = FullChargeAlertLogic.percent(level, scale);
        boolean powered = FullChargeAlertLogic.isPowered(plugged);
        boolean statusChanged = !hasBatteryReading || lastPowered != powered
                || lastPercentage != percentage;
        int decision = FullChargeAlertLogic.decision(true, plugged, status, level, scale,
                FullChargeAlertPreferences.announced(this));
        if (decision == FullChargeAlertLogic.RESET_SESSION) {
            if (FullChargeAlertPreferences.announced(this)) resetChargeSession();
            if (statusChanged) updateStatus(percentage, "চার্জার সংযুক্ত নেই");
        } else if (decision == FullChargeAlertLogic.ANNOUNCE_ONCE) {
            // Persist before media playback to avoid duplicate speech from rapid broadcasts.
            if (FullChargeAlertPreferences.setAnnounced(this, true)) {
                announceFullBattery();
            }
        } else if (statusChanged) {
            updateStatus(percentage, plugged > 0
                    ? (FullChargeAlertLogic.isFull(status, level, scale)
                        ? "ব্যাটারি পূর্ণ · চার্জ থেকে খুলুন"
                        : "চার্জ হচ্ছে · পূর্ণ হলে সতর্ক করবে")
                    : "চার্জার সংযুক্ত নেই");
        }
        lastPercentage = percentage;
        lastPowered = powered;
        hasBatteryReading = true;
    }

    private void announceFullBattery() {
        voice = FullChargeVoicePlayer.play(this);
        NotificationManager manager = manager();
        if (manager != null) {
            Intent open = new Intent(this, FullChargeAlertActivity.class);
            PendingIntent openPending = PendingIntent.getActivity(this, 2503, open,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    ? new Notification.Builder(this, CHANNEL_ALERT) : new Notification.Builder(this);
            manager.notify(ALERT_NOTIFICATION, builder
                    .setSmallIcon(android.R.drawable.ic_lock_idle_charging)
                    .setContentTitle("🔋 ব্যাটারি ১০০% — চার্জ থেকে খুলুন")
                    .setContentText("ব্যাটারি ফুল চার্জ হয়েছে, চার্জ থেকে খুলুন।")
                    .setContentIntent(openPending).setAutoCancel(true).build());
        }
        updateStatus(100, "ব্যাটারি পূর্ণ · চার্জ থেকে খুলুন");
    }

    private void resetChargeSession() {
        FullChargeAlertPreferences.setAnnounced(this, false);
        NotificationManager manager = manager();
        if (manager != null) manager.cancel(ALERT_NOTIFICATION);
    }

    private NotificationManager manager() {
        return (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
    }

    private void updateStatus(int percentage, String state) {
        NotificationManager manager = manager();
        if (manager == null) return;
        String text = (percentage >= 0 ? percentage + "% · " : "") + state;
        manager.notify(MONITOR_NOTIFICATION, notification(text, true));
    }

    private Notification notification(String text, boolean ongoing) {
        PendingIntent open = PendingIntent.getActivity(this, 2501,
                new Intent(this, FullChargeAlertActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, FullChargeVoiceService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(this, 2502, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_MONITOR) : new Notification.Builder(this);
        return builder.setSmallIcon(android.R.drawable.ic_lock_idle_charging)
                .setContentTitle("SR Full Charge বাংলা Voice Alert")
                .setContentText(text).setContentIntent(open)
                .setOngoing(ongoing)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "বন্ধ করুন", stopPending)
                .build();
    }

    private void createChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager manager = manager();
        if (manager == null) return;
        NotificationChannel monitor = new NotificationChannel(CHANNEL_MONITOR,
                "Battery 100% voice monitor", NotificationManager.IMPORTANCE_LOW);
        monitor.setDescription("User-enabled battery full-charge monitoring. Tap Stop to disable.");
        manager.createNotificationChannel(monitor);
        NotificationChannel alert = new NotificationChannel(CHANNEL_ALERT,
                "Battery full — charge removal", NotificationManager.IMPORTANCE_HIGH);
        // Voice is supplied by the app; don't play a second Android notification sound.
        alert.setSound(null, null);
        alert.enableVibration(false);
        manager.createNotificationChannel(alert);
    }

    private void stopListening() {
        if (registered) {
            try { unregisterReceiver(batteryReceiver); } catch (RuntimeException ignored) { }
            registered = false;
        }
        if (voice != null) {
            try { if (voice.isPlaying()) voice.stop(); } catch (RuntimeException ignored) { }
            try { voice.release(); } catch (RuntimeException ignored) { }
            voice = null;
        }
        NotificationManager manager = manager();
        if (manager != null) manager.cancel(ALERT_NOTIFICATION);
    }

    @Override public void onDestroy() {
        stopListening();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
