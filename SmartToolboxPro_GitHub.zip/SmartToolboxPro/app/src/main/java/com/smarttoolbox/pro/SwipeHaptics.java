package com.smarttoolbox.pro;

import android.content.Context;
import android.provider.Settings;

/** Haptics only for a completed swipe-to-open; respects BOTH vibration toggles. */
final class SwipeHaptics {
    private SwipeHaptics() { }
    static void onSwipeMenuOpen(Context c) {
        boolean enabled = c.getSharedPreferences("tool_state", Context.MODE_PRIVATE)
                .getBoolean(SwipeVibrationLogic.PREF, true);
        boolean systemHaptics = Settings.System.getInt(c.getContentResolver(),
                Settings.System.HAPTIC_FEEDBACK_ENABLED, 1) != 0;
        if (!SwipeVibrationLogic.shouldVibrate(enabled, true, true, false, systemHaptics)) return;
        UiHaptics.pulse(c, 24L, 75);
    }
}
