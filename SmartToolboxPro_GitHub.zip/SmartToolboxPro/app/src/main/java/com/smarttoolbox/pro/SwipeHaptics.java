package com.smarttoolbox.pro;

import android.content.Context;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.provider.Settings;

/** Light feedback exactly once when a real Swipe-to-Open gesture succeeds. */
final class SwipeHaptics {
    private SwipeHaptics() { }
    static void onSwipeMenuOpen(Context c) {
        boolean enabled = c.getSharedPreferences("tool_state", Context.MODE_PRIVATE)
                .getBoolean(SwipeVibrationLogic.PREF, true);
        boolean systemHaptics = Settings.System.getInt(c.getContentResolver(),
                Settings.System.HAPTIC_FEEDBACK_ENABLED, 1) != 0;
        if (!SwipeVibrationLogic.shouldVibrate(enabled, true, true, false, systemHaptics)) return;
        try {
            Vibrator v;
            if (Build.VERSION.SDK_INT >= 31) {
                VibratorManager manager = (VibratorManager)c.getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
                v = manager == null ? null : manager.getDefaultVibrator();
            } else v = (Vibrator)c.getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null && v.hasVibrator()) {
                v.vibrate(VibrationEffect.createOneShot(24L, 75));
            }
        } catch (RuntimeException ignored) {
            // No haptic hardware, disabled by OEM, or a device policy: menu still opens.
        }
    }
}
