package com.smarttoolbox.pro;

/** Pure-Java scanner feedback: avoid claiming a gallery scan found a code. */
final class GalleryBarcodeResultLogic {
    private GalleryBarcodeResultLogic() {}
    static String status(boolean canceled, int codeCount, boolean hasReadableText) {
        if (canceled) return "Image selection cancelled.";
        if (codeCount <= 0) return "No QR code or barcode found in this image.";
        if (!hasReadableText) return "A barcode was detected but it has no readable text.";
        return "Gallery image scan successful.";
    }
}
