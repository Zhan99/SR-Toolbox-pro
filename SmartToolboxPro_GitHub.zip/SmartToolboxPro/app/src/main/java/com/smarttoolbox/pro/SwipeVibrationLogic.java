package com.smarttoolbox.pro;
/** Swipe feedback is independent of tap and of the two-second drag gesture. */
final class SwipeVibrationLogic {
    static final String PREF = "floating.swipe.vibration";
    private SwipeVibrationLogic() { }
    static boolean shouldVibrate(boolean enabled, boolean menuEnabled,
                                 boolean openedWithSwipe, boolean dragging,
                                 boolean systemHapticsEnabled) {
        return enabled && menuEnabled && openedWithSwipe && !dragging && systemHapticsEnabled;
    }
}
