package com.smarttoolbox.pro;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.os.BatteryManager;
import android.os.Build;
import android.os.IBinder;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.util.Log;

import java.util.Locale;

/** User-opted-in, visible, foreground battery monitoring for Bengali full-charge speech. */
public final class BatteryFullVoiceService extends Service {
    static final String ACTION_START = "com.smarttoolbox.pro.BATTERY_VOICE_START";
    static final String ACTION_STOP = "com.smarttoolbox.pro.BATTERY_VOICE_STOP";
    static final String ACTION_TEST = "com.smarttoolbox.pro.BATTERY_VOICE_TEST";
    static final String FULL_MESSAGE = "ব্যাটারি ফুল চার্জ হয়েছে, চার্জ থেকে খুলুন।";
    private static final String CHANNEL = "sr_full_charge_monitor_v1";
    private static final String ALERT_CHANNEL = "sr_full_charge_alert_v1";
    private static final int MONITOR_ID = 2661;
    private static final int FULL_ID = 2662;
    private static final String TAG = "FullChargeVoice";

    private TextToSpeech tts;
    private boolean ttsReady;
    private boolean bengaliAvailable;
    private boolean pendingSpeech;
    private boolean registered;
    private int lastPercent = -1;
    private boolean lastPlugged;

    private final BroadcastReceiver batteryReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (Intent.ACTION_BATTERY_CHANGED.equals(intent.getAction())) inspectBattery(intent);
        }
    };

    /** Foreground service is only started by explicit user opt-in, or best-effort boot restore. */
    static boolean startMonitoring(Context context) {
        if (!BatteryFullAlertPrefs.enabled(context)) return false;
        Intent command = new Intent(context, BatteryFullVoiceService.class).setAction(ACTION_START);
        return dispatch(context, command);
    }

    static void stopMonitoring(Context context) {
        Intent command = new Intent(context, BatteryFullVoiceService.class).setAction(ACTION_STOP);
        // If already running this command disables and terminates the foreground service.
        // Stop even if Android disallows creating a new background service instance.
        context.stopService(new Intent(context, BatteryFullVoiceService.class));
    }

    static boolean testVoice(Context context) {
        return dispatch(context, new Intent(context, BatteryFullVoiceService.class).setAction(ACTION_TEST));
    }

    private static boolean dispatch(Context context, Intent command) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(command);
            else context.startService(command);
            return true;
        } catch (RuntimeException error) {
            Log.w(TAG, "Could not start foreground battery monitoring", error);
            return false;
        }
    }

    @Override public void onCreate() {
        super.onCreate();
        createChannels();
        tts = new TextToSpeech(getApplicationContext(), status ->
                new Handler(Looper.getMainLooper()).post(() -> {
                    if (status == TextToSpeech.SUCCESS && tts != null) {
                        try {
                            int lang = tts.setLanguage(new Locale("bn", "BD"));
                            if (lang == TextToSpeech.LANG_MISSING_DATA
                                    || lang == TextToSpeech.LANG_NOT_SUPPORTED) {
                                // Many phones ship a Bengali voice tagged bn-IN, not bn-BD.
                                lang = tts.setLanguage(new Locale("bn", "IN"));
                            }
                            if (lang == TextToSpeech.LANG_MISSING_DATA
                                    || lang == TextToSpeech.LANG_NOT_SUPPORTED) {
                                lang = tts.setLanguage(new Locale("bn"));
                            }
                            bengaliAvailable = lang != TextToSpeech.LANG_MISSING_DATA
                                    && lang != TextToSpeech.LANG_NOT_SUPPORTED;
                        } catch (RuntimeException error) {
                            bengaliAvailable = false;
                        }
                    }
                    ttsReady = true;
                    if (pendingSpeech) {
                        pendingSpeech = false;
                        speakBengali();
                    }
                }));
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            BatteryFullAlertPrefs.setEnabled(this, false);
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager != null) manager.cancel(FULL_ID);
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!BatteryFullAlertPrefs.enabled(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        try {
            foreground();
        } catch (RuntimeException error) {
            Log.w(TAG, "Foreground monitoring not allowed", error);
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!registered) {
            registered = true;
            // BATTERY_CHANGED is a sticky broadcast and must be received dynamically.
            Intent sticky = registerReceiver(batteryReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (sticky != null) inspectBattery(sticky);
        }
        if (intent != null && ACTION_TEST.equals(intent.getAction())) requestSpeech();
        return START_STICKY;
    }

    private void inspectBattery(Intent intent) {
        if (!BatteryFullAlertPrefs.enabled(this)) return;
        int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
        int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        lastPlugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0;
        lastPercent = level < 0 || scale <= 0 ? -1 : (int) (100L * level / scale);
        boolean full = BatteryFullAlertLogic.isFull(level, scale,
                status, BatteryManager.BATTERY_STATUS_FULL);
        boolean previous = BatteryFullAlertPrefs.announced(this);
        if (BatteryFullAlertLogic.shouldAnnounce(true, lastPlugged, full, previous)) {
            BatteryFullAlertPrefs.setAnnounced(this, true);
            showFullNotification();
            requestSpeech();
        } else if (!BatteryFullAlertLogic.nextAnnouncedState(lastPlugged, full, previous) && previous) {
            BatteryFullAlertPrefs.setAnnounced(this, false);
        }
        updateOngoingNotification();
    }

    private void requestSpeech() {
        if (!ttsReady) { pendingSpeech = true; return; }
        speakBengali();
    }

    private void speakBengali() {
        if (!BatteryFullAlertPrefs.enabled(this)) return;
        if (tts == null || !bengaliAvailable) {
            // Do not silently speak this Bengali sentence in an unrelated language.
            notifyMissingBanglaVoice();
            return;
        }
        try {
            tts.speak(FULL_MESSAGE, TextToSpeech.QUEUE_FLUSH, null, "sr-charge-full");
        } catch (RuntimeException error) {
            Log.w(TAG, "Bengali speech failed", error);
            notifyMissingBanglaVoice();
        }
    }

    private void foreground() {
        Notification n = ongoingNotification();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(MONITOR_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else startForeground(MONITOR_ID, n);
    }

    private void createChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager == null) return;
        NotificationChannel monitoring = new NotificationChannel(
                CHANNEL, "Battery full voice monitor", NotificationManager.IMPORTANCE_LOW);
        monitoring.setDescription("Monitoring 100% battery level for opted-in Bengali voice alerts");
        manager.createNotificationChannel(monitoring);
        NotificationChannel alerts = new NotificationChannel(
                ALERT_CHANNEL, "Battery full alerts", NotificationManager.IMPORTANCE_HIGH);
        alerts.setDescription("Battery is fully charged; unplug the charger");
        alerts.setSound(null, null); // Voice TTS is the alert; avoid duplicate sounds.
        manager.createNotificationChannel(alerts);
    }

    private Notification.Builder builder(String channel) {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, channel) : new Notification.Builder(this);
    }

    private Notification ongoingNotification() {
        Intent home = new Intent(this, BatteryFullAlertActivity.class);
        PendingIntent open = PendingIntent.getActivity(this, 2661, home,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, BatteryFullVoiceService.class).setAction(ACTION_STOP);
        PendingIntent stopAction = PendingIntent.getService(this, 2662, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        String detail = lastPercent < 0 ? "চার্জের অবস্থা পর্যবেক্ষণ চলছে"
                : ("ব্যাটারি " + lastPercent + "% • " + (lastPlugged ? "চার্জে আছে" : "চার্জে নেই"));
        return builder(CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("🔋 ফুল চার্জ বাংলা ভয়েস সতর্কতা চালু")
                .setContentText(detail)
                .setContentIntent(open)
                .setOngoing(true)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "বন্ধ করুন", stopAction)
                .build();
    }

    private void updateOngoingNotification() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(MONITOR_ID, ongoingNotification());
    }

    private void showFullNotification() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(FULL_ID, builder(ALERT_CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("🔋 ব্যাটারি ফুল চার্জ হয়েছে")
                .setContentText("চার্জ থেকে খুলুন")
                .setAutoCancel(true)
                .build());
    }

    private void notifyMissingBanglaVoice() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(FULL_ID, builder(ALERT_CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("বাংলা TTS Voice পাওয়া যায়নি")
                .setContentText("ফোনে বাংলা Text-to-Speech Voice ইনস্টল/চালু করুন")
                .setAutoCancel(true)
                .build());
    }

    @Override public void onDestroy() {
        if (registered) {
            try { unregisterReceiver(batteryReceiver); } catch (RuntimeException ignored) {}
            registered = false;
        }
        pendingSpeech = false;
        if (tts != null) {
            try { tts.stop(); tts.shutdown(); } catch (RuntimeException ignored) {}
            tts = null;
        }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
