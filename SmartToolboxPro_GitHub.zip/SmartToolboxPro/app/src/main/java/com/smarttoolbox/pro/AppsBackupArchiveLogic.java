package com.smarttoolbox.pro;

import java.util.Locale;

/** Pure-Java filename rules for backed-up base APKs and complete split archives. */
final class AppsBackupArchiveLogic {
    private AppsBackupArchiveLogic() {}
    static String stem(String name){
        if(name==null) return "";
        int at=name.lastIndexOf('.');
        return at<0?name:name.substring(0,at);
    }
    static boolean isApk(String name){
        return name!=null && name.toLowerCase(Locale.ROOT).endsWith(".apk");
    }
    static boolean isApks(String name){
        return name!=null && name.toLowerCase(Locale.ROOT).endsWith(".apks");
    }
    static boolean supported(String name){return isApk(name)||isApks(name);}
    static boolean paired(String apk,String apks){
        return isApk(apk) && isApks(apks) && stem(apk).equals(stem(apks));
    }
}
