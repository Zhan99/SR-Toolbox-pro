package com.smarttoolbox.pro;

/** Bounded controls for the floating icon's inactivity and vertical edge tab. */
final class FloatingIdleLogic {
    static final String PREF_EDGE_HEIGHT_DP = "floating.edge.height_dp";
    static final int MIN_EDGE_HEIGHT_DP = 64;
    static final int MAX_EDGE_HEIGHT_DP = 136;
    private FloatingIdleLogic() {}
    static int clampEdgeHeight(int dp) { return Math.max(MIN_EDGE_HEIGHT_DP,
            Math.min(MAX_EDGE_HEIGHT_DP, dp)); }
    static long idleTimeoutMs(int seconds) {
        return Math.max(1, Math.min(60, seconds)) * 1000L;
    }
    static boolean holdFeedbackAllowed(long heldMillis, boolean movedBeforeHold,
                                       boolean touchActive, boolean alreadyPlayed) {
        return touchActive && !alreadyPlayed && !movedBeforeHold &&
                heldMillis >= FloatingOpenModeLogic.HOLD_TO_MOVE_MS;
    }
}
