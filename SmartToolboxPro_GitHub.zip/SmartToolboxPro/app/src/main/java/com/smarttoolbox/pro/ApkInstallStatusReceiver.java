package com.smarttoolbox.pro;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInstaller;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;

/** Android requires user confirmation for an ordinary app's APK installation. */
public final class ApkInstallStatusReceiver extends BroadcastReceiver {
    private static final String CHANNEL = "sr_apk_restore";
    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        int status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS,
                PackageInstaller.STATUS_FAILURE);
        int sessionId = intent.getIntExtra("session_id", 0);
        if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
            Intent confirm = (Intent) intent.getParcelableExtra(Intent.EXTRA_INTENT);
            if (confirm == null) return;
            confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            // On some Android versions background launches are restricted; always offer
            // the installer confirmation as a user-tappable notification as well.
            notifyResult(context, sessionId, "Confirm app restore",
                    "Tap to approve installation of the saved APK files", confirm);
            try { context.startActivity(confirm); }
            catch (Exception e) { Log.w("SRAppRestore", "Tap the install notification to continue", e); }
        } else if (status == PackageInstaller.STATUS_SUCCESS) {
            notifyResult(context, sessionId, "App restored", "Android installed the selected APK backup", null);
        } else {
            String reason = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);
            notifyResult(context, sessionId, "Restore did not complete",
                    reason == null ? "Android declined this backup" : reason, null);
        }
    }

    private void notifyResult(Context c, int id, String title, String description, Intent action) {
        NotificationManager manager = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) return;
        if (manager.getNotificationChannel(CHANNEL) == null) {
            manager.createNotificationChannel(new NotificationChannel(CHANNEL,
                    "App Backup & Restore", NotificationManager.IMPORTANCE_HIGH));
        }
        Notification.Builder note = new Notification.Builder(c, CHANNEL)
                .setSmallIcon(R.drawable.ic_launcher).setContentTitle(title)
                .setContentText(description).setAutoCancel(true);
        if (action != null) {
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
            note.setContentIntent(PendingIntent.getActivity(c, Math.max(1,id), action, flags));
        }
        manager.notify(6000 + (id % 1000), note.build());
    }
}
