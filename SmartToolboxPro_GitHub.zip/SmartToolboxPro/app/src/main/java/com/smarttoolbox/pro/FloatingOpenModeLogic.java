package com.smarttoolbox.pro;

/** Independent tap/swipe options and a shared, deliberate two-second move gesture. */
final class FloatingOpenModeLogic {
    static final String PREF_TAP = "floating.open.tap";
    static final String PREF_SWIPE = "floating.open.swipe";
    static final long HOLD_TO_MOVE_MS = 2000L;

    private FloatingOpenModeLogic() { }

    static boolean significantMotion(float dx, float dy, int threshold) {
        return Math.max(Math.abs(dx), Math.abs(dy)) >= Math.max(1, threshold);
    }

    static boolean movedTooEarly(long elapsed, float dx, float dy, int touchSlop) {
        return elapsed < HOLD_TO_MOVE_MS && significantMotion(dx, dy, touchSlop);
    }

    /** Drag may begin ONLY after a stationary two-second press. */
    static boolean startDrag(long elapsed, boolean movedBeforeHold,
                             float dx, float dy, int touchSlop) {
        return elapsed >= HOLD_TO_MOVE_MS && !movedBeforeHold
                && significantMotion(dx, dy, touchSlop);
    }

    /** Swipe mode and Tap mode are independent; dragging never opens the menu. */
    static boolean shouldOpen(boolean tapEnabled, boolean swipeEnabled, boolean panelEnabled,
                              boolean dragging, boolean movedBeforeHold,
                              long elapsed, float dx, float dy,
                              int tapSlop, int swipeThreshold) {
        if (!panelEnabled || dragging || elapsed < 0L) return false;
        if (movedBeforeHold) {
            return swipeEnabled && significantMotion(dx, dy, swipeThreshold);
        }
        if (elapsed >= HOLD_TO_MOVE_MS) return false; // deliberate hold, not a tap
        return tapEnabled && !significantMotion(dx, dy, Math.max(1, tapSlop) + 1);
    }
}
