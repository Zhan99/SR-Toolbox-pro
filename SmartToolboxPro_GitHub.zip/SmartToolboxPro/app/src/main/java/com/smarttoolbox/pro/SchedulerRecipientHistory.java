package com.smarttoolbox.pro;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/** Device-local, opt-in recipient history. It does not claim WhatsApp delivery. */
final class SchedulerRecipientHistory {
    private static final String PREFS = "sr_scheduler_recipient_history_v1";
    private static final String KEY_HISTORY = "recent_numbers";
    private static final String KEY_MIGRATED = "old_schedules_imported";
    private static final int MAX_ENTRIES = 40;

    static final class Entry {
        final String phone;
        final String name;
        final long lastUsedAt;
        Entry(String phone, String name, long lastUsedAt) {
            this.phone = phone;
            this.name = name;
            this.lastUsedAt = lastUsedAt;
        }
    }

    private SchedulerRecipientHistory() {}

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static List<Entry> read(Context context) {
        List<Entry> entries = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(prefs(context).getString(KEY_HISTORY, "[]"));
            for (int i = 0; i < array.length() && entries.size() < MAX_ENTRIES; i++) {
                JSONObject obj = array.optJSONObject(i);
                if (obj == null) continue;
                String phone = obj.optString("phone", "");
                if (!MessageScheduleLogic.isValidPhone(phone)) continue;
                entries.add(new Entry(phone, obj.optString("name", ""),
                        obj.optLong("lastUsedAt", 0L)));
            }
        } catch (Exception ignored) { /* Corrupt old history must never break schedules. */ }
        return entries;
    }

    private static void write(Context context, List<Entry> entries) {
        JSONArray data = new JSONArray();
        try {
            for (int i = 0; i < entries.size() && i < MAX_ENTRIES; i++) {
                Entry entry = entries.get(i);
                JSONObject json = new JSONObject();
                json.put("phone", entry.phone);
                json.put("name", entry.name);
                json.put("lastUsedAt", entry.lastUsedAt);
                data.put(json);
            }
            prefs(context).edit().putString(KEY_HISTORY, data.toString()).apply();
        } catch (Exception ignored) { }
    }

    private static void migrateExistingSchedulesOnce(Context context) {
        SharedPreferences preferences = prefs(context);
        if (preferences.getBoolean(KEY_MIGRATED, false)) return;
        List<Entry> entries = read(context);
        for (MessageScheduleStore.Item item : MessageScheduleStore.getAll(context)) {
            String phone = MessageScheduleLogic.normalizePhone("880", "+" + item.phone);
            if (!MessageScheduleLogic.isValidPhone(phone)) continue;
            boolean found = false;
            for (Entry old : entries) {
                if (old.phone.equals(phone)) {
                    found = true;
                    break;
                }
            }
            if (!found) entries.add(new Entry(phone, item.contactName,
                    item.lastTriggeredAtMillis > 0 ? item.lastTriggeredAtMillis : item.scheduledAtMillis));
        }
        if (entries.size() > MAX_ENTRIES) entries = new ArrayList<>(entries.subList(0, MAX_ENTRIES));
        write(context, entries);
        preferences.edit().putBoolean(KEY_MIGRATED, true).apply();
    }

    static synchronized List<Entry> getAll(Context context) {
        migrateExistingSchedulesOnce(context);
        return read(context);
    }

    static synchronized void record(Context context, String rawPhone, String name) {
        migrateExistingSchedulesOnce(context);
        String phone = MessageScheduleLogic.normalizePhone("880", "+" + rawPhone);
        if (!MessageScheduleLogic.isValidPhone(phone)) return;
        List<Entry> entries = read(context);
        String chosenName = name == null ? "" : name.trim();
        for (int i = 0; i < entries.size(); i++) {
            if (entries.get(i).phone.equals(phone)) {
                Entry previous = entries.remove(i);
                if (chosenName.isEmpty()) chosenName = previous.name;
                break;
            }
        }
        entries.add(0, new Entry(phone, chosenName, System.currentTimeMillis()));
        write(context, entries);
    }

    static synchronized void remove(Context context, String phone) {
        migrateExistingSchedulesOnce(context);
        List<Entry> entries = read(context);
        entries.removeIf(entry -> entry.phone.equals(phone));
        write(context, entries);
        // This removes recipient history only. Saved schedules remain unchanged.
    }
}
