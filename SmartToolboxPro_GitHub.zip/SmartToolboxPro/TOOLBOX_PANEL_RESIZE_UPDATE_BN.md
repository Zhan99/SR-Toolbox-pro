# SR Smart Toolbox Pro — Floating Toolbox Panel Resize

Version: **1.4.7-alpha22** (`versionCode 22`)

## কোথায় থাকবে?
Home Screen → ⋮ → **Floating Icon Settings** → **Toolbox panel size**

## নতুন Controls
- **Toolbox Width:** 220–440 dp; ডিফল্ট 292 dp।
- **Maximum Toolbox Height:** 240–760 dp; ডিফল্ট 580 dp।
- **Reset toolbox size:** আগের ডিফল্ট মান ফিরে পেতে।
- Slider ছেড়ে দিলে মান SharedPreferences-এ সংরক্ষিত হয়। পরবর্তীবার Floating Toolbox খুললে নতুন আকার পাওয়া যায়।
- Android ফোনের ছোট স্ক্রিনে প্রস্থ ও উচ্চতা স্ক্রিনের মাপ অনুযায়ী সীমাবদ্ধ থাকে। জায়গা কম হলে Quick Panel-এর ভেতরের Controls Scroll করা যায়।
- Floating Icon-এর নিজের Size Slider ও Toolbox-এর Size Slider **পৃথক**।

## আগের ফিচার
Night Screen, Thermal Monitor, Extra Volume/Equalizer, QR/Barcode Scanner, SR Video Player, Floating Swipe Animation, 3-second Quick Panel timeout, Video Library/Resume, Notification Controls এবং Themes আগের মতো রাখা হয়েছে।

## Testing
- Java-ভিত্তিক ToolboxPanelSizeTest: ১৩টি Test Pass।
- Workflow static checks, Java AST/source tests, XML parse ও ZIP integrity সম্পন্ন।
- Full Android Gradle APK Build এই পরিবেশে হয়নি (Android SDK ও Gradle অনুপস্থিত)। GitHub Actions Build ও বাস্তব ফোনে Panel Resize যাচাই করতে হবে।
