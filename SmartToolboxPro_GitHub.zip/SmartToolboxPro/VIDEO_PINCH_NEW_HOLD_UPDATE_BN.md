# SR Smart Toolbox Pro — Video Player Update 1.5.22-alpha48

## ১. দুই আঙুলে Zoom (1×–4×)
- SR Video Player-এ চলমান ভিডিওর ওপর দুই আঙুল বাইরে ছড়িয়ে **Zoom In** এবং আঙুল কাছাকাছি এনে **Zoom Out** করতে পারবেন।
- জুমের সীমা 100%–400%, অ্যাপের **Menu → Reset pinch zoom** দিয়ে 100%-এ ফেরা যায়।
- ভিডিও বদলালে Zoom স্বয়ংক্রিয়ভাবে 100%-এ ফিরে যাবে।
- TextureView-ভিত্তিক Media3 Player ব্যবহার করা হয়েছে, যাতে Zoom/Scale কার্যকর থাকে। পুরোনো Screenshot-এর জন্য TextureView Bitmap capture সমর্থন যুক্ত করা হয়েছে।
- Double Tap ±10s Seek এবং এক আঙুলে Brightness/Volume/Seek-এর Gesture অক্ষত। দুই আঙুলের Gesture এক আঙুলের Gesture হিসেবে ধরা হবে না।

## ২. নতুন Video ও Folder Red Dot / NEW
- **প্রথমবার Video Library সফলভাবে Scan** হওয়ার সময় ইনডেক্স করা ভিডিওগুলিকে পুরোনো তালিকা হিসেবে ধরা হয়।
- তার পরে ফোনের MediaStore-এ **নতুন ভিডিও যুক্ত/ডাউনলোড হলে** ভিডিওর Thumbnail-এ **● NEW** এবং সংশ্লিষ্ট Folder-এ লাল **● NEW + সংখ্যা** দেখা যাবে।
- SR Video Player-এ ওই ভিডিও সত্যিই **Play** হওয়া শুরু করলে NEW চিহ্ন মুছে যাবে; শুধু ফাইল খুলে Play না হলে এটি থাকবে।
- MediaStore ContentObserver দিয়ে Video Library খোলা থাকা অবস্থায়ও নতুন Video Detect/Refresh-এর চেষ্টা করা হয়। Library-তে ফিরে এলে আবার Scan হয়।
- NEW Status অ্যাপের SharedPreferences-এ সংরক্ষিত হয়; ফোনের অন্য Video Player-এ ভিডিও দেখা হয়েছে কি না তা জানার অনুমতি/সুবিধা নেই।
- শুধু অ্যাপের অনুমতিতে দৃশ্যমান ভিডিওগুলো দেখানো যাবে; Android-এর Partial Media Access সীমাবদ্ধতায় সব Folder দেখা নাও যেতে পারে।

## ৩. Press & Hold Fast Playback
- ভিডিও চলার সময় স্ক্রিনে **এক আঙুল চেপে ধরে থাকলে** Playback নির্বাচিত গতিতে চলবে; আঙুল তুললে আগের Playback Speed ফিরে আসবে।
- Video Player **⋮ → Hold-to-fast speed (choose ×)** থেকে **1.5×, 2×, 2.5×, 3×, 4×** বেছে নিতে পারবেন। পছন্দ সংরক্ষিত থাকবে।
- Pause/Lock/Pinch Zoom অবস্থায় Fast Mode শুরু হবে না; ভিডিও থেকে বের হলেও মূল Playback Speed ফেরানোর চেষ্টা হবে।
- এটি অস্থায়ী Playback-Speed বৃদ্ধি, সরাসরি 10-Second Seek নয়। Double Tap Seek আগের মতো আছে।

## Build ও Testing সীমাবদ্ধতা
- Java source AST/syntax, Pure Java gesture + NEW tests, XML, shell script, source ZIP integrity এবং workflow extraction যাচাই করা হয়েছে।
- Android SDK ও Gradle এই পরিবেশে নেই, তাই সম্পূর্ণ APK Build এবং বাস্তব ফোনে Touch/Media3 Video Playback/NEW detection পরীক্ষা করা সম্ভব হয়নি।

## GitHub মোবাইল Build
Repository root-এ শুধু `SmartToolboxPro_GitHub.zip` আপলোড করুন এবং `.github/workflows/build-apk.yml`-এ একই Release-এর Workflow দিন। এরপর Commit → Actions → Build SR Smart Toolbox Pro APK চালান।
