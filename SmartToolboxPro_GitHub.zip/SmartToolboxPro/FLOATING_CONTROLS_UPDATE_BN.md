# Floating Quick Controls — 1.2.8-alpha11

- Night Screen: ON/OFF এবং শুধুমাত্র Extra Darkness Slider (০–৯৫%)। ফোনের নিজস্ব Brightness Control সরানো হয়েছে।
- Thermal Monitor: ON/OFF এবং লাইভ ব্যাটারি Temperature।
- Master Volume Boost: ON/OFF, Extra Boost Gain Slider, ফোনের নিজস্ব Media Volume `−` এবং `+`।
- QR / Barcode Scanner: Open/Close।
- সব কন্ট্রোল নিজেদের কার্ডে থাকবে; নিচে আলাদা Control Section থাকবে না।
- Edge Tab-এর দিক থেকে ভেতরে সোয়াইপ করলে Bubble দেখা যাবে; Tab-এ ট্যাপ করলে Panel খুলবে।
- কাজ শেষে নির্ধারিত সময় পর Panel বন্ধ ও Bubble আগের পাশেই Auto-hide হবে।

## Version 1.4.9-alpha24
পুরোনো আলাদা Slider Box বাদ; Night Screen ও Volume Boost-এর একই রঙিন ON/OFF বারে Tap=Toggle এবং horizontal Drag=Level। Thermal-এর তাপমাত্রাও একই বারে। ছোট Toolbox-এর অতিরিক্ত অংশ বাইরে না দেখিয়ে ভেতরে Scroll।
