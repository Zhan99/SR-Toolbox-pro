# SR Smart Toolbox Pro — v1.5.12-alpha38

## অ্যাপ খোলার সময় Branding Animation
- App Launcher থেকে চালু করলে প্রায় ১.৮৫ সেকেন্ডের হালকা অ্যানিমেশন দেখাবে।
- Launcher Icon, **SR CREATION FARM**, **SR Smart Toolbox Pro**, **Created by Shahriar Rahman**, YouTube **@SRCreation-farm**, Facebook **fb.com/srcreation.farm** এবং Copyright/Version দেখাবে।
- Fade + Zoom + Slide Animation। স্ক্রিনে Tap করলে দ্রুত Main App খুলবে।
- কোনো নতুন Permission বা আলাদা Settings লাগবে না।
- Home Screen-এ আগের Branding ও About Developer বজায় থাকবে।

## Group/Broadcast Schedule: এক Group Card
- নির্ধারিত গ্রুপের সব সদস্য আর ২০টি আলাদা কার্ড হিসেবে দেখাবে না। একটি **Group Card**-এ Group Name, সব নাম/নম্বর, মেসেজ, Schedule Date/Time, Repeat এবং প্রত্যেকের Status দেখাবে।
- **Today / Tomorrow / Upcoming / History / Paused** ফোল্ডারে একটি Group Card-ই গণনা করা হবে।
- একটি গ্রুপের কারও মেসেজ Pending ও কারও Attempted হলেও কার্ডটি দুই জায়গায় ভাগ হবে না। Pending সদস্য থাকলে প্রাসঙ্গিক সময়ের ফোল্ডারেই থাকবে।
- সদস্যের নম্বরে চাপলে ওই প্রাপকের WhatsApp Chat খুলবে।
- **Edit / Reuse Group**: পুরোনো শিডিউল/History রেখে নম্বর ও মেসেজ নতুন শিডিউলে এডিট করার জন্য কপি করবে; স্বয়ংক্রিয়ভাবে আগের গ্রুপে পরিবর্তন করবে না।
- **Delete Group**: কনফার্মেশন নিয়ে ওই গ্রুপের সব সদস্যের Saved Schedule ও Alarm বাতিল করবে।
- Send Attempt-কে Delivered বলা হবে না; প্রত্যেক সদস্যের প্রকৃত Status আলাদা থাকবে।
- এটি শুধু UI-তে গ্রুপ প্রদর্শনের পরিবর্তন। WhatsApp-এর আলাদা ব্যক্তিগত Chat-এ Send Attempt ধারাবাহিকভাবে হয়; সত্যিকারের WhatsApp Group Chat বা সবার কাছে একযোগে Delivery নয়।

## পরীক্ষা ও সীমাবদ্ধতা
- Java AST/Syntax + duplicate field scan: ৬২টি Source PASS।
- Group Card Logic: ২২টি Assertion PASS।
- GitHub Workflow Source/Java Test Steps: ২৬টি PASS।
- ৬টি Android XML Parse, GitHub YAML Parse এবং Bash Syntax: PASS।
- GitHub Source ZIP Extract করে নতুন Group Test: PASS (প্যাকেজের সময়)।
- এই পরিবেশে Android SDK/Gradle নেই: **পূর্ণ :app:assembleDebug চালানো হয়নি**, তাই GitHub Build ও ফোনে বাস্তব UI পরীক্ষা বাকি।
