# SR Smart Toolbox Pro — GitHub Build Branding Verification Fix

**Version:** 1.4.9-alpha24 (অ্যাপ কোড অপরিবর্তিত; শুধু GitHub Actions Workflow-তে সংশোধন)।

## স্ক্রিনশটের সমস্যার ব্যাখ্যা
GitHub Actions-এ `Verify SR branding and developer profile` ধাপটি `exit code 1` দিয়ে থেমেছে।
স্ক্রিনশটে শুধু এই ধাপের ফলাফল আছে, তাই কোন একটি `grep -q` বা `test -f` ব্যর্থ হয়েছে তা **সেখান থেকে নিশ্চিত করা যায় না**।
আগের Workflow-তে `versionCode 24` এবং `versionName '1.4.9-alpha24'` হুবহু মেলানোর শর্তও ছিল।
মোবাইল থেকে Source ZIP ও Workflow আলাদাভাবে আপলোড করার কারণে পুরোনো ZIP থাকলে এই ধাপটি ব্যর্থ হতে পারে।

## সংশোধন
- `AboutDeveloperActivity.java`, App Icon, App Name, About Page, YouTube, Facebook এবং `applicationId`-এর পরীক্ষা বজায় রাখা হয়েছে।
- Branding যাচাই এখন প্রতিটি সফল ফাইল/তথ্যের নাম দেখাবে। কোনোটি না থাকলে `::error` দিয়ে কোন ফাইল বা তথ্য নেই তা দেখাবে।
- `versionCode 24` ও `versionName '1.4.9-alpha24'`-এর মতো Release-নির্ভর hard-coded শর্ত তুলে দেওয়া হয়েছে। Version তথ্যের গঠন যাচাই হয়।
- Theme/Folder-এর যাচাই থেকেও একই hard-coded version শর্ত সরানো হয়েছে।
- অন্যান্য সোর্স যাচাইয়ের ধাপগুলোর ব্যর্থ কমান্ড দেখানোর ব্যবস্থা যোগ হয়েছে।
- অ্যাপের Java সোর্স, XML, Manifest, Gradle configuration ও আগের সব ফিচার **অপরিবর্তিত** রাখা হয়েছে।

## GitHub মোবাইলে আপডেট করার নিয়ম
1. Repository-এর root থেকে পুরোনো `SmartToolboxPro_GitHub.zip` ফাইলটি বদলে এই রিলিজের নতুন ZIP আপলোড করুন।
2. Repository-এর `.github/workflows/build-apk.yml` ফাইলটিতে এই রিলিজের `build-apk.yml`-এর সম্পূর্ণ কনটেন্ট প্রতিস্থাপন করুন।
3. ZIP ও Workflow **দুটোই একই রিলিজের** রাখবেন। Repository-তে দ্বিতীয় Android source ZIP থাকলে সরান, নয়তো multiple-source error হতে পারে।
4. Commit Changes -> Actions -> নতুন `Build SR Smart Toolbox Pro APK` রান খুলুন।
5. Branding ধাপ ব্যর্থ হলে তার `::error` মেসেজ দেখুন। Build ব্যর্থ হলে প্রথম **প্রকৃত compiler error** (`.java:<line>: error:`) পাঠান।
6. Build সফল হলে `SR-Smart-Toolbox-Pro-debug-apk` Artifact থেকে APK ডাউনলোড করুন।

## পরীক্ষার সীমা
এখানে **১৬টি** উপলভ্য GitHub Source/Unit ধাপ, YAML ও Bash syntax, ZIP extraction, XML ও Manifest tests সফল হয়েছে।
তবে স্থানীয় পরিবেশে Android SDK ও Gradle নেই। তাই `:app:assembleDebug` চালিয়ে APK Build সফল হয়েছে বলে দাবি করা হচ্ছে না।
