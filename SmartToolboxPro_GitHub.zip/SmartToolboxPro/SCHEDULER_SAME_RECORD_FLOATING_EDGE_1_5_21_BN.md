# SR Smart Toolbox Pro — 1.5.21-alpha47 (versionCode 47)

## ১. WhatsApp Scheduler: আজকের মেসেজ ও ক্যালেন্ডার আলাদাভাবে Hide / Show
- **📬 আজকের মেসেজ** শিরোনামের ডান পাশে `▴ Hide` / `▾ Show` বাটন।
- **🗓️ ক্যালেন্ডার** শিরোনামের ডান পাশে আলাদা `▴ Hide` / `▾ Show` বাটন।
- একটির বাটন চাপলে অন্যটি লুকাবে না; দুটি পছন্দই Settings-এ (SharedPreferences) আলাদাভাবে সংরক্ষিত হবে।
- ক্যালেন্ডারের ডট, আগের/পরের তারিখের বার্তা এবং আজকের Group Card আগের মতো থাকবে।
- Hide/Show করা শুধু UI পরিবর্তন; কোনো সংরক্ষিত রেকর্ড/Alarm মুছে যায় না।

## ২. Edit -> Save Changes: একটি মেসেজ শুধু একটি রেকর্ড
- Single Message-এর **Edit & Save Changes (same message)** দিলে আগের ID দিয়েই আপডেট হবে।
- Group Card-এর **Edit Group**-এ একই Group ID ব্যবহার হবে; সদস্যদের আগের ফোন নম্বর অপরিবর্তিত থাকলে তাদের Schedule ID এবং Alarm ID একই থাকবে।
- গ্রুপ থেকে নম্বর বাদ দিলে সেই সদস্যের Alarm বাতিল হবে; নতুন নম্বর যোগ করলে কেবল নতুন প্রাপকের জন্য Record ও Alarm তৈরি হবে। কোনো নতুন Group Card তৈরি হবে না।
- Edit ফর্মের Save বাটনের লেখা হবে **Save Changes**; সাধারণ নতুন মেসেজে আগের **Schedule message** লেখা থাকবে।
- পুরোনো তারিখ Edit করলে আগের ঘণ্টা-মিনিট রেখে নিকটতম ভবিষ্যতের উপযুক্ত তারিখ নির্বাচন হবে; চাইলে সময়/তারিখ ম্যানুয়ালি পাল্টাতে পারবে।
- ইতোমধ্যে Attempted/Done/Due হওয়া Record-ও Edit করলে একই Record পুনরায় Pending হবে এবং আগের Send Status ও Trigger Time রিসেট হবে। **এটি অতীতে পাঠানোর প্রমাণ সংরক্ষণ করে না**—ব্যবহারকারী একই রেকর্ড নতুন করে শিডিউল করার সিদ্ধান্ত নিচ্ছেন। পূর্বের History সংরক্ষণ জরুরি হলে আগে লিখে/এক্সপোর্ট করে রাখতে হবে।
- নতুন Message বা Group না বানানোর জন্য Edit-এর সময় ভুল করে Single/Group মোড পাল্টানো এবং Test-trigger চালানোর ক্ষেত্রে সতর্কতা যুক্ত হয়েছে।
- Android AlarmManager-এর পুরোনো PendingIntent Cancel করে সংশোধিত সময়ের Alarm সেট করার চেষ্টা করে। Exact Alarm অনুমতি না থাকলে Android দেরি করতে পারে।

## ৩. Floating Bar: পাশ ও উচ্চতা মনে রাখবে
- Edge Bar ২ সেকেন্ড Hold করে বাম/ডান পাশে বা ওপর-নিচে সরালে নতুন **পাশ** এবং **উচ্চতার অনুপাত** সংরক্ষিত হবে।
- Portrait থেকে Landscape বা উল্টো হলে বর্তমান স্ক্রিনের উচ্চতার অনুপাতে একই নির্বাচিত উচ্চতায় এবং **একই বাম/ডান পাশে** থাকবে।
- Auto-hide, Tap/Swipe, Vibration এবং Quick Controls আগের মতো।
- আপনি নিজে পরবর্তীবার Hold-to-Move না করা পর্যন্ত স্বয়ংক্রিয় Orientation Change আর নির্বাচিত পাশ বদলাবে না।
- একেবারে আগের ডিফল্ট অবস্থায় নিতে Floating Icon Settings-এ Reset Icon অপশন আগের মতো আছে।

## পরীক্ষা ও সীমাবদ্ধতা
- Java AST/source checks এবং নতুন In-place Edit / Edge Geometry pure Java Test চালানো হয়েছে।
- **সম্পূর্ণ Gradle assembleDebug এবং বাস্তব Android ডিভাইসে অটোমেশন/Rotation পরীক্ষা এখানে করা হয়নি।** GitHub Actions Build এবং বাস্তব ফোনে পরীক্ষা জরুরি।
