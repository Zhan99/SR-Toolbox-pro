# SR Smart Toolbox Pro — 1.4.5-alpha20

## এই আপডেটে সংশোধিত Build Error
GitHub Build log-এ `VideoLibraryActivity.java` এর `:app:compileDebugJavaWithJavac` ব্যর্থ হয়েছিল। স্ক্রিনশটে একাধিক জায়গায় `cannot find symbol` — `status` ও `adapter` দেখা যাচ্ছিল। মূল ক্লাসে এদের declaration ছিল না। এখন ঠিকঠাক ক্লাস-ফিল্ড হিসেবে যুক্ত করা হয়েছে:

```java
private VideoAdapter adapter;
private TextView status;
```

নতুন `VideoLibrarySourceFieldsTest` JDK Java Compiler AST দিয়ে এই ছয়টি প্রয়োজনীয় ক্লাস-ফিল্ড যাচাই করে। `JavaSourceSyntaxTest` SDK ছাড়াই সব Java সোর্সের syntax ও duplicate class-field পরীক্ষা করে। এই পরীক্ষাগুলো GitHub Actions-এ APK Build-এর আগে চলবে।

## Floating Icon Animation
- বাম প্রান্তের চিকন Tab থেকে ডানে Swipe করলে ST Icon স্লাইড ও Fade/Scale Animation দিয়ে ভেতরে আসবে।
- ডান প্রান্ত থেকে বাঁয়ে Swipe করলেও একইভাবে পাশ থেকে বের হবে।
- Icon-এর Animation শেষ হলে Quick Control Panel মৃদু স্লাইড/ফেড হয়ে খুলবে।
- Icon reveal সময় **270ms**, Panel reveal সময় **200ms**।
- আগে নির্ধারিত **৩ সেকেন্ডে Quick Panel auto-close**, বাইরের জায়গায় Tap করলে তাৎক্ষণিক close এবং Bubble Auto-hide (সেটিংস অনুযায়ী) অক্ষত আছে।
- Animation চলাকালে Service বন্ধ/রিফ্রেশ হলে callback cancel করে View release করার ব্যবস্থা আছে।

## আগের ফিচার সংরক্ষিত
- SR Video Player, folder-first library, প্রত্যেক ভিডিওর resume point।
- ৫টি Theme Settings, ⋮ Menu, Floating volume controls।
- Night Screen, Extra Volume & Equalizer, Temperature Monitor, QR/Barcode Scanner, Notification Controls, Shahriar Rahman / SR Creation Farm Branding।

## Verification
- ২৭টি Java সোর্স JDK compiler AST parser: PASS (syntax/duplicate-fields)।
- VideoLibrary field declaration AST: ৬টি PASS।
- Floating BubbleSlideLogic: ৮টি PASS।
- Existing EdgeSwipeLogic: ৯টি PASS।
- VideoPlayerLogic: ১৩টি PASS।
- VideoResumeLogic: ১২টি PASS।
- VideoFolderLogic: ৮টি PASS; ThemePalette tests: PASS।
- GitHub Actions local verification steps এবং YAML/Bash: PASS।
- Android XML: PASS।
- ZIP integrity: PASS (packaging step)।

**সীমা:** এখানে Android SDK ও Gradle নেই; প্রকৃত Android APK Compile, Overlay Animation ও ফোনে পরীক্ষা হয়নি। GitHub Actions-এ `:app:assembleDebug` সফল হওয়া এবং ফোনে ব্যবহার করে পরীক্ষা করা প্রয়োজন।
