## আপডেট 1.5.18-alpha44
1. নতুন `SmartToolboxPro_GitHub.zip` **ও একই release-এর** `build-apk.yml` একসঙ্গে GitHub-এ Replace করুন।
2. Build সফল হলে Settings → Floating Icon Settings → **Swipe Vibration** পরীক্ষা করুন।
3. Home ⋮ → Full Charge Voice Alert → **বাংলা / English / বাংলা+English** নির্বাচন করে **Preview** শুনুন।
4. Android 13+ এ Notification Permission প্রয়োজন হতে পারে। Background Battery Monitoring চালু রাখলে Notification দেখা যাবে।
5. Swipe সফল হলে কম্পন; Tap বা Hold-to-Drag-এ নয়। System Haptics বন্ধ থাকলে কম্পন বন্ধ থাকতে পারে।
6. APK Build/Install ও বাস্তব ফোনে Voice/TTS/Swipe পরীক্ষা করতে হবে; কেবল Java Logic Test ডিভাইস আচরণ নিশ্চিত করে না।

# GitHub Mobile Build — SR Smart Toolbox Pro 1.5.18-alpha44

১. GitHub Repository Root-এর পুরোনো `SmartToolboxPro_GitHub.zip` নতুন Source ZIP দিয়ে **Replace** করুন।
২. `.github/workflows/build-apk.yml`-এ এই release-এর `build-apk.yml` দিন। দুটো ফাইল অবশ্যই একই release থেকে হবে।
৩. **Commit Changes → Actions → Build SR Smart Toolbox Pro APK** চালান।
৪. সফল হলে `SR-Smart-Toolbox-Pro-debug-apk` Artifact থেকে APK পাবেন।
৫. অ্যাপে Calendar-এর ডট, Same Time Edit/Reuse ও বর্ডারের Floating Icon ফোনে পরীক্ষা করুন।
৬. APK Build না হলে Actions-এর `Build debug APK` Log অথবা প্রথম Java Error পাঠান।

## আপডেট: 1.5.14-alpha40 (Apps Backup & Restore)
1. Repository Root-এ **শুধুমাত্র নতুন** `SmartToolboxPro_GitHub.zip` আপলোড করুন। পুরোনো Source ZIP থাকলে Replace/Remove করুন।
2. **`.github/workflows/build-apk.yml`** পাথের Workflow-টি নতুন `build-apk.yml` দিয়ে Replace করুন।
3. Commit করে **Actions → Build SR Smart Toolbox Pro APK** চালান।
4. `SR-Smart-Toolbox-Pro-debug-apk` Artifact থেকে `app-debug.apk` নিন।
5. Apps Backup-এর ইনস্টল/Restore কার্যকারিতা ফোনে নিজে Test করুন। Split Apps-এর জন্য Archived → Restore ব্যবহার করুন।
6. `SR-Smart-Toolbox-Pro-lint-report` তৈরি হলে রিপোর্ট দেখুন। Build বা Lint-এ সমস্যা থাকলে সেই Error Log দিন।

**বিশেষ নোট:** `SR_Apps_Backup_Restore.zip`-এর স্বতন্ত্র `build.yml` দিয়ে একীভূত Toolbox তৈরি হবে না। এখানে দেওয়া `build-apk.yml` ব্যবহার করবেন।

# GitHub Mobile Build — SR Smart Toolbox Pro 1.5.13-alpha39

এই আপডেটের জন্য **SmartToolboxPro_GitHub.zip** এবং **.github/workflows/build-apk.yml** দুটি একই Release থেকে আপলোড করুন।
App Launcher-এ Branding Animation, Scheduler Group Card-এ সব নম্বর একসঙ্গে থাকবে।
Android SDK / Gradle এখানে নেই, তাই GitHub Actions Build এবং ফোনে UI পরীক্ষা প্রয়োজন।

# GitHub Mobile Build — SR Smart Toolbox Pro 1.5.10-alpha36

1. Repository root-এর পুরোনো `SmartToolboxPro_GitHub.zip` নতুন ZIP দিয়ে Replace করো।
2. Repository-এর `.github/workflows/build-apk.yml` ফাইলটি নতুন `build-apk.yml` দিয়ে Replace করো।
3. Commit Changes → Actions → `Build SR Smart Toolbox Pro APK` চালাও।
4. Build সফল হলে `SR-Smart-Toolbox-Pro-debug-apk` Artifact ডাউনলোড করো।
5. ব্যর্থ হলে `Build debug APK` অথবা `Print Java compiler errors (if build fails)`-এ প্রথম `.java:line: error` পাঠাও।

**শুধু `build-apk.yml` আপডেট করলেই নতুন Accessibility Service আসবে না।** নতুন Source ZIP-ও লাগবে।
**Android SDK/Gradle এই পরিবেশে নেই।** পূর্ণ APK Build GitHub Actions-এ করতে হবে।

## Experimental automation চালু করতে
1. অ্যাপ → WhatsApp Smart Scheduler → ⋮ → Alarm, Notification & Automation Settings → Experimental Auto-Send & Unlock (ডিফল্ট OFF)।
2. Accessibility Service ম্যানুয়ালি চালু করো; Overlay, Alarm ও Notification permission দাও।
3. Locked PIN Attempt চাইলে আগে PIN encrypted storage-এ Save করে আলাদা toggle ON করো।
4. নিজের নম্বরে পরীক্ষা করো। Android/WhatsApp restriction-এর কারণে ফলাফল নিশ্চয়তাপূর্ণ নয়।

### নতুন UI
Recent Recipient History-এর +/−, Quick Templates, 10s Test এবং শিডিউলের Remaining Time-এর তথ্য `SMART_SCHEDULER_UI_UPDATE_BN.md`-এ আছে।

## Update 1.5.4-alpha30
Repository-তে `SmartToolboxPro_GitHub.zip` ও `.github/workflows/build-apk.yml` একই release থেকে Replace করুন। Actions সফল হলে APK Artifact ডাউনলোড করুন।
Screen ON-এর 3→2→1 Reminder দেখাতে Display Over Other Apps Permission এবং Accessibility Service চালু প্রয়োজন। Restore App Android-এর Task Back Stack অনুযায়ী best-effort।

## Update 1.5.4-alpha30 — Template, Group Message & Theme Studio
- Scheduler-এ ⋮ → Manage / Add Quick Templates থেকে built-in বা custom template Add, Edit, Delete করা যাবে।
- Single Message এবং Group / Broadcast mode আলাদা। Group mode-এ Contacts থেকে একাধিক নম্বর বেছে নেওয়া বা comma/semicolon/new line দিয়ে নম্বর দেওয়া যাবে।
- Group mode সর্বোচ্চ ২০ জনকে একই মেসেজ আলাদা WhatsApp chat-এ পাঠানোর শিডিউল করে; সবার নির্ধারিত সময় একই; আলাদা চ্যাটে Send চেষ্টা পর্যায়ক্রমে। এটি WhatsApp group chat নয়।
- প্রথমবার Select many চাপলে Contacts permission চাইবে।
- Theme Settings-এ ৯টি palette এবং System / Light / Dark appearance mode আছে।
- Source ZIP এবং workflow একই release থেকে Replace করতে হবে।

## Compile fix — 1.5.4-alpha30
`MessageSchedulerActivity.java`-এর missing `SchedulerDisplayLogic.messagePreview(String, int)` method যোগ করা হয়েছে। এই fix-এর জন্য Source ZIP এবং workflow দুটোই নতুন release থেকে Replace করতে হবে। Build-এর পূর্ণ ফলাফল Actions-এ যাচাই করো।

## Update 1.5.5-alpha31 — Group Name / Contacts / History
- **From Contacts** দিয়ে ১ জন; **Select many Contacts** দিয়ে সর্বোচ্চ ২০ জন যোগ করা যায়। একাধিক Contacts পড়তে READ_CONTACTS অনুমতি দিতে হবে।
- **Group Name** ব্যাচ চিহ্নিত করার নাম, নতুন WhatsApp Group তৈরি নয়। সব প্রাপকের due-time একই।
- আগের ৬০ সেকেন্ড ইচ্ছাকৃত Interval নেই; WhatsApp UI একসঙ্গে একাধিক chat চালাতে পারে না, তাই Automation queue-তে একে একে Send চেষ্টা করবে।
- আগের History থেকে **Edit message & schedule again** করলে পুরোনো History না পাল্টিয়ে নতুন Schedule তৈরি হবে।
- GitHub Actions থেকে APK Build সফল হয়েছে কি না যাচাই করে তারপর ইনস্টল করুন।

## Update 1.5.6-alpha32 — Scheduler Inbox Folders
- নতুন `SmartToolboxPro_GitHub.zip` এবং `build-apk.yml` একই release থেকে আপলোড করুন।
- আজ/আগামীকাল/পরবর্তী/History/Paused ফোল্ডারে শিডিউল সাজানো থাকবে; আগে সেভ করা মেসেজ মুছে যাবে না।
- নতুন GitHub Workflow-এ `Verify collapsible scheduler inbox sections and local-date grouping` Test আছে।

## Update 1.5.7-alpha33 — Notepad ও Portrait Video Edge
- পুরোনো `SmartToolboxPro_GitHub.zip` সম্পূর্ণ Replace করুন, সঙ্গে `.github/workflows/build-apk.yml`-ও এই release-এরটি দিয়ে Replace করুন।
- Auto Scheduler → ⋮ → Scheduler Notepad অথবা Message Input-এর নিচে **Notepad থেকে মেসেজ নিন**।
- Floating Icon Settings → **Portrait video-তে floating icon কিনারায় রাখুন**।
- ভিডিও চলা শুরু করলে Portrait-এ Edge Tab; ভিডিও Pause/Exit করলে আগের অবস্থান। Android Overlay Permission প্রয়োজন।
- GitHub Actions-এ `Verify scheduler notepad and portrait video edge` এবং `Build debug APK` দুটোই PASS হয়েছে কি না পরীক্ষা করুন।

## v1.5.8-alpha34 — All Apps Portrait Edge
1. GitHub root-এ একই Release থেকে `SmartToolboxPro_GitHub.zip` Replace করুন।
2. `.github/workflows/build-apk.yml` Replace করুন।
3. Actions → Build SR Smart Toolbox Pro APK চালান।
4. APK ইনস্টল → Floating Icon Settings → **Portrait Edge — ALL apps** ON। Display over other apps Permission চালু রাখতে হবে।
5. YouTube, Gallery, অন্য Player ও Home Screen-এ Portrait/Landscape ঘুরিয়ে পরীক্ষা করুন।

Android/OEM Overlay Restriction ও Lock Screen-এ Edge Tab সবসময় দৃশ্যমান নাও থাকতে পারে।

## Update 1.5.9-alpha35 — Floating Bar Swipe Menu
Repository root-এ নতুন `SmartToolboxPro_GitHub.zip` ও `.github/workflows/build-apk.yml` একই release থেকে Replace করুন। Actions-এ `Verify floating bar swipe opens controls in Home and other apps` এবং `Build debug APK` পরীক্ষার ফলাফল দেখুন।
ফোনে Home, YouTube, অন্য অ্যাপের ওপর Edge Tab-এ Tap, ভিতরের দিকে Swipe ও উপর/নিচে Slide করে দেখুন। Android Gesture Navigation বা Protected Window Overlay বন্ধ করতে পারে।

## Update 1.5.10-alpha36 — Night Screen Minimum Brightness
- `SmartToolboxPro_GitHub.zip` এবং `build-apk.yml` দুটোই একই Release থেকে Replace করুন।
- Night Screen-এর Black Overlay-এর জন্য Display over other apps অনুমতি; Physical Brightness কমাতে আলাদা Modify system settings অনুমতি দিন।
- System Brightness documented minimum 1/255 (০ নয়)। Night Screen OFF করলে আগের Brightness ও Auto Mode ফিরবে, যদি অন্য কেউ সেটা ইতোমধ্যে পরিবর্তন না করে থাকে।
- GitHub Actions-এ `Verify minimum-brightness Night Screen and restore-safety regression` Test যোগ হয়েছে।

## Update 1.5.11-alpha37
- Repo-তে নতুন `SmartToolboxPro_GitHub.zip` আপলোড/Replace করুন।
- `.github/workflows/build-apk.yml` ফাইলে নতুন দেওয়া `build-apk.yml` আপলোড/Replace করুন।
- Actions-এ Android APK Build চালান। GitHub Source ZIP ও YAML অবশ্যই একই Release-এর হতে হবে।
- APK-তে Floating Icon Settings → Tap to Open / Swipe to Open দুটি আলাদা অপশন পাবেন। Hold 2 Seconds then Drag দিয়ে বড় আইকন বা Edge Bar নড়ানো যাবে।

## Update 1.5.13-alpha39 — Premium UI + Sound
- `SmartToolboxPro_GitHub.zip` এবং `.github/workflows/build-apk.yml` অবশ্যই এই একই Release থেকে আপলোড করুন।
- `Theme Settings → Premium / Classic` দিয়ে দুই ধরনের UI বেছে নিন।
- `Theme Settings → UI Animation & Sound` থেকে Sound Style এবং Sound ON/OFF, Animation ON/OFF পাওয়া যাবে।
- নতুন Logo ও ১৬টি WAV সোর্স ZIP-এর `app/src/main/res`-এ আছে।
- GitHub Actions-এ APK Build সফল হলে ইনস্টল করে বিভিন্ন স্ক্রিন পরীক্ষা করুন।

## v1.5.15-alpha41 — Battery 100% Bengali Voice Alert
- একই রিলিজের `SmartToolboxPro_GitHub.zip` ও `build-apk.yml` Replace করুন।
- নতুন Full Charge Alert-এর Offline Bengali WAV ও Java Test Source ZIP-এ আছে।
- Apps Backup/Scheduler/Video Player/Floating Toolbox-এর পুরোনো Source/Workflow Test বজায় আছে।
- GitHub Actions → Build SR Smart Toolbox Pro APK → Run workflow; সফল হলে Artifacts থেকে APK নিন।

## 1.5.17-alpha43 — Apps Backup Folder ও Central Permissions
- Android 10+: `Download/App Backup/` স্বয়ংক্রিয়ভাবে প্রথম ব্যাকআপে তৈরি হয়। Split ফাইল `Split backups/`-এ।
- Android 8–9: ফোল্ডার-পিকার একবার ব্যবহার করতে হবে। Custom Folder-এ `App Backup` নিজে তৈরি হবে।
- `Home → ⋮ → App Permissions (সব অনুমতি)` স্ক্রিনে ফিচার অনুযায়ী অনুমতি সাজানো।
- Main Home-এর Creator পরিচিতির বড় Card সরানো হয়েছে, About Developer আলাদা মেনুতে আছে।
- গিটহাবে একই আপডেটের Source ZIP + `.github/workflows/build-apk.yml` আপলোড করুন।
