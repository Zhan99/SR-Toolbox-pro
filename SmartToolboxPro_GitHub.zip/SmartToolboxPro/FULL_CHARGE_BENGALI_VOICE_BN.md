# 🔋 SR Smart Toolbox Pro — Full Charge Bengali Voice Alert

**Version: 1.5.15-alpha41 (versionCode 41)**

## নতুন ফিচার

**Home → ⋮ Three-Dot Menu → 🔋 Full Charge বাংলা Voice Alert** থেকে ফিচারটি খুলুন।

- **Full Charge Voice Alert ON/OFF:** ডিফল্ট বন্ধ। একবার ON করলে ব্যাটারি মনিটরিং চালু থাকবে।
- **Battery Status:** বর্তমান ব্যাটারির শতাংশ ও চার্জার সংযুক্ত থাকার অবস্থা দেখাবে।
- **▶ বাংলা ভয়েস শুনে দেখুন:** বাংলায় প্রি-রেকর্ড করা সতর্কবার্তা বাজাবে।
- ফোন চার্জে থাকা অবস্থায় ১০০% হলে **একবার** বলবে: **“ব্যাটারি ফুল চার্জ হয়েছে, চার্জ থেকে খুলুন।”**
- একই চার্জিং সেশনে পরপর BATTERY_CHANGED Broadcast এলেও পুনরাবৃত্তি হবে না।
- চার্জার খুললে Reset হবে; আবার চার্জ দিলে পরবর্তী পূর্ণ চার্জে নতুন করে সতর্ক করবে।
- ১০০% হলে Notification-ও দেখাবে। ওই সেবার স্থায়ী Notification থেকে **বন্ধ করুন** চাপলে মনিটরিং বন্ধ হবে।
- আগের SR Creation Farm Branding, Premium/Classic Design, UI Sound ON/OFF, Apps Backup, Scheduler, Video Player, Floating Icon, Night Screen ও অন্যান্য ফিচার সংরক্ষিত আছে।

## সাউন্ড ও অফলাইন সুবিধা

অ্যাপের মধ্যে ৪.৭ সেকেন্ডের একটি **অফলাইন বাংলা সিন্থেসাইজড ভয়েস** (`battery_full_bengali.wav`) দেওয়া আছে। এই ভয়েস বাজাতে ইন্টারনেট বা বাংলা Text-to-Speech প্যাক লাগবে না। এটি ফোনের **Alarm Volume**, Do Not Disturb ও অন্যান্য Audio Policy-এর সীমাবদ্ধতার অধীনে চলবে। অন্য Premium UI Sound Settings থেকে এটি **আলাদাভাবে** ON/OFF করা যাবে।

## ব্যাকগ্রাউন্ডে কাজ করার সীমা

ফিচারটি চালু থাকলে ব্যবহারকারীর অনুমতি নিয়ে একটি **Foreground Service** ও স্থায়ী Notification চলে। `ACTION_BATTERY_CHANGED` Android-এর নিয়ম অনুযায়ী **dynamic receiver** দিয়ে শুনতে হয়; AndroidManifest-এ শুধু এই ইভেন্ট দিয়ে ব্যাটারি স্তর পাওয়া যায় না।

ফোন রিস্টার্ট বা অ্যাপ আপডেটের পরে আগের ON সেটিং থাকলে মনিটরিং পুনরায় চালুর চেষ্টা হবে। তবে Force Stop, কিছু OEM Battery Optimization/Background Restriction, Notification Permission, Android Foreground Service নিষেধাজ্ঞা বা ফোন বন্ধ থাকার সময় সাথে সাথে সতর্ক করার **নিশ্চয়তা নেই**। ফোনের নিজস্ব ব্যাটারি ব্যবস্থার ওপর নির্ভর করবে।

- Android 13+ এ **Notifications** Permission দিলে মনিটরিং ও Full Charge Notification দেখা সহজ হয়।
- Always-on monitoring আপনার ফোনে সামান্য বাড়তি ব্যাটারি/সিস্টেম রিসোর্স ব্যবহার করতে পারে।
- এটি চার্জার নিজে খুলে দিতে বা চার্জ থামাতে পারে না; **সতর্ক করে** মাত্র।
- অ্যাপ ইনস্টল করার পর Settings-এ একবার ON করুন; কোনো Root/Accessibility Permission লাগে না।

## GitHub Build

মূল `SmartToolboxPro_GitHub.zip` এবং `.github/workflows/build-apk.yml` একই `1.5.15-alpha41` রিলিজ থেকে আপলোড করুন। GitHub Actions-এ `Build SR Smart Toolbox Pro APK` চালিয়ে APK তৈরি করুন।

## যাচাই

- FullChargeAlertLogic: ২৯টি Pure-Java Test পাস।
- নতুন WAV: mono PCM, 22050 Hz, প্রায় ৪.৭ সেকেন্ড; WAV Format পরীক্ষা পাস।
- মোট ২৯টি স্থানীয় GitHub Workflow Source/Logic Test পাস।
- Java AST, XML Parse, Shell Syntax, ZIP Integrity ও ZIP-only Workflow Extraction পরীক্ষা হয়েছে।
- **এখানে পূর্ণ Android Gradle APK Build ও বাস্তব ফোনে Voice পরীক্ষা চালানো সম্ভব হয়নি।** GitHub Actions এবং বাস্তব ফোনে পরীক্ষা প্রয়োজন।
