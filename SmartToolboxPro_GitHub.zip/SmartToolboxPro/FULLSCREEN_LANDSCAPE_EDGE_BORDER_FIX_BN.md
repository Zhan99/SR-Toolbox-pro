# SR Smart Toolbox Pro — Landscape Fullscreen Border Fix

**সংস্করণ:** 1.5.25-alpha51  
**সমস্যা:** ভিডিও ফুলস্ক্রিন করে Portrait থেকে Landscape-এ ঘোরালে ছোট লম্বালম্বি Floating Bar ডান দিকের আসল বর্ডার থেকে কিছুটা ভেতরে চলে আসছিল।

## কারণ ও সংশোধন

আগে `FloatingControlService` ব্যবহারযোগ্য App Display-এর `getMetrics().widthPixels - barWidth` দিয়ে ডান দিকের X পজিশন হিসাব করত। Immersive/Fullscreen ভিডিওতে এই ব্যবহারযোগ্য প্রস্থ বাস্তব উইন্ডোর প্রস্থের চেয়ে ছোট হতে পারে।

এখন WindowManager-এর `Gravity.RIGHT` অথবা `Gravity.LEFT` দিয়ে সরাসরি বর্ডারে Anchoring করা হয় এবং Horizontal Offset সবসময় **0**। শুধু বারটির উচ্চতার অবস্থান ও Drag-এর পাশ শনাক্ত করতে Full Display-এর `getRealMetrics()` ব্যবহার হয়। Notch/Cutout যুক্ত Landscape ডিসপ্লেতে Short-Edge Cutout Mode ব্যবহার করা হয় যেখানে Android সমর্থন করে।

## যেসব ফিচার সংরক্ষিত আছে

- Auto-Hide শেষে সরু Vertical Edge Bar
- বাম/ডান যে পাশে ব্যবহারকারী শেষবার রেখেছেন সেই পাশ
- Portrait/Landscape এ একই আনুপাতিক উচ্চতা
- ২ সেকেন্ড Hold করে ভাইব্রেশনসহ Drag
- Swipe-only Open, আশপাশে Tap Pass-through-এর জন্য সরু Touch Area
- Sound/Vibration ON/OFF; WhatsApp Scheduler, Apps Backup, QR Scanner, Night Screen, Battery Voice Alert এবং অন্যান্য ফিচার
- সরানো Video Player পুনরায় যুক্ত করা হয়নি। স্ক্রিনশটে অন্য অ্যাপের ভিডিওর ওপর Floating Bar দেখা যাচ্ছে।

## পরীক্ষা ও সীমাবদ্ধতা

- `python3 tests/verify_fullscreen_edge_anchor.py` — ২৪টি Source Regression Check
- বিদ্যমান Java Unit/Source Test এবং GitHub Workflow-এর স্থানীয় যাচাই
- APK Build এবং বাস্তব ডিভাইসে YouTube/অন্য ভিডিও অ্যাপের Fullscreen Rotation পরীক্ষা করার জন্য Android SDK বা ফোন প্রয়োজন; এই পরিবেশে সেগুলো চালানো সম্ভব হয়নি।
- কিছু OEM/Android সিস্টেম Gesture Navigation Bar, System Cutout ও Security Policy অনুসারে Overlay-এর নিরাপদ জায়গা সীমিত করতে পারে।

## GitHub আপডেট

Repository Root-এ `SmartToolboxPro_GitHub.zip` Replace এবং `.github/workflows/build-apk.yml` Replace করো। এরপর GitHub Actions থেকে Build চালাও।
