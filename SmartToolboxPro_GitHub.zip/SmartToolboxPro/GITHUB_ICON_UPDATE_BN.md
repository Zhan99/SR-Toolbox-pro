# GitHub-এ নতুন আইকনসহ APK তৈরি করুন

**Version: `1.5.16-alpha42`**

নতুন `SmartToolboxPro_GitHub.zip` এবং **একই রিলিজের** `build-apk.yml` ব্যবহার করুন।

1. `SmartToolboxPro_GitHub.zip` রিপোজিটরির মূল ফোল্ডারে আপলোড/Replace করুন।
2. `.github/workflows/build-apk.yml`-এ দেওয়া `build-apk.yml` আপলোড/Replace করুন।
3. GitHub-এ Commit করে **Actions → Build SR Smart Toolbox Pro APK → Run workflow** (অথবা নতুন Push-এ শুরু হওয়া Run) চালান।
4. সফল হলে `SR-Smart-Toolbox-Pro-debug-apk` Artifact থেকে APK নিন।

এক বিকল্প: `Smart-Toolbox-Pro-main.zip` আনজিপ করে **ভেতরের ফাইলগুলো** রিপোজিটরিতে আপলোড করুন। সম্পূর্ণ Outer ZIP একা আপলোড করবেন না।

Package Name অপরিবর্তিত `com.smarttoolbox.pro`; তাই সঠিক Signing Key মিললে আগের অ্যাপের ওপর আপডেট ইনস্টল হবে। GitHub Debug Key পূর্বের ইনস্টলের Key থেকে আলাদা হলে Android Update প্রত্যাখ্যান করতে পারে—সেক্ষেত্রে ডেটা ব্যাকআপ ছাড়া Uninstall করবেন না।

এখানে সম্পূর্ণ APK Build বা বাস্তব ফোনে Launcher Icon পরীক্ষা করা হয়নি।
