# SR Smart Toolbox Pro — Floating Tap / Swipe + 2-Second Move

**অ্যাপ ভার্সন:** `1.5.11-alpha37` · `versionCode 37`

## নতুন Floating Icon Settings
- **Enable Floating Quick Controls menu**: মেনুর মূল ON/OFF অপশন আগের মতো রাখা হয়েছে।
- **Tap to Open**: ট্যাপ করে Floating Controls খুলতে চাইলে ON করুন। আলাদাভাবে OFF করা যায়।
- **Swipe to Open**: Floating Icon বা Edge Bar-এর ওপর আঙুল স্লাইড করে মেনু খুলতে চাইলে ON করুন। আলাদাভাবে OFF করা যায়।
- আগের ব্যবহারকারীদের আচরণ পরিবর্তন না করতে প্রথমবার **দুটি অপশনই ON** থাকবে। দুটি OFF করলেও ২ সেকেন্ড ধরে আইকন/বার Move করা সম্ভব থাকবে, কিন্তু Tap/Swipe দিয়ে মেনু খুলবে না। Settings থেকে আবার চালু করা যাবে।

## আইকন ও Edge Bar মুভ করার একই নিয়ম
1. আইকন বা কিনারার ছোট Floating Bar-এ আঙুল রাখুন।
2. **২ সেকেন্ড একই জায়গায় চেপে ধরুন**। সামান্য অনিচ্ছাকৃত আঙুল নড়াচড়ার জন্য ১৪dp tolerance রাখা হয়েছে।
3. তারপর আঙুল টেনে স্থানান্তর করুন। আগে থেকেই Swipe শুরু করলে সেটি পরে ২ সেকেন্ডে Drag হয়ে যাবে না।
4. আঙুল ছাড়লে নতুন অবস্থান সংরক্ষিত হবে। বড় আইকন ফোনের স্ক্রিনে সরানো যাবে; ছোট Edge Bar-টি স্বাভাবিকভাবে নির্বাচিত বাম/ডান কিনারায় নতুন উচ্চতায় Dock হবে।
5. আগের **Portrait Edge (All Apps)** বা Auto-Hide চালু থাকলে সেগুলোর নিয়ম অনুযায়ী আইকন পরবর্তীতে কিনারায় ফিরে যেতে পারে।

## Open Gesture নিয়ম
- Tap ON + Swipe OFF: ছোট Tap-এ মেনু খুলবে, দ্রুত Slide-এ খুলবে না।
- Tap OFF + Swipe ON: Slide-এ খুলবে, Tap-এ খুলবে না।
- Tap ON + Swipe ON: দুটোতেই মেনু খুলবে।
- Tap OFF + Swipe OFF: দুটোতেই মেনু বন্ধ থাকবে, কিন্তু ২ সেকেন্ড Hold-to-Move কাজ করবে।
- বড় Floating Icon এবং Collapsed Edge Bar—উভয়ের জন্য একই নিয়ম।

## কী সংরক্ষিত আছে
আগের Night Screen (Minimum Brightness / Restore), Scheduler (Notepad, History, Group Message, Folder Inbox), Video Player, Portrait Edge, Volume Booster, Theme Settings, Floating Toolbox, App Branding ও অন্যান্য ফিচার রাখা হয়েছে।

## বাস্তব সীমাবদ্ধতা
এখানে পূর্ণ Android Gradle APK Build বা Android ডিভাইসে টাচ পরীক্ষা হয়নি। Overlay Permission ছাড়া Floating Icon কাজ করে না। Android-এর Gesture Navigation, Secure/Protected Screens বা OEM Restriction-এর কারণে কিছু অ্যাপে Overlay Gesture সীমিত হতে পারে।
